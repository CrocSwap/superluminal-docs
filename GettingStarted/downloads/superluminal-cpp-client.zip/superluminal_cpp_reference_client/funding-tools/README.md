# Superluminal Funding Tools

This directory is a self-contained source distribution of the account-funding
utilities. It runs on Linux, macOS, and Windows with Bun 1.3.14 or newer. No
private key leaves the local machine.

Install runtime dependencies:

```bash
bun install --production --frozen-lockfile
```

Fund testnet subaccount 0 from the public faucet:

```bash
bun run fund:testnet --keypair /path/to/wallet.json
```

Register and print the deposit address for a manual transfer:

```bash
bun run deposit:address --help
```

See `../docs/index.html` for the complete public documentation.
