import type { AccountClient } from "@aethon/client-account";
import { displayConnectError } from "@aethon/client-account/connectError";
import { displayRegisterDepositAddressError } from "@aethon/client-account/registerDepositAddressError";
import type { DepositClient } from "@aethon/client-deposit";
import { displayGetUserDepositAddressError } from "@aethon/client-deposit/getUserDepositAddressError";
import type { Address } from "@solana/kit";

type FundingAccountClient = Pick<
  AccountClient,
  | "close"
  | "connect"
  | "createRawAccountPositionsSubscription"
  | "registerUserDepositAddress"
>;

type FundingDepositClient = Pick<DepositClient, "getUserDepositAddress">;

export type TestnetFundingReceipt = Readonly<{
  collateralBalance: bigint;
  depositAddress: string;
  faucetTransactionHash: string;
  walletAddress: Address;
}>;

export type FundTestnetAccountOptions = Readonly<{
  accountClient: FundingAccountClient;
  depositClient: FundingDepositClient;
  faucetUrl: string;
  requestFaucet: (
    faucetUrl: string,
    depositAddress: string,
    walletAddress: Address,
  ) => Promise<string>;
  settlementTimeoutMs: number;
  subaccountId: bigint;
  walletAddress: Address;
}>;

type BalanceObserver = Readonly<{
  initialBalance: Promise<bigint>;
  waitForIncrease: () => Promise<bigint>;
}>;

const createBalanceObserver = (
  accountClient: FundingAccountClient,
  subaccountId: bigint,
): Readonly<{
  observer: BalanceObserver;
  subscribe: () => Promise<() => void>;
}> => {
  const initial = Promise.withResolvers<bigint>();
  let currentBalance: bigint | undefined;
  let pendingIncrease:
    | Readonly<{
        baseline: bigint;
        resolve: (balance: bigint) => void;
      }>
    | undefined;
  const onUpdate = ({ collateralBalance }: { collateralBalance: bigint }) => {
    if (currentBalance === undefined) {
      initial.resolve(collateralBalance);
    }
    currentBalance = collateralBalance;
    if (
      pendingIncrease !== undefined &&
      collateralBalance > pendingIncrease.baseline
    ) {
      const { resolve } = pendingIncrease;
      pendingIncrease = undefined;
      resolve(collateralBalance);
    }
  };
  const waitForIncrease = (): Promise<bigint> => {
    if (currentBalance === undefined) {
      throw new Error("initial trading balance has not been received");
    }
    if (pendingIncrease !== undefined) {
      throw new Error("a collateral increase waiter is already active");
    }
    const increased = Promise.withResolvers<bigint>();
    pendingIncrease = {
      baseline: currentBalance,
      resolve: increased.resolve,
    };
    return increased.promise;
  };
  return {
    observer: {
      initialBalance: initial.promise,
      waitForIncrease,
    },
    subscribe: () =>
      accountClient.createRawAccountPositionsSubscription(
        subaccountId,
        onUpdate,
      ),
  };
};

const withTimeout = <T>(
  promise: Promise<T>,
  timeoutMs: number,
  message: string,
): Promise<T> => {
  const timeout = Promise.withResolvers<T>();
  const timeoutId = setTimeout(() => {
    timeout.reject(new Error(message));
  }, timeoutMs);
  return Promise.race([promise, timeout.promise]).finally(() => {
    clearTimeout(timeoutId);
  });
};

const assertPublicFaucetSubaccount = (subaccountId: bigint) => {
  if (subaccountId !== 0n) {
    throw new Error("the public testnet faucet only funds subaccount 0");
  }
};

export const fundTestnetAccount = async ({
  accountClient,
  depositClient,
  faucetUrl,
  requestFaucet,
  settlementTimeoutMs,
  subaccountId,
  walletAddress,
}: FundTestnetAccountOptions): Promise<TestnetFundingReceipt> => {
  assertPublicFaucetSubaccount(subaccountId);
  try {
    const connection = await accountClient.connect();
    connection.match({
      Err: (error) => {
        throw new Error(
          `gateway connection failed: ${displayConnectError(error)}`,
        );
      },
      Ok: () => true,
    });

    const { observer, subscribe } = createBalanceObserver(
      accountClient,
      subaccountId,
    );
    const cancel = await subscribe();
    try {
      await withTimeout(
        observer.initialBalance,
        settlementTimeoutMs,
        "timed out waiting for the initial trading balance",
      );

      const registration =
        await accountClient.registerUserDepositAddress(subaccountId);
      registration.match({
        Err: (error) => {
          throw new Error(
            `deposit-address registration failed: ${displayRegisterDepositAddressError(error)}`,
          );
        },
        Ok: () => true,
      });

      const depositAddressResult = await depositClient.getUserDepositAddress(
        walletAddress,
        subaccountId,
      );
      const depositAddress = depositAddressResult.match({
        Err: (error) => {
          throw new Error(
            `deposit-address derivation failed: ${displayGetUserDepositAddressError(error)}`,
          );
        },
        Ok: (address) => address,
      });
      const increasedBalance = observer.waitForIncrease();
      const faucetTransactionHash = await requestFaucet(
        faucetUrl,
        depositAddress,
        walletAddress,
      );
      const collateralBalance = await withTimeout(
        increasedBalance,
        settlementTimeoutMs,
        `timed out waiting for UserCollateralUpdate after faucet transaction ${faucetTransactionHash}`,
      );

      return {
        collateralBalance,
        depositAddress,
        faucetTransactionHash,
        walletAddress,
      };
    } finally {
      cancel();
    }
  } finally {
    accountClient.close();
  }
};
