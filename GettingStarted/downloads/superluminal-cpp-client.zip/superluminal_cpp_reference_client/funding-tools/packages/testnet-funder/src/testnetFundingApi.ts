import type { Address } from "@solana/kit";
import { z } from "zod";
import { fetchEvmDeploymentMetadata } from "./evmDeploymentApi";

type Fetch = (input: string, init?: RequestInit) => Promise<Response>;

const transactionHashSchema = z.string().regex(/^0x[0-9a-fA-F]{64}$/);

const faucetResponseSchema = z.union([
  z.object({ hash: transactionHashSchema }),
  z.object({ error: z.string().min(1) }),
]);

const assertOk = (response: Response, label: string) => {
  if (!response.ok) {
    throw new Error(`${label} failed with HTTP ${response.status}`);
  }
};

export const fetchEvmGatewayAddress = async (
  gatewayHttpUrl: string,
  fetchFn: Fetch = fetch,
): Promise<string> =>
  (await fetchEvmDeploymentMetadata(gatewayHttpUrl, fetchFn)).gatewayAddress;

export const requestTestnetFaucet = async (
  faucetUrl: string,
  depositAddress: string,
  walletAddress: Address,
  fetchFn: Fetch = fetch,
): Promise<string> => {
  const response = await fetchFn(faucetUrl, {
    body: JSON.stringify({ depositAddress, walletAddress }),
    headers: { "content-type": "application/json" },
    method: "POST",
  });
  const body = faucetResponseSchema.parse(await response.json());
  if ("error" in body) {
    throw new Error(body.error);
  } else {
    assertOk(response, "testnet faucet request");
    return body.hash;
  }
};
