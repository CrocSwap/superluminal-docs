import type { AccountClient } from "@aethon/client-account";
import { createAccountClient as createDefaultAccountClient } from "@aethon/client-account";
import type { AuthSigner } from "@aethon/client-account/authSigner";
import type { DepositClient } from "@aethon/client-deposit";
import { createDepositClient as createDefaultDepositClient } from "@aethon/client-deposit";
import type { Address } from "@solana/kit";
import type {
  FundTestnetAccountOptions,
  TestnetFundingReceipt,
} from "./fundTestnetAccount";
import { fundTestnetAccount as fundDefaultTestnetAccount } from "./fundTestnetAccount";
import type { FundTestnetAccountCliArgs } from "./fundTestnetAccountCliArgs";
import { parseFundTestnetAccountCliArgs } from "./fundTestnetAccountCliArgs";
import { loadKeypairAuthSigner as loadDefaultKeypairAuthSigner } from "./keypairAuthSigner";
import {
  fetchEvmGatewayAddress as fetchDefaultEvmGatewayAddress,
  requestTestnetFaucet as requestDefaultTestnetFaucet,
} from "./testnetFundingApi";

export const FUND_TESTNET_ACCOUNT_USAGE = `Usage:
  bun run fund:testnet --keypair <wallet.json> [options]

Options:
  --gateway <wss-url>               Default: wss://testnet.slx.fi/ws
  --gateway-http <https-url>        Default: https://testnet.slx.fi
  --evm-rpc <https-url>             Default: https://sepolia-rollup.arbitrum.io/rpc
  --faucet <https-url>              Default: https://faucet.testnet.slx.fi/api/faucet
  --partition-id <u16>              Default: 1
  --settlement-timeout-ms <ms>      Default: 120000
  --help

The public faucet funds subaccount 0 only.`;

type AccountClientFactory = (options: {
  partitionId: number;
  signer: AuthSigner;
  websocketUrl: string;
}) => AccountClient;

type DepositClientFactory = (options: {
  evmGatewayAddress: string;
  evmRpcUrl: string;
}) => DepositClient;

type FundTestnetAccountCliDependencies = Readonly<{
  createAccountClient: AccountClientFactory;
  createDepositClient: DepositClientFactory;
  fetchEvmGatewayAddress: (gatewayHttpUrl: string) => Promise<string>;
  fundTestnetAccount: (
    options: FundTestnetAccountOptions,
  ) => Promise<TestnetFundingReceipt>;
  loadKeypairAuthSigner: (path: string) => Promise<AuthSigner>;
  requestTestnetFaucet: (
    faucetUrl: string,
    depositAddress: string,
    walletAddress: Address,
  ) => Promise<string>;
  writeLine: (line: string) => void;
}>;

const writeStdoutLine = (line: string) => {
  process.stdout.write(`${line}\n`);
};

const defaultDependencies: FundTestnetAccountCliDependencies = {
  createAccountClient: createDefaultAccountClient,
  createDepositClient: createDefaultDepositClient,
  fetchEvmGatewayAddress: fetchDefaultEvmGatewayAddress,
  fundTestnetAccount: fundDefaultTestnetAccount,
  loadKeypairAuthSigner: loadDefaultKeypairAuthSigner,
  requestTestnetFaucet: requestDefaultTestnetFaucet,
  writeLine: writeStdoutLine,
};

export const formatUsdcBalance = (rawBalance: bigint): string => {
  const sign = rawBalance < 0n ? "-" : "";
  const absoluteBalance = rawBalance < 0n ? -rawBalance : rawBalance;
  const whole = absoluteBalance / 1_000_000n;
  const fractional = absoluteBalance % 1_000_000n;
  const formattedWhole = new Intl.NumberFormat("en-US").format(whole);
  if (fractional === 0n) {
    return `${sign}${formattedWhole}`;
  } else {
    return `${sign}${formattedWhole}.${fractional.toString().padStart(6, "0")}`;
  }
};

const printReceipt = (
  receipt: TestnetFundingReceipt,
  writeLine: (line: string) => void,
) => {
  writeLine(`EVM deposit address: ${receipt.depositAddress}`);
  writeLine(`Faucet transaction:  ${receipt.faucetTransactionHash}`);
  writeLine(
    `Trading balance:     ${formatUsdcBalance(receipt.collateralBalance)} USDC`,
  );
  writeLine("Funding complete.");
};

const runFunding = async (
  args: Extract<FundTestnetAccountCliArgs, { kind: "fund" }>,
  dependencies: FundTestnetAccountCliDependencies,
) => {
  const signer = await dependencies.loadKeypairAuthSigner(args.keypairPath);
  dependencies.writeLine(`Fogo account:        ${signer.walletPublicKey}`);
  dependencies.writeLine("Subaccount:          0");
  const evmGatewayAddress = await dependencies.fetchEvmGatewayAddress(
    args.gatewayHttpUrl,
  );
  const accountClient = dependencies.createAccountClient({
    partitionId: args.partitionId,
    signer,
    websocketUrl: args.websocketUrl,
  });
  const depositClient = dependencies.createDepositClient({
    evmGatewayAddress,
    evmRpcUrl: args.evmRpcUrl,
  });
  const receipt = await dependencies.fundTestnetAccount({
    accountClient,
    depositClient,
    faucetUrl: args.faucetUrl,
    requestFaucet: dependencies.requestTestnetFaucet,
    settlementTimeoutMs: args.settlementTimeoutMs,
    subaccountId: 0n,
    walletAddress: signer.walletPublicKey,
  });
  printReceipt(receipt, dependencies.writeLine);
};

export const runFundTestnetAccountCli = async (
  argv: readonly string[],
  dependencies: FundTestnetAccountCliDependencies = defaultDependencies,
) => {
  const args = parseFundTestnetAccountCliArgs(argv);
  switch (args.kind) {
    case "help":
      dependencies.writeLine(FUND_TESTNET_ACCOUNT_USAGE);
      break;
    case "fund":
      await runFunding(args, dependencies);
      break;
  }
};

const errorMessage = (error: unknown): string =>
  error instanceof Error ? error.message : String(error);

if (import.meta.main) {
  runFundTestnetAccountCli(process.argv.slice(2)).catch((error: unknown) => {
    process.stderr.write(`Funding failed: ${errorMessage(error)}\n`);
    process.exitCode = 1;
  });
}
