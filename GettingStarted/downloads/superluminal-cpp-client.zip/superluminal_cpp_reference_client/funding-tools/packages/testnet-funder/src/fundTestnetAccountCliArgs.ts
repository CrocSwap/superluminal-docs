import { z } from "zod";

const DEFAULT_EVM_RPC_URL = "https://sepolia-rollup.arbitrum.io/rpc";
const DEFAULT_FAUCET_URL = "https://faucet.testnet.slx.fi/api/faucet";
const DEFAULT_GATEWAY_HTTP_URL = "https://testnet.slx.fi";
const DEFAULT_PARTITION_ID = 1;
const DEFAULT_SETTLEMENT_TIMEOUT_MS = 120_000;
const DEFAULT_WEBSOCKET_URL = "wss://testnet.slx.fi/ws";

const websocketUrlSchema = z
  .url()
  .refine((value) => value.startsWith("ws://") || value.startsWith("wss://"), {
    error: "--gateway must use ws:// or wss://",
  });
const httpUrlSchema = z
  .url()
  .refine(
    (value) => value.startsWith("http://") || value.startsWith("https://"),
    { error: "URL must use http:// or https://" },
  );
const unsignedIntegerSchema = z
  .string()
  .regex(/^\d+$/)
  .transform(Number)
  .pipe(z.int().nonnegative());

export type FundTestnetAccountCliArgs =
  | Readonly<{ kind: "help" }>
  | Readonly<{
      evmRpcUrl: string;
      faucetUrl: string;
      gatewayHttpUrl: string;
      keypairPath: string;
      kind: "fund";
      partitionId: number;
      settlementTimeoutMs: number;
      websocketUrl: string;
    }>;

type RawCliValues = Readonly<{
  evmRpcUrl?: string;
  faucetUrl?: string;
  gatewayHttpUrl?: string;
  keypairPath?: string;
  partitionId?: string;
  settlementTimeoutMs?: string;
  websocketUrl?: string;
}>;

const assertKnownArgument = (flag: string) => {
  const known = [
    "--evm-rpc",
    "--faucet",
    "--gateway",
    "--gateway-http",
    "--keypair",
    "--partition-id",
    "--settlement-timeout-ms",
  ].includes(flag);
  if (!known) {
    throw new Error(`unknown argument: ${flag}`);
  }
};

const assignArgument = (
  values: RawCliValues,
  flag: string,
  value: string,
): RawCliValues => {
  switch (flag) {
    case "--keypair":
      return { ...values, keypairPath: value };
    case "--gateway":
      return { ...values, websocketUrl: value };
    case "--gateway-http":
      return { ...values, gatewayHttpUrl: value };
    case "--evm-rpc":
      return { ...values, evmRpcUrl: value };
    case "--faucet":
      return { ...values, faucetUrl: value };
    case "--partition-id":
      return { ...values, partitionId: value };
    case "--settlement-timeout-ms":
      return { ...values, settlementTimeoutMs: value };
    default:
      throw new Error(`unknown argument: ${flag}`);
  }
};

const parseRawCliValues = (
  argv: readonly string[],
  index = 0,
  values: RawCliValues = {},
): RawCliValues => {
  const flag = argv[index];
  if (flag === undefined) {
    return values;
  } else {
    assertKnownArgument(flag);
    const value = argv[index + 1];
    if (value === undefined || value.startsWith("--")) {
      throw new Error(`${flag} requires a value`);
    } else {
      return parseRawCliValues(
        argv,
        index + 2,
        assignArgument(values, flag, value),
      );
    }
  }
};

export const parseFundTestnetAccountCliArgs = (
  argv: readonly string[],
): FundTestnetAccountCliArgs => {
  if (argv.includes("--help") || argv.includes("-h")) {
    return { kind: "help" };
  } else {
    const values = parseRawCliValues(argv);
    if (values.keypairPath === undefined) {
      throw new Error("--keypair is required");
    } else {
      return {
        evmRpcUrl: httpUrlSchema.parse(values.evmRpcUrl ?? DEFAULT_EVM_RPC_URL),
        faucetUrl: httpUrlSchema.parse(values.faucetUrl ?? DEFAULT_FAUCET_URL),
        gatewayHttpUrl: httpUrlSchema.parse(
          values.gatewayHttpUrl ?? DEFAULT_GATEWAY_HTTP_URL,
        ),
        keypairPath: z.string().min(1).parse(values.keypairPath),
        kind: "fund",
        partitionId: unsignedIntegerSchema
          .pipe(z.number().max(65_535))
          .parse(values.partitionId ?? String(DEFAULT_PARTITION_ID)),
        settlementTimeoutMs: unsignedIntegerSchema
          .pipe(z.number().positive())
          .parse(
            values.settlementTimeoutMs ?? String(DEFAULT_SETTLEMENT_TIMEOUT_MS),
          ),
        websocketUrl: websocketUrlSchema.parse(
          values.websocketUrl ?? DEFAULT_WEBSOCKET_URL,
        ),
      };
    }
  }
};
