import type { Order } from "./order";

export type OrderHistoryPage = {
  nextCursor: string | undefined;
  orders: Order[];
};
