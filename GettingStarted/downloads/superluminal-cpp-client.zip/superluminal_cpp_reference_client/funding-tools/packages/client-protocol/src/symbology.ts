import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import { z } from "zod";
import { SymbologyError } from "./symbologyError";

// Symbology: HTTP fetch + Zod schema for the `GET /v1/symbology` payload
// served alongside the WebSocket endpoint.  Used by `createLiveClient` to
// translate an internal symbology symbol ("BTC") into the numeric
// `symbol_id` the WebSocket protocol speaks.

const symbologyMarketSchema = z.object({
  id: z.number(),
  initial_margin_bps: z.number(),
  maintenance_margin_bps: z.number(),
  px_exponent: z.number(),
  // Quote currency this market is denominated against (e.g. "USDC").
  // Surfaced to the UI so the form's base/quote unit toggle doesn't have
  // to hardcode the dollar leg.
  quote: z.string(),
  size_decimals: z.number(),
  symbol: z.string(),
});

// Exchange-wide taker/maker fee rates in parts per million live at the top
// level of the symbology payload, alongside `markets` -- not inside each
// market record (the gateway treats fees as venue-wide, not per-symbol).
// Optional on the wire so older gateway builds still parse cleanly; absent
// rates default to 0 and surface as `0 ppm` fees through the FeeRates
// accessor.
const symbologySchema = z.object({
  maker_fee_ppm: z.number().int().default(0),
  markets: z.array(symbologyMarketSchema),
  taker_fee_ppm: z.number().int().default(0),
  version: z.number(),
});

export type Symbology = z.infer<typeof symbologySchema>;

export const fetchSymbology = async (
  httpBaseUrl: string,
  fetchFn: typeof fetch = fetch,
): Promise<Result<Symbology, SymbologyError>> => {
  try {
    const res = await fetchFn(`${httpBaseUrl}/v1/symbology`);
    if (res.ok) {
      const parsed = symbologySchema.safeParse(await res.json());
      if (parsed.success) {
        return Ok(parsed.data);
      } else {
        return Err(SymbologyError.Parse(parsed.error.message));
      }
    } else {
      return Err(SymbologyError.Network(res.status));
    }
  } catch (cause) {
    return Err(SymbologyError.Unexpected(cause));
  }
};
