// Reject-reason codes mirrored from the gateway's authoritative
// `OrderRejectReason` / `CancelRejectReason` / `ModifyRejectReason` enums in
// `dfba_common/dfba_event_log.h`. The wire schema for both the live stream and
// the persisted history page emits the reason as a raw `uint32`; the kind of
// the event determines which enum applies (`rejected` → order; `cancel_rejected`
// → cancel; `modify_rejected` → modify). The reason travels with the
// `OrderEvent` this package defines, so its typing lives here too.
//
// Keep these maps in sync with the C++ header; the gateway is the single source
// of truth, and adding a new variant there requires a matching entry here. A
// code with no entry is modelled as an explicit `Unknown` variant rather than
// silently coerced, so a newly-added gateway code surfaces as a distinct,
// handleable state instead of disappearing into a formatted string.

const ORDER_REJECT_REASONS: Record<number, string> = {
  1: "Missing Symbology",
  2: "Book Full",
  3: "Risk Rejected",
  4: "Account is not liquidating.",
  5: "Account is inactive/liquidating.",
  6: "Insufficient free collateral.",
};

const CANCEL_REJECT_REASONS: Record<number, string> = {
  1: "Unknown Order",
  2: "IOC Expired",
  3: "Missing Symbology",
  4: "Role Mismatch",
  5: "Order Expired",
};

const MODIFY_REJECT_REASONS: Record<number, string> = {
  1: "Unknown Order",
  2: "Role Mismatch",
  3: "IOC Not Modifiable",
  4: "Market Not Modifiable",
  5: "Invalid Qty",
  6: "Invalid Price",
  7: "Book Full",
  8: "Missing Symbology",
};

// Discriminant for `RejectReason`: the code either resolves to a named reason
// from the gateway's table (`Known`) or is one this build doesn't know
// (`Unknown`), carrying the raw code so the display leaf can still show it.
export enum RejectReasonKind {
  Known,
  Unknown,
}

export const RejectReason = {
  Known: (label: string) => ({
    kind: RejectReasonKind.Known as const,
    label,
  }),
  Unknown: (code: number) => ({
    code,
    kind: RejectReasonKind.Unknown as const,
  }),
};

export type RejectReason = ReturnType<
  (typeof RejectReason)[keyof typeof RejectReason]
>;

const classify = (
  table: Record<number, string>,
  code: number,
): RejectReason => {
  const label = table[code];
  return label === undefined
    ? RejectReason.Unknown(code)
    : RejectReason.Known(label);
};

export const orderRejectReason = (code: number): RejectReason =>
  classify(ORDER_REJECT_REASONS, code);

export const cancelRejectReason = (code: number): RejectReason =>
  classify(CANCEL_REJECT_REASONS, code);

export const modifyRejectReason = (code: number): RejectReason =>
  classify(MODIFY_REJECT_REASONS, code);

// Fold a `RejectReason` to the human string surfaced at the render leaf.
export const displayRejectReason = (reason: RejectReason): string => {
  switch (reason.kind) {
    case RejectReasonKind.Known:
      return reason.label;
    case RejectReasonKind.Unknown:
      return `Reason ${reason.code.toString()}`;
  }
};
