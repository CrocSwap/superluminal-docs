import type { Dnum } from "dnum";

export type OrderStatus =
  | "unfilled"
  | "partially_filled"
  | "filled"
  | "busted"
  | "cancelled"
  | "rejected";

// Per-order lifecycle event.  The gateway emits one of these on every
// transition the order goes through; the trading-app's per-order
// sub-table renders the full sequence so the user can audit what
// happened, when, and why.  The discriminant `kind` matches the wire
// `event_type` verbatim so a future codegen pass can collapse the two.
//
// `id` is the per-order monotonic event seq -- the wire's `stream_seq`
// for persisted events and the gateway's `seq` for live events; both
// refer to the same sequence space, so it's also the stable dedup key
// when merging the page-fetched history with the live overlay.
//
// `clientInstructionId` is the request id the submitting client put on
// the wire and is forwarded back on the event so a UI can correlate an
// outgoing intent (place/modify/cancel) with its sequencer outcome.
// It is `undefined` on events the matcher generates without a
// triggering client request (`filled`, `settled`, `busted`).
export type OrderEventBase = {
  id: bigint;
  timestamp: Date;
  clientInstructionId: bigint | undefined;
};

// Sequencer accepted the order at the given quantity. Limit orders carry their
// submitted price, protected market orders carry their reference price, and
// mark-to-mid orders have no fixed accepted price.
export type OrderAcceptedEvent = OrderEventBase & {
  kind: "accepted";
  price: Dnum | undefined;
  size: Dnum;
};

// Sequencer accepted a modify of the resting order.  `price` / `size`
// are the post-modify values; absent on the wire for partial modifies
// (e.g. a mark-to-mid that only carries `delta_ppm`).
export type OrderModifiedEvent = OrderEventBase & {
  kind: "modified";
  price: Dnum | undefined;
  size: Dnum | undefined;
  deltaPpm: number | undefined;
};

// Single fill leg.  `tradeId` is the matcher-assigned `trade_id`; absent
// only for in-flight fills the matcher hasn't yet stamped (which fall
// back to `id` for the React key in the UI).
export type OrderFilledEvent = OrderEventBase & {
  kind: "filled";
  price: Dnum;
  size: Dnum;
  tradeId: bigint | undefined;
};

// Sequencer-confirmed cancel of the resting order.
export type OrderCancelledEvent = OrderEventBase & {
  kind: "cancelled";
  reasonCode: number | undefined;
};

// Sequencer rejected the order at admission.
export type OrderRejectedEvent = OrderEventBase & {
  kind: "rejected";
  reasonCode: number | undefined;
};

// Settlement event for a previously-filled leg.  `settlementSeq` and
// `fee` are pinned by the settlement pipeline and are the user-visible
// facts that distinguish a settled fill from an unsettled one.  `fee`
// is a signed USDC amount (negative = rebate) carried as a Dnum so
// consumers can format it the same way as any other USDC value.
export type OrderSettledEvent = OrderEventBase & {
  kind: "settled";
  size: Dnum;
  fee: Dnum | undefined;
  settlementSeq: bigint | undefined;
};

// Reverse of a fill (e.g. a position bust the matcher unwound).  The
// `size` is the reversed quantity.
export type OrderBustedEvent = OrderEventBase & {
  errorCode?: number | undefined;
  errorMessage?: string | undefined;
  kind: "busted";
  size: Dnum;
};

// Sequencer rejected a cancel attempt against this order (e.g. order
// already terminal, role mismatch).
export type OrderCancelRejectedEvent = OrderEventBase & {
  kind: "cancel_rejected";
  reasonCode: number | undefined;
};

// Sequencer rejected a modify attempt against this order.
export type OrderModifyRejectedEvent = OrderEventBase & {
  kind: "modify_rejected";
  reasonCode: number | undefined;
};

export type OrderEvent =
  | OrderAcceptedEvent
  | OrderModifiedEvent
  | OrderFilledEvent
  | OrderCancelledEvent
  | OrderRejectedEvent
  | OrderSettledEvent
  | OrderBustedEvent
  | OrderCancelRejectedEvent
  | OrderModifyRejectedEvent;

export type OrderEventKind = OrderEvent["kind"];

export type OrderType = "limit" | "market" | "mark-to-mid" | "adl";
export type NormalOrderType = Exclude<OrderType, "adl">;

// A terminal automatic-deleveraging result persisted alongside a user's
// normal order history.  It deliberately has no external order id: the
// operation nonce identifies this non-order workflow and must never be sent
// to cancel or order-activity endpoints.
export type AdlHistory = {
  allocatedLoss: bigint;
  batchId: bigint;
  cleanupErrorCode: number;
  errorCode: number;
  failureStage: number;
  operationNonce: bigint;
  requestSeq: bigint;
  role: "target" | "counterparty";
  workflowErrorCode: number;
};

// `id` is the gateway's `external_order_id` (uint64), so a `bigint` is
// required to round-trip values above 2^53 without precision loss.  The
// trading-app uses it as a React key, where bigint is fine.
//
// `role` and `symbolId` exist so a consumer can issue a `cancelOrder`
// without re-resolving them from symbology -- the matcher rejects a
// cancel whose role doesn't match the live order role, so we carry the
// matcher-assigned role from `OrderAccepted` / `working_orders` /
// `order_history` through to the public surface.  Wire payloads where
// `role` is absent default to `"taker"` (the role the trading-app
// always submits as).
//
// `orderType` mirrors the matcher's per-order classification (limit /
// market / mark-to-mid). `deltaPpm` is the gateway-side parts-per-million
// value: mark-price delta for mark-to-mid and slippage for market orders;
// `undefined` on limit orders. For market orders, `price` retains the submitted
// reference price (zero for an unrestricted market order).
//
// `events` is the per-order lifecycle sequence in `id` (stream_seq)
// order, populated by the live order stream (post-mount transitions).
// The persisted history page no longer inlines events; the full
// pre-mount lifecycle is fetched on demand via `get_order_events`
// (see `OrderEventsPage`) and merged with this live overlay by id.
// Consumers that need just the fills can filter `e.kind === "filled"`;
// per-trade `direction` (open_long, etc.) and `realizedPnl` are
// intentionally absent: both depend on the position state at fill time,
// which can't be reconstructed from a paginated history without walking
// every fill the user has ever placed.
//
// `closedTimestamp` is when the order reached a terminal state (the
// gateway's `closed_unix_ns`); `undefined` while the order is still
// working.  It is the list's "Updated" time for terminal orders, which
// no longer carry inline lifecycle events to derive it from.
export type Order = {
  // The client-supplied identifier for the original order instruction.
  // Absent only on ADL outcomes, which are not user order instructions.
  clientInstructionId?: bigint | undefined;
  // Order-direction axis, matching `Position.side`.  `long` is a bid
  // (book buy), `short` an ask (book sell); a closing order reads back as
  // its book side (closing a long is an ask, so `side: "short"`).  The
  // wire's `BID`/`ASK` encoding stays trapped behind the read mapper.
  side: "long" | "short";
  filledSize: Dnum;
  id: bigint;
  deltaPpm: number | undefined;
  executionMode?: number | undefined;
  price: Dnum;
  role: "maker" | "taker";
  size: Dnum;
  status: OrderStatus;
  symbol: string;
  symbolId: number;
  timestamp: Date;
  closedTimestamp: Date | undefined;
  events: OrderEvent[];
  orderType: OrderType;
  adl?: AdlHistory;
};
