import type { Canceler } from "@aethon/client-protocol/canceler";
import { createConnectionStatusTracker } from "@aethon/client-protocol/connectionStatus";
import type { FundingHistoryPage } from "@aethon/client-protocol/fundingHistoryPage";
import type { Order } from "@aethon/client-protocol/order";
import type { OrderEventsPage } from "@aethon/client-protocol/orderEventsPage";
import type { OrderHistoryPage } from "@aethon/client-protocol/orderHistoryPage";
import { fetchSymbology } from "@aethon/client-protocol/symbology";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";
import type { SymbologyMarket } from "@aethon/client-protocol/symbologyMarket";
import { toSymbologyMarket } from "@aethon/client-protocol/symbologyMarket";
import type { VaultAccountPerfPage } from "@aethon/client-protocol/vaultAccountPerfPage";
import type { VaultAccountsPage } from "@aethon/client-protocol/vaultAccountsPage";
import { wsUrlToHttpUrl } from "@aethon/client-protocol/wsUrl";
import { Err, Ok, Result } from "@cprussin/option-result";
import { getAddressEncoder } from "@solana/kit";
import type { AccountClient, GetOrderHistoryOptions } from "./accountClient";
import { createAccountState } from "./accountState/accountState";
import type { RawAccountPositions } from "./accountState/rawAccountPositions";
import { CancelOrderError } from "./cancelOrderError";
import { ConnectError } from "./connectError";
import { toFundingHistoryPage } from "./funding/fundingHistoryMapping";
import { GetFundingHistoryError } from "./getFundingHistoryError";
import { GetOrderEventsError } from "./getOrderEventsError";
import { GetOrderHistoryError } from "./getOrderHistoryError";
import { GetVaultAccountPerfError } from "./getVaultAccountPerfError";
import { GetVaultAccountsError } from "./getVaultAccountsError";
import { orderHistoryQueryValidationReason } from "./orderHistoryQueryValidation";
import { toOrderEventsPage } from "./orders/orderEventsMapping";
import { toOrderHistoryPage } from "./orders/orderHistoryMapping";
import { createOrderState } from "./orders/orderState";
import { createAuthSession } from "./session/authSession";
import type { AuthSigner } from "./session/authSigner";
import { commandAckRejectReason } from "./session/awaitResolution";
import type { SessionEndEvent } from "./session/sessionEnd";
import { cancelOrder } from "./signing/cancelOrder";
import { generateClientRequestId64 } from "./signing/clientRequestId";
import { registerUserDepositAddress } from "./signing/registerUserDepositAddress";
import type { SignedCommandContext } from "./signing/signedCommand";
import { submitOrder } from "./signing/submitOrder";
import { submitVaultDeposit } from "./signing/submitVaultDeposit";
import { submitVaultWithdraw } from "./signing/submitVaultWithdraw";
import { submitWithdraw } from "./signing/submitWithdraw";
import { SubmitOrderError } from "./submitOrderError";
import type { VaultOperationStatus } from "./vaultOperationStatus";
import { toVaultOperationStatus } from "./vaultOperationStatus";
import { toVaultAccountPerfPage } from "./vaults/vaultAccountPerfMapping";
import { toVaultAccountsPage } from "./vaults/vaultAccountsMapping";
import {
  applyVaultStatusToShares,
  vaultSharesFromSnapshot,
} from "./vaults/vaultShares";
import { classifyAccountFrame } from "./wire/accountFrame";
import type { WireMarket } from "./wire/encodeOrderWire";
import { encodeOrderWire, toWireOrder } from "./wire/encodeOrderWire";
import { tryParseJson } from "./wire/tryParseJson";
import type { WithdrawStatus } from "./withdrawStatus";
import { toWithdrawStatus } from "./withdrawStatus";

// Gateway-deployment-configured signed-proof partition.  Every signed
// command (order, withdraw, cancel, ...) must carry the gateway's expected
// partition id or admission rejects it.  See
// `dfba_gateway/gateway_config.go:45` for the server-side knob and
// `apps/superluminal/src/config.ts` for the env-var threading.
//
// `nowSeconds` and `generateRequestId` are injectable so tests can pin
// `iat` and `request_id_64` to fixed values and assert against a
// deterministic signed_order frame.  Production callers leave them
// unset and get `Date.now() / 1000` plus `generateClientRequestId64`
// from `crypto.getRandomValues`.
export type LiveAccountClientOptions = {
  websocketUrl: string;
  signer: AuthSigner;
  partitionId: number;
  createWebSocket?: ((url: string) => WebSocket) | undefined;
  fetch?: typeof fetch | undefined;
  nowSeconds?: (() => bigint) | undefined;
  generateRequestId?: (() => bigint) | undefined;
  // How long to wait for a rejection ack before treating the gateway's
  // silence as "queued by gateway / proceeded to sequencer".  The gateway
  // only acks signed_withdraw on rejection or busy
  // (`dfba_gateway/signed_message_handlers.go:682-703`), so a happy-path
  // submission yields no ack -- the eventual collateral debit arrives
  // later as a `UserCollateralUpdate`.  Default 1500ms covers a wide
  // network RTT plus the gateway's fast-path policy checks.
  withdrawAckGraceMs?: number | undefined;
};

const DEFAULT_WITHDRAW_ACK_GRACE_MS = 1500;

// Upper bound on how long the order-history request waits for its reply before
// surfacing a timeout. 10s absorbs a slow gateway round-trip; a gateway-level
// rejection (rare, operator-actionable) surfaces as this timeout rather than a
// specific reason.
const ORDER_HISTORY_TIMEOUT_MS = 10_000;

// Same bound for funding history: a slow gateway round-trip is absorbed and a
// gateway-level rejection surfaces as this timeout if no reject ack arrives.
const FUNDING_HISTORY_TIMEOUT_MS = 10_000;

// Same bound for the per-order events fetch backing the widget's activity panel.
const ORDER_EVENTS_TIMEOUT_MS = 10_000;

// Same bound for the `get_vault_accounts` round-trip.
const VAULT_ACCOUNTS_TIMEOUT_MS = 10_000;

const VAULT_ACCOUNT_PERF_TIMEOUT_MS = 10_000;

// Request the largest page the gateway allows (it clamps to
// `orderHistoryFetchLimitMax`) so a single fetch covers the whole selectable
// window.  At the deployed ~daily perf cadence one 100-row page spans ~100
// days, which fully covers the 7D / 30D / 90D windows the vaults UI offers, so
// the hook never has to paginate to draw a sparkline.
const VAULT_ACCOUNT_PERF_PAGE_LIMIT = 100;

// Seconds-since-epoch for the signed-message `iat`.  `Date.now()` is ms;
// the wire format and SVM handler (`contracts/svm/src/lib.rs:1186-1200`)
// both treat the field as Unix seconds.
const defaultNowSeconds = (): bigint => BigInt(Math.floor(Date.now() / 1000));

// Empty payload handed to a subscriber when the authoritative snapshot
// doesn't mention their subaccountId.  Without this the widget would hang
// in its loading state for a freshly-onboarded wallet that has no
// collateral or positions yet.
const EMPTY_RAW: RawAccountPositions = {
  collateralBalance: 0n,
  positions: [],
};

// Live account client.  Owns a single authenticated WS session, fetches
// symbology once for the per-market scaling decimals the state machine
// needs to apply incremental fills, then forwards every account-stream
// message to a shared `AccountState`.  Each subscription registers an
// `onUpdate` callback bucketed by `subaccountId`; the state machine's
// `apply` result tells us which subaccounts changed so we can route
// notifications without re-emitting to unrelated subscribers.
export const createLiveAccountClient = (
  options: LiveAccountClientOptions,
): AccountClient => {
  const connectionStatusTracker = createConnectionStatusTracker();
  const sessionEndSubscribers = new Set<(event: SessionEndEvent) => void>();
  const session = createAuthSession({
    ...options,
    connectionStatus: connectionStatusTracker.register(),
    onSessionEnd: (event) => {
      for (const onEvent of sessionEndSubscribers) {
        onEvent(event);
      }
    },
  });

  type Subscribers = Set<(positions: RawAccountPositions) => void>;
  const subscribersBySubaccountId = new Map<bigint, Subscribers>();
  type WithdrawStatusSubscribers = Set<(status: WithdrawStatus) => void>;
  const withdrawStatusSubscribersBySubaccountId = new Map<
    bigint,
    WithdrawStatusSubscribers
  >();
  type VaultOperationStatusSubscribers = Set<
    (status: VaultOperationStatus) => void
  >;
  const vaultOperationStatusSubscribersBySubaccountId = new Map<
    bigint,
    VaultOperationStatusSubscribers
  >();
  // Vault share holdings (vaultAccountPubkey -> shares) from the latest
  // snapshot, plus the subscribers replayed on each snapshot.  Seeded empty so
  // a late subscriber before the first snapshot gets an empty map.
  const vaultPositionsSubscribers = new Set<
    (shares: ReadonlyMap<string, bigint>) => void
  >();
  let latestVaultShares: ReadonlyMap<string, bigint> = new Map();
  // The per-symbol market records, parsed once at init from the symbology
  // fetch.  The order/funding wire decoders and the state machines read the
  // decimals, symbol name, and wire-scaling envelope they each need off this
  // one record (each of those consumer shapes is a structural subset of
  // `SymbologyMarket`), so there is no parallel cache to keep in sync.
  const marketsBySymbolId = new Map<number, SymbologyMarket>();
  // Name -> symbol id index over `marketsBySymbolId`, keyed by the upper-cased
  // market name so `submitOrder` / `cancelOrder` can resolve the
  // human-entered symbol the same way `client-public`'s `getMarketBySymbol`
  // does.  Populated once at init from the same symbology fetch.
  const symbolIdByName = new Map<string, number>();
  // In-flight `get_order_history` requests keyed by `request_id`.  The
  // socket message handler routes matching `order_history` events (the
  // gateway's request_id-correlated success response) back to the awaiting
  // resolver.  `getOrderHistory` races that success channel against the
  // gateway's uncorrelated `ack rejected` (for failure modes like
  // `order_history_unavailable`), a socket close, and a request-scoped timeout.
  const pendingOrderHistoryRequests = new Map<
    string,
    (page: OrderHistoryPage) => void
  >();
  // In-flight `get_funding_history` requests keyed by `request_id`.  Mirrors
  // `pendingOrderHistoryRequests`: the socket message handler routes matching
  // `funding_history` events back to the awaiting resolver, which
  // `getFundingHistory` races against the gateway's uncorrelated `ack
  // rejected`, a socket close, and a request-scoped timeout.
  const pendingFundingHistoryRequests = new Map<
    string,
    (page: FundingHistoryPage) => void
  >();
  // In-flight `get_order_events` requests keyed by `request_id`.  Mirrors the
  // history/funding pending maps: the socket message handler routes matching
  // `order_events` events back to the awaiting resolver, which `getOrderEvents`
  // races against the gateway's uncorrelated `ack rejected`, a socket close,
  // and a request-scoped timeout.
  const pendingOrderEventsRequests = new Map<
    string,
    (page: OrderEventsPage) => void
  >();
  // In-flight `get_vault_accounts` requests keyed by `request_id`, resolved by
  // the correlated `vault_accounts` event the same way order history is (see
  // `pendingOrderHistoryRequests`).
  const pendingVaultAccountsRequests = new Map<
    string,
    (page: VaultAccountsPage) => void
  >();
  // In-flight `get_vault_account_perf` requests keyed by `request_id`, resolved
  // by the correlated `vault_account_perf` event the same way vault accounts is
  // (see `pendingVaultAccountsRequests`).
  const pendingVaultAccountPerfRequests = new Map<
    string,
    (page: VaultAccountPerfPage) => void
  >();

  const state = createAccountState({
    getMarketDecimals: (symbolId) => marketsBySymbolId.get(symbolId),
  });

  // Separate state machine for the orders list (working orders from the
  // bootstrap snapshot + live `OrderAccepted` / `Fill` / `CancelAck` /
  // `ModifyAck` / `OrderReject` events).  Each apply returns the set of
  // order ids that changed; `notifyOrder` fans those out to per-subscriber
  // callbacks.
  const orderState = createOrderState({
    getMarketInfo: (symbolId) => marketsBySymbolId.get(symbolId),
  });

  const orderUpdateSubscribers = new Set<(order: Order) => void>();

  const notify = (subaccountId: bigint, raw: RawAccountPositions) => {
    const subscribers = subscribersBySubaccountId.get(subaccountId);
    if (subscribers !== undefined) {
      for (const onUpdate of subscribers) {
        onUpdate(raw);
      }
    }
  };

  const notifyOrder = (order: Order) => {
    for (const onUpdate of orderUpdateSubscribers) {
      onUpdate(order);
    }
  };

  // Flipped once the gateway's first `AccountSnapshot` has been applied.
  // Late subscribers (registered after the snapshot arrived) use this to
  // know whether to emit immediately or wait for the snapshot fan-out.
  let snapshotReceived = false;

  const handleMessage = (event: MessageEvent<unknown>) => {
    if (typeof event.data === "string") {
      tryParseJson(event.data).match({
        None: () => {
          // Non-JSON frames ride the same socket but aren't account frames;
          // not ours to handle.
        },
        Some: (parsed) => {
          const frame = classifyAccountFrame(parsed);
          switch (frame.kind) {
            case "orderHistory": {
              // Correlated by `request_id` -- resolve the pending
              // `getOrderHistory` waiting on it (if any).
              const requestId = frame.data.request_id;
              if (requestId !== undefined) {
                const resolver = pendingOrderHistoryRequests.get(requestId);
                if (resolver !== undefined) {
                  pendingOrderHistoryRequests.delete(requestId);
                  resolver(toOrderHistoryPage(frame.data, marketsBySymbolId));
                }
              }
              break;
            }
            case "orderEvents": {
              // Correlated by `request_id` -- resolve the pending
              // `getOrderEvents` waiting on it (if any).
              const requestId = frame.data.request_id;
              if (requestId !== undefined) {
                const resolver = pendingOrderEventsRequests.get(requestId);
                if (resolver !== undefined) {
                  pendingOrderEventsRequests.delete(requestId);
                  resolver(toOrderEventsPage(frame.data, marketsBySymbolId));
                }
              }
              break;
            }
            case "fundingHistory": {
              // Correlated by `request_id` -- resolve the pending
              // `getFundingHistory` waiting on it (if any).
              const requestId = frame.data.request_id;
              if (requestId !== undefined) {
                const resolver = pendingFundingHistoryRequests.get(requestId);
                if (resolver !== undefined) {
                  pendingFundingHistoryRequests.delete(requestId);
                  resolver(toFundingHistoryPage(frame.data, marketsBySymbolId));
                }
              }
              break;
            }
            case "vaultAccounts": {
              // Correlated by `request_id` -- resolve the pending
              // `getVaultAccounts` waiting on it (if any).
              const requestId = frame.data.request_id;
              if (requestId !== undefined) {
                const resolver = pendingVaultAccountsRequests.get(requestId);
                if (resolver !== undefined) {
                  pendingVaultAccountsRequests.delete(requestId);
                  resolver(toVaultAccountsPage(frame.data));
                }
              }
              break;
            }
            case "vaultAccountPerf": {
              // Correlated by `request_id` -- resolve the pending
              // `getVaultAccountPerf` waiting on it (if any).
              const requestId = frame.data.request_id;
              if (requestId !== undefined) {
                const resolver = pendingVaultAccountPerfRequests.get(requestId);
                if (resolver !== undefined) {
                  pendingVaultAccountPerfRequests.delete(requestId);
                  resolver(toVaultAccountPerfPage(frame.data));
                }
              }
              break;
            }
            case "accountStream": {
              const message = frame.data;
              const changed = state.apply(message);
              if (message.type === "AccountSnapshot") {
                // The snapshot is authoritative for the user's whole account.
                // Every subscriber gets either their slice of the snapshot or
                // the empty payload -- the latter unblocks the loading state
                // for a wallet that hasn't created the requested subaccount yet.
                snapshotReceived = true;
                for (const subaccountId of subscribersBySubaccountId.keys()) {
                  notify(subaccountId, state.getRaw(subaccountId) ?? EMPTY_RAW);
                }
                // Vault holdings ride the same snapshot; recompute and fan out.
                latestVaultShares = vaultSharesFromSnapshot(
                  message.vault_participant_accounts,
                );
                for (const onUpdate of vaultPositionsSubscribers) {
                  onUpdate(latestVaultShares);
                }
              } else {
                for (const subaccountId of changed) {
                  const raw = state.getRaw(subaccountId);
                  if (raw !== undefined) {
                    notify(subaccountId, raw);
                  }
                }
              }
              // The order state machine is a parallel consumer: snapshot
              // working_orders + every lifecycle event flow through it.  Any
              // order ids it reports as touched fan out to every order-update
              // subscriber.
              const orderChanges = orderState.apply(message);
              for (const orderId of orderChanges) {
                const order = orderState.get(orderId);
                if (order !== undefined) {
                  notifyOrder(order);
                }
              }
              if (message.type === "WithdrawStatus") {
                // `WithdrawStatus` doubles as the collateral debit (handled by
                // the state machine above) and the consumer-facing settlement
                // event the trading-app uses to update its "Withdraw queued"
                // toast.  Fan out after the balance has been applied so a UI
                // re-reading balance in the callback sees the post-debit value.
                const subscribers = withdrawStatusSubscribersBySubaccountId.get(
                  message.subaccount_id,
                );
                if (subscribers !== undefined) {
                  const status = toWithdrawStatus(message);
                  for (const onStatus of subscribers) {
                    onStatus(status);
                  }
                }
              }
              if (
                message.type === "DepositVault" ||
                message.type === "DepositVaultStatus" ||
                message.type === "WithdrawVault" ||
                message.type === "WithdrawVaultStatus"
              ) {
                // A rejected vault operation or settlement outcome. The proof was
                // processed off-chain; this is the async result the trading-app
                // surfaces (notably a failure dialog). Fanned out to per-subaccount
                // subscribers, matching `WithdrawStatus`.
                const subscribers =
                  vaultOperationStatusSubscribersBySubaccountId.get(
                    message.subaccount_id,
                  );
                if (subscribers !== undefined) {
                  const status = toVaultOperationStatus(message);
                  for (const onStatus of subscribers) {
                    onStatus(status);
                  }
                }
                // A successful settlement is authoritative for the wallet's share
                // holding in that vault ahead of the next snapshot; apply the
                // delta and re-emit so the "your position" column + withdraw gate
                // update live (mirrors the `WithdrawStatus` collateral debit).
                const nextShares = applyVaultStatusToShares(
                  latestVaultShares,
                  message,
                );
                if (nextShares !== latestVaultShares) {
                  latestVaultShares = nextShares;
                  for (const onUpdate of vaultPositionsSubscribers) {
                    onUpdate(latestVaultShares);
                  }
                }
              }
              break;
            }
            case "malformedKnown": {
              // A known discriminant whose body failed validation is a real bug.
              // biome-ignore lint/suspicious/noConsole: surface malformed known-type payload
              console.error(
                "[account WS] malformed payload for known type",
                frame.type,
                frame.error,
              );
              break;
            }
            case "ignored": {
              // Non-account frames (`pong`, gateway acks, ...) ride the same
              // socket but aren't ours to handle.
              break;
            }
          }
        },
      });
    }
  };

  // Auth + symbology bootstrap, cached per authenticated socket. Resolves
  // `Ok(true)` once symbology is cached and `subscribe_account` is sent, or
  // `Err(SymbologyError)` when the symbology fetch fails -- threaded (not
  // thrown) so every caller lifts it into its own typed error rather than a
  // rejection. The auth handshake still rejects the promise on failure (an
  // infra failure the callers map to their `Disconnected` variant).
  let initPromise: Promise<Result<true, SymbologyError>> | undefined;
  const ensureInitialized = (): Promise<Result<true, SymbologyError>> => {
    if (initPromise === undefined) {
      initPromise = (async () => {
        const [ws, symbologyResult] = await Promise.all([
          session.ensureAuthenticated(),
          fetchSymbology(
            wsUrlToHttpUrl(options.websocketUrl),
            options.fetch ?? fetch,
          ),
        ]);
        return symbologyResult.map((symbology) => {
          for (const wireMarket of symbology.markets) {
            const market = toSymbologyMarket(wireMarket);
            marketsBySymbolId.set(market.symbolId, market);
            symbolIdByName.set(market.symbol.toUpperCase(), market.symbolId);
          }
          // The message listener must be installed before `subscribe_account`
          // so we don't drop the snapshot the gateway sends in response.
          ws.addEventListener("message", handleMessage);
          // Couple the init cache to *this* socket: when it closes (gateway
          // teardown, user `disconnect`, or any unexpected drop) the cached
          // promise is no longer valid; the next `ensureInitialized` must
          // re-handshake and re-`subscribe_account`.
          ws.addEventListener("close", () => {
            initPromise = undefined;
          });
          ws.send(JSON.stringify({ type: "subscribe_account" }));
          return true as const;
        });
      })();
    }
    return initPromise;
  };

  // Subscriptions surface init failure as a promise rejection (the
  // connection-status indicator reports the broken session and the subscriber
  // gets no replay). `ensureInitialized` threads a symbology fetch failure as
  // `Err`, so re-throw it here to keep the reject-on-init-failure contract the
  // account subscriptions rely on; an auth handshake failure already rejects.
  const ensureInitializedOrThrow = async (): Promise<void> => {
    (await ensureInitialized()).unwrapOrElse((error) => {
      throw new Error(`symbology unavailable: ${displaySymbologyError(error)}`);
    });
  };

  const nowSeconds = options.nowSeconds ?? defaultNowSeconds;
  const generateRequestId =
    options.generateRequestId ?? generateClientRequestId64;
  const senderPubkey = new Uint8Array(
    getAddressEncoder().encode(options.signer.walletPublicKey),
  );

  // Shared collaborators for the signed-command builders in `./signing/*`.
  const signedCommandContext: SignedCommandContext = {
    ensureAuthenticated: session.ensureAuthenticated,
    generateRequestId,
    nowSeconds,
    partitionId: options.partitionId,
    senderPubkey,
    signer: options.signer,
  };

  // Source for the per-request correlation id sent on the wire as
  // `request_id`.  Injectable via the same `generateRequestId` knob the
  // signed-order path uses; tests can pin it for deterministic frames.
  const nextHistoryRequestId = (): string => generateRequestId().toString(16);

  const getOrderHistory = (
    optionsOrCursor?: GetOrderHistoryOptions | string | undefined,
  ): Promise<Result<OrderHistoryPage, GetOrderHistoryError>> => {
    const options =
      typeof optionsOrCursor === "string"
        ? { cursor: optionsOrCursor }
        : optionsOrCursor;
    const validationReason = orderHistoryQueryValidationReason(options);
    if (validationReason === undefined) {
      return Result.wrapAsync(session.ensureAuthenticated()).then(
        (sessionResult) =>
          sessionResult
            .mapErr(
              (): GetOrderHistoryError => GetOrderHistoryError.Disconnected(),
            )
            .andThenAsync(async (socket) => {
              // Symbology must be loaded before we can scale the response; wait for
              // the same init the account stream uses and thread its failure up as
              // the wrapped `Symbology` error.
              const initResult = await ensureInitialized();
              return initResult
                .mapErr(
                  (error): GetOrderHistoryError =>
                    GetOrderHistoryError.Symbology(error),
                )
                .andThenAsync(async () => {
                  const requestId = nextHistoryRequestId();
                  // The gateway emits `order_history` before its `ack accepted`
                  // on success, and `ack rejected` on failure.  Both success
                  // events and modern reject ACKs carry `request_id`; legacy
                  // reject ACKs do not.  Race the correlated success event against
                  // a matching-or-legacy rejected ACK so failures surface
                  // immediately without cross-failing another in-flight page.
                  // Socket close and the timeout remain as backstops.
                  const result = await new Promise<
                    Result<OrderHistoryPage, GetOrderHistoryError>
                  >((resolve) => {
                    let settled = false;
                    const finish = (
                      outcome: Result<OrderHistoryPage, GetOrderHistoryError>,
                    ) => {
                      if (!settled) {
                        settled = true;
                        pendingOrderHistoryRequests.delete(requestId);
                        socket.removeEventListener("close", onClose);
                        socket.removeEventListener("message", onReject);
                        clearTimeout(timeoutHandle);
                        resolve(outcome);
                      }
                    };
                    const onClose = () => {
                      finish(Err(GetOrderHistoryError.Disconnected()));
                    };
                    const onReject = (event: MessageEvent<unknown>) => {
                      const reason = commandAckRejectReason(
                        tryParseJson(String(event.data)),
                        requestId,
                      );
                      if (reason !== undefined) {
                        finish(Err(GetOrderHistoryError.Rejected(reason)));
                      }
                    };
                    const timeoutHandle = setTimeout(() => {
                      finish(Err(GetOrderHistoryError.Timeout()));
                    }, ORDER_HISTORY_TIMEOUT_MS);
                    pendingOrderHistoryRequests.set(requestId, (page) => {
                      finish(Ok(page));
                    });
                    socket.addEventListener("close", onClose);
                    socket.addEventListener("message", onReject);
                    socket.send(
                      JSON.stringify({
                        created_from_unix_s: options?.createdFromUnixS,
                        created_to_unix_s: options?.createdToUnixS,
                        cursor: options?.cursor ?? "",
                        request_id: requestId,
                        type: "get_order_history",
                      }),
                    );
                  });
                  return result;
                });
            }),
      );
    } else {
      return Promise.resolve(
        Err(GetOrderHistoryError.Rejected(validationReason)),
      );
    }
  };

  const getVaultAccounts = (
    cursor?: string | undefined,
  ): Promise<Result<VaultAccountsPage, GetVaultAccountsError>> =>
    Result.wrapAsync(session.ensureAuthenticated()).then((sessionResult) =>
      sessionResult
        .mapErr(
          (): GetVaultAccountsError => GetVaultAccountsError.Disconnected(),
        )
        .andThenAsync(async (socket) => {
          // The vault mapping needs no symbology, but `ensureInitialized` is
          // what installs the message listener that routes the correlated
          // `vault_accounts` event, so an init failure is threaded up the same
          // way `getOrderHistory` does.
          const initResult = await ensureInitialized();
          return initResult
            .mapErr(
              (error): GetVaultAccountsError =>
                GetVaultAccountsError.Symbology(error),
            )
            .andThenAsync(async () => {
              const requestId = nextHistoryRequestId();
              // Same race as `getOrderHistory`: the `vault_accounts` event
              // (carrying `request_id`) resolves success, the next uncorrelated
              // `ack rejected` surfaces a gateway rejection immediately, and
              // socket close / timeout are the backstops.
              const result = await new Promise<
                Result<VaultAccountsPage, GetVaultAccountsError>
              >((resolve) => {
                let settled = false;
                const finish = (
                  outcome: Result<VaultAccountsPage, GetVaultAccountsError>,
                ) => {
                  if (!settled) {
                    settled = true;
                    pendingVaultAccountsRequests.delete(requestId);
                    socket.removeEventListener("close", onClose);
                    socket.removeEventListener("message", onReject);
                    clearTimeout(timeoutHandle);
                    resolve(outcome);
                  }
                };
                const onClose = () => {
                  finish(Err(GetVaultAccountsError.Disconnected()));
                };
                const onReject = (event: MessageEvent<unknown>) => {
                  const reason = commandAckRejectReason(
                    tryParseJson(String(event.data)),
                  );
                  if (reason !== undefined) {
                    finish(Err(GetVaultAccountsError.Rejected(reason)));
                  }
                };
                const timeoutHandle = setTimeout(() => {
                  finish(Err(GetVaultAccountsError.Timeout()));
                }, VAULT_ACCOUNTS_TIMEOUT_MS);
                pendingVaultAccountsRequests.set(requestId, (page) => {
                  finish(Ok(page));
                });
                socket.addEventListener("close", onClose);
                socket.addEventListener("message", onReject);
                socket.send(
                  JSON.stringify({
                    cursor: cursor ?? "",
                    request_id: requestId,
                    type: "get_vault_accounts",
                  }),
                );
              });
              return result;
            });
        }),
    );

  // Mirrors `getVaultAccounts` for the per-vault performance-history endpoint:
  // waits on the shared init (which installs the message listener routing the
  // correlated `vault_account_perf` event), sends `get_vault_account_perf` for
  // one vault at the max page size, and races the `request_id`-correlated
  // success event against a matching-or-legacy rejected ACK, a socket close,
  // and a request-scoped timeout.
  const getVaultAccountPerf = (
    vaultAccount: string,
    cursor?: string | undefined,
  ): Promise<Result<VaultAccountPerfPage, GetVaultAccountPerfError>> =>
    Result.wrapAsync(session.ensureAuthenticated()).then((sessionResult) =>
      sessionResult
        .mapErr(
          (): GetVaultAccountPerfError =>
            GetVaultAccountPerfError.Disconnected(),
        )
        .andThenAsync(async (socket) => {
          const initResult = await ensureInitialized();
          return initResult
            .mapErr(
              (error): GetVaultAccountPerfError =>
                GetVaultAccountPerfError.Symbology(error),
            )
            .andThenAsync(async () => {
              const requestId = nextHistoryRequestId();
              const result = await new Promise<
                Result<VaultAccountPerfPage, GetVaultAccountPerfError>
              >((resolve) => {
                let settled = false;
                const finish = (
                  outcome: Result<
                    VaultAccountPerfPage,
                    GetVaultAccountPerfError
                  >,
                ) => {
                  if (!settled) {
                    settled = true;
                    pendingVaultAccountPerfRequests.delete(requestId);
                    socket.removeEventListener("close", onClose);
                    socket.removeEventListener("message", onReject);
                    clearTimeout(timeoutHandle);
                    resolve(outcome);
                  }
                };
                const onClose = () => {
                  finish(Err(GetVaultAccountPerfError.Disconnected()));
                };
                const onReject = (event: MessageEvent<unknown>) => {
                  const reason = commandAckRejectReason(
                    tryParseJson(String(event.data)),
                    requestId,
                  );
                  if (reason !== undefined) {
                    finish(Err(GetVaultAccountPerfError.Rejected(reason)));
                  }
                };
                const timeoutHandle = setTimeout(() => {
                  finish(Err(GetVaultAccountPerfError.Timeout()));
                }, VAULT_ACCOUNT_PERF_TIMEOUT_MS);
                pendingVaultAccountPerfRequests.set(requestId, (page) => {
                  finish(Ok(page));
                });
                socket.addEventListener("close", onClose);
                socket.addEventListener("message", onReject);
                socket.send(
                  JSON.stringify({
                    cursor: cursor ?? "",
                    limit: VAULT_ACCOUNT_PERF_PAGE_LIMIT,
                    request_id: requestId,
                    type: "get_vault_account_perf",
                    vault_account: vaultAccount,
                  }),
                );
              });
              return result;
            });
        }),
    );

  // Mirrors `getOrderHistory` for the funding-history endpoint: waits for
  // symbology (so `market_id` can be resolved to a symbol name), sends
  // `get_funding_history`, and races the `request_id`-correlated
  // `funding_history` success event against a matching-or-legacy rejected
  // `ack`, a socket close, and a request-scoped timeout.
  const getFundingHistory = (
    cursor?: string | undefined,
  ): Promise<Result<FundingHistoryPage, GetFundingHistoryError>> =>
    Result.wrapAsync(session.ensureAuthenticated()).then((sessionResult) =>
      sessionResult
        .mapErr(
          (): GetFundingHistoryError => GetFundingHistoryError.Disconnected(),
        )
        .andThenAsync(async (socket) => {
          const initResult = await ensureInitialized();
          return initResult
            .mapErr(
              (error): GetFundingHistoryError =>
                GetFundingHistoryError.Symbology(error),
            )
            .andThenAsync(async () => {
              const requestId = nextHistoryRequestId();
              const result = await new Promise<
                Result<FundingHistoryPage, GetFundingHistoryError>
              >((resolve) => {
                let settled = false;
                const finish = (
                  outcome: Result<FundingHistoryPage, GetFundingHistoryError>,
                ) => {
                  if (!settled) {
                    settled = true;
                    pendingFundingHistoryRequests.delete(requestId);
                    socket.removeEventListener("close", onClose);
                    socket.removeEventListener("message", onReject);
                    clearTimeout(timeoutHandle);
                    resolve(outcome);
                  }
                };
                const onClose = () => {
                  finish(Err(GetFundingHistoryError.Disconnected()));
                };
                const onReject = (event: MessageEvent<unknown>) => {
                  const reason = commandAckRejectReason(
                    tryParseJson(String(event.data)),
                    requestId,
                  );
                  if (reason !== undefined) {
                    finish(Err(GetFundingHistoryError.Rejected(reason)));
                  }
                };
                const timeoutHandle = setTimeout(() => {
                  finish(Err(GetFundingHistoryError.Timeout()));
                }, FUNDING_HISTORY_TIMEOUT_MS);
                pendingFundingHistoryRequests.set(requestId, (page) => {
                  finish(Ok(page));
                });
                socket.addEventListener("close", onClose);
                socket.addEventListener("message", onReject);
                socket.send(
                  JSON.stringify({
                    cursor: cursor ?? "",
                    request_id: requestId,
                    type: "get_funding_history",
                  }),
                );
              });
              return result;
            });
        }),
    );

  // Mirrors `getOrderHistory` for the per-order events endpoint: waits for
  // symbology (so `market_id` can be scaled), sends `get_order_events`, and
  // races the `request_id`-correlated `order_events` success event against a
  // matching-or-legacy rejected `ack`, a socket close, and a request-scoped
  // timeout.
  const getOrderEvents = (
    externalOrderId: bigint,
    marketId: number,
    cursor?: string | undefined,
  ): Promise<Result<OrderEventsPage, GetOrderEventsError>> => {
    if (
      externalOrderId < 1n ||
      externalOrderId > BigInt(Number.MAX_SAFE_INTEGER)
    ) {
      return Promise.resolve(
        Err(GetOrderEventsError.InvalidExternalOrderId(externalOrderId)),
      );
    } else {
      return Result.wrapAsync(session.ensureAuthenticated()).then(
        (sessionResult) =>
          sessionResult
            .mapErr(
              (): GetOrderEventsError => GetOrderEventsError.Disconnected(),
            )
            .andThenAsync(async (socket) => {
              const initResult = await ensureInitialized();
              return initResult
                .mapErr(
                  (error): GetOrderEventsError =>
                    GetOrderEventsError.Symbology(error),
                )
                .andThenAsync(async () => {
                  const requestId = nextHistoryRequestId();
                  const result = await new Promise<
                    Result<OrderEventsPage, GetOrderEventsError>
                  >((resolve) => {
                    let settled = false;
                    const finish = (
                      outcome: Result<OrderEventsPage, GetOrderEventsError>,
                    ) => {
                      if (!settled) {
                        settled = true;
                        pendingOrderEventsRequests.delete(requestId);
                        socket.removeEventListener("close", onClose);
                        socket.removeEventListener("message", onReject);
                        clearTimeout(timeoutHandle);
                        resolve(outcome);
                      }
                    };
                    const onClose = () => {
                      finish(Err(GetOrderEventsError.Disconnected()));
                    };
                    const onReject = (event: MessageEvent<unknown>) => {
                      const reason = commandAckRejectReason(
                        tryParseJson(String(event.data)),
                        requestId,
                      );
                      if (reason !== undefined) {
                        finish(Err(GetOrderEventsError.Rejected(reason)));
                      }
                    };
                    const timeoutHandle = setTimeout(() => {
                      finish(Err(GetOrderEventsError.Timeout()));
                    }, ORDER_EVENTS_TIMEOUT_MS);
                    pendingOrderEventsRequests.set(requestId, (page) => {
                      finish(Ok(page));
                    });
                    socket.addEventListener("close", onClose);
                    socket.addEventListener("message", onReject);
                    socket.send(
                      JSON.stringify({
                        cursor: cursor ?? "",
                        external_order_id: Number(externalOrderId),
                        market_id: marketId,
                        request_id: requestId,
                        type: "get_order_events",
                      }),
                    );
                  });
                  return result;
                });
            }),
      );
    }
  };

  // Resolves a human market name to its wire-scaling envelope once symbology
  // has loaded.  Case-insensitive, matching `client-public`'s
  // `getMarketBySymbol`.  `Err(unknownSymbol(symbol))` in the caller's own
  // error type when the passed symbol isn't in symbology.
  const resolveMarketMeta = <E extends NonNullable<unknown>>(
    symbol: string,
    unknownSymbol: (symbol: string) => E,
  ): Result<WireMarket, E> => {
    const symbolId = symbolIdByName.get(symbol.toUpperCase());
    const market =
      symbolId === undefined ? undefined : marketsBySymbolId.get(symbolId);
    return market === undefined ? Err(unknownSymbol(symbol)) : Ok(market);
  };

  // Shared prelude for the symbol-scoped signed commands (`submitOrder`,
  // `cancelOrder`): ensure symbology is loaded, resolve the symbol to its wire
  // envelope, then run the command with that `meta`.  Each precondition maps
  // into the caller's own typed error -- a symbology fetch failure wraps the
  // `SymbologyError` (`err.symbology`), an unknown symbol (`err.unknownSymbol`),
  // and an auth handshake failure while initialising (`err.disconnected`).
  const withResolvedMarket = <E extends NonNullable<unknown>>(
    symbol: string,
    err: {
      disconnected: () => E;
      symbology: (error: SymbologyError) => E;
      unknownSymbol: (symbol: string) => E;
    },
    run: (meta: WireMarket) => Promise<Result<true, E>>,
  ): Promise<Result<true, E>> =>
    ensureInitialized().then(
      (initResult) =>
        initResult
          .mapErr(err.symbology)
          .andThen(() => resolveMarketMeta(symbol, err.unknownSymbol))
          .match({
            Err: (e) => Promise.resolve(Err<true, E>(e)),
            Ok: run,
          }),
      () => Promise.resolve(Err<true, E>(err.disconnected())),
    );

  return {
    cancelOrder: (params) =>
      withResolvedMarket<CancelOrderError>(
        params.symbol,
        {
          disconnected: CancelOrderError.Disconnected,
          symbology: CancelOrderError.Symbology,
          unknownSymbol: CancelOrderError.UnknownSymbol,
        },
        (meta) =>
          cancelOrder(signedCommandContext, {
            externalOrderId: params.externalOrderId,
            role: params.role,
            subaccountId: params.subaccountId,
            symbol: meta.symbolId,
          }),
      ),
    close: () => {
      session.close();
    },
    connect: async () => {
      session.resume();
      // `initPromise` is cleared by the socket's own close listener (see
      // `ensureInitialized`), so a stale cache is already resolved by the
      // time this runs -- no explicit invalidation is needed.
      try {
        const initResult = await ensureInitialized();
        return initResult.match<Result<true, ConnectError>>({
          Err: (error) => {
            // A symbology fetch failure threads its typed error up; reset so a
            // later attempt re-fetches instead of inheriting this failure.
            initPromise = undefined;
            return Err(ConnectError.Symbology(error));
          },
          Ok: () => Ok(true),
        });
      } catch (cause: unknown) {
        // The auth handshake rejected (or another init throw). Reset so a
        // later attempt isn't poisoned by this failure.
        initPromise = undefined;
        return Err(ConnectError.Unexpected(cause));
      }
    },
    createConnectionStatusSubscription: (onUpdate) =>
      connectionStatusTracker.subscribe(onUpdate),
    createOrderUpdateSubscription: (onUpdate) => {
      orderUpdateSubscribers.add(onUpdate);
      // Kick off the auth + symbology fetch + subscribe_account flow on
      // first subscribe so the snapshot replay reaches this subscriber
      // without the caller having to also subscribe to positions.  If
      // the snapshot has already arrived (late subscribe), replay the
      // current tracked orders into the new callback so it doesn't
      // have to wait for the next live event.
      ensureInitializedOrThrow().then(
        () => {
          if (snapshotReceived && orderUpdateSubscribers.has(onUpdate)) {
            for (const order of orderState.all()) {
              onUpdate(order);
            }
          }
        },
        () => {
          // Initialization failed; the connection-status indicator
          // already reports the broken session.  Order subscribers
          // receive no replay until the next successful connect.
        },
      );
      return () => {
        orderUpdateSubscribers.delete(onUpdate);
      };
    },
    createRawAccountPositionsSubscription: async (subaccountId, onUpdate) => {
      // Register the subscriber synchronously (before awaiting init) so a
      // snapshot that arrives between init completing and this callback
      // running still finds us in the set.  The state machine already
      // tolerates `notify` calls during the apply loop, and any update
      // already in `state` is replayed via `notify` after registration.
      const existing = subscribersBySubaccountId.get(subaccountId);
      const subscribers = existing ?? new Set<typeof onUpdate>();
      if (existing === undefined) {
        subscribersBySubaccountId.set(subaccountId, subscribers);
      }
      subscribers.add(onUpdate);

      const canceler: Canceler = () => {
        subscribers.delete(onUpdate);
        if (subscribers.size === 0) {
          subscribersBySubaccountId.delete(subaccountId);
        }
      };

      await ensureInitializedOrThrow();
      // If the snapshot already arrived (e.g. subscribing twice, or after
      // the snapshot fan-out has already happened), replay the latest
      // state to this new subscriber.  When the snapshot is in but our
      // subaccount has no data, emit the empty payload so the consumer
      // exits the loading state instead of hanging on the absent subaccount.
      if (snapshotReceived) {
        onUpdate(state.getRaw(subaccountId) ?? EMPTY_RAW);
      } else {
        const existingRaw = state.getRaw(subaccountId);
        if (existingRaw !== undefined) {
          onUpdate(existingRaw);
        }
      }
      return canceler;
    },
    createSessionEndSubscription: (onEvent) => {
      sessionEndSubscribers.add(onEvent);
      return () => {
        sessionEndSubscribers.delete(onEvent);
      };
    },
    createVaultOperationStatusSubscription: async (subaccountId, onStatus) => {
      // Mirrors `createWithdrawStatusSubscription`: register synchronously so
      // an event arriving between init completing and this callback running
      // still finds us in the set.  No replay -- a vault settlement status is
      // one-shot per submitted deposit/withdraw, not standing state.
      const existing =
        vaultOperationStatusSubscribersBySubaccountId.get(subaccountId);
      const subscribers = existing ?? new Set<typeof onStatus>();
      if (existing === undefined) {
        vaultOperationStatusSubscribersBySubaccountId.set(
          subaccountId,
          subscribers,
        );
      }
      subscribers.add(onStatus);
      const canceler: Canceler = () => {
        subscribers.delete(onStatus);
        if (subscribers.size === 0) {
          vaultOperationStatusSubscribersBySubaccountId.delete(subaccountId);
        }
      };
      await ensureInitializedOrThrow();
      return canceler;
    },
    createVaultPositionsSubscription: (onUpdate) => {
      vaultPositionsSubscribers.add(onUpdate);
      // Kick off auth + subscribe_account so the snapshot (and thus the
      // holdings) arrives; replay the latest map to a late subscriber that
      // registered after the snapshot already landed.
      ensureInitialized().then(
        () => {
          if (snapshotReceived && vaultPositionsSubscribers.has(onUpdate)) {
            onUpdate(latestVaultShares);
          }
        },
        () => {
          // Initialization failed; the connection-status indicator already
          // reports the broken session.  No replay until the next connect.
        },
      );
      return () => {
        vaultPositionsSubscribers.delete(onUpdate);
      };
    },
    createWithdrawStatusSubscription: async (subaccountId, onStatus) => {
      // Mirrors `createRawAccountPositionsSubscription` -- register the
      // callback synchronously so events arriving between init completing
      // and this callback running still find us in the set.  No replay
      // here: WithdrawStatus is a one-shot per submitted withdraw, not
      // standing state the way positions are.
      const existing =
        withdrawStatusSubscribersBySubaccountId.get(subaccountId);
      const subscribers = existing ?? new Set<typeof onStatus>();
      if (existing === undefined) {
        withdrawStatusSubscribersBySubaccountId.set(subaccountId, subscribers);
      }
      subscribers.add(onStatus);
      const canceler: Canceler = () => {
        subscribers.delete(onStatus);
        if (subscribers.size === 0) {
          withdrawStatusSubscribersBySubaccountId.delete(subaccountId);
        }
      };
      await ensureInitializedOrThrow();
      return canceler;
    },
    disconnect: () => {
      session.disconnect();
    },
    getFundingHistory,
    getOrderEvents,
    getOrderHistory,
    getVaultAccountPerf,
    getVaultAccounts,
    registerUserDepositAddress: (subaccountId) =>
      registerUserDepositAddress(session.ensureAuthenticated, subaccountId),
    submitOrder: (params) =>
      withResolvedMarket<SubmitOrderError>(
        params.symbol,
        {
          disconnected: SubmitOrderError.Disconnected,
          symbology: SubmitOrderError.Symbology,
          unknownSymbol: SubmitOrderError.UnknownSymbol,
        },
        (meta) =>
          toWireOrder(params)
            .andThen((order) => encodeOrderWire(meta, order))
            .match<Promise<Result<true, SubmitOrderError>>>({
              Err: (message) =>
                Promise.resolve(Err(SubmitOrderError.Validation(message))),
              Ok: (wire) =>
                submitOrder(signedCommandContext, {
                  ...wire,
                  subaccountId: params.subaccountId,
                }),
            }),
      ),
    submitVaultDeposit: (params) =>
      submitVaultDeposit(
        signedCommandContext,
        params,
        options.withdrawAckGraceMs ?? DEFAULT_WITHDRAW_ACK_GRACE_MS,
      ),
    submitVaultWithdraw: (params) =>
      submitVaultWithdraw(
        signedCommandContext,
        params,
        options.withdrawAckGraceMs ?? DEFAULT_WITHDRAW_ACK_GRACE_MS,
      ),
    submitWithdraw: (params) =>
      submitWithdraw(
        signedCommandContext,
        params,
        options.withdrawAckGraceMs ?? DEFAULT_WITHDRAW_ACK_GRACE_MS,
      ),
  };
};
