import type {
  FillBustedMessage,
  FillMessage,
  FillSettledMessage,
} from "../wire/wireSchema";
import { computeCostBasisDelta } from "./costBasisDelta";
import type { MarketDecimals } from "./marketDecimals";
import type { InternalPosition, Subaccount } from "./subaccount";
import { ensurePosition, ensureSubaccount } from "./subaccount";

const absBigint = (n: bigint): bigint => (n < 0n ? -n : n);

const sameDirection = (a: bigint, b: bigint): boolean =>
  (a > 0n && b > 0n) || (a < 0n && b < 0n);

// `value * numerator / denominator`, truncating toward zero.  Mirrors the
// notifier's `prorateInt64`; its int64 overflow split is unnecessary for
// BigInt, and with non-negative numerator/denominator the truncated result is
// identical.
const prorate = (
  value: bigint,
  numerator: bigint,
  denominator: bigint,
): bigint =>
  value === 0n || numerator === 0n || denominator === 0n
    ? 0n
    : (value * numerator) / denominator;

// Average-cost position math, ported verbatim from the notifier's
// `averageCostPositionAfterFill`.  Returns the position's cost basis after the
// fill leg and the realized PnL the leg produces.  An opening / increasing leg
// (or any leg against a flat position) realizes nothing and the basis is just
// additive; a reducing leg realizes `-(fill_closed + old_closed)` on the
// closed quantity, retains the remaining basis pro rata, and -- when the leg
// overshoots the position -- opens the residual at the fill price.  The closed
// basis is the COMPLEMENT of the retained basis (`oldCost - remainingOldCost`),
// matching the notifier exactly: a direct `oldCost * closeAbs / oldAbs` can
// differ from it by one unit under truncation.
const averageCostPositionAfterFill = (
  oldQty: bigint,
  oldCost: bigint,
  signedQty: bigint,
  signedFillCost: bigint,
): { averageCost: bigint; realizedPnl: bigint } => {
  const additiveCost = oldCost + signedFillCost;
  if (oldQty === 0n || signedQty === 0n || sameDirection(oldQty, signedQty)) {
    return { averageCost: additiveCost, realizedPnl: 0n };
  } else {
    const oldAbs = absBigint(oldQty);
    const fillAbs = absBigint(signedQty);
    const closeAbs = oldAbs < fillAbs ? oldAbs : fillAbs;
    const remainingOldAbs = oldAbs - closeAbs;
    const remainingOldCost =
      remainingOldAbs === 0n ? 0n : prorate(oldCost, remainingOldAbs, oldAbs);
    const openingCost =
      fillAbs > oldAbs
        ? prorate(signedFillCost, fillAbs - oldAbs, fillAbs)
        : 0n;
    const fillCloseCost = prorate(signedFillCost, closeAbs, fillAbs);
    const oldClosedCost = oldCost - remainingOldCost;
    return {
      averageCost: remainingOldCost + openingCost,
      realizedPnl: -fillCloseCost - oldClosedCost,
    };
  }
};

// A fill's identity for matching its later `FillSettled` / `FillBusted`.
// Mirrors the notifier's `findPendingRealizedFill`: the subaccount is implicit
// (the pending list is per-subaccount) and price only has to agree when both
// sides carry a non-zero price.
type FillKey = {
  external_order_id?: bigint | undefined;
  symbol: number;
  side: "BID" | "ASK";
  qty: bigint;
  price?: bigint | undefined;
};

const findPendingRealizedFill = (
  subaccount: Subaccount,
  key: FillKey,
): number => {
  const keyPrice = key.price ?? 0n;
  const keyOrderId = key.external_order_id ?? 0n;
  return subaccount.pendingRealized.findIndex(
    (pending) =>
      pending.externalOrderId === keyOrderId &&
      pending.symbolId === key.symbol &&
      pending.side === key.side &&
      pending.qty === key.qty &&
      (keyPrice === 0n || pending.price === 0n || pending.price === keyPrice),
  );
};

// Record (but don't yet realize) the average-cost PnL a reducing leg produces,
// returning the cost-basis correction to fold into the position now so a later
// fill in the same settlement batch sees the average-cost basis.  Mirrors the
// notifier's `recordPendingRealizedFill`; a leg that neither realizes nor
// corrects (opening / increasing) records nothing.
const recordPendingRealizedFill = (
  subaccount: Subaccount,
  key: FillKey,
  position: InternalPosition,
  signedQty: bigint,
  costDelta: bigint,
): bigint => {
  const { averageCost, realizedPnl } = averageCostPositionAfterFill(
    position.netQty,
    position.costBasis,
    signedQty,
    costDelta,
  );
  const correction = averageCost - (position.costBasis + costDelta);
  if (correction === 0n && realizedPnl === 0n) {
    return 0n;
  } else {
    subaccount.pendingRealized.push({
      costBasisCorrection: correction,
      externalOrderId: key.external_order_id ?? 0n,
      price: key.price ?? 0n,
      qty: key.qty,
      realizedPnlDelta: realizedPnl,
      side: key.side,
      symbolId: key.symbol,
    });
    return correction;
  }
};

// Apply one fill leg to its position, mirroring the notifier's
// `applyFillPosition`.  A live fill folds its notional into the cost basis and,
// when it reduces the position, also folds the average-cost correction so the
// basis tracks average cost immediately; the realized PnL itself stays pending
// until the matching `FillSettled`.  A bust passes the negated leg with
// `busted` true -- it skips the pending record (the matching pending is
// discarded separately) and reverses the raw notional, undoing the fill.
const applyFillPosition = (
  subaccount: Subaccount,
  message: FillMessage | FillBustedMessage,
  decimals: MarketDecimals | undefined,
  busted: boolean,
): void => {
  if (decimals === undefined) {
    // biome-ignore lint/suspicious/noConsole: surface the unvalued fill leg; the next snapshot re-sets basis and realized PnL
    console.error(
      "applyFillPosition: no market decimals for symbol, applying qty only",
      message.symbol,
    );
  }
  const fillQty = message.side === "ASK" ? -message.qty : message.qty;
  const fillCostDelta =
    decimals === undefined
      ? 0n
      : computeCostBasisDelta(message.price ?? 0n, fillQty, decimals);
  const signedQty = busted ? -fillQty : fillQty;
  const costDelta = busted ? -fillCostDelta : fillCostDelta;
  const feeDelta = busted ? -(message.fee ?? 0n) : (message.fee ?? 0n);
  const position = ensurePosition(subaccount, message.symbol);
  // Without decimals we can't value the leg, so we can't realize either; just
  // record the qty and let the next snapshot re-set basis and realized PnL.
  const costBasisCorrection =
    !busted && decimals !== undefined
      ? recordPendingRealizedFill(
          subaccount,
          message,
          position,
          signedQty,
          costDelta,
        )
      : 0n;
  position.netQty += signedQty;
  position.costBasis += costDelta + costBasisCorrection;
  position.pendingFees += feeDelta;
};

// Commit a settled fill's pending realized PnL into the position.  Mirrors the
// notifier's `commitPendingRealizedFill` (which, post-pnl-fix, no longer
// touches the cost basis -- the correction was applied at fill time).  Returns
// whether a pending fill matched.
const commitPendingRealizedFill = (
  subaccount: Subaccount,
  key: FillKey,
): boolean => {
  const idx = findPendingRealizedFill(subaccount, key);
  if (idx < 0) {
    return false;
  } else {
    const [pending] = subaccount.pendingRealized.splice(idx, 1);
    if (pending === undefined) {
      // `idx >= 0` was just proved, so splicing one element always yields it.
      throw new Error(
        "commitPendingRealizedFill: splice at a valid index returned no element",
      );
    } else {
      const position = ensurePosition(subaccount, key.symbol);
      position.realizedPnl += pending.realizedPnlDelta;
      return true;
    }
  }
};

// Drop a busted fill's pending realized PnL and unwind the average-cost basis
// correction it applied.  Mirrors the notifier's `discardPendingRealizedFill`;
// the rest of the leg is reversed by `applyFillPosition` with `busted` true.
const discardPendingRealizedFill = (
  subaccount: Subaccount,
  key: FillKey,
): void => {
  const idx = findPendingRealizedFill(subaccount, key);
  if (idx >= 0) {
    const [pending] = subaccount.pendingRealized.splice(idx, 1);
    if (pending === undefined) {
      // `idx >= 0` was just proved, so splicing one element always yields it.
      throw new Error(
        "discardPendingRealizedFill: splice at a valid index returned no element",
      );
    } else {
      const position = ensurePosition(subaccount, key.symbol);
      position.costBasis -= pending.costBasisCorrection;
    }
  }
};

export const applyFill = (
  subaccounts: Map<bigint, Subaccount>,
  message: FillMessage,
  decimals: MarketDecimals | undefined,
): bigint[] => {
  if (message.seq === 0n || message.symbol === 0 || message.qty === 0n) {
    return [];
  } else {
    const subaccount = ensureSubaccount(subaccounts, message.subaccount_id);
    applyFillPosition(subaccount, message, decimals, false);
    if (message.reason === 1) {
      commitPendingRealizedFill(subaccount, message);
    }
    return [message.subaccount_id];
  }
};

export const applyFillSettled = (
  subaccounts: Map<bigint, Subaccount>,
  message: FillSettledMessage,
): bigint[] => {
  if (message.seq === 0n || message.symbol === 0 || message.qty === 0n) {
    return [];
  } else {
    const subaccount = subaccounts.get(message.subaccount_id);
    if (subaccount === undefined) {
      return [];
    } else {
      // Only signal a change (so the client re-emits) when a pending fill
      // actually committed; an unmatched settlement leaves position state
      // untouched.
      return commitPendingRealizedFill(subaccount, message)
        ? [message.subaccount_id]
        : [];
    }
  }
};

export const applyFillBusted = (
  subaccounts: Map<bigint, Subaccount>,
  message: FillBustedMessage,
  decimals: MarketDecimals | undefined,
): bigint[] => {
  if (message.seq === 0n || message.symbol === 0 || message.qty === 0n) {
    return [];
  } else {
    // Busting a fill reverses the position delta: drop its pending realized PnL
    // (unwinding the basis correction), then reverse the raw notional and qty.
    // Like the C++ bust path it does not realize PnL -- the matching fill never
    // settled -- and the next snapshot re-sets cost basis and realized PnL
    // authoritatively.
    const subaccount = ensureSubaccount(subaccounts, message.subaccount_id);
    discardPendingRealizedFill(subaccount, message);
    applyFillPosition(subaccount, message, decimals, true);
    return [message.subaccount_id];
  }
};
