import type { ConnectionStatusReporter } from "@aethon/client-protocol/connectionStatus";
import { z } from "zod";
import { base64Encode } from "../signing/signMessage";
import { tryParseJson } from "../wire/tryParseJson";
import type { AuthSigner } from "./authSigner";
import type { SessionEndEvent } from "./sessionEnd";
import { RATE_LIMIT_CLOSE_REASON, sessionEndMessageSchema } from "./sessionEnd";

// The gateway authenticates the WS session before any account stream is
// accessible: open the socket, send `auth_wallet` with the wallet pubkey,
// receive `auth_challenge` carrying a string `message` and a `nonce`, sign
// the UTF-8 bytes of `message` with the wallet's ed25519 key, then send
// `auth_response` with the base64-encoded signature and the original nonce.
// The gateway emits two `ack { status: "accepted" }` messages during this
// flow -- the first ("wallet challenge issued") immediately after
// `auth_wallet` is received, and the second ("wallet authenticated") after
// the signature verifies.  We ignore the pre-`auth_response` ack and resolve
// on the post-`auth_response` one; `status: "rejected" | "busy"` at any
// point rejects the handshake.  This mirrors `api_client/main.cpp`'s
// phase + `auth_wallet_ack_received_` state machine.
//
// Wire-format assumptions (mirroring `api_client/gateway_protocol_codec.cpp`
// and `api_client_signer.cpp`):
//
// - `wallet_pubkey` is a base58-encoded SVM public key.  `@solana/kit`'s
//   `Address` already meets this contract; we pass it through verbatim.
// - The `message` from `auth_challenge` is signed as raw UTF-8 bytes; the
//   resulting 64-byte ed25519 signature is base64-encoded with standard
//   padding (matching libsodium `sodium_base64_VARIANT_ORIGINAL` and the
//   `signature_b64` field name on the gateway side).
//
// The session retries from scratch on failure — a rejected handshake clears
// the cached promise so the next `ensureAuthenticated` call attempts a fresh
// connect.  This keeps a transient gateway error from poisoning the client
// for the lifetime of the React provider.  Transparent re-auth on
// disconnect / expiry is deliberately deferred to a follow-up PR.

export type AuthSessionOptions = {
  websocketUrl: string;
  signer: AuthSigner;
  createWebSocket?: ((url: string) => WebSocket) | undefined;
  connectionStatus: ConnectionStatusReporter;
  // Called (at most once per authenticated socket) when the gateway ends
  // the session: a `session_preempted` / `auth_expired` message, or a
  // rate-limit close.  Deliberate `disconnect()` / `close()` do not emit.
  onSessionEnd?: ((event: SessionEndEvent) => void) | undefined;
};

export type AuthSession = {
  // Lazily opens an authenticated WS.  Concurrent calls share one in-flight
  // handshake; subsequent calls after success return the same socket.  After
  // the authenticated socket drops, the next call performs a fresh
  // handshake.
  ensureAuthenticated: () => Promise<WebSocket>;
  // User-initiated disconnect: closes the socket and suppresses
  // `ensureAuthenticated` (it rejects) until `resume()` is called.
  disconnect: () => void;
  // Lifts a `disconnect()` suspension so the next `ensureAuthenticated`
  // can open a fresh session.
  resume: () => void;
  // Tears the session down: closes the socket, rejects any in-flight
  // handshake, and prevents future `ensureAuthenticated` from reusing the
  // closed session.
  close: () => void;
};

const SIGNED_MESSAGE_ENCODER = new TextEncoder();

const encodeAuthWallet = (walletPublicKey: string): string =>
  JSON.stringify({
    expiry_seconds: 0,
    type: "auth_wallet",
    wallet_pubkey: walletPublicKey,
  });

const encodeAuthResponse = (nonce: string, signatureB64: string): string =>
  JSON.stringify({
    nonce,
    signature_b64: signatureB64,
    type: "auth_response",
  });

// Pre-auth wire messages.  Validating at the boundary with Zod (rather than
// casting from `JSON.parse`'s `unknown`) is the project's data policy --
// see `docs/typescript/data.md`.  The discriminated union narrows on `type`
// so the switch in `onMessage` is exhaustive and adding a new pre-auth
// message kind is a compile error until handled.
const authChallengeSchema = z.object({
  message: z.string(),
  nonce: z.string(),
  type: z.literal("auth_challenge"),
});

const ackSchema = z.object({
  reason: z.string().optional(),
  status: z.string(),
  type: z.literal("ack"),
});

const preAuthMessageSchema = z.discriminatedUnion("type", [
  authChallengeSchema,
  ackSchema,
]);

export const createAuthSession = (options: AuthSessionOptions): AuthSession => {
  const { websocketUrl, signer, connectionStatus } = options;
  const createWs =
    options.createWebSocket ?? ((url: string) => new WebSocket(url));

  let session: Promise<WebSocket> | undefined;
  let activeSocket: WebSocket | undefined;
  let closed = false;
  let suspended = false;

  // Post-handshake lifecycle: surface gateway-initiated session ends (at
  // most one per socket) and reset the cached session so a later
  // `ensureAuthenticated` re-handshakes instead of returning a dead socket.
  const watchAuthenticatedSocket = (socket: WebSocket) => {
    let ended = false;
    const emitSessionEnd = (event: SessionEndEvent) => {
      if (!ended) {
        ended = true;
        options.onSessionEnd?.(event);
      }
    };
    socket.addEventListener("message", (event: MessageEvent) => {
      tryParseJson(String(event.data)).match({
        None: () => {
          // Non-JSON frames on the authenticated socket are not session-end
          // messages; nothing to do.
        },
        Some: (rawJson) => {
          const parsed = sessionEndMessageSchema.safeParse(rawJson);
          if (parsed.success) {
            emitSessionEnd(
              parsed.data.type === "session_preempted"
                ? { type: "sessionPreempted" }
                : { reason: parsed.data.reason, type: "authExpired" },
            );
          }
        },
      });
    });
    socket.addEventListener("close", (event: CloseEvent) => {
      if (event.reason === RATE_LIMIT_CLOSE_REASON) {
        emitSessionEnd({ type: "rateLimited" });
      }
      if (activeSocket === socket) {
        activeSocket = undefined;
        session = undefined;
      }
      if (!closed && !suspended) {
        connectionStatus.report("disconnected");
      }
    });
  };

  const performHandshake = (): Promise<WebSocket> =>
    new Promise<WebSocket>((resolve, reject) => {
      const socket = createWs(websocketUrl);
      activeSocket = socket;
      connectionStatus.report("connecting");
      // Flips to `true` once `auth_response` has gone out.  The gateway
      // emits two `ack { status: "accepted" }` messages; the pre-response
      // one is informational ("wallet challenge issued") and the
      // post-response one is what actually flips the session authenticated.
      let authResponseSent = false;

      const cleanup = () => {
        socket.removeEventListener("open", onOpen);
        socket.removeEventListener("message", onMessage);
        socket.removeEventListener("close", onClose);
        socket.removeEventListener("error", onError);
      };

      const fail = (error: Error) => {
        cleanup();
        // A deliberate `close()` flips `closed` before tearing the socket
        // down and clears the reporter itself -- only an unexpected failure
        // is a `disconnected`.
        if (!closed) {
          connectionStatus.report("disconnected");
        }
        reject(error);
      };

      const onOpen = () => {
        try {
          socket.send(encodeAuthWallet(signer.walletPublicKey));
        } catch (cause: unknown) {
          fail(
            cause instanceof Error
              ? cause
              : new Error("failed to send auth_wallet"),
          );
        }
      };

      const onMessage = (event: MessageEvent) => {
        tryParseJson(String(event.data)).match({
          None: () => {
            fail(new Error("gateway sent non-JSON pre-auth message"));
          },
          Some: (rawJson) => {
            // Unknown / malformed pre-auth messages are ignored; the gateway
            // never sends unsolicited stream data before the session is
            // authenticated, so anything we don't recognise here is not for
            // us.
            const parseResult = preAuthMessageSchema.safeParse(rawJson);
            if (parseResult.success) {
              const message = parseResult.data;
              switch (message.type) {
                case "auth_challenge": {
                  const messageBytes = SIGNED_MESSAGE_ENCODER.encode(
                    message.message,
                  );
                  signer
                    .signMessage(messageBytes)
                    .then((signatureBytes) => {
                      socket.send(
                        encodeAuthResponse(
                          message.nonce,
                          base64Encode(signatureBytes),
                        ),
                      );
                      authResponseSent = true;
                    })
                    .catch((cause: unknown) => {
                      fail(
                        cause instanceof Error
                          ? cause
                          : new Error(`signer rejected: ${String(cause)}`),
                      );
                    });
                  return;
                }
                case "ack": {
                  if (message.status === "accepted") {
                    if (authResponseSent) {
                      cleanup();
                      connectionStatus.report("connected");
                      // The handshake listeners are gone; watch the authenticated
                      // socket so gateway-initiated session ends and unexpected
                      // drops are surfaced.
                      watchAuthenticatedSocket(socket);
                      resolve(socket);
                    }
                    // Pre-`auth_response` "accepted" is just the wallet-challenge
                    // acknowledgement; the gateway will still send `auth_challenge`
                    // next, so we wait for it.
                  } else {
                    fail(
                      new Error(
                        `gateway auth rejected: ${message.reason ?? message.status}`,
                      ),
                    );
                  }
                  return;
                }
              }
            }
          },
        });
      };

      const onClose = () => {
        fail(new Error("gateway closed before auth completed"));
      };

      const onError = () => {
        fail(new Error("gateway connection error"));
      };

      socket.addEventListener("open", onOpen);
      socket.addEventListener("message", onMessage);
      socket.addEventListener("close", onClose);
      socket.addEventListener("error", onError);
    });

  return {
    close: () => {
      closed = true;
      session = undefined;
      activeSocket?.close();
      activeSocket = undefined;
      connectionStatus.clear();
    },
    disconnect: () => {
      suspended = true;
      session = undefined;
      const socket = activeSocket;
      activeSocket = undefined;
      socket?.close();
      connectionStatus.report("disconnected");
    },
    ensureAuthenticated: () => {
      if (closed) {
        return Promise.reject(new Error("auth session closed"));
      } else if (suspended) {
        return Promise.reject(new Error("auth session disconnected"));
      } else {
        if (session === undefined) {
          session = performHandshake().catch((cause: unknown) => {
            // Reset so a future call can retry from scratch instead of
            // permanently inheriting this attempt's failure.
            session = undefined;
            throw cause;
          });
        }
        return session;
      }
    },
    resume: () => {
      suspended = false;
    },
  };
};
