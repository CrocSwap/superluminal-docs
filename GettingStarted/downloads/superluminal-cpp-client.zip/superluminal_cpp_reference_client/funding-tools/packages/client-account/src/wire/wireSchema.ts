import { z } from "zod";
import {
  wireBigint,
  wireDecimalUint64,
  wireExternalOrderId,
  wireOptionalExternalOrderId,
} from "./wireBigint";

// Wire-format Zod schemas for the gateway's account-stream messages.  These
// run after the auth handshake completes and represent the payloads the
// gateway pushes on the authenticated WS.  Validating them at the boundary
// (per `docs/typescript/data.md`) keeps the rest of the live account client
// working in branded TS types instead of `unknown`.

// `AccountSnapshot.positions[].symbol` is a uint32 symbol id; the surrounding
// app surfaces it as `number` since JS handles uint32 in `number` without
// precision loss.
const positionSchema = z.object({
  cost_basis: wireBigint,
  funding_accrued: wireBigint,
  last_funding_index_e8: wireBigint,
  net_qty: wireBigint,
  pending_fees: wireBigint,
  realized_pnl: wireBigint.optional().transform((n) => n ?? 0n),
  symbol: z.number(),
});

// `working_orders[]` mirrors the gateway's bootstrap shape (see
// `dfba_gateway/hub_private_snapshot.go::privateAccountWorkingOrder`).
// The fields here are the minimum needed to build a public `Order`
// (id, side, price, sizes, timestamp), plus the strict-zod `tif` /
// `role` enums so a malformed payload fails parse at the boundary.
const workingOrderSchema = z.object({
  client_instruction_id: wireDecimalUint64.optional(),
  delta_ppm: z.number().optional(),
  execution_mode: z.number().optional(),
  external_order_id: wireExternalOrderId,
  filled_qty: wireBigint,
  order_type: z.number(),
  original_iat: wireBigint,
  original_qty: wireBigint,
  price: wireBigint,
  remaining_qty: wireBigint,
  role: z.enum(["MAKER", "TAKER"]).optional(),
  side: z.enum(["BID", "ASK"]),
  symbol: z.number(),
  tif: z.enum(["GTC", "IOC"]).optional(),
});

const subaccountSchema = z.object({
  // `filled_orders[]` is present in the wire format but unused by the
  // client today: every order it tracks also lives in `working_orders[]`
  // (still open) or in the gateway-side `orders` table (terminal,
  // reachable via `get_order_history`).  Keeping the field permissive
  // means a future shape extension on the gateway side doesn't break
  // the strict-zod boundary parse here.
  collateral_balance: wireBigint.optional(),
  filled_orders: z.array(z.unknown()).optional(),
  positions: z.array(positionSchema),
  subaccount_id: wireBigint,
  working_orders: z.array(workingOrderSchema).optional(),
});

// Per-vault holding inside a participant account.  Only `shares` and the vault
// pubkey are consumed (to show the user's position and gate withdraw); the rest
// of the wire entry (cost basis, seqs) is permissive to survive shape drift.
const vaultParticipantEntrySchema = z.object({
  shares: wireBigint,
  vault_account_pubkey: z.string(),
});

const vaultParticipantAccountSchema = z.object({
  entries: z.array(vaultParticipantEntrySchema),
});

const accountSnapshotSchema = z.object({
  last_seq: wireBigint,
  subaccounts: z.array(subaccountSchema),
  type: z.literal("AccountSnapshot"),
  // Present when the wallet holds vault positions; absent otherwise.
  vault_participant_accounts: z.array(vaultParticipantAccountSchema).optional(),
});

const fillEventSchema = z.object({
  allocated_loss: wireBigint.optional(),
  batch_id: wireBigint.optional(),
  execution_mode: z.number().optional(),
  external_order_id: wireOptionalExternalOrderId.optional(),
  fee: wireBigint.optional(),
  market_id: z.number().optional(),
  matcher_unix_ns: wireBigint.optional(),
  onchain_signature: z.string().optional(),
  operation_nonce: wireBigint.optional(),
  price: wireBigint.optional(),
  qty: wireBigint,
  reason: z.number().optional(),
  request_seq: wireBigint.optional(),
  role: z.enum(["MAKER", "TAKER", "target", "counterparty"]).optional(),
  seq: wireBigint,
  side: z.enum(["BID", "ASK"]),
  subaccount_id: wireBigint,
  symbol: z.number(),
  trade_id: wireBigint.optional(),
  type: z.literal("Fill"),
});

// `AdlFailed` is a terminal non-order workflow result. Unlike a successful
// ADL leg it never becomes a `Fill`, so the live orders feed needs its own
// boundary schema to show the rejected ADL outcome immediately.
const adlFailedSchema = z.object({
  allocated_loss: wireBigint,
  batch_id: wireBigint,
  cleanup_error_code: z
    .number()
    .optional()
    .transform((n) => n ?? 0),
  error: z.string().optional(),
  error_code: z.number(),
  error_domain: z.string().optional(),
  error_message: z.string().optional(),
  failure_stage: z.number(),
  market_id: z.number(),
  operation_nonce: wireBigint,
  price: wireBigint,
  qty: wireBigint,
  request_seq: wireBigint,
  role: z.enum(["target", "counterparty"]),
  seq: wireBigint,
  side: z.enum(["BID", "ASK"]),
  subaccount_id: wireBigint,
  type: z.literal("AdlFailed"),
  workflow_error_code: z.number(),
});

// `FillSettled` and `FillBusted` share the same wire shape; the C++ side
// has different apply paths for them (settle adjusts pending fees / fills;
// bust reverses the position delta).  Discriminated by `type`.
const fillSettledSchema = z.object({
  error: z.string().optional(),
  error_code: z.number().optional(),
  error_domain: z.string().optional(),
  error_message: z.string().optional(),
  external_order_id: wireExternalOrderId,
  fee: wireBigint.optional(),
  onchain_signature: z.string().optional(),
  price: wireBigint.optional(),
  qty: wireBigint,
  seq: wireBigint,
  side: z.enum(["BID", "ASK"]),
  status: z.number().optional(),
  subaccount_id: wireBigint,
  symbol: z.number(),
  type: z.literal("FillSettled"),
});

const fillBustedSchema = z.object({
  error: z.string().optional(),
  error_code: z.number().optional(),
  error_domain: z.string().optional(),
  error_message: z.string().optional(),
  external_order_id: wireExternalOrderId,
  fee: wireBigint.optional(),
  onchain_signature: z.string().optional(),
  price: wireBigint.optional(),
  qty: wireBigint,
  seq: wireBigint,
  side: z.enum(["BID", "ASK"]),
  status: z.number().optional(),
  subaccount_id: wireBigint,
  symbol: z.number(),
  type: z.literal("FillBusted"),
});

const userCollateralUpdateSchema = z.object({
  collateral_balance: wireBigint,
  collateral_delta: wireBigint,
  seq: wireBigint,
  subaccount_id: wireBigint,
  type: z.literal("UserCollateralUpdate"),
});

const accountFundingUpdateSchema = z.object({
  funding_accrued: wireBigint.optional(),
  funding_delta: wireBigint.optional(),
  last_funding_index_e8: wireBigint.optional(),
  market_id: z.number(),
  prev_funding_index_e8: wireBigint.optional(),
  seq: wireBigint,
  subaccount_id: wireBigint,
  // `symbol` defaults to `market_id` per the C++ codec.
  symbol: z.number().optional(),
  type: z.literal("AccountFundingUpdate"),
});

// Order lifecycle events.  The gateway streams these on the same
// authenticated WS as fills and snapshots, after the user submits a
// signed order / cancel / modify.  Together they let the live client
// maintain a current view of the user's open orders without re-fetching
// `get_order_history` every time something changes.
//
// `OrderAccepted` carries the full original order parameters (price,
// qty, side, etc.) at sequencer-accept time -- enough to construct a
// fresh `Order` object for a freshly-placed order.
const orderAcceptedSchema = z.object({
  client_instruction_id: wireDecimalUint64.optional(),
  delta_ppm: z.number().int().min(-2_147_483_648).max(2_147_483_647),
  execution_mode: z.number().optional(),
  external_order_id: wireExternalOrderId,
  matcher_unix_ns: wireBigint,
  order_type: z.number(),
  original_iat: wireBigint.optional(),
  price: wireBigint,
  qty: wireBigint,
  role: z.enum(["MAKER", "TAKER"]).optional(),
  seq: wireBigint,
  side: z.enum(["BID", "ASK"]),
  subaccount_id: wireBigint,
  symbol: z.number(),
  tif: z.enum(["GTC", "IOC"]).optional(),
  type: z.literal("OrderAccepted"),
});

// `OrderReject` is emitted instead of `OrderAccepted` when the sequencer
// rejects the order.  Carries the requested parameters so the client
// can surface a "rejected" entry in the orders list even though the
// order never reached the matcher.
const orderRejectEventSchema = z.object({
  client_instruction_id: wireDecimalUint64.optional(),
  delta_ppm: z.number().optional(),
  external_order_id: wireExternalOrderId.optional(),
  matcher_unix_ns: wireBigint.optional(),
  order_type: z.number(),
  price: wireBigint,
  qty: wireBigint.optional(),
  reason: z.number().optional(),
  seq: wireBigint,
  side: z.enum(["BID", "ASK"]),
  subaccount_id: wireBigint,
  symbol: z.number(),
  type: z.literal("OrderReject"),
});

// `CancelAck` carries the order identity; the client transitions the
// order's status to `cancelled`.
const cancelAckSchema = z.object({
  external_order_id: wireExternalOrderId,
  matcher_unix_ns: wireBigint.optional(),
  seq: wireBigint,
  subaccount_id: wireBigint,
  symbol: z.number(),
  type: z.literal("CancelAck"),
});

// `ModifyAck` carries the new price / remaining qty / delta. Matcher rejects
// an increase, so qty is always `<= remaining_qty_before`.
const modifyAckSchema = z.object({
  delta_ppm: z.number().int().min(-2_147_483_648).max(2_147_483_647),
  external_order_id: wireExternalOrderId,
  matcher_unix_ns: wireBigint.optional(),
  original_client_instruction_id: wireDecimalUint64.optional(),
  price: wireBigint,
  qty: wireBigint.refine((qty) => qty > 0n),
  seq: wireBigint,
  subaccount_id: wireBigint,
  symbol: z.number(),
  type: z.literal("ModifyAck"),
});

// Emitted by the notifier once the sequencer-driven on-chain
// `withdraw_collateral` transaction has settled.  `onchain_signature` is
// the base58-encoded SVM tx signature -- present on success, omitted on
// pre-settlement / retry records (see PR #408).  Used by the trading-app
// to update its "Withdraw queued" toast with a link to the bridge tx
// once it lands.  `client_instruction_id` matches the `request_id_64`
// the client supplied in `signed_withdraw`, so consumers correlate by
// equality.  Feeds the state machine as an authoritative debit ahead
// of the next snapshot/UCU catching up.
const withdrawStatusSchema = z.object({
  actual_withdraw_amount: wireBigint.optional(),
  batch_id: wireBigint.optional(),
  client_instruction_id: wireDecimalUint64,
  error_code: z.number().optional(),
  onchain_signature: z.string().optional(),
  requested_withdraw_amount: wireBigint.optional(),
  seq: wireBigint,
  status: z.number(),
  subaccount_id: wireBigint,
  type: z.literal("WithdrawStatus"),
});

// Settlement outcome for a `signed_deposit_vault` / `signed_withdraw_vault`.
// The proof is processed off-chain (shares minted / redeemed) and the on-chain
// settlement tx is posted afterwards; either can fail independently, so the
// gateway emits one of these once the settlement finalizes.  `status` is 0 on
// success; a non-zero `status` (or `error_code`) means the settlement failed and
// nothing moved.  `error` / `error_message` / `error_domain` carry the
// human-facing failure detail (e.g. domain "settlement", error "TransactionFailed",
// message "Settlement transaction failed").  `client_instruction_id` matches the
// `request_id_64` the client embedded in the proof, so consumers correlate by
// equality.  Only the consumed share-delta field is declared on each subtype
// (`minted_vault_shares` / `requested_vault_shares`); the settlement's other
// amount fields ride the wire but aren't read, so the non-strict parse drops
// them.  `seq` is optional because these settlement records don't always ride
// the seq'd balance stream the way `WithdrawStatus` does.
const vaultStatusBase = {
  client_instruction_id: wireDecimalUint64,
  error: z.string().optional(),
  error_code: z.number().optional(),
  error_domain: z.string().optional(),
  error_message: z.string().optional(),
  seq: wireBigint.optional(),
  status: z.number(),
  subaccount_id: wireBigint,
  vault_account_pubkey: z.string().optional(),
  vault_id: wireBigint.optional(),
};

const depositVaultStatusSchema = z.object({
  ...vaultStatusBase,
  minted_vault_shares: wireBigint.optional(),
  type: z.literal("DepositVaultStatus"),
});

const withdrawVaultStatusSchema = z.object({
  ...vaultStatusBase,
  requested_vault_shares: wireBigint.optional(),
  type: z.literal("WithdrawVaultStatus"),
});

// A non-approved vault operation is emitted with the operation's original
// discriminant rather than its later settlement-status discriminant.  It has
// the same correlation and error fields as a settlement status, so model it in
// the same stream union and normalize it to a failed vault operation.
const depositVaultRejectedSchema = z.object({
  ...vaultStatusBase,
  type: z.literal("DepositVault"),
});

const withdrawVaultRejectedSchema = z.object({
  ...vaultStatusBase,
  type: z.literal("WithdrawVault"),
});

// Discriminated union of every account-stream message the state machine
// reacts to.  Unknown discriminants the trading-app doesn't render are ignored
// by `live.ts`'s dispatcher.
export const accountStreamMessageSchema = z.discriminatedUnion("type", [
  accountSnapshotSchema,
  fillEventSchema,
  adlFailedSchema,
  fillSettledSchema,
  fillBustedSchema,
  userCollateralUpdateSchema,
  accountFundingUpdateSchema,
  orderAcceptedSchema,
  orderRejectEventSchema,
  cancelAckSchema,
  modifyAckSchema,
  withdrawStatusSchema,
  depositVaultRejectedSchema,
  depositVaultStatusSchema,
  withdrawVaultRejectedSchema,
  withdrawVaultStatusSchema,
]);

export type AccountStreamMessage = z.infer<typeof accountStreamMessageSchema>;
export type AccountSnapshotMessage = z.infer<typeof accountSnapshotSchema>;
export type AccountSnapshotPosition = z.infer<typeof positionSchema>;
export type AccountSnapshotWorkingOrder = z.infer<typeof workingOrderSchema>;
export type FillMessage = z.infer<typeof fillEventSchema>;
export type AdlFailedMessage = z.infer<typeof adlFailedSchema>;
export type FillSettledMessage = z.infer<typeof fillSettledSchema>;
export type FillBustedMessage = z.infer<typeof fillBustedSchema>;
export type UserCollateralUpdateMessage = z.infer<
  typeof userCollateralUpdateSchema
>;
export type AccountFundingUpdateMessage = z.infer<
  typeof accountFundingUpdateSchema
>;
export type OrderAcceptedMessage = z.infer<typeof orderAcceptedSchema>;
export type OrderRejectMessage = z.infer<typeof orderRejectEventSchema>;
export type CancelAckMessage = z.infer<typeof cancelAckSchema>;
export type ModifyAckMessage = z.infer<typeof modifyAckSchema>;
export type WithdrawStatusMessage = z.infer<typeof withdrawStatusSchema>;
export type DepositVaultStatusMessage = z.infer<
  typeof depositVaultStatusSchema
>;
export type WithdrawVaultStatusMessage = z.infer<
  typeof withdrawVaultStatusSchema
>;
export type DepositVaultRejectedMessage = z.infer<
  typeof depositVaultRejectedSchema
>;
export type WithdrawVaultRejectedMessage = z.infer<
  typeof withdrawVaultRejectedSchema
>;
export type VaultStatusMessage =
  | DepositVaultRejectedMessage
  | DepositVaultStatusMessage
  | WithdrawVaultRejectedMessage
  | WithdrawVaultStatusMessage;
