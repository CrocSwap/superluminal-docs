import { z } from "zod";
import {
  wireBigint,
  wireDecimalUint64,
  wireExternalOrderId,
} from "../wire/wireBigint";

// Wire-format Zod schema for the gateway's `order_history` event (response
// to `get_order_history`).  Validating at the boundary (per
// `docs/typescript/data.md`) lets the live client work in branded TS types
// instead of `unknown`.

// `side` and `status` are forwarded verbatim from the gateway-side
// notifier query (which mirrors the persisted enum strings). `role` is parsed because the cancel
// path needs it to match the matcher-assigned role on cancel.  The page is
// flat: `filled_qty` / `settled_qty` / `busted_qty` are gateway-aggregated
// totals and per-order lifecycle events are fetched separately with
// `get_order_events` (see `orderEventsWire.ts`).
//
// `filled_qty` is optional because the released gateway does not yet emit it
// (it lands with PR #880); the mapping falls back to
// `original_qty - remaining_qty` when it is absent.  The released gateway also
// still emits a legacy `events` field (as `null`); the schema ignores it (the
// default `z.object` strips unknown keys), so a `null` or array value passes
// through harmlessly.
const orderHistoryOrderSchema = z.object({
  busted_qty: wireBigint,
  client_instruction_id: wireDecimalUint64.optional(),
  closed_unix_ns: wireBigint.optional(),
  created_unix_ns: wireBigint,
  delta_ppm: z.number().optional(),
  execution_mode: z.number().optional(),
  external_order_id: wireExternalOrderId,
  filled_qty: wireBigint.optional(),
  last_event_seq: wireBigint,
  order_type: z.number(),
  original_qty: wireBigint,
  price: wireBigint,
  remaining_qty: wireBigint,
  role: z.enum(["MAKER", "TAKER"]).optional(),
  settled_qty: wireBigint,
  side: z.enum(["BID", "ASK"]),
  status: z.enum(["open", "filled", "canceled", "rejected"]),
  symbol: z.number(),
});

const adlHistoryRecordSchema = z.object({
  allocated_loss: wireBigint,
  batch_id: wireBigint,
  cleanup_error_code: z.number(),
  error_code: z.number(),
  event_unix_ns: wireBigint,
  failure_stage: z.number(),
  fill_price: wireBigint,
  fill_qty: wireBigint,
  last_event_seq: wireBigint,
  market_id: z.number(),
  operation_nonce: wireBigint,
  request_seq: wireBigint,
  role: z.enum(["target", "counterparty"]),
  side: z.enum(["BID", "ASK"]),
  status: z.enum(["settled", "failed"]),
  subaccount_id: wireBigint,
  workflow_error_code: z.number(),
});

export const orderHistoryEventSchema = z.object({
  adl: z.array(adlHistoryRecordSchema).default([]),
  next_cursor: z.string().optional(),
  orders: z.array(orderHistoryOrderSchema),
  request_id: z.string().optional(),
  type: z.literal("order_history"),
});

export type OrderHistoryEvent = z.infer<typeof orderHistoryEventSchema>;
export type OrderHistoryWireOrder = z.infer<typeof orderHistoryOrderSchema>;
export type AdlHistoryWireRecord = z.infer<typeof adlHistoryRecordSchema>;
