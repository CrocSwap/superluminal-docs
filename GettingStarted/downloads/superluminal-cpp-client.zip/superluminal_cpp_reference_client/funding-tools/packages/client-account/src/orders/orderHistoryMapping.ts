import type {
  AdlHistory,
  Order,
  OrderStatus,
} from "@aethon/client-protocol/order";
import type { OrderHistoryPage } from "@aethon/client-protocol/orderHistoryPage";
import type { SymbologyMarket } from "@aethon/client-protocol/symbologyMarket";
import type {
  AdlHistoryWireRecord,
  OrderHistoryEvent,
  OrderHistoryWireOrder,
} from "./orderHistoryWire";
import {
  dateFromUnixNs,
  deltaPpmForOrderType,
  dnumPrice,
  dnumSize,
  orderTypeFromWire,
  roleFromWire,
  sideFromWireSide,
} from "./orderWireFields";

// Wire -> domain mapping for the notifier's `get_order_history` response.
// Raw bigints are scaled to Dnum using the per-symbol metadata the live client
// caches at init, and the gateway's order-history status enum is mapped to the
// trading-app's. Kept separate from the socket lifecycle in `live.ts`: this is
// pure transport-to-domain translation, parameterised by the symbology lookups.
// The page is flat -- per-order lifecycle events are fetched separately with
// `get_order_events` (see `orderEventsMapping.ts`), so `events` starts empty
// here and the live overlay / on-demand fetch fill it in.

// Maps the gateway's order-history status enum to the trading-app's: `open`
// orders split into `unfilled` / `partially_filled` based on whether any
// filled qty has accumulated (the gateway exposes the raw `remaining_qty` and
// `original_qty` separately, but the UI distinguishes the two open states via
// the badge variant).
const toOrderStatus = (
  wireStatus: "open" | "filled" | "canceled" | "rejected",
  filledQty: bigint,
  bustedQty: bigint,
): OrderStatus => {
  if (bustedQty > 0n) {
    return "busted";
  }
  switch (wireStatus) {
    case "open":
      return filledQty === 0n ? "unfilled" : "partially_filled";
    case "filled":
      return "filled";
    case "canceled":
      return "cancelled";
    case "rejected":
      return "rejected";
  }
};

const toOrder = (
  wire: OrderHistoryWireOrder,
  marketsBySymbolId: ReadonlyMap<number, SymbologyMarket>,
): Order => {
  const market = marketsBySymbolId.get(wire.symbol);
  if (market === undefined) {
    throw new Error(
      `unknown symbol ${wire.symbol.toString()} in order history; symbology cache missing entry`,
    );
  } else {
    const orderType = orderTypeFromWire(wire.order_type);
    // The gateway's aggregated `filled_qty` is authoritative across every
    // status.  The released gateway does not emit it yet, so fall back to
    // `original_qty - remaining_qty`: exact for open orders and for
    // fully-filled terminal orders. `remaining_qty` is pinned to 0 on a
    // partially-filled-then-canceled order, so that one edge over-reports
    // until the gateway starts sending `filled_qty`.
    const filledQty = wire.filled_qty ?? wire.original_qty - wire.remaining_qty;
    const netFilledQty = filledQty - wire.busted_qty;
    return {
      clientInstructionId: wire.client_instruction_id,
      closedTimestamp:
        wire.closed_unix_ns === undefined
          ? undefined
          : dateFromUnixNs(wire.closed_unix_ns),
      // Retain mark-to-mid delta and market slippage; limit orders do not use
      // `delta_ppm`.
      deltaPpm: deltaPpmForOrderType(orderType, wire.delta_ppm),
      // The flat page carries no inline lifecycle events; the live overlay and
      // the on-demand `get_order_events` fetch populate this.
      events: [],
      executionMode: wire.execution_mode,
      filledSize: dnumSize(netFilledQty, market.sizeDecimals),
      id: wire.external_order_id,
      orderType,
      price: dnumPrice(wire.price, market.pxExponent),
      role: roleFromWire(wire.role),
      side: sideFromWireSide(wire.side),
      size: dnumSize(wire.original_qty, market.sizeDecimals),
      status: toOrderStatus(wire.status, netFilledQty, wire.busted_qty),
      symbol: market.symbol,
      symbolId: wire.symbol,
      timestamp: dateFromUnixNs(wire.created_unix_ns),
    };
  }
};

const toAdlOrder = (
  wire: AdlHistoryWireRecord,
  marketsBySymbolId: ReadonlyMap<number, SymbologyMarket>,
): Order => {
  const market = marketsBySymbolId.get(wire.market_id);
  if (market === undefined) {
    throw new Error(
      `unknown symbol ${wire.market_id.toString()} in ADL history; symbology cache missing entry`,
    );
  }
  const adl: AdlHistory = {
    allocatedLoss: wire.allocated_loss,
    batchId: wire.batch_id,
    cleanupErrorCode: wire.cleanup_error_code,
    errorCode: wire.error_code,
    failureStage: wire.failure_stage,
    operationNonce: wire.operation_nonce,
    requestSeq: wire.request_seq,
    role: wire.role,
    workflowErrorCode: wire.workflow_error_code,
  };
  return {
    adl,
    closedTimestamp: dateFromUnixNs(wire.event_unix_ns),
    deltaPpm: undefined,
    events: [],
    filledSize: dnumSize(wire.fill_qty, market.sizeDecimals),
    id: wire.operation_nonce,
    orderType: "adl",
    price: dnumPrice(wire.fill_price, market.pxExponent),
    role: "taker",
    side: sideFromWireSide(wire.side),
    size: dnumSize(wire.fill_qty, market.sizeDecimals),
    status: wire.status === "settled" ? "filled" : "rejected",
    symbol: market.symbol,
    symbolId: wire.market_id,
    timestamp: dateFromUnixNs(wire.event_unix_ns),
  };
};

// Convert a wire `order_history` event to the public-facing `OrderHistoryPage`,
// scaling raw bigints to Dnum using the per-symbol metadata the live client
// caches at init.
export const toOrderHistoryPage = (
  wire: OrderHistoryEvent,
  marketsBySymbolId: ReadonlyMap<number, SymbologyMarket>,
): OrderHistoryPage => ({
  nextCursor: wire.next_cursor,
  orders: [
    ...wire.orders.map((order) => ({
      order: toOrder(order, marketsBySymbolId),
      seq: order.last_event_seq,
    })),
    ...wire.adl.map((record) => ({
      order: toAdlOrder(record, marketsBySymbolId),
      seq: record.last_event_seq,
    })),
  ]
    .sort((a, b) => {
      if (a.seq === b.seq) {
        return 0;
      }
      return a.seq > b.seq ? -1 : 1;
    })
    .map((item) => item.order),
});
