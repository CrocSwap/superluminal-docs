import {
  buildOrderSignMessage,
  encodeContractOrderProof,
  encodeContractOrderV1,
} from "@aethon/client-protocol/signedWire";
import { Result } from "@cprussin/option-result";
import { awaitOrderResolution } from "../session/awaitResolution";
import { SubmitOrderError } from "../submitOrderError";
import type { SignedCommandContext } from "./signedCommand";
import {
  base64Encode,
  orderExpFor,
  orderTypeWireConfig,
  tifWireValue,
} from "./signMessage";

export type SubmitOrderParams = {
  subaccountId: bigint;
  symbol: number;
  side: "long" | "short";
  orderType: "market" | "limit" | "mark-to-mid";
  price: bigint;
  size: bigint;
  deltaPpm: number;
  tif: "gtc" | "ioc";
};

// Builds the `ContractOrderProof` envelope, has the signer produce the
// ORDER-domain-prefixed signature, then posts the base64-wrapped proof and
// waits for the sequencer-confirmed `OrderAccepted` / `OrderReject`.
export const submitOrder = (
  ctx: SignedCommandContext,
  params: SubmitOrderParams,
): Promise<Result<true, SubmitOrderError>> => {
  const iat = ctx.nowSeconds();
  // `execution_mode` is `Normal(0)` for every user-submitted order; the
  // non-Normal variants (`MaintenanceLiquidation` / `Adl`) are
  // sequencer-internal and would be rejected coming from a public
  // client (see `documentation/OnChain_Accounts.md:761-766`).
  const wireConfig = orderTypeWireConfig(params.orderType);
  // Captured so the resolution waiter can correlate the gateway's
  // `OrderAccepted` / `OrderReject` (which echo it as `client_instruction_id`)
  // back to this specific order rather than the next lifecycle frame to arrive.
  const requestId64 = ctx.generateRequestId();
  const orderBytes = encodeContractOrderV1({
    deltaPpm: params.deltaPpm,
    executionMode: 0,
    orderType: wireConfig.orderType,
    price: params.price,
    qty: params.size,
    requestId64,
    role: wireConfig.role,
    side: params.side === "long" ? 0 : 1,
    symbol: params.symbol,
    tif: tifWireValue(params.tif),
  });
  const payload = {
    exp: orderExpFor(iat, params.tif),
    iat,
    orderBytes,
    partitionId: ctx.partitionId,
    senderPubkey: ctx.senderPubkey,
    subaccountId: params.subaccountId,
  };
  const signMessage = buildOrderSignMessage(payload);
  return Result.wrapAsync(ctx.ensureAuthenticated()).then((sessionResult) =>
    sessionResult
      .mapErr((): SubmitOrderError => SubmitOrderError.Disconnected())
      .andThenAsync((socket) =>
        Result.wrapAsync(ctx.signer.signMessage(signMessage)).then(
          (sigResult) =>
            sigResult
              .mapErr(
                (cause): SubmitOrderError =>
                  SubmitOrderError.SignerRejected(
                    cause.match({ None: () => undefined, Some: (c) => c }),
                  ),
              )
              .andThenAsync((signature) => {
                const proofBytes = encodeContractOrderProof({
                  payload,
                  signature,
                  signerPubkey: ctx.senderPubkey,
                });
                // Listener attached before send so a fast-path
                // `OrderAccepted` / `OrderReject` can't race the
                // promise resolution on a busy event loop.
                const ackPromise = awaitOrderResolution<SubmitOrderError>(
                  socket,
                  requestId64,
                  {
                    disconnected: SubmitOrderError.Disconnected,
                    rejected: SubmitOrderError.Rejected,
                    timeout: SubmitOrderError.Timeout,
                  },
                );
                socket.send(
                  JSON.stringify({
                    msg_b64: base64Encode(proofBytes),
                    type: "signed_order",
                  }),
                );
                return ackPromise;
              }),
        ),
      ),
  );
};
