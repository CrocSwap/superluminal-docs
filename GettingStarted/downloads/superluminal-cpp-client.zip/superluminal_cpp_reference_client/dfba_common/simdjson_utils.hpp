#pragma once

#include <cstdint>
#include <limits>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>

#include "third_party/simdjson/simdjson.h"

namespace dfba::json {

using JsonArray = simdjson::dom::array;
using JsonElement = simdjson::dom::element;
using JsonObject = simdjson::dom::object;

inline bool parse_json_object(std::string const& text, simdjson::dom::parser& parser, JsonObject& out) {
  JsonElement root;
  if (parser.parse(text).get(root) != simdjson::SUCCESS) {
    return false;
  }
  return root.get(out) == simdjson::SUCCESS;
}

inline simdjson::error_code find_json_field(JsonObject const& object,
                                            std::string_view key,
                                            JsonElement& out) {
  return object.at_key(key).get(out);
}

template <typename T>
inline bool extract_json_field(JsonObject const& object, std::string_view key, T& out) {
  JsonElement value;
  if (find_json_field(object, key, value) != simdjson::SUCCESS) {
    return false;
  }
  if constexpr (std::is_same_v<T, std::string>) {
    std::string_view text;
    if (value.get(text) != simdjson::SUCCESS) {
      return false;
    }
    out.assign(text.data(), text.size());
    return true;
  } else if constexpr (std::is_same_v<T, uint16_t>) {
    uint64_t parsed = 0;
    if (value.get(parsed) != simdjson::SUCCESS ||
        parsed > static_cast<uint64_t>(std::numeric_limits<uint16_t>::max())) {
      return false;
    }
    out = static_cast<uint16_t>(parsed);
    return true;
  } else {
    return value.get(out) == simdjson::SUCCESS;
  }
}

inline void append_json_string(std::string& out, std::string_view value) {
  out.push_back('"');
  out += static_cast<std::string>(simdjson::internal::escape_json_string(value));
  out.push_back('"');
}

class JsonObjectBuilder {
 public:
  JsonObjectBuilder() {
    out_.push_back('{');
  }

  void string_field(std::string_view key, std::string_view value) {
    begin_field(key);
    append_json_string(out_, value);
  }

  void uint64_field(std::string_view key, uint64_t value) {
    begin_field(key);
    out_ += std::to_string(value);
  }

  void bool_field(std::string_view key, bool value) {
    begin_field(key);
    out_ += value ? "true" : "false";
  }

  std::string finish() && {
    out_.push_back('}');
    return std::move(out_);
  }

 private:
  std::string out_{};
  bool first_{true};

  void begin_field(std::string_view key) {
    if (!first_) {
      out_.push_back(',');
    }
    first_ = false;
    append_json_string(out_, key);
    out_.push_back(':');
  }
};

} // namespace dfba::json
