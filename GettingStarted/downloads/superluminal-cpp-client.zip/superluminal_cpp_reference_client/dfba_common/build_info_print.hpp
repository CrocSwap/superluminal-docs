#pragma once

#include "aethon_build_info.hpp"

#include <cstring>
#include <iostream>

namespace aethon {

inline char const* app_basename(char const* path) {
  if (path == nullptr) {
    return "";
  }
  char const* slash = std::strrchr(path, '/');
  if (slash == nullptr) {
    return path;
  }
  return slash + 1;
}

inline bool print_version_if_requested(int argc, char** argv) {
  for (int i = 1; i < argc; ++i) {
    if (std::strcmp(argv[i], "--version") == 0) {
      std::cout << app_basename(argv[0]) << " version " << build::kVersion
                << " commit " << build::kGitCommit << "\n";
      return true;
    }
  }
  return false;
}

} // namespace aethon
