#pragma once

namespace aethon::build {
inline constexpr char kVersion[] = "1.0.0";
inline constexpr char kGitCommit[] = "b8eee38d3caa";
} // namespace aethon::build
