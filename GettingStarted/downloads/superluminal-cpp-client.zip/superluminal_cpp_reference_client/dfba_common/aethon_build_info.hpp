#pragma once

namespace aethon::build {
inline constexpr char kVersion[] = "1.0.0";
inline constexpr char kGitCommit[] = "cde7384e3b6c";
} // namespace aethon::build
