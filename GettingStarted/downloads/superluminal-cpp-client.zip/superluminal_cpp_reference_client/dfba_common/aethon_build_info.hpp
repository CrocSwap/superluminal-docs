#pragma once

namespace aethon::build {
inline constexpr char kVersion[] = "1.0.0";
inline constexpr char kGitCommit[] = "7b208c4c5d59";
} // namespace aethon::build
