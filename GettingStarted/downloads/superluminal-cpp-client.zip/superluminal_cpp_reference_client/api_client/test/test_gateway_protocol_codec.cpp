#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest/doctest.h"

#include <array>
#include <charconv>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include <sodium.h>

#include "api_client/api_client_signer.h"
#include "api_client/gateway_protocol_codec.h"

namespace {

constexpr uint64_t kGtcOrderExpirySeconds = 30ULL * 24ULL * 60ULL * 60ULL;

uint32_t read_u32_le(std::vector<unsigned char> const& data, size_t offset) {
  return static_cast<uint32_t>(data[offset]) |
         (static_cast<uint32_t>(data[offset + 1U]) << 8U) |
         (static_cast<uint32_t>(data[offset + 2U]) << 16U) |
         (static_cast<uint32_t>(data[offset + 3U]) << 24U);
}

uint16_t read_u16_le(std::vector<unsigned char> const& data, size_t offset) {
  return static_cast<uint16_t>(data[offset]) |
         static_cast<uint16_t>(static_cast<uint16_t>(data[offset + 1U]) << 8U);
}

uint64_t read_u64_le(std::vector<unsigned char> const& data, size_t offset) {
  uint64_t value = 0;
  for (size_t i = 0; i < 8U; ++i) {
    value |= static_cast<uint64_t>(data[offset + i]) << (i * 8U);
  }
  return value;
}

std::vector<unsigned char> decode_base64(std::string const& text) {
  std::vector<unsigned char> out(text.size(), 0U);
  size_t out_len = 0;
  REQUIRE(sodium_base642bin(out.data(),
                            out.size(),
                            text.c_str(),
                            text.size(),
                            nullptr,
                            &out_len,
                            nullptr,
                            sodium_base64_VARIANT_ORIGINAL) == 0);
  out.resize(out_len);
  return out;
}

wallet_codec::Keypair make_test_keypair() {
  wallet_codec::Keypair keypair;
  std::array<unsigned char, crypto_sign_SEEDBYTES> seed{};
  for (size_t i = 0; i < seed.size(); ++i) {
    seed[i] = static_cast<unsigned char>(i + 1U);
  }
  REQUIRE(crypto_sign_seed_keypair(
              keypair.public_key.data(),
              keypair.secret_key.data(),
              seed.data()) == 0);
  return keypair;
}

std::string required_string(dfba::json::JsonObject const& object, std::string_view field) {
  std::string value;
  if (!dfba::json::extract_json_field(object, field, value)) [[unlikely]] {
    throw std::runtime_error("missing string field: " + std::string(field));
  }
  return value;
}

dfba::json::JsonObject required_object(dfba::json::JsonObject const& object,
                                       std::string_view field) {
  dfba::json::JsonObject value;
  if (!dfba::json::extract_json_field(object, field, value)) [[unlikely]] {
    throw std::runtime_error("missing object field: " + std::string(field));
  }
  return value;
}

uint64_t parse_u64(std::string const& text) {
  uint64_t value = 0;
  auto const result = std::from_chars(text.data(), text.data() + text.size(), value);
  if (result.ec != std::errc{} || result.ptr != text.data() + text.size()) [[unlikely]] {
    throw std::runtime_error("invalid uint64: " + text);
  }
  return value;
}

uint32_t parse_u32(std::string const& text) {
  uint64_t const value = parse_u64(text);
  if (value > std::numeric_limits<uint32_t>::max()) [[unlikely]] {
    throw std::runtime_error("uint32 out of range: " + text);
  }
  return static_cast<uint32_t>(value);
}

uint16_t parse_u16(std::string const& text) {
  uint64_t const value = parse_u64(text);
  if (value > std::numeric_limits<uint16_t>::max()) [[unlikely]] {
    throw std::runtime_error("uint16 out of range: " + text);
  }
  return static_cast<uint16_t>(value);
}

int32_t parse_i32(std::string const& text) {
  int32_t value = 0;
  auto const result = std::from_chars(text.data(), text.data() + text.size(), value);
  if (result.ec != std::errc{} || result.ptr != text.data() + text.size()) [[unlikely]] {
    throw std::runtime_error("invalid int32: " + text);
  }
  return value;
}

wallet_codec::Keypair keypair_from_seed_hex(std::string const& seed_hex) {
  std::array<unsigned char, crypto_sign_SEEDBYTES> seed{};
  size_t decoded_size = 0;
  if (sodium_hex2bin(seed.data(),
                     seed.size(),
                     seed_hex.data(),
                     seed_hex.size(),
                     nullptr,
                     &decoded_size,
                     nullptr) != 0 ||
      decoded_size != seed.size()) [[unlikely]] {
    throw std::runtime_error("invalid Ed25519 seed_hex");
  }

  wallet_codec::Keypair keypair;
  if (crypto_sign_seed_keypair(
          keypair.public_key.data(), keypair.secret_key.data(), seed.data()) != 0) [[unlikely]] {
    throw std::runtime_error("failed to derive Ed25519 keypair");
  }
  return keypair;
}

std::string encode_hex(unsigned char const* data, size_t size) {
  std::string value(size * 2U, '\0');
  sodium_bin2hex(value.data(), value.size() + 1U, data, size);
  return value;
}

} // namespace

TEST_CASE("conditional proof signs exact wire fields and reduce-only order uses mode four") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const keypair = make_test_keypair();
  api_client::ConditionalGroupDraft group;
  group.symbol = 7;
  group.qty = 2000;
  group.exit_is_sell = true;
  group.leg_flags = 3;
  group.tp_trigger_sources = 3;
  group.sl_trigger_sources = 2;
  group.immediate = false;
  group.tp_trigger_price = 5500000;
  group.sl_trigger_price = 4500000;
  group.expiry_seconds = 86400;
  std::string const group_b64 =
      api_client::ApiClientSigner::build_signed_conditional_group_proof_base64_for_sender_at(
          keypair, keypair.public_key, 1, 0, 9009, 1700000000, group);
  std::vector<unsigned char> const proof = decode_base64(group_b64);
  REQUIRE(proof.size() == 196);
  CHECK(read_u32_le(proof, 58) == 7);
  CHECK(read_u64_le(proof, 62) == 2000);
  CHECK(proof[70] == 1);
  CHECK(proof[71] == 3);
  CHECK(proof[72] == 3);
  CHECK(proof[73] == 2);
  CHECK(proof[74] == 1);
  CHECK(proof[75] == 0);
  CHECK(read_u64_le(proof, 76) == 5500000);
  CHECK(read_u64_le(proof, 84) == 4500000);
  CHECK(read_u64_le(proof, 92) == 9009);
  CHECK(read_u64_le(proof, 50) == 1700086400);
  std::string const domain("AETHEON_COND_V1\0", 16);
  std::vector<unsigned char> signed_message(domain.begin(), domain.end());
  signed_message.insert(signed_message.end(), proof.begin(), proof.begin() + 100);
  CHECK(crypto_sign_verify_detached(proof.data() + 132, signed_message.data(),
                                    signed_message.size(), proof.data() + 100) == 0);

  api_client::OrderDraft order;
  order.symbol = 7;
  order.qty = 2000;
  order.price = 5500000;
  order.reduce_only = true;
  std::vector<unsigned char> const order_proof = decode_base64(
      api_client::ApiClientSigner::build_signed_order_proof_base64_for_sender_at(
          keypair, keypair.public_key, 1, 0, 9010, 1700000000, order));
  REQUIRE(order_proof.size() == 191);
  CHECK(order_proof[80] == 4);

  std::string const parent = api_client::GatewayProtocolCodec::encode_signed_conditional_parent(
      9007199254740993ULL, "abc");
  CHECK(parent.find("\"conditional_group_external_order_id\":\"9007199254740993\"") !=
        std::string::npos);
}

TEST_CASE("conditional account snapshot and lifecycle preserve group identity") {
  std::string const payload =
      R"({"type":"AccountSnapshot","last_seq":10,"subaccounts":[{"subaccount_id":0,"positions":[],"working_orders":[],"conditional_groups":[{"group_external_order_id":101,"client_instruction_id":"9007199254740993","symbol":7,"qty":2000,"side":"ASK","state":"dormant","activation_mode":"immediate","leg_flags":3,"tp_trigger_price":5500000,"sl_trigger_price":4500000}]}]})";
  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  api_client::AccountSnapshotMessage snapshot;
  REQUIRE(api_client::GatewayProtocolCodec::decode_account_snapshot(object, snapshot));
  REQUIRE(snapshot.subaccounts.size() == 1);
  REQUIRE(snapshot.subaccounts[0].conditional_groups.size() == 1);
  CHECK(snapshot.subaccounts[0].conditional_groups[0].client_instruction_id == 9007199254740993ULL);

  std::string const triggered =
      R"({"type":"ConditionalTriggered","seq":11,"subaccount_id":0,"group_external_order_id":101,"selected_external_order_id":202})";
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(triggered, parser, object, type));
  api_client::ConditionalEventMessage event;
  REQUIRE(api_client::GatewayProtocolCodec::decode_conditional_event(object, event));
  CHECK(event.group_external_order_id == 101);
  CHECK(event.selected_external_order_id == 202);
}

TEST_CASE("adjusted reduce-only settlement requires exact quantities and applied fee") {
  std::string const adjusted =
      R"({"type":"FillSettled","seq":12,"subaccount_id":0,"external_order_id":101,"symbol":7,"side":"ASK","price":100,"qty":3,"trade_id":99,"fee":30,"adjustment_reason":"reduce_only","settled_qty":2,"reduced_qty":1,"applied_fee":20})";
  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(adjusted, parser, object, type));
  api_client::FillSettlementEventMessage event;
  REQUIRE(api_client::GatewayProtocolCodec::decode_fill_settlement_event(object, event));
  CHECK(event.reduce_only_adjustment);
  CHECK(event.trade_id == 99);
  CHECK(event.settled_qty == 2);
  CHECK(event.reduced_qty == 1);
  CHECK(event.applied_fee == 20);

  std::string const malformed =
      R"({"type":"FillSettled","seq":12,"subaccount_id":0,"external_order_id":101,"symbol":7,"side":"ASK","qty":3,"trade_id":99,"adjustment_reason":"reduce_only","settled_qty":2,"reduced_qty":2,"applied_fee":20})";
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(malformed, parser, object, type));
  CHECK_FALSE(api_client::GatewayProtocolCodec::decode_fill_settlement_event(object, event));
}

TEST_CASE("ack decoder reads reason and order ids") {
  std::string const payload =
      R"({"type":"ack","status":"rejected","request_id":"history-1","reason":"risk_rejected","client_instruction_id":"12","external_order_id":34})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "ack");

  api_client::AckMessage ack;
  REQUIRE(api_client::GatewayProtocolCodec::decode_ack(object, ack));
  CHECK(ack.status == "rejected");
  CHECK(ack.reason == "risk_rejected");
  CHECK(ack.request_id == "history-1");
  CHECK(ack.has_client_instruction_id);
  CHECK(ack.client_instruction_id == 12);
  CHECK(ack.has_external_order_id);
  CHECK(ack.external_order_id == 34);
}

TEST_CASE("ack decoder rejects unstable order identifier types") {
  std::string const numeric_client_id =
      R"({"type":"ack","status":"rejected","client_instruction_id":12,"external_order_id":34})";
  std::string const string_external_id =
      R"({"type":"ack","status":"rejected","client_instruction_id":"12","external_order_id":"34"})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  REQUIRE(dfba::json::parse_json_object(numeric_client_id, parser, object));
  api_client::AckMessage ack;
  CHECK_FALSE(api_client::GatewayProtocolCodec::decode_ack(object, ack));

  simdjson::dom::parser second_parser;
  REQUIRE(dfba::json::parse_json_object(string_external_id, second_parser, object));
  CHECK_FALSE(api_client::GatewayProtocolCodec::decode_ack(object, ack));
}

TEST_CASE("ack decoder keeps ids absent when omitted") {
  std::string const payload = R"({"type":"ack","status":"accepted"})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));

  api_client::AckMessage ack;
  REQUIRE(api_client::GatewayProtocolCodec::decode_ack(object, ack));
  CHECK(ack.status == "accepted");
  CHECK(ack.reason.empty());
  CHECK(!ack.has_client_instruction_id);
  CHECK(!ack.has_external_order_id);
}

TEST_CASE("exchange config decoder reads signed fee rates") {
  std::string const payload =
      R"({"type":"ExchangeConfigSnapshot","taker_fee_ppm":100,"maker_fee_ppm":-2,"environment":"testnet","min_deposit_amount_usd":100,"deposit_withdraw_fee_usd":1,"min_vault_deposit_amount_usd":100,"vault_creation_fee_usd":100,"leader_share_bps":1000,"leader_fee_bps":2000})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(
      payload,
      parser,
      object,
      type));
  CHECK(type == "ExchangeConfigSnapshot");

  api_client::ExchangeConfigMessage config;
  REQUIRE(api_client::GatewayProtocolCodec::decode_exchange_config(
      object,
      config));
  CHECK(config.taker_fee_ppm == 100);
  CHECK(config.maker_fee_ppm == -2);
  CHECK(config.environment == "testnet");
  CHECK(config.min_deposit_amount_usd == 100);
  CHECK(config.deposit_withdraw_fee_usd == 1);
  CHECK(config.min_vault_deposit_amount_usd == 100);
  CHECK(config.vault_creation_fee_usd == 100);
  CHECK(config.leader_share_bps == 1000);
  CHECK(config.leader_fee_bps == 2000);
}

TEST_CASE("exchange config decoder rejects fee rates outside int32") {
  std::string const payload =
      R"({"type":"ExchangeConfigSnapshot","taker_fee_ppm":2147483648,"maker_fee_ppm":0,"environment":"dev","min_deposit_amount_usd":100,"deposit_withdraw_fee_usd":1,"min_vault_deposit_amount_usd":100,"vault_creation_fee_usd":100,"leader_share_bps":1000,"leader_fee_bps":2000})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  REQUIRE(dfba::json::parse_json_object(payload, parser, object));
  api_client::ExchangeConfigMessage config;
  CHECK_FALSE(api_client::GatewayProtocolCodec::decode_exchange_config(
      object,
      config));
}

TEST_CASE("order history decoder uses stable order identifier types") {
  std::string const payload =
      R"({"orders":[{"external_order_id":123456,)"
      R"("client_instruction_id":"9007199254740993","subaccount_id":0,)"
      R"("symbol":1,"last_event_seq":2,"events":[]}]})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  REQUIRE(dfba::json::parse_json_object(payload, parser, object));

  api_client::OrderHistoryMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_order_history(object, message));
  REQUIRE(message.orders.size() == 1);
  CHECK(message.orders[0].external_order_id == 123'456);
  CHECK(message.orders[0].client_instruction_id == 9'007'199'254'740'993ULL);
}

TEST_CASE("modify ack decoder requires delta ppm") {
  std::string const payload =
      R"({"type":"ModifyAck","seq":1,"subaccount_id":7,"external_order_id":34,"qty":10})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "ModifyAck");

  api_client::ModifyAckEventMessage message;
  CHECK_FALSE(api_client::GatewayProtocolCodec::decode_modify_ack_event(object, message));
}

TEST_CASE("modify ack decoder accepts explicit zero delta ppm") {
  std::string const payload =
      R"({"type":"ModifyAck","seq":1,"subaccount_id":7,"external_order_id":34,"qty":10,"delta_ppm":0})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "ModifyAck");

  api_client::ModifyAckEventMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_modify_ack_event(object, message));
  CHECK(message.delta_ppm == 0);
}

TEST_CASE("order accepted decoder requires delta ppm") {
  std::string const payload =
      R"({"type":"OrderAccepted","seq":1,"subaccount_id":7,"external_order_id":34,)"
      R"("symbol":1,"side":"BID","qty":10})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "OrderAccepted");

  api_client::OrderAcceptedMessage message;
  CHECK_FALSE(api_client::GatewayProtocolCodec::decode_order_accepted(object, message));
}

TEST_CASE("order accepted decoder accepts explicit zero delta ppm") {
  std::string const payload =
      R"({"type":"OrderAccepted","seq":1,"subaccount_id":7,"external_order_id":34,)"
      R"("symbol":1,"side":"BID","qty":10,"delta_ppm":0})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "OrderAccepted");

  api_client::OrderAcceptedMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_order_accepted(object, message));
  CHECK(message.delta_ppm == 0);
}

TEST_CASE("order accepted decoder rejects zero external order id") {
  std::string const payload =
      R"({"type":"OrderAccepted","seq":1,"subaccount_id":7,"external_order_id":0,)"
      R"("symbol":1,"side":"BID","qty":10,"delta_ppm":0})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "OrderAccepted");

  api_client::OrderAcceptedMessage message;
  CHECK_FALSE(api_client::GatewayProtocolCodec::decode_order_accepted(object, message));
}

TEST_CASE("order accepted decoder rejects delta ppm outside int32") {
  std::string const payload =
      R"({"type":"OrderAccepted","seq":1,"subaccount_id":7,"external_order_id":34,)"
      R"("symbol":1,"side":"BID","qty":10,"delta_ppm":2147483648})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "OrderAccepted");

  api_client::OrderAcceptedMessage message;
  CHECK_FALSE(api_client::GatewayProtocolCodec::decode_order_accepted(object, message));
}

TEST_CASE("signed create vault encoder uses live gateway command") {
  CHECK(api_client::GatewayProtocolCodec::encode_signed_create_vault("abc") ==
        R"({"type":"signed_create_vault","msg_b64":"abc"})");
}

TEST_CASE("market unsubscribe encoder uses live gateway command") {
  CHECK(api_client::GatewayProtocolCodec::encode_unsubscribe_market(42) ==
        R"({"type":"unsubscribe_market","symbol":42})");
}

TEST_CASE("auth response encoder marks delegate auth") {
  CHECK(api_client::GatewayProtocolCodec::encode_auth_response("nonce", "sig", true) ==
        R"({"type":"auth_response","nonce":"nonce","signature_b64":"sig","is_delegate":true})");
}

TEST_CASE("signed order proof matches gateway wire layout") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const keypair = make_test_keypair();
  api_client::OrderDraft draft;
  draft.symbol = 7;
  draft.mode = api_client::OrderMode::MarkToMid;
  draft.role = api_client::OrderRole::Maker;
  draft.is_sell = false;
  draft.qty = 100;
  draft.price = 0;
  draft.delta_ppm = 12;

  std::vector<unsigned char> const proof =
      api_client::ApiClientSigner::build_signed_order_proof_raw(
          keypair,
          0x01,
          2,
          99,
          0,
          draft);

  REQUIRE(proof.size() == 191);
  CHECK(std::memcmp(proof.data(), keypair.public_key.data(), keypair.public_key.size()) == 0);
  CHECK(read_u16_le(proof, 32U) == 0x01);
  CHECK(read_u64_le(proof, 34U) == 2);
  CHECK(read_u64_le(proof, 50U) - read_u64_le(proof, 42U) == kGtcOrderExpirySeconds);
  CHECK(read_u32_le(proof, 58U) == 7);
  CHECK(read_u64_le(proof, 62U) == 0);
  CHECK(read_u64_le(proof, 70U) == 100);
  CHECK(proof[78U] == 1);
  CHECK(proof[79U] == 1);
  CHECK(proof[80U] == 0);
  CHECK(proof[81U] == 0);
  CHECK(read_u32_le(proof, 82U) == 12);
  CHECK(proof[86U] == 0);
  CHECK(read_u64_le(proof, 87U) == 99);

  std::vector<unsigned char> payload;
  char const domain[] = "AETHEON_ORDER_V1";
  payload.insert(payload.end(), domain, domain + std::strlen(domain));
  payload.push_back(0U);
  payload.insert(payload.end(), proof.begin(), proof.begin() + 95);
  CHECK(crypto_sign_verify_detached(
            proof.data() + 127U,
            payload.data(),
            payload.size(),
            proof.data() + 95U) == 0);
}

TEST_CASE("C++ reference matches all published conformance vectors") {
  REQUIRE(sodium_init() >= 0);
  std::ifstream input(
      std::string(AETHON_SOURCE_ROOT) + "/documentation/public/conformance/test-vectors.json");
  if (!input.good()) [[unlikely]] {
    input.close();
    input.open(std::string(AETHON_SOURCE_ROOT) + "/docs/conformance/test-vectors.json");
  }
  REQUIRE(input.good());
  std::ostringstream buffer;
  buffer << input.rdbuf();

  simdjson::dom::parser parser;
  dfba::json::JsonObject root;
  REQUIRE(dfba::json::parse_json_object(buffer.str(), parser, root));
  dfba::json::JsonObject const test_key = required_object(root, "test_key");
  wallet_codec::Keypair const keypair =
      keypair_from_seed_hex(required_string(test_key, "seed_hex"));
  CHECK(encode_hex(keypair.public_key.data(), keypair.public_key.size()) ==
        required_string(test_key, "public_key_hex"));
  CHECK(wallet_codec::WalletCodec::encode_base58(
            keypair.public_key.data(), keypair.public_key.size()) ==
        required_string(test_key, "public_key_base58"));

  dfba::json::JsonObject const authentication = required_object(root, "authentication");
  CHECK(api_client::ApiClientSigner::sign_auth_challenge_base64(
            required_string(authentication, "message_utf8"), keypair) ==
        required_string(authentication, "signature_base64"));

  dfba::json::JsonObject const signed_order = required_object(root, "signed_order");
  dfba::json::JsonObject const order = required_object(signed_order, "order");
  api_client::OrderDraft draft;
  draft.symbol = parse_u32(required_string(order, "symbol"));
  draft.price = parse_u64(required_string(order, "price"));
  draft.qty = parse_u64(required_string(order, "qty"));
  draft.delta_ppm = parse_i32(required_string(order, "delta_ppm"));
  uint64_t const tif = parse_u64(required_string(order, "tif"));
  uint64_t const order_type = parse_u64(required_string(order, "order_type"));
  REQUIRE(tif == 0);
  REQUIRE(order_type == 0);
  draft.mode = api_client::OrderMode::IocLimit;
  uint64_t const order_role = parse_u64(required_string(order, "role"));
  REQUIRE(order_role <= 1);
  draft.role = order_role == 1 ? api_client::OrderRole::Taker : api_client::OrderRole::Maker;
  uint64_t const side = parse_u64(required_string(order, "side"));
  REQUIRE(side <= 1);
  draft.is_sell = side == 1;
  uint64_t const execution_mode = parse_u64(required_string(order, "execution_mode"));
  REQUIRE(execution_mode == 0);

  std::string const order_proof =
      api_client::ApiClientSigner::build_signed_order_proof_base64_for_sender_at(
          keypair,
          keypair.public_key,
          parse_u16(required_string(signed_order, "partition_id")),
          parse_u64(required_string(signed_order, "subaccount_id")),
          parse_u64(required_string(signed_order, "request_id64")),
          parse_u64(required_string(signed_order, "fixed_unix_seconds")),
          draft);
  CHECK(order_proof == required_string(signed_order, "proof_base64"));
  uint64_t order_proof_length = 0;
  REQUIRE(dfba::json::extract_json_field(
      signed_order, "proof_length_bytes", order_proof_length));
  CHECK(decode_base64(order_proof).size() == order_proof_length);

  dfba::json::JsonObject const signed_cancel = required_object(root, "signed_cancel");
  uint64_t const cancel_role = parse_u64(required_string(signed_cancel, "role"));
  REQUIRE(cancel_role <= 1);
  std::string const cancel_proof =
      api_client::ApiClientSigner::build_signed_cancel_proof_base64_for_sender_at(
          keypair,
          keypair.public_key,
          parse_u16(required_string(signed_cancel, "partition_id")),
          parse_u64(required_string(signed_cancel, "subaccount_id")),
          parse_u64(required_string(signed_cancel, "external_order_id")),
          parse_u64(required_string(signed_cancel, "request_id64")),
          parse_u64(required_string(signed_cancel, "fixed_unix_seconds")),
          parse_u32(required_string(signed_cancel, "symbol")),
          cancel_role == 1 ? api_client::OrderRole::Taker : api_client::OrderRole::Maker);
  CHECK(cancel_proof == required_string(signed_cancel, "proof_base64"));
  uint64_t cancel_proof_length = 0;
  REQUIRE(dfba::json::extract_json_field(
      signed_cancel, "proof_length_bytes", cancel_proof_length));
  CHECK(decode_base64(cancel_proof).size() == cancel_proof_length);

  dfba::json::JsonObject identifier_encoding =
      required_object(root, "json_identifier_encoding");
  dfba::json::JsonObject client_id =
      required_object(identifier_encoding, "client_instruction_id");
  dfba::json::JsonObject original_client_id =
      required_object(identifier_encoding, "original_client_instruction_id");
  dfba::json::JsonObject external_id =
      required_object(identifier_encoding, "external_order_id");
  std::string const client_wire_value = required_string(client_id, "wire_value");
  std::string const original_client_wire_value =
      required_string(original_client_id, "wire_value");
  uint64_t external_wire_value = 0;
  REQUIRE(dfba::json::extract_json_field(external_id, "wire_value", external_wire_value));
  std::string const payload =
      R"({"orders":[{"client_instruction_id":")" + client_wire_value +
      R"(","external_order_id":)" + std::to_string(external_wire_value) +
      R"(,"subaccount_id":0,"symbol":1,"last_event_seq":1,"events":[]}]})";
  simdjson::dom::parser identifier_parser;
  dfba::json::JsonObject identifier_payload;
  REQUIRE(dfba::json::parse_json_object(payload, identifier_parser, identifier_payload));
  api_client::OrderHistoryMessage history;
  REQUIRE(api_client::GatewayProtocolCodec::decode_order_history(identifier_payload, history));
  REQUIRE(history.orders.size() == 1);
  CHECK(std::to_string(history.orders[0].client_instruction_id) ==
        required_string(client_id, "required_decimal_round_trip"));
  CHECK(std::to_string(history.orders[0].external_order_id) ==
        required_string(external_id, "required_decimal_round_trip"));

  std::string const modify_payload =
      R"({"seq":2,"subaccount_id":0,"client_instruction_id":")" + client_wire_value +
      R"(","original_client_instruction_id":")" + original_client_wire_value +
      R"(","external_order_id":)" + std::to_string(external_wire_value) +
      R"(,"qty":1,"delta_ppm":0})";
  simdjson::dom::parser modify_parser;
  dfba::json::JsonObject modify_object;
  REQUIRE(dfba::json::parse_json_object(modify_payload, modify_parser, modify_object));
  api_client::ModifyAckEventMessage modify;
  REQUIRE(api_client::GatewayProtocolCodec::decode_modify_ack_event(modify_object, modify));
  CHECK(std::to_string(modify.original_client_instruction_id) ==
        required_string(original_client_id, "required_decimal_round_trip"));

  std::string const modify_reject_payload =
      R"({"seq":3,"subaccount_id":0,"client_instruction_id":")" + client_wire_value +
      R"(","original_client_instruction_id":")" + original_client_wire_value +
      R"(","external_order_id":)" + std::to_string(external_wire_value) +
      R"(,"reason":1})";
  simdjson::dom::parser modify_reject_parser;
  dfba::json::JsonObject modify_reject_object;
  REQUIRE(dfba::json::parse_json_object(
      modify_reject_payload, modify_reject_parser, modify_reject_object));
  api_client::ModifyRejectEventMessage modify_reject;
  REQUIRE(api_client::GatewayProtocolCodec::decode_modify_reject_event(
      modify_reject_object, modify_reject));
  CHECK(std::to_string(modify_reject.original_client_instruction_id) ==
        required_string(original_client_id, "required_decimal_round_trip"));
}

TEST_CASE("signed protected market order carries reference price and slippage") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const keypair = make_test_keypair();
  api_client::OrderDraft draft;
  draft.symbol = 7;
  draft.mode = api_client::OrderMode::Market;
  draft.role = api_client::OrderRole::Taker;
  draft.is_sell = true;
  draft.qty = 100;
  draft.price = 5'000'000;
  draft.delta_ppm = 10'000;

  std::vector<unsigned char> const proof =
      api_client::ApiClientSigner::build_signed_order_proof_raw(
          keypair,
          0x01,
          2,
          99,
          0,
          draft);

  REQUIRE(proof.size() == 191);
  CHECK(read_u64_le(proof, 62U) == 5'000'000);
  CHECK(read_u64_le(proof, 70U) == 100);
  CHECK(proof[78U] == 0);
  CHECK(proof[79U] == 2);
  CHECK(proof[81U] == 1);
  CHECK(read_u32_le(proof, 82U) == 10'000);
  CHECK(proof[86U] == 1);
}

TEST_CASE("signed market order enforces reference price and slippage constraints") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const keypair = make_test_keypair();
  api_client::OrderDraft draft;
  draft.symbol = 7;
  draft.mode = api_client::OrderMode::Market;
  draft.role = api_client::OrderRole::Taker;
  draft.qty = 100;

  draft.price = 0;
  draft.delta_ppm = 1;
  CHECK_THROWS_WITH(
      api_client::ApiClientSigner::build_signed_order_proof_raw(
          keypair, 1, 2, 99, 0, draft),
      "market order slippage requires a reference price");

  draft.price = 100;
  draft.delta_ppm = 0;
  CHECK_THROWS_WITH(
      api_client::ApiClientSigner::build_signed_order_proof_raw(
          keypair, 1, 2, 99, 0, draft),
      "market order reference price requires non-zero slippage");

  draft.delta_ppm = -1;
  CHECK_THROWS_WITH(
      api_client::ApiClientSigner::build_signed_order_proof_raw(
          keypair, 1, 2, 99, 0, draft),
      "market order slippage must be nonnegative");

  draft.delta_ppm = 1'000'001;
  CHECK_THROWS_WITH(
      api_client::ApiClientSigner::build_signed_order_proof_raw(
          keypair, 1, 2, 99, 0, draft),
      "market order slippage must not exceed 1000000 ppm");

  draft.price = 0;
  draft.delta_ppm = 0;
  CHECK_NOTHROW(api_client::ApiClientSigner::build_signed_order_proof_raw(
      keypair, 1, 2, 99, 0, draft));

  draft.price = 100;
  draft.delta_ppm = 1'000'000;
  CHECK_NOTHROW(api_client::ApiClientSigner::build_signed_order_proof_raw(
      keypair, 1, 2, 99, 0, draft));
}

TEST_CASE("signed order proof at keeps mark-to-mid gtc expiry") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const keypair = make_test_keypair();
  api_client::OrderDraft draft;
  draft.symbol = 7;
  draft.mode = api_client::OrderMode::MarkToMid;
  draft.role = api_client::OrderRole::Maker;
  draft.is_sell = false;
  draft.qty = 100;
  draft.price = 0;
  draft.delta_ppm = 12;

  uint64_t const iat_sec = 1'700'000'000ULL;
  std::vector<unsigned char> const proof = decode_base64(
      api_client::ApiClientSigner::build_signed_order_proof_base64_for_sender_at(
          keypair,
          keypair.public_key,
          0x01,
          2,
          99,
          iat_sec,
          draft));

  REQUIRE(proof.size() == 191);
  CHECK(read_u64_le(proof, 42U) == iat_sec);
  CHECK(read_u64_le(proof, 50U) == iat_sec + kGtcOrderExpirySeconds);
  CHECK(proof[78U] == 1);
  CHECK(proof[79U] == 1);
}

TEST_CASE("signed order proof at can override mark-to-mid expiry") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const keypair = make_test_keypair();
  api_client::OrderDraft draft;
  draft.symbol = 7;
  draft.mode = api_client::OrderMode::MarkToMid;
  draft.role = api_client::OrderRole::Maker;
  draft.is_sell = false;
  draft.qty = 100;
  draft.price = 0;
  draft.delta_ppm = 12;

  uint64_t const iat_sec = 1'700'000'000ULL;
  uint64_t const expiry_sec = 60;
  std::vector<unsigned char> const proof = decode_base64(
      api_client::ApiClientSigner::build_signed_order_proof_base64_for_sender_at(
          keypair,
          keypair.public_key,
          0x01,
          2,
          99,
          iat_sec,
          draft,
          expiry_sec));

  REQUIRE(proof.size() == 191);
  CHECK(read_u64_le(proof, 42U) == iat_sec);
  CHECK(read_u64_le(proof, 50U) == iat_sec + expiry_sec);
  CHECK(proof[78U] == 1);
  CHECK(proof[79U] == 1);
}

TEST_CASE("signed modify proof at uses the requested renewal expiry") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const keypair = make_test_keypair();
  uint64_t const iat_sec = 1'700'000'045ULL;
  uint64_t const expiry_sec = 60;
  std::vector<unsigned char> const proof = decode_base64(
      api_client::ApiClientSigner::build_signed_modify_proof_base64_for_sender_at(
          keypair,
          keypair.public_key,
          0x01,
          2,
          123,
          100,
          iat_sec,
          1'700'000'000ULL,
          99,
          7,
          api_client::OrderRole::Maker,
          false,
          1,
          1,
          0,
          0,
          100,
          12,
          expiry_sec));

  REQUIRE(proof.size() == 215);
  CHECK(read_u64_le(proof, 42U) == iat_sec);
  CHECK(read_u64_le(proof, 50U) == iat_sec + expiry_sec);
  CHECK(read_u64_le(proof, 58U) == 123);
  CHECK(read_u64_le(proof, 66U) == 100);
  CHECK(read_u64_le(proof, 74U) == 1'700'000'000ULL);
  CHECK(read_u64_le(proof, 82U) == 99);
  CHECK(read_u64_le(proof, 99U) == 0);
  CHECK(read_u64_le(proof, 107U) == 100);
}

TEST_CASE("create vault status decoder reads finalized event") {
  std::string const payload =
      R"({"type":"CreateVaultStatus","client_instruction_id":"77","source_subaccount_id":1,)"
      R"("operation_subaccount_id":2,"vault_id":3,"status":0,"error_code":0,)"
      R"("total_vault_shares":123456})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "CreateVaultStatus");

  api_client::CreateVaultStatusMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_create_vault_status(object, message));
  CHECK(message.client_instruction_id == 77);
  CHECK(message.source_subaccount_id == 1);
  CHECK(message.operation_subaccount_id == 2);
  CHECK(message.vault_id == 3);
  CHECK(message.status == 0);
  CHECK(message.error_code == 0);
  CHECK(message.has_total_vault_shares);
  CHECK(message.total_vault_shares == 123'456);
}

TEST_CASE("create vault status decoder reads existing-vault decision event") {
  std::string const payload =
      R"({"type":"CreateVault","client_instruction_id":"88","source_subaccount_id":1,)"
      R"("operation_subaccount_id":2,"vault_id":4,"status":1,"error_code":0})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "CreateVault");

  api_client::CreateVaultStatusMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_create_vault_status(object, message));
  CHECK(message.client_instruction_id == 88);
  CHECK(message.source_subaccount_id == 1);
  CHECK(message.operation_subaccount_id == 2);
  CHECK(message.vault_id == 4);
  CHECK(message.status == 1);
  CHECK(message.error_code == 0);
  CHECK(!message.has_total_vault_shares);
}

TEST_CASE("create vault status decoder accepts omitted zero source subaccount and vault id") {
  std::string const payload =
      R"({"type":"CreateVault","client_instruction_id":"88","operation_subaccount_id":1,)"
      R"("status":1,"error_code":0})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "CreateVault");

  api_client::CreateVaultStatusMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_create_vault_status(object, message));
  CHECK(message.client_instruction_id == 88);
  CHECK(message.source_subaccount_id == 0);
  CHECK(message.operation_subaccount_id == 1);
  CHECK(message.vault_id == 0);
  CHECK(message.status == 1);
  CHECK(message.error_code == 0);
}

TEST_CASE("vault operation subaccount collateral change decoder reads deposit and withdraw fields") {
  std::string const payload =
      R"({"type":"VaultOperationSubaccountCollateralChange","seq":19,)"
      R"("client_instruction_id":"77","subaccount_id":2,"source_subaccount_id":1,)"
      R"("destination_subaccount_id":3,"operation_subaccount_id":2,)"
      R"("operation_subaccount_pubkey":"op","vault_account_pubkey":"vault",)"
      R"("participant_account_pubkey":"participant","deposit_amount":100,)"
      R"("minted_vault_shares":99,"requested_vault_shares":50,)"
      R"("actual_withdraw_amount":48,"leader_fee_amount":2,)"
      R"("previous_total_vault_shares":1000,"total_vault_shares":1049,)"
      R"("status":0,"error_code":0,"batch_id":9,"term":4})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "VaultOperationSubaccountCollateralChange");

  api_client::VaultOperationSubaccountCollateralChangeMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_vault_operation_subaccount_collateral_change(
      object,
      message));
  CHECK(message.seq == 19);
  CHECK(message.client_instruction_id == 77);
  CHECK(message.subaccount_id == 2);
  CHECK(message.source_subaccount_id == 1);
  CHECK(message.destination_subaccount_id == 3);
  CHECK(message.operation_subaccount_id == 2);
  CHECK(message.operation_subaccount_pubkey == "op");
  CHECK(message.vault_account_pubkey == "vault");
  CHECK(message.participant_account_pubkey == "participant");
  CHECK(message.deposit_amount == 100);
  CHECK(message.minted_vault_shares == 99);
  CHECK(message.requested_vault_shares == 50);
  CHECK(message.actual_withdraw_amount == 48);
  CHECK(message.leader_fee_amount == 2);
  CHECK(message.previous_total_vault_shares == 1000);
  CHECK(message.total_vault_shares == 1049);
  CHECK(message.status == 0);
  CHECK(message.error_code == 0);
  CHECK(message.batch_id == 9);
  CHECK(message.term == 4);
}

TEST_CASE("signed create vault proof matches gateway wire layout") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const keypair = make_test_keypair();
  std::string const msg_b64 =
      api_client::ApiClientSigner::build_signed_create_vault_proof_base64(
          keypair,
          0x01,
          1,
          9,
          2,
          1'000'000,
          100'000,
          77);

  std::vector<unsigned char> const proof = decode_base64(msg_b64);
  REQUIRE(proof.size() == 194);
  CHECK(std::memcmp(proof.data(), keypair.public_key.data(), keypair.public_key.size()) == 0);
  CHECK(read_u16_le(proof, 32U) == 0x01);
  CHECK(read_u64_le(proof, 34U) == 1);
  CHECK(read_u64_le(proof, 50U) == read_u64_le(proof, 42U) + 300U);
  CHECK(read_u32_le(proof, 58U) == 9);
  CHECK(read_u32_le(proof, 62U) == 0);
  CHECK(read_u64_le(proof, 66U) == 2);
  CHECK(read_u64_le(proof, 74U) == 1'000'000);
  CHECK(read_u64_le(proof, 82U) == 100'000);
  CHECK(read_u64_le(proof, 90U) == 77);

  std::vector<unsigned char> payload;
  char const domain[] = "AETHEON_CREATE_VAULT_V1";
  payload.insert(payload.end(), domain, domain + std::strlen(domain));
  payload.push_back(0U);
  payload.insert(payload.end(), proof.begin(), proof.begin() + 98);
  CHECK(crypto_sign_verify_detached(
            proof.data() + 130U,
            payload.data(),
            payload.size(),
            proof.data() + 98U) == 0);
}

TEST_CASE("signed create vault proof can use delegate signer") {
  REQUIRE(sodium_init() >= 0);
  wallet_codec::Keypair const signing_keypair = make_test_keypair();
  std::array<unsigned char, 32> sender_pubkey{};
  for (size_t i = 0; i < sender_pubkey.size(); ++i) {
    sender_pubkey[i] = static_cast<unsigned char>(200U - i);
  }

  std::string const msg_b64 =
      api_client::ApiClientSigner::build_signed_create_vault_proof_base64_for_sender(
          signing_keypair,
          sender_pubkey,
          0x01,
          0,
          9,
          2,
          1'000'000,
          100'000,
          77);

  std::vector<unsigned char> const proof = decode_base64(msg_b64);
  REQUIRE(proof.size() == 194);
  CHECK(std::memcmp(proof.data(), sender_pubkey.data(), sender_pubkey.size()) == 0);
  CHECK(read_u64_le(proof, 34U) == 0);
  CHECK(std::memcmp(proof.data() + 98U, signing_keypair.public_key.data(), signing_keypair.public_key.size()) == 0);

  std::vector<unsigned char> payload;
  char const domain[] = "AETHEON_CREATE_VAULT_V1";
  payload.insert(payload.end(), domain, domain + std::strlen(domain));
  payload.push_back(0U);
  payload.insert(payload.end(), proof.begin(), proof.begin() + 98);
  CHECK(crypto_sign_verify_detached(
            proof.data() + 130U,
            payload.data(),
            payload.size(),
            proof.data() + 98U) == 0);
}

TEST_CASE("account snapshot decoder reads position cost basis and pending fees") {
  std::string const payload =
      R"({"type":"AccountSnapshot","last_seq":77,"subaccounts":[{"subaccount_id":7,)"
      R"("positions":[{"symbol":1,"net_qty":10,"cost_basis":1234560,"pending_fees":-4,)"
      R"("realized_pnl":99,"funding_accrued":-25,"last_funding_index_e8":25000000}],)"
      R"("working_orders":[]}]})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "AccountSnapshot");

  api_client::AccountSnapshotMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_account_snapshot(object, message));
  CHECK(message.last_seq == 77);
  REQUIRE(message.subaccounts.size() == 1);
  CHECK(message.subaccounts.front().collateral_balance == 0);
  REQUIRE(message.subaccounts.front().positions.size() == 1);
  api_client::AccountSnapshotMessage::Position const& position = message.subaccounts.front().positions.front();
  CHECK(position.symbol == 1);
  CHECK(position.net_qty == 10);
  CHECK(position.cost_basis == 1'234'560);
  CHECK(position.pending_fees == -4);
  CHECK(position.realized_pnl == 99);
  CHECK(position.funding_accrued == -25);
  CHECK(position.last_funding_index_e8 == 25'000'000);
}

TEST_CASE("account snapshot decoder reads collateral balance") {
  std::string const payload =
      R"({"type":"AccountSnapshot","last_seq":77,"subaccounts":[{"subaccount_id":7,)"
      R"("collateral_balance":123456789,"positions":[],"working_orders":[]}]})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "AccountSnapshot");

  api_client::AccountSnapshotMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_account_snapshot(object, message));
  REQUIRE(message.subaccounts.size() == 1);
  CHECK(message.subaccounts.front().subaccount_id == 7);
  CHECK(message.subaccounts.front().collateral_balance == 123'456'789);
}

TEST_CASE("account snapshot decoder reads vault accounts") {
  std::string const payload =
      R"({"type":"AccountSnapshot","last_seq":77,"subaccounts":[{"subaccount_id":7,)"
      R"("positions":[],"working_orders":[]}],)"
      R"("vault_accounts":[{"vault_account_pubkey":"vault-abc","vault_id":3,"operation_subaccount_id":7,)"
      R"("leader_source_subaccount_id":0,"collateral_amount":123456789,)"
      R"("total_vault_shares":120000000,"last_seq":76}]})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "AccountSnapshot");

  api_client::AccountSnapshotMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_account_snapshot(object, message));
  REQUIRE(message.vault_accounts.size() == 1);
  api_client::AccountSnapshotMessage::VaultAccount const& vault = message.vault_accounts.front();
  CHECK(vault.vault_account_pubkey == "vault-abc");
  CHECK(vault.vault_id == 3);
  CHECK(vault.operation_subaccount_id == 7);
  CHECK(vault.leader_source_subaccount_id == 0);
  CHECK(vault.collateral_amount == 123'456'789);
  CHECK(vault.total_vault_shares == 120'000'000);
  CHECK(vault.last_seq == 76);
}

TEST_CASE("vault account performance codec round trips gateway fields") {
  CHECK(api_client::GatewayProtocolCodec::encode_get_vault_account_perf(
            "vault-abc",
            "douro-vault-perf-7",
            100) ==
        R"({"type":"get_vault_account_perf","vault_account":"vault-abc","request_id":"douro-vault-perf-7","limit":100})");

  std::string const payload =
      R"({"type":"vault_account_perf","request_id":"douro-vault-perf-7",)"
      R"("vault_account_pubkey":"vault-abc","events":[)"
      R"({"datetime":"2026-09-14T12:00:00Z","total_vault_shares":200000000,)"
      R"("total_equity":250000000,"leader_share_percentage":"25.0000000000"},)"
      R"({"datetime":"2026-08-15T12:00:00Z","total_vault_shares":100000000,)"
      R"("total_equity":100000000,"leader_share_percentage":"50.0000000000"}]})";
  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(
      payload, parser, object, type));
  CHECK(type == "vault_account_perf");

  api_client::VaultAccountPerfMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_vault_account_perf(
      object, message));
  CHECK(message.request_id == "douro-vault-perf-7");
  CHECK(message.vault_account_pubkey == "vault-abc");
  REQUIRE(message.events.size() == 2);
  CHECK(message.events[0].datetime == "2026-09-14T12:00:00Z");
  CHECK(message.events[0].total_vault_shares == 200'000'000);
  CHECK(message.events[0].total_equity == 250'000'000);
  CHECK(message.events[1].total_vault_shares == 100'000'000);
  CHECK(message.events[1].total_equity == 100'000'000);
}

TEST_CASE("order reject decoder reads notifier account event") {
  std::string const payload =
      R"({"seq":51,"type":"OrderReject","reason":3,"subaccount_id":7,"external_order_id":88,)"
      R"("client_instruction_id":"99","symbol":65536,"side":"BID","role":"TAKER","tif":"IOC",)"
      R"("order_type":1,"price":12345,"qty":50,"delta_ppm":-7,"matcher_unix_ns":1003,)"
      R"("sequencer_recv_unix_ns":1001})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "OrderReject");

  api_client::OrderRejectMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_order_reject(object, message));
  CHECK(message.seq == 51);
  CHECK(message.reason == 3);
  CHECK(message.subaccount_id == 7);
  CHECK(message.external_order_id == 88);
  CHECK(message.client_instruction_id == 99);
  CHECK(message.symbol == 65536);
  CHECK(message.side == "BID");
  CHECK(message.role == "TAKER");
  CHECK(message.tif == "IOC");
  CHECK(message.order_type == 1);
  CHECK(message.price == 12'345);
  CHECK(message.qty == 50);
  CHECK(message.delta_ppm == -7);
  CHECK(message.has_matcher_unix_ns);
  CHECK(message.matcher_unix_ns == 1003);
  CHECK(message.has_sequencer_recv_unix_ns);
  CHECK(message.sequencer_recv_unix_ns == 1001);
}

TEST_CASE("fill decoder reads fee") {
  std::string const payload =
      R"({"seq":54,"type":"Fill","subaccount_id":7,"external_order_id":88,)"
      R"("client_instruction_id":"99","trade_id":123,"symbol":1,"side":"BID",)"
      R"("role":"TAKER","price":12345,"qty":50,"fee":-4})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "Fill");

  api_client::FillEventMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_fill_event(object, message));
  CHECK(message.seq == 54);
  CHECK(message.subaccount_id == 7);
  CHECK(message.price == 12'345);
  CHECK(message.qty == 50);
  CHECK(message.has_fee);
  CHECK(message.fee == -4);
}

TEST_CASE("fill decoder reads unsolicited liquidation fill") {
  std::string const payload =
      R"({"seq":54,"type":"Fill","subaccount_id":7,"client_instruction_id":"99",)"
      R"("trade_id":123,"symbol":1,"side":"ASK","role":"TAKER",)"
      R"("price":12345,"qty":50,"execution_mode":1})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "Fill");

  api_client::FillEventMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_fill_event(object, message));
  CHECK(message.external_order_id == 0);
  CHECK(message.has_execution_mode);
  CHECK(message.execution_mode == 1);
}

TEST_CASE("account funding update decoder reads funding materialization") {
  std::string const payload =
      R"({"seq":71,"type":"AccountFundingUpdate","subaccount_id":7,"symbol":1,"market_id":17,)"
      R"("prev_funding_index_e8":100,"last_funding_index_e8":250,)"
      R"("funding_delta":-12,"funding_accrued":-44})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "AccountFundingUpdate");

  api_client::AccountFundingUpdateMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_account_funding_update(object, message));
  CHECK(message.seq == 71);
  CHECK(message.subaccount_id == 7);
  CHECK(message.symbol == 1);
  CHECK(message.market_id == 17);
  CHECK(message.prev_funding_index_e8 == 100);
  CHECK(message.last_funding_index_e8 == 250);
  CHECK(message.funding_delta == -12);
  CHECK(message.funding_accrued == -44);
}

TEST_CASE("account funding update decoder accepts omitted zero funding fields") {
  std::string const payload =
      R"({"seq":71,"type":"AccountFundingUpdate","subaccount_id":7,"market_id":70000,)"
      R"("last_funding_index_e8":250,"funding_delta":12})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "AccountFundingUpdate");

  api_client::AccountFundingUpdateMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_account_funding_update(object, message));
  CHECK(message.seq == 71);
  CHECK(message.subaccount_id == 7);
  CHECK(message.symbol == 70000);
  CHECK(message.market_id == 70000);
  CHECK(message.prev_funding_index_e8 == 0);
  CHECK(message.last_funding_index_e8 == 250);
  CHECK(message.funding_delta == 12);
  CHECK(message.funding_accrued == 0);
}

TEST_CASE("user collateral update decoder reads delta and total") {
  std::string const payload =
      R"({"seq":72,"type":"UserCollateralUpdate","subaccount_id":7,)"
      R"("collateral_delta":-1000,"collateral_balance":-9000})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "UserCollateralUpdate");

  api_client::UserCollateralUpdateMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_user_collateral_update(object, message));
  CHECK(message.seq == 72);
  CHECK(message.subaccount_id == 7);
  CHECK(message.collateral_delta == -1000);
  CHECK(message.collateral_balance == -9000);
}

TEST_CASE("user collateral update decoder preserves zero sequence for consumer validation") {
  std::string const payload =
      R"({"seq":0,"type":"UserCollateralUpdate","subaccount_id":7,)"
      R"("collateral_delta":-1000,"collateral_balance":-9000})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));

  api_client::UserCollateralUpdateMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_user_collateral_update(object, message));
  CHECK(message.seq == 0);
}

TEST_CASE("funding index decoder reads market entries") {
  std::string const payload =
      R"({"seq":80,"type":"FundingIndex","oracle_price_batch_id":700,)"
      R"("entries":[{"market_id":1,"perp_price":12345,"premium_e8":2500,)"
      R"("cum_funding_index_e8":123456789}]})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "FundingIndex");

  api_client::FundingIndexMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_funding_index(object, message));
  CHECK(message.seq == 80);
  CHECK(message.has_oracle_price_batch_id);
  CHECK(message.oracle_price_batch_id == 700);
  REQUIRE(message.entries.size() == 1);
  CHECK(message.entries[0].market_id == 1);
  CHECK(message.entries[0].perp_price == 12'345);
  CHECK(message.entries[0].premium_e8 == 2'500);
  CHECK(message.entries[0].cum_funding_index_e8 == 123'456'789);
}

TEST_CASE("local order reject decoder reads gateway validation reject") {
  std::string const payload =
      R"({"type":"OrderReject","reason":"Permission Denied","client_instruction_id":"99",)"
      R"("gateway_send_unix_ns":1003})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "OrderReject");

  api_client::LocalOrderRejectMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_local_order_reject(object, message));
  CHECK(message.reason == "Permission Denied");
  CHECK(message.has_client_instruction_id);
  CHECK(message.client_instruction_id == 99);
  CHECK(!message.has_external_order_id);
  CHECK(message.has_gateway_send_unix_ns);
  CHECK(message.gateway_send_unix_ns == 1003);
}

TEST_CASE("order reject decoder accepts sparse numeric account event") {
  std::string const payload =
      R"({"seq":53,"type":"OrderReject","reason":3,"subaccount_id":7,)"
      R"("external_order_id":88,"client_instruction_id":"99"})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "OrderReject");

  api_client::OrderRejectMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_order_reject(object, message));
  CHECK(message.seq == 53);
  CHECK(message.reason == 3);
  CHECK(message.subaccount_id == 7);
  CHECK(message.external_order_id == 88);
  CHECK(message.client_instruction_id == 99);
  CHECK(message.symbol == 0);
  CHECK(message.side.empty());
  CHECK(message.qty == 0);
}

TEST_CASE("account snapshot decoder reads working order mtm fields") {
  std::string const payload =
      R"({"type":"AccountSnapshot","last_seq":99,"subaccounts":[{"subaccount_id":7,)"
      R"("positions":[],"working_orders":[{"external_order_id":88,"client_instruction_id":"99",)"
      R"("original_iat":1700000000,"symbol":1,"side":"ASK","role":"MAKER","tif":"GTC","order_type":1,"execution_mode":4,"price":0,)"
      R"("original_qty":50,"filled_qty":20,"remaining_qty":25,"delta_ppm":1234}]}]})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "AccountSnapshot");

  api_client::AccountSnapshotMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_account_snapshot(object, message));
  CHECK(message.last_seq == 99);
  REQUIRE(message.subaccounts.size() == 1);
  REQUIRE(message.subaccounts[0].working_orders.size() == 1);
  api_client::AccountSnapshotMessage::WorkingOrder const& order =
      message.subaccounts[0].working_orders[0];
  CHECK(order.external_order_id == 88);
  CHECK(order.client_instruction_id == 99);
  CHECK(order.original_iat == 1700000000);
  CHECK(order.symbol == 1);
  CHECK(order.side == "ASK");
  CHECK(order.role == "MAKER");
  CHECK(order.tif == "GTC");
  CHECK(order.order_type == 1);
  CHECK(order.execution_mode == 4);
  CHECK(order.price == 0);
  CHECK(order.original_qty == 50);
  CHECK(order.filled_qty == 20);
  CHECK(order.remaining_qty == 25);
  CHECK(order.delta_ppm == 1234);
}

TEST_CASE("fill decoder reads explicit zero remaining qty") {
  std::string const payload =
      R"({"seq":54,"type":"Fill","subaccount_id":7,"external_order_id":88,)"
      R"("client_instruction_id":"99","trade_id":100,"symbol":1,"side":"BID",)"
      R"("role":"MAKER","price":12345,"qty":50,"remaining_qty":0})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "Fill");

  api_client::FillEventMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_fill_event(object, message));
  CHECK(message.seq == 54);
  CHECK(message.subaccount_id == 7);
  CHECK(message.external_order_id == 88);
  CHECK(message.client_instruction_id == 99);
  CHECK(message.trade_id == 100);
  CHECK(message.symbol == 1);
  CHECK(message.side == "BID");
  CHECK(message.role == "MAKER");
  CHECK(message.price == 12'345);
  CHECK(message.qty == 50);
  CHECK(message.has_remaining_qty);
  CHECK(message.remaining_qty == 0);
}

TEST_CASE("ADL failed decoder reads terminal failure details") {
  std::string const payload =
      R"({"seq":54,"type":"AdlFailed","subaccount_id":7,"operation_nonce":100,)"
      R"("request_seq":99,"batch_id":55,"market_id":1,"side":"ASK","role":"counterparty",)"
      R"("price":12345,"qty":50,"allocated_loss":500,"status":1,"error_code":6087,)"
      R"("workflow_error_code":20005,"cleanup_error_code":20007,"failure_stage":5,)"
      R"("error_domain":"svm","error":"AdlCounterpartyMaintenanceBreach",)"
      R"("error_message":"maintenance margin breach"})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "AdlFailed");

  api_client::AdlFailedMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_adl_failed(object, message));
  CHECK(message.operation_nonce == 100);
  CHECK(message.market_id == 1);
  CHECK(message.role == "counterparty");
  CHECK(message.qty == 50);
  CHECK(message.error_code == 6087);
  CHECK(message.workflow_error_code == 20005);
  CHECK(message.cleanup_error_code == 20007);
  CHECK(message.failure_stage == 5);
}

TEST_CASE("order history decoder reads ADL outcomes") {
  std::string const payload =
      R"({"type":"order_history","orders":[],"adl":[{)"
      R"("operation_nonce":100,"request_seq":99,"batch_id":55,"subaccount_id":7,"market_id":1,)"
      R"("side":"ASK","role":"counterparty","fill_price":12345,"fill_qty":50,)"
      R"("allocated_loss":500,"status":"failed","error_code":6087,)"
      R"("workflow_error_code":20005,"cleanup_error_code":20007,"failure_stage":5,)"
      R"("event_unix_ns":1000000,"last_event_seq":54}]})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));

  api_client::OrderHistoryMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_order_history(object, message));
  REQUIRE(message.adl.size() == 1);
  api_client::OrderHistoryMessage::Adl const& adl = message.adl.front();
  CHECK(adl.operation_nonce == 100);
  CHECK(adl.status == "failed");
  CHECK(adl.error_code == 6087);
  CHECK(adl.last_event_seq == 54);
}

TEST_CASE("cancel ack decoder reads optional reason") {
  std::string const payload =
      R"({"seq":52,"type":"CancelAck","reason":5,"subaccount_id":7,)"
      R"("external_order_id":88,"client_instruction_id":"99",)"
      R"("matcher_unix_ns":1003,"sequencer_recv_unix_ns":1001})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "CancelAck");

  api_client::CancelAckEventMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_cancel_ack_event(object, message));
  CHECK(message.seq == 52);
  CHECK(message.reason == 5);
  CHECK(message.subaccount_id == 7);
  CHECK(message.external_order_id == 88);
  CHECK(message.client_instruction_id == 99);
  CHECK(message.has_matcher_unix_ns);
  CHECK(message.matcher_unix_ns == 1003);
  CHECK(message.has_sequencer_recv_unix_ns);
  CHECK(message.sequencer_recv_unix_ns == 1001);
}

TEST_CASE("cancel reject decoder reads notifier account event") {
  std::string const payload =
      R"({"seq":52,"type":"CancelReject","reason":2,"subaccount_id":7,)"
      R"("external_order_id":88,"client_instruction_id":"99",)"
      R"("matcher_unix_ns":1003,"sequencer_recv_unix_ns":1001})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "CancelReject");

  api_client::CancelRejectEventMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_cancel_reject_event(object, message));
  CHECK(message.seq == 52);
  CHECK(message.reason == 2);
  CHECK(message.subaccount_id == 7);
  CHECK(message.external_order_id == 88);
  CHECK(message.client_instruction_id == 99);
  CHECK(message.has_matcher_unix_ns);
  CHECK(message.matcher_unix_ns == 1003);
  CHECK(message.has_sequencer_recv_unix_ns);
  CHECK(message.sequencer_recv_unix_ns == 1001);
}

TEST_CASE("inactive position settlement decoder reads audited account values") {
  std::string const payload =
      R"({"seq":60,"type":"InactivePositionSettlementStatus","subaccount_id":7,)"
      R"("symbol":3,"market_id":3,"position_index":0,"position_qty":-25,)"
      R"("workflow_change_count":9,"status":0,"error_code":0,"audit_event_present":true,)"
      R"("collateral_balance":1234,"fees_accrued_after":5,"net_funding_after":-6,)"
      R"("position_count_after":1})";

  simdjson::dom::parser parser;
  dfba::json::JsonObject object;
  std::string type;
  REQUIRE(api_client::GatewayProtocolCodec::parse_message_type(payload, parser, object, type));
  CHECK(type == "InactivePositionSettlementStatus");

  api_client::InactivePositionSettlementStatusMessage message;
  REQUIRE(api_client::GatewayProtocolCodec::decode_inactive_position_settlement_status(object, message));
  CHECK(message.seq == 60);
  CHECK(message.subaccount_id == 7);
  CHECK(message.market_id == 3);
  CHECK(message.position_qty == -25);
  CHECK(message.workflow_change_count == 9);
  CHECK(message.audit_event_present);
  CHECK(message.has_collateral_balance);
  CHECK(message.collateral_balance == 1234);
  CHECK(message.fees_accrued_after == 5);
  CHECK(message.net_funding_after == -6);
  CHECK(message.has_position_count_after);
  CHECK(message.position_count_after == 1);
}
