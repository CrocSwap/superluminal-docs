#include "price_ladder_view.h"

#include <algorithm>
#include <cerrno>
#include <cstdlib>
#include <functional>
#include <iomanip>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>

#include <ftxui/component/event.hpp>
#include <ftxui/dom/elements.hpp>
#include <ftxui/screen/terminal.hpp>

#include "price_grid.h"
#include "qty_utils.h"

namespace {

using api_client::LadderRow;
using api_client::MarketInfo;
using api_client::OrderDraft;
using api_client::OrderMode;
using api_client::OrderRole;
using api_client::PriceLadderClient;
using api_client::SymbolView;
using api_client::UiSnapshot;

constexpr int kOrderTicketWidth = 40;
constexpr int kLogPanelHeight = 12;
constexpr int kAccountPanelHeight = 10;
constexpr int kLadderQtyWidth = 12;
constexpr int kLadderColumnGapWidth = 2;
constexpr int kWindowBorderWidth = 2;

std::string format_latency_ns(double latency_ns) {
  std::ostringstream out;
  out << std::fixed << std::setprecision(2);
  if (latency_ns >= 1000000.0) {
    out << (latency_ns / 1000000.0) << " ms";
  } else if (latency_ns >= 1000.0) {
    out << (latency_ns / 1000.0) << " us";
  } else {
    out << latency_ns << " ns";
  }
  return out.str();
}

std::string format_avg_latency(double avg_ns, uint64_t samples) {
  std::ostringstream out;
  out << format_latency_ns(avg_ns);
  out << " avg";
  out << " n=" << samples;
  return out.str();
}

std::string format_fee_rate_bps(int32_t fee_ppm) {
  std::ostringstream out;
  out << std::fixed << std::setprecision(2) << (static_cast<double>(fee_ppm) / 100.0);
  return out.str();
}

std::string format_settled_qty(uint64_t qty, MarketInfo const *market) {
  if (market == nullptr) {
    return std::to_string(qty);
  }
  return api_client::qty_utils::format_qty(qty, market->size_decimals);
}

std::string format_fill_settlement_status(UiSnapshot::FillRow const &fill, MarketInfo const *market) {
  if (fill.adl_failed) [[unlikely]] {
    std::string status = "adl=failed e=" + std::to_string(fill.error_code);
    if (fill.workflow_error_code != 0) {
      status += " w=" + std::to_string(fill.workflow_error_code);
    }
    if (fill.cleanup_error_code != 0) {
      status += " c=" + std::to_string(fill.cleanup_error_code);
    }
    if (fill.failure_stage != 0) {
      status += " s=" + std::to_string(fill.failure_stage);
    }
    return status;
  }
  std::string status;
  if (!fill.settled) {
    status = "settle=pending";
  } else if (!fill.has_settle_delta_ns) {
    status = "settle=settled";
  } else {
    status = "settle=settled dt=" + format_latency_ns(static_cast<double>(fill.settle_delta_ns));
  }
  if (fill.has_order_settled_qty) {
    status += " order_settled_qty=" + format_settled_qty(fill.order_settled_qty, market);
  }
  return status;
}

std::string format_book_price(SymbolView const &book, uint64_t price) {
  if (!book.has_symbology) {
    return std::to_string(price);
  }
  return api_client::price_grid::format_price(price, book.px_exponent);
}

std::string format_book_mid_price(SymbolView const &book) {
  if (!book.has_mid) {
    return "n/a";
  }
  return api_client::price_grid::format_mid_price(
      book.best_bid_price, book.best_ask_price, book.px_exponent);
}

std::string format_mark_to_mid_delta(int32_t delta_ppm, MarketInfo const *market) {
  (void)market;
  std::string out = std::to_string(delta_ppm);
  out += " ppm";
  return out;
}

bool parse_delta_ppm(std::string const &text, int32_t &out) {
  char *end = nullptr;
  errno = 0;
  long const parsed = std::strtol(text.c_str(), &end, 10);
  if (errno != 0 || end == text.c_str() || *end != '\0') {
    return false;
  }
  if (parsed < static_cast<long>(std::numeric_limits<int32_t>::min()) ||
      parsed > static_cast<long>(std::numeric_limits<int32_t>::max())) {
    return false;
  }
  out = static_cast<int32_t>(parsed);
  return true;
}

bool pow10_i128(uint32_t exp, __int128_t &out) {
  __int128_t value = 1;
  for (uint32_t i = 0; i < exp; ++i) {
    value *= 10;
  }
  out = value;
  return true;
}

bool notional_to_usd_micro(
    uint64_t price,
    int16_t price_exponent,
    int64_t qty,
    uint8_t size_decimals,
    int64_t &out) {
  __int128_t scaled = static_cast<__int128_t>(price) * static_cast<__int128_t>(qty);
  int const exponent = static_cast<int>(price_exponent) - static_cast<int>(size_decimals);
  if (exponent > -6) {
    __int128_t factor = 1;
    if (!pow10_i128(static_cast<uint32_t>(exponent + 6), factor)) {
      return false;
    }
    scaled *= factor;
  } else if (exponent < -6) {
    __int128_t divisor = 1;
    if (!pow10_i128(static_cast<uint32_t>(-6 - exponent), divisor) || divisor == 0) {
      return false;
    }
    scaled /= divisor;
  }
  if (scaled > static_cast<__int128_t>(std::numeric_limits<int64_t>::max()) ||
      scaled < static_cast<__int128_t>(std::numeric_limits<int64_t>::min())) {
    return false;
  }
  out = static_cast<int64_t>(scaled);
  return true;
}

std::string format_fixed_decimal_i64(int64_t value, size_t decimals) {
  bool const negative = value < 0;
  uint64_t magnitude =
      negative ? static_cast<uint64_t>(-(value + 1)) + 1U : static_cast<uint64_t>(value);
  std::string digits = std::to_string(magnitude);
  if (digits.size() <= decimals) {
    digits.insert(0, decimals - digits.size() + 1U, '0');
  }
  digits.insert(digits.size() - decimals, 1U, '.');
  while (!digits.empty() && digits.back() == '0') {
    digits.pop_back();
  }
  if (!digits.empty() && digits.back() == '.') {
    digits.pop_back();
  }
  if (negative && digits != "0") {
    digits.insert(digits.begin(), '-');
  }
  return digits;
}

std::string format_usd_micro(int64_t value) {
  constexpr size_t kUsdDecimals = 6;
  return format_fixed_decimal_i64(value, kUsdDecimals);
}

std::string format_e8(int64_t value) {
  constexpr size_t kE8Decimals = 8;
  return format_fixed_decimal_i64(value, kE8Decimals);
}

std::string format_funding_index(SymbolView const &book) {
  if (!book.has_funding_index) {
    return "n/a";
  }
  return format_e8(book.funding_index_e8);
}

std::string format_position_pnl(
    UiSnapshot::PositionRow const &position,
    SymbolView const *book,
    MarketInfo const *market) {
  if (position.net_qty == 0) {
    return format_usd_micro(position.realized_pnl - position.cost_basis);
  }
  if (book == nullptr || market == nullptr) {
    return "n/a";
  }
  uint64_t pnl_price = 0;
  int16_t pnl_exponent = market->px_exponent;
  if (book->has_mid) {
    if (book->best_bid_price > (std::numeric_limits<uint64_t>::max() - book->best_ask_price)) {
      return "n/a";
    }
    uint64_t const sum = book->best_bid_price + book->best_ask_price;
    pnl_price = sum / 2U;
    if ((sum % 2U) != 0U) {
      if (sum > (std::numeric_limits<uint64_t>::max() / 5U)) {
        return "n/a";
      }
      pnl_price = sum * 5U;
      pnl_exponent = static_cast<int16_t>(pnl_exponent - 1);
    }
  } else if (book->has_mark_price) {
    pnl_price = book->mark_price;
  } else {
    return "n/a";
  }
  int64_t mark_value = 0;
  if (!notional_to_usd_micro(pnl_price, pnl_exponent, position.net_qty, market->size_decimals, mark_value)) {
    return "n/a";
  }
  return format_usd_micro(mark_value - position.cost_basis + position.realized_pnl);
}

int ladder_price_width(SymbolView const &book) {
  size_t width = format_book_mid_price(book).size();
  for (LadderRow const &row : book.asks) {
    width = std::max(width, format_book_price(book, row.price).size());
  }
  for (LadderRow const &row : book.bids) {
    width = std::max(width, format_book_price(book, row.price).size());
  }
  return static_cast<int>(std::max<size_t>(1, width));
}

std::string build_book_title(SymbolView const &book) {
  std::string title = "Feed " +
                      (book.symbol.empty()
                           ? std::to_string(book.feed_id)
                           : std::to_string(book.feed_id) + " " + book.symbol) +
                      "  seq=" + std::to_string(book.seq) +
                      "  sync=" + (book.synced ? "yes" : "no") +
                      "  fund_idx=" + format_funding_index(book);
  return title;
}

struct BookRenderData {
  SymbolView const *book{nullptr};
  std::string title{};
  int price_width{1};
  int window_width{0};
};

BookRenderData build_book_render_data(SymbolView const &book) {
  BookRenderData out;
  out.book = &book;
  out.title = build_book_title(book);
  out.price_width = ladder_price_width(book);
  int const ladder_row_width =
      kLadderQtyWidth + kLadderColumnGapWidth + out.price_width +
      kLadderColumnGapWidth + kLadderQtyWidth;
  int const title_width = static_cast<int>(out.title.size()) + 4;
  out.window_width = std::max(ladder_row_width + kWindowBorderWidth, title_width);
  return out;
}

int max_scroll_offset_for_lines(int line_count, int viewport_height) {
  return std::max(0, line_count - viewport_height);
}

int clamp_scroll_offset_for_lines(int offset, int line_count, int viewport_height) {
  return std::clamp(offset, 0, max_scroll_offset_for_lines(line_count, viewport_height));
}

int scrollbar_thumb_size_for_lines(int line_count, int viewport_height) {
  if (line_count <= viewport_height) {
    return 0;
  }
  int const thumb_size = (viewport_height * viewport_height) / line_count;
  return std::max(1, thumb_size);
}

int scrollbar_thumb_top_for_lines(int line_count, int viewport_height, int offset) {
  int const thumb_size = scrollbar_thumb_size_for_lines(line_count, viewport_height);
  if (thumb_size == 0) {
    return 0;
  }
  int const max_offset = std::max(1, max_scroll_offset_for_lines(line_count, viewport_height));
  int const track_span = std::max(0, viewport_height - thumb_size);
  return (offset * track_span) / max_offset;
}

std::string scrollbar_cell_for_row(int row, int thumb_top, int thumb_size) {
  if (thumb_size == 0) {
    return " ";
  }
  if (row >= thumb_top && row < thumb_top + thumb_size) {
    return "#";
  }
  return "|";
}

ftxui::Element render_scrollbar(int line_count, int offset, int viewport_height) {
  std::vector<ftxui::Element> rows;
  rows.reserve(static_cast<size_t>(viewport_height));
  int const thumb_top = scrollbar_thumb_top_for_lines(line_count, viewport_height, offset);
  int const thumb_size = scrollbar_thumb_size_for_lines(line_count, viewport_height);
  for (int row = 0; row < viewport_height; ++row) {
    rows.push_back(ftxui::text(scrollbar_cell_for_row(row, thumb_top, thumb_size)));
  }
  return ftxui::vbox(std::move(rows));
}

void sync_scrolling_entries(
    std::vector<std::string> const &next_entries,
    std::vector<std::string> &entries,
    int &scroll_offset,
    int viewport_height) {
  if (entries == next_entries) {
    return;
  }

  bool const follow_tail =
      entries.empty() ||
      scroll_offset >= std::max(0, static_cast<int>(entries.size()) - viewport_height);
  int const previous_offset = scroll_offset;
  size_t trim_count = 0;
  for (; trim_count <= entries.size(); ++trim_count) {
    size_t const preserved_count = entries.size() - trim_count;
    if (preserved_count > next_entries.size()) {
      continue;
    }

    bool matches = true;
    for (size_t i = 0; i < preserved_count; ++i) {
      if (entries[trim_count + i] != next_entries[i]) {
        matches = false;
        break;
      }
    }
    if (matches) {
      break;
    }
  }
  entries = next_entries;

  if (entries.empty()) {
    scroll_offset = 0;
    return;
  }

  int const max_scroll_offset = std::max(0, static_cast<int>(entries.size()) - viewport_height);
  if (follow_tail) {
    scroll_offset = max_scroll_offset;
    return;
  }

  if (previous_offset < 0) {
    scroll_offset = 0;
    return;
  }

  if (static_cast<size_t>(previous_offset) < trim_count) {
    scroll_offset = 0;
    return;
  }

  int const next_offset = previous_offset - static_cast<int>(trim_count);
  scroll_offset = std::clamp(next_offset, 0, max_scroll_offset);
}

ftxui::Element render_text_panel(
    std::string const &title_base,
    std::string const &empty_text,
    ftxui::Component const &component,
    std::vector<std::string> const &entries,
    int scroll_offset,
    int viewport_height) {
  ftxui::Element list;
  if (entries.empty()) {
    list = ftxui::text(empty_text) |
           ftxui::dim |
           ftxui::size(ftxui::HEIGHT, ftxui::EQUAL, viewport_height);
  } else {
    list = component->Render() |
           ftxui::size(ftxui::HEIGHT, ftxui::EQUAL, viewport_height);
  }

  int const line_count = static_cast<int>(entries.size());
  int const first_line = line_count == 0 ? 0 : scroll_offset + 1;
  int const last_line = line_count == 0 ? 0 : std::min(scroll_offset + viewport_height, line_count);
  std::string title = title_base;
  if (component->Focused()) {
    title += " [scroll]";
  }

  return ftxui::window(
             ftxui::text(title),
             ftxui::vbox({
                 std::move(list),
                 ftxui::separator(),
                 ftxui::text(
                     "lines " + std::to_string(first_line) + "-" + std::to_string(last_line) +
                     "/" + std::to_string(line_count)) |
                     ftxui::dim,
                 ftxui::text("Tab focus, arrows or j/k scroll, PgUp/PgDn jump") | ftxui::dim,
             })) |
         ftxui::flex;
}

ftxui::Element render_ladder_row(
    std::string const &left,
    std::string const &price,
    std::string const &right,
    int price_width) {
  return ftxui::hbox({
      ftxui::text(left) | ftxui::size(ftxui::WIDTH, ftxui::EQUAL, kLadderQtyWidth),
      ftxui::text(std::string(kLadderColumnGapWidth, ' ')),
      ftxui::text(price) | ftxui::size(ftxui::WIDTH, ftxui::EQUAL, price_width),
      ftxui::text(std::string(kLadderColumnGapWidth, ' ')),
      ftxui::text(right) | ftxui::size(ftxui::WIDTH, ftxui::EQUAL, kLadderQtyWidth),
  });
}

MarketInfo const *find_market_info(
    std::map<uint32_t, MarketInfo> const &markets,
    uint32_t symbol) {
  auto const it = markets.find(symbol);
  if (it == markets.end()) {
    return nullptr;
  }
  return &it->second;
}

std::string format_symbol_label(uint32_t symbol, MarketInfo const *market) {
  if (market == nullptr || market->symbol.empty()) {
    return std::to_string(symbol);
  }
  return std::to_string(symbol) + " " + format_market_symbol(*market);
}

class TextViewportComponent : public ftxui::ComponentBase {
 public:
  TextViewportComponent(
      std::vector<std::string> *entries,
      int *scroll_offset,
      int viewport_height)
      : entries_(entries),
        scroll_offset_(scroll_offset),
        viewport_height_(viewport_height) {
  }

  bool Focusable() const override {
    return entries_ != nullptr && !entries_->empty();
  }

  ftxui::Element OnRender() override {
    std::vector<ftxui::Element> rows;
    rows.reserve(static_cast<size_t>(viewport_height_));

    int const line_count = static_cast<int>(entries_->size());
    int const offset = clamp_scroll_offset(*scroll_offset_);
    int const end = std::min(offset + viewport_height_, line_count);
    int const thumb_top = scrollbar_thumb_top(line_count, offset);
    int const thumb_size = scrollbar_thumb_size(line_count);
    for (int i = offset; i < end; ++i) {
      int const row = i - offset;
      rows.push_back(ftxui::hbox({
          ftxui::text((*entries_)[static_cast<size_t>(i)]) | ftxui::xflex,
          ftxui::text(scrollbar_cell(row, thumb_top, thumb_size)),
      }));
    }
    while (static_cast<int>(rows.size()) < viewport_height_) {
      int const row = static_cast<int>(rows.size());
      rows.push_back(ftxui::hbox({
          ftxui::text("") | ftxui::xflex,
          ftxui::text(scrollbar_cell(row, thumb_top, thumb_size)),
      }));
    }
    return ftxui::vbox(std::move(rows)) | ftxui::reflect(box_);
  }

  bool OnEvent(ftxui::Event event) override {
    if (event.is_mouse()) {
      return on_mouse_event(event);
    }
    if (!Focused()) {
      return false;
    }

    int next_offset = *scroll_offset_;
    if (event == ftxui::Event::ArrowUp || event == ftxui::Event::Character('k')) {
      next_offset--;
    }
    if (event == ftxui::Event::ArrowDown || event == ftxui::Event::Character('j')) {
      next_offset++;
    }
    if (event == ftxui::Event::PageUp) {
      next_offset -= viewport_height_;
    }
    if (event == ftxui::Event::PageDown) {
      next_offset += viewport_height_;
    }
    if (event == ftxui::Event::Home) {
      next_offset = 0;
    }
    if (event == ftxui::Event::End) {
      next_offset = max_scroll_offset();
    }

    next_offset = clamp_scroll_offset(next_offset);
    if (next_offset == *scroll_offset_) {
      return false;
    }
    *scroll_offset_ = next_offset;
    return true;
  }

 private:
  std::vector<std::string> *entries_{nullptr};
  int *scroll_offset_{nullptr};
  int viewport_height_{0};
  ftxui::Box box_{};

  int max_scroll_offset() const {
    return max_scroll_offset_for_lines(static_cast<int>(entries_->size()), viewport_height_);
  }

  int clamp_scroll_offset(int offset) const {
    return clamp_scroll_offset_for_lines(offset, static_cast<int>(entries_->size()), viewport_height_);
  }

  int scrollbar_thumb_size(int line_count) const {
    return scrollbar_thumb_size_for_lines(line_count, viewport_height_);
  }

  int scrollbar_thumb_top(int line_count, int offset) const {
    return scrollbar_thumb_top_for_lines(line_count, viewport_height_, offset);
  }

  static std::string scrollbar_cell(int row, int thumb_top, int thumb_size) {
    return scrollbar_cell_for_row(row, thumb_top, thumb_size);
  }

  bool on_mouse_event(ftxui::Event event) {
    if (!box_.Contain(event.mouse().x, event.mouse().y)) {
      return false;
    }
    if (event.mouse().button == ftxui::Mouse::WheelUp) {
      int const next_offset = clamp_scroll_offset(*scroll_offset_ - 1);
      if (next_offset == *scroll_offset_) {
        return false;
      }
      *scroll_offset_ = next_offset;
      return true;
    }
    if (event.mouse().button == ftxui::Mouse::WheelDown) {
      int const next_offset = clamp_scroll_offset(*scroll_offset_ + 1);
      if (next_offset == *scroll_offset_) {
        return false;
      }
      *scroll_offset_ = next_offset;
      return true;
    }
    if (event.mouse().button == ftxui::Mouse::Left &&
        event.mouse().motion == ftxui::Mouse::Pressed) {
      TakeFocus();
      return true;
    }
    return false;
  }
};

class PriceLadderComponent : public ftxui::ComponentBase {
 public:
  explicit PriceLadderComponent(PriceLadderClient &client);

  ftxui::Element OnRender() override;
  bool OnEvent(ftxui::Event event) override;

 private:
  struct InteractiveWorkingOrder {
    uint64_t subaccount_id{0};
    UiSnapshot::WorkingOrderRow order{};
  };

  PriceLadderClient &client_;
  std::vector<std::string> symbol_entries_{};
  std::vector<std::string> side_entries_{"Buy", "Sell"};
  std::vector<std::string> role_entries_{"Maker", "Taker"};
  std::vector<std::string> order_mode_entries_{"GTC", "Mark-to-mid", "Market"};
  int root_panel_index_{0};
  int symbol_index_{0};
  int side_index_{0};
  int role_index_{0};
  int order_mode_index_{0};
  int account_panel_index_{0};
  int bottom_panel_index_{0};
  int working_order_index_{0};
  int position_scroll_offset_{0};
  int fill_scroll_offset_{0};
  int trade_scroll_offset_{0};
  int log_scroll_offset_{0};
  std::string qty_input_{"0.001"};
  std::string price_input_{};
  std::string delta_ppm_input_{};
  std::string form_error_{};
  std::string working_orders_error_{};
  std::string modify_price_input_{};
  std::string modify_qty_input_{};
  bool modify_dialog_open_{false};
  InteractiveWorkingOrder modifying_order_{};
  UiSnapshot snapshot_{};
  std::vector<InteractiveWorkingOrder> interactive_working_orders_{};
  std::vector<std::string> position_entries_{};
  std::vector<std::string> fill_entries_{};
  std::vector<std::string> trade_entries_{};
  std::vector<std::string> log_entries_{};
  ftxui::Component root_container_{};
  ftxui::Component account_panel_container_{};
  ftxui::Component account_panel_component_{};
  ftxui::Component bottom_panel_container_{};
  ftxui::Component bottom_panels_component_{};
  ftxui::Component order_form_{};
  ftxui::Component positions_component_{};
  ftxui::Component positions_panel_component_{};
  ftxui::Component working_orders_container_{};
  ftxui::Component working_orders_panel_component_{};
  ftxui::Component fills_component_{};
  ftxui::Component fills_panel_component_{};
  ftxui::Component trades_component_{};
  ftxui::Component trades_panel_component_{};
  ftxui::Component log_component_{};
  ftxui::Component symbol_toggle_{};
  ftxui::Component symbol_toggle_maybe_{};
  ftxui::Component side_toggle_{};
  ftxui::Component role_toggle_{};
  ftxui::Component order_mode_radiobox_{};
  ftxui::Component qty_input_component_{};
  ftxui::Component price_input_component_{};
  ftxui::Component price_input_maybe_{};
  ftxui::Component delta_ppm_input_component_{};
  ftxui::Component delta_ppm_input_maybe_{};
  ftxui::Component place_order_button_{};
  ftxui::Component modify_price_input_component_{};
  ftxui::Component modify_qty_input_component_{};
  ftxui::Component modify_ok_button_{};
  ftxui::Component modify_cancel_button_{};
  ftxui::Component modify_buttons_component_{};
  ftxui::Component modify_dialog_container_{};
  ftxui::Component modify_dialog_component_{};

  static ftxui::Element render_header(UiSnapshot const &snapshot);
  static ftxui::Element render_book(BookRenderData const &book_data);
  static ftxui::Element render_ask_row(LadderRow const &row, SymbolView const &book, int price_width);
  static ftxui::Element render_bid_row(LadderRow const &row, SymbolView const &book, int price_width);
  static ftxui::Element render_mid_row(SymbolView const &book, int price_width);
  ftxui::Element render_books_panel(UiSnapshot const &snapshot, int available_width) const;
  ftxui::Element render_order_ticket(UiSnapshot const &snapshot);
  ftxui::Element render_account_panel() const;
  ftxui::Element render_positions_panel() const;
  ftxui::Element render_working_orders_panel() const;
  ftxui::Element render_fills_panel() const;
  ftxui::Element render_trades_panel() const;
  ftxui::Element render_bottom_panels() const;
  ftxui::Element render_log_panel() const;
  ftxui::Element render_preview(UiSnapshot const &snapshot) const;
  ftxui::Element render_working_order_label(size_t index) const;
  ftxui::Element render_working_order_label_focus(size_t index, bool focused) const;
  ftxui::Element render_modify_dialog() const;
  static ftxui::Element render_labeled_control(std::string const &label, ftxui::Component const &component);
  OrderMode selected_order_mode() const;
  uint32_t selected_symbol() const;
  bool show_symbol_toggle() const;
  bool show_price_input() const;
  bool show_delta_ppm_input() const;
  bool build_order_draft(UiSnapshot const &snapshot, OrderDraft &draft, std::string &error) const;
  void apply_normalized_order_inputs(OrderDraft const &draft, MarketInfo const *market);
  void sync_account_entries(UiSnapshot const &snapshot);
  void sync_trade_component(UiSnapshot const &snapshot);
  void sync_working_order_components(UiSnapshot const &snapshot);
  void sync_log_component(UiSnapshot const &snapshot);
  bool working_orders_match(std::vector<InteractiveWorkingOrder> const &next_orders) const;
  static std::vector<InteractiveWorkingOrder> flatten_working_orders(UiSnapshot const &snapshot);
  static bool working_order_matches(
      InteractiveWorkingOrder const &lhs,
      InteractiveWorkingOrder const &rhs);
  ftxui::Component make_working_order_component(size_t index);
  void submit_order();
  void submit_cancel_order(uint64_t subaccount_id, uint64_t external_order_id);
  void open_modify_dialog(size_t index);
  void submit_modify_dialog();
  void cancel_modify_dialog();
  bool parse_modify_inputs(uint64_t &price, uint64_t &qty, std::string &error) const;
  SymbolView const *find_selected_book(UiSnapshot const &snapshot) const;
  static SymbolView const *find_book(UiSnapshot const &snapshot, uint32_t symbol);
  int find_selected_book_index(UiSnapshot const &snapshot) const;
  MarketInfo const *find_market(uint32_t symbol) const;
  static std::string format_price(uint64_t price, MarketInfo const *market);
  static std::string format_qty(double qty, uint8_t size_decimals);
  static std::string format_atomic_qty(uint64_t qty, MarketInfo const *market);
  static std::string format_signed_atomic_qty(int64_t qty, MarketInfo const *market);
};

PriceLadderComponent::PriceLadderComponent(PriceLadderClient &client)
    : client_(client) {
  std::map<uint32_t, MarketInfo> const &markets = client_.markets();
  std::vector<uint32_t> const &feed_ids = client_.feed_ids();
  symbol_entries_.reserve(feed_ids.size());
  for (uint32_t feed_id : feed_ids) {
    symbol_entries_.push_back(format_symbol_label(feed_id, find_market_info(markets, feed_id)));
  }

  symbol_toggle_ = ftxui::Toggle(&symbol_entries_, &symbol_index_);
  symbol_toggle_maybe_ =
      ftxui::Maybe(symbol_toggle_, std::bind(&PriceLadderComponent::show_symbol_toggle, this));
  side_toggle_ = ftxui::Toggle(&side_entries_, &side_index_);
  role_toggle_ = ftxui::Toggle(&role_entries_, &role_index_);
  order_mode_radiobox_ = ftxui::Radiobox(&order_mode_entries_, &order_mode_index_);
  qty_input_component_ = ftxui::Input(&qty_input_, "qty");
  price_input_component_ = ftxui::Input(&price_input_, "price");
  price_input_maybe_ =
      ftxui::Maybe(price_input_component_, std::bind(&PriceLadderComponent::show_price_input, this));
  delta_ppm_input_component_ = ftxui::Input(&delta_ppm_input_, "delta");
  delta_ppm_input_maybe_ = ftxui::Maybe(
      delta_ppm_input_component_, std::bind(&PriceLadderComponent::show_delta_ppm_input, this));
  place_order_button_ =
      ftxui::Button("Place Order", std::bind(&PriceLadderComponent::submit_order, this),
                    ftxui::ButtonOption::Border());
  modify_price_input_component_ = ftxui::Input(&modify_price_input_, "price");
  modify_qty_input_component_ = ftxui::Input(&modify_qty_input_, "qty");
  modify_ok_button_ =
      ftxui::Button("OK", std::bind(&PriceLadderComponent::submit_modify_dialog, this),
                    ftxui::ButtonOption::Border());
  modify_cancel_button_ =
      ftxui::Button("Cancel", std::bind(&PriceLadderComponent::cancel_modify_dialog, this),
                    ftxui::ButtonOption::Border());
  modify_buttons_component_ = ftxui::Container::Horizontal({
      modify_ok_button_,
      modify_cancel_button_,
  });
  modify_dialog_container_ = ftxui::Container::Vertical({
      modify_price_input_component_,
      modify_qty_input_component_,
      modify_buttons_component_,
  });
  modify_dialog_component_ =
      ftxui::Renderer(modify_dialog_container_, std::bind(&PriceLadderComponent::render_modify_dialog, this));
  positions_component_ =
      std::make_shared<TextViewportComponent>(&position_entries_, &position_scroll_offset_, kAccountPanelHeight);
  working_orders_container_ = ftxui::Container::Vertical({}, &working_order_index_);
  fills_component_ =
      std::make_shared<TextViewportComponent>(&fill_entries_, &fill_scroll_offset_, kAccountPanelHeight);
  trades_component_ =
      std::make_shared<TextViewportComponent>(&trade_entries_, &trade_scroll_offset_, kLogPanelHeight);
  log_component_ = std::make_shared<TextViewportComponent>(&log_entries_, &log_scroll_offset_, kLogPanelHeight);

  order_form_ = ftxui::Container::Vertical({
      symbol_toggle_maybe_,
      side_toggle_,
      role_toggle_,
      order_mode_radiobox_,
      qty_input_component_,
      price_input_maybe_,
      delta_ppm_input_maybe_,
      place_order_button_,
  });
  positions_panel_component_ =
      ftxui::Renderer(positions_component_, std::bind(&PriceLadderComponent::render_positions_panel, this));
  working_orders_panel_component_ = ftxui::Renderer(
      working_orders_container_,
      std::bind(&PriceLadderComponent::render_working_orders_panel, this));
  fills_panel_component_ =
      ftxui::Renderer(fills_component_, std::bind(&PriceLadderComponent::render_fills_panel, this));
  trades_panel_component_ =
      ftxui::Renderer(trades_component_, std::bind(&PriceLadderComponent::render_trades_panel, this));
  account_panel_container_ = ftxui::Container::Horizontal({
                                                              positions_panel_component_,
                                                              working_orders_panel_component_,
                                                              fills_panel_component_,
                                                          },
                                                          &account_panel_index_);
  account_panel_component_ =
      ftxui::Renderer(account_panel_container_, std::bind(&PriceLadderComponent::render_account_panel, this));
  bottom_panel_container_ = ftxui::Container::Horizontal({
                                                             trades_panel_component_,
                                                             log_component_,
                                                         },
                                                         &bottom_panel_index_);
  bottom_panels_component_ =
      ftxui::Renderer(bottom_panel_container_, std::bind(&PriceLadderComponent::render_bottom_panels, this));
  root_container_ = ftxui::Container::Vertical({
                                                   order_form_,
                                                   account_panel_component_,
                                                   bottom_panels_component_,
                                               },
                                               &root_panel_index_);
  Add(root_container_);
}

ftxui::Element PriceLadderComponent::OnRender() {
  snapshot_ = client_.snapshot();
  sync_account_entries(snapshot_);
  sync_trade_component(snapshot_);
  sync_working_order_components(snapshot_);
  sync_log_component(snapshot_);
  int const terminal_width = ftxui::Terminal::Size().dimx;
  int const available_books_width = std::max(1, terminal_width - kOrderTicketWidth - 2);
  ftxui::Element body =
      ftxui::vbox({
          ftxui::hbox({
              render_books_panel(snapshot_, available_books_width) |
                  ftxui::size(ftxui::WIDTH, ftxui::EQUAL, available_books_width),
              ftxui::filler(),
              render_order_ticket(snapshot_) |
                  ftxui::size(ftxui::WIDTH, ftxui::EQUAL, kOrderTicketWidth),
          }),
          ftxui::separator(),
          account_panel_component_->Render(),
          ftxui::separator(),
          bottom_panels_component_->Render(),
      }) |
      ftxui::border;
  if (!modify_dialog_open_) {
    return body;
  }
  return ftxui::dbox({
      std::move(body),
      modify_dialog_component_->Render() | ftxui::clear_under | ftxui::center,
  });
}

bool PriceLadderComponent::OnEvent(ftxui::Event event) {
  if (modify_dialog_open_) {
    if (event == ftxui::Event::Escape) {
      cancel_modify_dialog();
      return true;
    }
    return modify_dialog_container_->OnEvent(event);
  }
  if (event == ftxui::Event::Character('q') || event == ftxui::Event::Escape ||
      event == ftxui::Event::CtrlC) {
    client_.request_stop();
    return true;
  }
  return ftxui::ComponentBase::OnEvent(event);
}

ftxui::Element PriceLadderComponent::render_books_panel(
    UiSnapshot const &snapshot,
    int available_width) const {
  std::vector<ftxui::Element> children;
  children.push_back(render_header(snapshot));

  if (!snapshot.last_error.empty()) {
    children.push_back(ftxui::text("error: " + snapshot.last_error) | ftxui::color(ftxui::Color::Red));
  }

  if (snapshot.books.empty()) {
    children.push_back(ftxui::window(ftxui::text("Price Ladder"),
                                     ftxui::text("No symbols configured") | ftxui::dim));
  } else {
    int const selected_book_index = find_selected_book_index(snapshot);
    if (selected_book_index < 0) {
      children.push_back(ftxui::window(ftxui::text("Price Ladder"),
                                       ftxui::text("waiting for selected symbol book...") |
                                           ftxui::dim));
    } else {
      std::vector<BookRenderData> book_data;
      book_data.reserve(snapshot.books.size());
      for (SymbolView const &book : snapshot.books) {
        book_data.push_back(build_book_render_data(book));
      }

      int visible_start = selected_book_index;
      int visible_end = selected_book_index;
      int visible_width = book_data[static_cast<size_t>(selected_book_index)].window_width;

      while (true) {
        bool const can_take_left = visible_start > 0;
        bool const can_take_right = visible_end + 1 < static_cast<int>(book_data.size());
        if (!can_take_left && !can_take_right) {
          break;
        }

        int const left_width = can_take_left
                                   ? book_data[static_cast<size_t>(visible_start - 1)].window_width + 1
                                   : std::numeric_limits<int>::max();
        int const right_width = can_take_right
                                    ? book_data[static_cast<size_t>(visible_end + 1)].window_width + 1
                                    : std::numeric_limits<int>::max();

        bool expanded = false;
        if (left_width <= right_width) {
          if (can_take_left && visible_width + left_width <= available_width) {
            visible_width += left_width;
            --visible_start;
            expanded = true;
          } else if (can_take_right && visible_width + right_width <= available_width) {
            visible_width += right_width;
            ++visible_end;
            expanded = true;
          }
        } else {
          if (can_take_right && visible_width + right_width <= available_width) {
            visible_width += right_width;
            ++visible_end;
            expanded = true;
          } else if (can_take_left && visible_width + left_width <= available_width) {
            visible_width += left_width;
            --visible_start;
            expanded = true;
          }
        }

        if (!expanded) {
          break;
        }
      }

      std::vector<ftxui::Element> visible_books;
      visible_books.reserve(static_cast<size_t>(visible_end - visible_start + 1));
      for (int i = visible_start; i <= visible_end; ++i) {
        if (!visible_books.empty()) {
          visible_books.push_back(ftxui::text(" "));
        }
        visible_books.push_back(render_book(book_data[static_cast<size_t>(i)]));
      }
      children.push_back(
          ftxui::hbox({
              ftxui::filler(),
              ftxui::hbox(std::move(visible_books)),
              ftxui::filler(),
          }) |
          ftxui::size(ftxui::WIDTH, ftxui::EQUAL, available_width));
    }
  }

  children.push_back(ftxui::text("q or Esc to quit") | ftxui::dim);
  return ftxui::vbox(std::move(children));
}

ftxui::Element PriceLadderComponent::render_order_ticket(UiSnapshot const &snapshot) {
  std::vector<ftxui::Element> rows;
  MarketInfo const *selected_market = find_market(selected_symbol());

  rows.push_back(ftxui::text("Feed " + format_symbol_label(selected_symbol(), selected_market)) |
                 ftxui::bold);
  rows.push_back(ftxui::separator());

  if (show_symbol_toggle()) {
    rows.push_back(ftxui::text("Symbol") | ftxui::bold);
    rows.push_back(symbol_toggle_maybe_->Render());
    rows.push_back(ftxui::separator());
  }

  rows.push_back(ftxui::text("Side") | ftxui::bold);
  rows.push_back(side_toggle_->Render());
  rows.push_back(ftxui::separator());

  rows.push_back(ftxui::text("Role") | ftxui::bold);
  rows.push_back(role_toggle_->Render());
  rows.push_back(ftxui::separator());

  rows.push_back(ftxui::text("Order") | ftxui::bold);
  rows.push_back(order_mode_radiobox_->Render());
  rows.push_back(ftxui::separator());

  rows.push_back(render_labeled_control("Qty", qty_input_component_));
  if (show_price_input()) {
    std::string const price_label =
        selected_order_mode() == OrderMode::Market ? "Reference" : "Price";
    rows.push_back(render_labeled_control(price_label, price_input_component_));
    if (selected_market != nullptr && selected_order_mode() == OrderMode::GtcLimit) {
      rows.push_back(ftxui::text(
                         "Grid: exponent=" + std::to_string(selected_market->px_exponent) +
                         " size_decimals=" + std::to_string(selected_market->size_decimals)) |
                     ftxui::dim);
    }
  }
  if (show_delta_ppm_input()) {
    std::string const delta_label =
        selected_order_mode() == OrderMode::Market ? "Slippage" : "Delta";
    rows.push_back(render_labeled_control(delta_label, delta_ppm_input_component_));
    if (selected_order_mode() == OrderMode::Market) {
      rows.push_back(ftxui::text("Protected market slippage: 1..1000000 ppm.") |
                     ftxui::dim);
    } else {
      rows.push_back(ftxui::text("Signed delta in ppm from mark.") |
                     ftxui::dim);
    }
  }
  if (selected_order_mode() == OrderMode::Market) {
    rows.push_back(ftxui::text(
                       "Market maps to IOC and requires taker role. Leave reference and slippage blank for unrestricted.") |
                   ftxui::dim);
  }

  rows.push_back(ftxui::separator());
  rows.push_back(ftxui::text("Preview") | ftxui::bold);
  rows.push_back(render_preview(snapshot));

  if (!form_error_.empty()) {
    rows.push_back(ftxui::separator());
    rows.push_back(ftxui::text(form_error_) | ftxui::color(ftxui::Color::Red));
  }

  rows.push_back(ftxui::separator());
  rows.push_back(place_order_button_->Render());
  return ftxui::window(ftxui::text("Order Ticket"), ftxui::vbox(std::move(rows)));
}

ftxui::Element PriceLadderComponent::render_account_panel() const {
  std::vector<ftxui::Element> body;
  body.push_back(ftxui::text("last_seq=" + std::to_string(snapshot_.account_last_seq)));
  body.push_back(ftxui::separator());
  body.push_back(account_panel_container_->Render());
  return ftxui::window(ftxui::text("Account"), ftxui::vbox(std::move(body)));
}

ftxui::Element PriceLadderComponent::render_positions_panel() const {
  std::string title = "Positions";
  if (positions_component_->Focused()) {
    title += " [scroll]";
  }
  return ftxui::window(ftxui::text(title), positions_component_->Render()) | ftxui::flex;
}

ftxui::Element PriceLadderComponent::render_working_orders_panel() const {
  std::vector<ftxui::Element> body;
  if (!working_orders_error_.empty()) {
    body.push_back(ftxui::text(working_orders_error_) | ftxui::color(ftxui::Color::Red));
    body.push_back(ftxui::separator());
  }

  ftxui::Element orders;
  if (!snapshot_.account_stream_started) {
    orders = ftxui::text("account stream not subscribed") |
             ftxui::dim |
             ftxui::size(ftxui::HEIGHT, ftxui::EQUAL, kAccountPanelHeight);
  } else if (!snapshot_.has_account_snapshot) {
    orders = ftxui::text("waiting for account snapshot...") |
             ftxui::dim |
             ftxui::size(ftxui::HEIGHT, ftxui::EQUAL, kAccountPanelHeight);
  } else if (interactive_working_orders_.empty()) {
    orders = ftxui::text("no working orders") |
             ftxui::dim |
             ftxui::size(ftxui::HEIGHT, ftxui::EQUAL, kAccountPanelHeight);
  } else {
    int const order_count = static_cast<int>(interactive_working_orders_.size());
    int const line_count = order_count * 3;
    int const focused_line = std::min(line_count - 1, working_order_index_ * 3 + 1);
    int const max_offset = max_scroll_offset_for_lines(line_count, kAccountPanelHeight);
    int const offset = std::clamp(focused_line - (kAccountPanelHeight / 2), 0, max_offset);
    orders = ftxui::hbox({
        ftxui::yframe(working_orders_container_->Render()) |
            ftxui::size(ftxui::HEIGHT, ftxui::EQUAL, kAccountPanelHeight) |
            ftxui::xflex,
        render_scrollbar(line_count, offset, kAccountPanelHeight),
    });
  }
  body.push_back(std::move(orders));

  std::string title = "Working Orders";
  if (working_orders_container_->Focused()) {
    title += " [scroll]";
  }
  return ftxui::window(ftxui::text(title), ftxui::vbox(std::move(body))) | ftxui::flex;
}

ftxui::Element PriceLadderComponent::render_fills_panel() const {
  std::string title = "Recent Fills";
  if (fills_component_->Focused()) {
    title += " [scroll]";
  }
  return ftxui::window(ftxui::text(title), fills_component_->Render()) | ftxui::flex;
}

ftxui::Element PriceLadderComponent::render_trades_panel() const {
  return render_text_panel(
      "Trades",
      "no trades yet",
      trades_component_,
      trade_entries_,
      trade_scroll_offset_,
      kLogPanelHeight);
}

ftxui::Element PriceLadderComponent::render_bottom_panels() const {
  return ftxui::hbox({
      render_trades_panel(),
      render_log_panel(),
  });
}

ftxui::Element PriceLadderComponent::render_log_panel() const {
  return render_text_panel(
      "Log",
      "no log events yet",
      log_component_,
      log_entries_,
      log_scroll_offset_,
      kLogPanelHeight);
}

ftxui::Element PriceLadderComponent::render_preview(UiSnapshot const &snapshot) const {
  OrderDraft draft;
  std::string error;
  if (!build_order_draft(snapshot, draft, error)) {
    return ftxui::text(error) | ftxui::dim;
  }

  MarketInfo const *market = find_market(draft.symbol);
  std::ostringstream out;
  out << (draft.is_sell ? "SELL" : "BUY") << " ";
  out << (draft.role == OrderRole::Taker ? "TAKER " : "MAKER ");
  if (draft.mode == OrderMode::GtcLimit) {
    out << "GTC limit @" << format_price(draft.price, market);
  } else if (draft.mode == OrderMode::MarkToMid) {
    out << "GTC mark-to-mid ";
    out << format_mark_to_mid_delta(draft.delta_ppm, market) << " delta";
  } else if (draft.price == 0) {
    out << "IOC market unrestricted";
  } else {
    out << "IOC market ref@" << format_price(draft.price, market);
    out << " slippage=" << draft.delta_ppm << " ppm";
  }
  out << " qty=" << format_atomic_qty(draft.qty, market);

  SymbolView const *book = find_selected_book(snapshot);
  if (book != nullptr && book->has_mid) {
    out << " mid=" << api_client::price_grid::format_mid_price(book->best_bid_price, book->best_ask_price, book->px_exponent);
  }
  return ftxui::paragraph(out.str());
}

ftxui::Element PriceLadderComponent::render_working_order_label(size_t index) const {
  if (index >= interactive_working_orders_.size()) {
    return ftxui::text("stale working order") | ftxui::dim;
  }
  InteractiveWorkingOrder const &entry = interactive_working_orders_[index];
  UiSnapshot::WorkingOrderRow const &order = entry.order;
  MarketInfo const *market = find_market(order.symbol);
  return ftxui::text(
             "sub=" + std::to_string(entry.subaccount_id) +
             " oid=" + std::to_string(order.external_order_id) +
             " sym=" + format_symbol_label(order.symbol, market) +
             " " + order.side +
             " rem=" + format_atomic_qty(order.remaining_qty, market) +
             "/" + format_atomic_qty(order.original_qty, market) +
             " px=" + format_price(order.price, market)) |
         ftxui::xflex;
}

ftxui::Element PriceLadderComponent::render_labeled_control(
    std::string const &label,
    ftxui::Component const &component) {
  return ftxui::hbox({
      ftxui::text(label + ":") | ftxui::size(ftxui::WIDTH, ftxui::EQUAL, 11),
      component->Render() | ftxui::xflex,
  });
}

OrderMode PriceLadderComponent::selected_order_mode() const {
  if (order_mode_index_ == static_cast<int>(OrderMode::MarkToMid)) {
    return OrderMode::MarkToMid;
  }
  if (order_mode_index_ == static_cast<int>(OrderMode::Market)) {
    return OrderMode::Market;
  }
  return OrderMode::GtcLimit;
}

uint32_t PriceLadderComponent::selected_symbol() const {
  std::vector<uint32_t> const &feed_ids = client_.feed_ids();
  if (feed_ids.empty()) {
    return 0;
  }
  size_t const last = feed_ids.size() - 1;
  int index = symbol_index_;
  if (index < 0) {
    index = 0;
  }
  if (static_cast<size_t>(index) > last) {
    index = static_cast<int>(last);
  }
  return feed_ids[static_cast<size_t>(index)];
}

bool PriceLadderComponent::show_symbol_toggle() const {
  return symbol_entries_.size() > 1;
}

bool PriceLadderComponent::show_price_input() const {
  OrderMode const mode = selected_order_mode();
  return mode == OrderMode::GtcLimit || mode == OrderMode::Market;
}

bool PriceLadderComponent::show_delta_ppm_input() const {
  OrderMode const mode = selected_order_mode();
  return mode == OrderMode::MarkToMid || mode == OrderMode::Market;
}

bool PriceLadderComponent::build_order_draft(
    UiSnapshot const &snapshot,
    OrderDraft &draft,
    std::string &error) const {
  draft = OrderDraft{};
  draft.symbol = selected_symbol();
  if (draft.symbol == 0) {
    error = "symbol is required";
    return false;
  }
  draft.mode = selected_order_mode();
  draft.role = (role_index_ == static_cast<int>(OrderRole::Taker)) ? OrderRole::Taker : OrderRole::Maker;
  draft.is_sell = side_index_ != 0;

  MarketInfo const *market = find_market(draft.symbol);
  if (market == nullptr) {
    error = "symbology is missing for symbol " + std::to_string(draft.symbol);
    return false;
  }
  if (!api_client::qty_utils::parse_qty_decimal(
          std::string_view(qty_input_), market->size_decimals, draft.qty) ||
      draft.qty == 0) {
    error = "qty must be a positive decimal amount representable at size_decimals";
    return false;
  }

  if (draft.mode == OrderMode::GtcLimit) {
    uint64_t parsed_price = 0;
    if (!api_client::price_grid::parse_price_decimal(
            price_input_, market->px_exponent, parsed_price) ||
        parsed_price == 0) {
      error = "price must be a positive decimal amount on the market exponent";
      return false;
    }
    if (!api_client::price_grid::snap_price_to_grid(
            parsed_price,
            draft.is_sell,
            market->px_exponent,
            market->size_decimals,
            draft.price)) {
      error = "price is invalid for the selected market grid";
      return false;
    }
    draft.delta_ppm = 0;
    return true;
  }

  draft.price = 0;
  if (draft.mode == OrderMode::MarkToMid) {
    if (!parse_delta_ppm(delta_ppm_input_, draft.delta_ppm)) {
      error = "delta must be an integer ppm value";
      return false;
    }
    return true;
  }

  if (draft.role != OrderRole::Taker) {
    error = "market orders require taker role";
    return false;
  }
  if (!price_input_.empty() &&
      !api_client::price_grid::parse_price_decimal(
          price_input_, market->px_exponent, draft.price)) [[unlikely]] {
    error = "reference price must be a nonnegative decimal amount on the market exponent";
    return false;
  }
  if (!delta_ppm_input_.empty() &&
      (!parse_delta_ppm(delta_ppm_input_, draft.delta_ppm) || draft.delta_ppm < 0)) [[unlikely]] {
    error = "slippage must be a nonnegative integer ppm value";
    return false;
  }
  if (draft.price == 0 && draft.delta_ppm != 0) [[unlikely]] {
    error = "market order slippage requires a reference price";
    return false;
  }
  if (draft.price != 0 && draft.delta_ppm == 0) [[unlikely]] {
    error = "market order reference price requires non-zero slippage";
    return false;
  }
  if (draft.delta_ppm > 1'000'000) [[unlikely]] {
    error = "slippage must not exceed 1000000 ppm";
    return false;
  }
  return true;
}

void PriceLadderComponent::apply_normalized_order_inputs(
    OrderDraft const &draft,
    MarketInfo const *market) {
  if (market == nullptr) {
    return;
  }
  if (draft.mode == OrderMode::GtcLimit ||
      (draft.mode == OrderMode::Market && draft.price != 0)) {
    price_input_ = api_client::price_grid::format_price(draft.price, market->px_exponent);
  }
}

void PriceLadderComponent::sync_account_entries(UiSnapshot const &snapshot) {
  position_entries_.clear();
  if (!snapshot.account_stream_started) {
    position_entries_.push_back("account stream not subscribed");
  } else if (!snapshot.has_account_snapshot) {
    position_entries_.push_back("waiting for account snapshot...");
  } else {
    for (UiSnapshot::AccountSubaccountRow const &subaccount : snapshot.subaccounts) {
      position_entries_.push_back("subaccount " + std::to_string(subaccount.subaccount_id) +
                                  " collateral=" + format_usd_micro(subaccount.collateral_balance));
      if (subaccount.positions.empty()) {
        position_entries_.push_back("  no positions");
        continue;
      }
      for (UiSnapshot::PositionRow const &position : subaccount.positions) {
        MarketInfo const *market = find_market(position.symbol);
        SymbolView const *book = find_book(snapshot, position.symbol);
        position_entries_.push_back(
            "  sym=" + format_symbol_label(position.symbol, market) +
            " net=" + format_signed_atomic_qty(position.net_qty, market) +
            " cb=" + format_usd_micro(position.cost_basis) +
            " realized_pnl=" + format_usd_micro(position.realized_pnl) +
            " fee=" + format_usd_micro(position.pending_fees) +
            " funding_accrued=" + format_usd_micro(position.funding_accrued) +
            " pnl=" + format_position_pnl(position, book, market));
      }
    }
    if (position_entries_.empty()) {
      position_entries_.push_back("no positions");
    }
  }
  position_scroll_offset_ = clamp_scroll_offset_for_lines(
      position_scroll_offset_,
      static_cast<int>(position_entries_.size()),
      kAccountPanelHeight);

  bool const follow_fills_tail =
      fill_entries_.empty() ||
      fill_scroll_offset_ >=
          max_scroll_offset_for_lines(static_cast<int>(fill_entries_.size()), kAccountPanelHeight);
  fill_entries_.clear();
  if (snapshot.recent_fills.empty()) {
    fill_entries_.push_back("no fills yet");
  } else {
    for (UiSnapshot::FillRow const &fill : snapshot.recent_fills) {
      MarketInfo const *market = find_market(fill.symbol);
      std::string const adl_nonce =
          fill.operation_nonce == 0 ? "" : " adl_nonce=" + std::to_string(fill.operation_nonce);
      std::string const entry =
          "seq=" + std::to_string(fill.seq) +
          " trade=" + std::to_string(fill.trade_id) +
          " sym=" + format_symbol_label(fill.symbol, market) +
          " " + fill.side +
          " role=" + fill.role +
          " qty=" + format_atomic_qty(fill.qty, market) +
          " px=" + format_price(fill.price, market) +
          adl_nonce +
          " " + format_fill_settlement_status(fill, market);
      fill_entries_.push_back(entry);
      if (fill.adl_failed &&
          (fill.workflow_error_code != 0 || fill.cleanup_error_code != 0 || fill.failure_stage != 0)) [[unlikely]] {
        std::string detail = "  ADL detail";
        if (fill.workflow_error_code != 0) {
          detail += " workflow=" + std::to_string(fill.workflow_error_code);
        }
        if (fill.cleanup_error_code != 0) {
          detail += " cleanup=" + std::to_string(fill.cleanup_error_code);
        }
        if (fill.failure_stage != 0) {
          detail += " stage=" + std::to_string(fill.failure_stage);
        }
        fill_entries_.push_back(std::move(detail));
      }
    }
  }
  if (follow_fills_tail) {
    fill_scroll_offset_ = max_scroll_offset_for_lines(
        static_cast<int>(fill_entries_.size()),
        kAccountPanelHeight);
  } else {
    fill_scroll_offset_ = clamp_scroll_offset_for_lines(
        fill_scroll_offset_,
        static_cast<int>(fill_entries_.size()),
        kAccountPanelHeight);
  }
}

void PriceLadderComponent::sync_working_order_components(UiSnapshot const &snapshot) {
  std::vector<InteractiveWorkingOrder> const next_orders = flatten_working_orders(snapshot);
  if (working_orders_match(next_orders)) {
    return;
  }

  uint64_t focused_subaccount_id = 0;
  uint64_t focused_external_order_id = 0;
  if (working_order_index_ >= 0 &&
      static_cast<size_t>(working_order_index_) < interactive_working_orders_.size()) {
    focused_subaccount_id = interactive_working_orders_[static_cast<size_t>(working_order_index_)].subaccount_id;
    focused_external_order_id =
        interactive_working_orders_[static_cast<size_t>(working_order_index_)].order.external_order_id;
  }

  interactive_working_orders_ = next_orders;
  working_orders_container_->DetachAllChildren();
  for (size_t i = 0; i < interactive_working_orders_.size(); ++i) {
    working_orders_container_->Add(make_working_order_component(i));
  }

  if (interactive_working_orders_.empty()) {
    working_order_index_ = 0;
    if (account_panel_index_ == 1) {
      account_panel_index_ = 0;
    }
    return;
  }

  int next_index = 0;
  bool found_focus = false;
  for (size_t i = 0; i < interactive_working_orders_.size(); ++i) {
    if (interactive_working_orders_[i].subaccount_id == focused_subaccount_id &&
        interactive_working_orders_[i].order.external_order_id == focused_external_order_id) {
      next_index = static_cast<int>(i);
      found_focus = true;
      break;
    }
  }
  if (!found_focus && working_order_index_ > 0) {
    size_t const last_index = interactive_working_orders_.size() - 1;
    next_index = std::min(working_order_index_, static_cast<int>(last_index));
  }
  working_order_index_ = next_index;
}

void PriceLadderComponent::sync_trade_component(UiSnapshot const &snapshot) {
  sync_scrolling_entries(
      snapshot.trade_lines,
      trade_entries_,
      trade_scroll_offset_,
      kLogPanelHeight);
}

void PriceLadderComponent::sync_log_component(UiSnapshot const &snapshot) {
  sync_scrolling_entries(
      snapshot.log_lines,
      log_entries_,
      log_scroll_offset_,
      kLogPanelHeight);
}

bool PriceLadderComponent::working_orders_match(
    std::vector<InteractiveWorkingOrder> const &next_orders) const {
  if (interactive_working_orders_.size() != next_orders.size()) {
    return false;
  }
  for (size_t i = 0; i < next_orders.size(); ++i) {
    if (!working_order_matches(interactive_working_orders_[i], next_orders[i])) {
      return false;
    }
  }
  return true;
}

std::vector<PriceLadderComponent::InteractiveWorkingOrder>
PriceLadderComponent::flatten_working_orders(UiSnapshot const &snapshot) {
  std::vector<InteractiveWorkingOrder> out;
  for (UiSnapshot::AccountSubaccountRow const &subaccount : snapshot.subaccounts) {
    for (UiSnapshot::WorkingOrderRow const &order : subaccount.working_orders) {
      InteractiveWorkingOrder entry;
      entry.subaccount_id = subaccount.subaccount_id;
      entry.order = order;
      out.push_back(std::move(entry));
    }
  }
  return out;
}

bool PriceLadderComponent::working_order_matches(
    InteractiveWorkingOrder const &lhs,
    InteractiveWorkingOrder const &rhs) {
  return lhs.subaccount_id == rhs.subaccount_id &&
         lhs.order.external_order_id == rhs.order.external_order_id &&
         lhs.order.client_instruction_id == rhs.order.client_instruction_id &&
         lhs.order.symbol == rhs.order.symbol &&
         lhs.order.side == rhs.order.side &&
         lhs.order.role == rhs.order.role &&
         lhs.order.tif == rhs.order.tif &&
         lhs.order.price == rhs.order.price &&
         lhs.order.original_qty == rhs.order.original_qty &&
         lhs.order.remaining_qty == rhs.order.remaining_qty &&
         lhs.order.order_type == rhs.order.order_type &&
         lhs.order.delta_ppm == rhs.order.delta_ppm;
}

ftxui::Component PriceLadderComponent::make_working_order_component(size_t index) {
  uint64_t const external_order_id = interactive_working_orders_[index].order.external_order_id;
  ftxui::Component label =
      ftxui::Renderer(std::function<ftxui::Element(bool)>(std::bind(
          &PriceLadderComponent::render_working_order_label_focus,
          this,
          index,
          std::placeholders::_1)));
  ftxui::Component cancel_button =
      ftxui::Button("Cancel",
                    std::bind(&PriceLadderComponent::submit_cancel_order,
                              this,
                              interactive_working_orders_[index].subaccount_id,
                              external_order_id),
                    ftxui::ButtonOption::Border());
  ftxui::Component modify_button =
      ftxui::Button("Modify",
                    std::bind(&PriceLadderComponent::open_modify_dialog,
                              this,
                              index),
                    ftxui::ButtonOption::Border());
  return ftxui::Container::Horizontal({
      label,
      modify_button,
      cancel_button,
  });
}

ftxui::Element PriceLadderComponent::render_working_order_label_focus(
    size_t index,
    bool focused) const {
  ftxui::Element label = render_working_order_label(index) | ftxui::focus;
  if (focused) {
    label |= ftxui::inverted;
  }
  return label;
}

ftxui::Element PriceLadderComponent::render_modify_dialog() const {
  UiSnapshot::WorkingOrderRow const &order = modifying_order_.order;
  MarketInfo const *market = find_market(order.symbol);
  std::vector<ftxui::Element> rows;
  rows.push_back(ftxui::text("oid=" + std::to_string(order.external_order_id) +
                             " sym=" + format_symbol_label(order.symbol, market)) |
                 ftxui::bold);
  rows.push_back(ftxui::separator());
  rows.push_back(render_labeled_control("Price", modify_price_input_component_));
  rows.push_back(render_labeled_control("Qty", modify_qty_input_component_));
  if (market != nullptr) {
    rows.push_back(ftxui::text("Current px=" + format_price(order.price, market) +
                               " rem=" + format_atomic_qty(order.remaining_qty, market)) |
                   ftxui::dim);
  }
  if (!working_orders_error_.empty()) {
    rows.push_back(ftxui::separator());
    rows.push_back(ftxui::text(working_orders_error_) | ftxui::color(ftxui::Color::Red));
  }
  rows.push_back(ftxui::separator());
  rows.push_back(modify_buttons_component_->Render());
  return ftxui::window(ftxui::text("Modify Order"), ftxui::vbox(std::move(rows))) |
         ftxui::size(ftxui::WIDTH, ftxui::EQUAL, 52);
}

void PriceLadderComponent::submit_order() {
  UiSnapshot const snapshot = client_.snapshot();
  OrderDraft draft;
  std::string error;
  if (!build_order_draft(snapshot, draft, error)) {
    form_error_ = error;
    return;
  }
  apply_normalized_order_inputs(draft, find_market(draft.symbol));
  if (!client_.submit_order(draft, error)) {
    form_error_ = error;
    return;
  }
  form_error_.clear();
}

void PriceLadderComponent::submit_cancel_order(uint64_t subaccount_id, uint64_t external_order_id) {
  std::string error;
  if (!client_.submit_cancel(subaccount_id, external_order_id, error)) {
    working_orders_error_ = error;
    return;
  }
  working_orders_error_.clear();
}

void PriceLadderComponent::open_modify_dialog(size_t index) {
  if (index >= interactive_working_orders_.size()) {
    working_orders_error_ = "working order is no longer available";
    return;
  }
  modifying_order_ = interactive_working_orders_[index];
  MarketInfo const *market = find_market(modifying_order_.order.symbol);
  modify_price_input_ = format_price(modifying_order_.order.price, market);
  modify_qty_input_ = format_atomic_qty(modifying_order_.order.remaining_qty, market);
  working_orders_error_.clear();
  modify_dialog_open_ = true;
  modify_price_input_component_->TakeFocus();
}

void PriceLadderComponent::submit_modify_dialog() {
  uint64_t price = 0;
  uint64_t qty = 0;
  std::string error;
  if (!parse_modify_inputs(price, qty, error)) {
    working_orders_error_ = error;
    return;
  }
  if (!client_.submit_modify(modifying_order_.subaccount_id, modifying_order_.order, price, qty, error)) {
    working_orders_error_ = error;
    return;
  }
  working_orders_error_.clear();
  modify_dialog_open_ = false;
}

void PriceLadderComponent::cancel_modify_dialog() {
  modify_dialog_open_ = false;
}

bool PriceLadderComponent::parse_modify_inputs(uint64_t &price, uint64_t &qty, std::string &error) const {
  UiSnapshot::WorkingOrderRow const &order = modifying_order_.order;
  MarketInfo const *market = find_market(order.symbol);
  if (market == nullptr) {
    error = "symbology is missing for symbol " + std::to_string(order.symbol);
    return false;
  }
  uint64_t parsed_price = 0;
  if (!api_client::price_grid::parse_price_decimal(
          modify_price_input_, market->px_exponent, parsed_price) ||
      parsed_price == 0) {
    error = "price must be a positive decimal amount on the market exponent";
    return false;
  }
  bool const is_sell = order.side == "ASK" || order.side == "Sell";
  if (!api_client::price_grid::snap_price_to_grid(
          parsed_price,
          is_sell,
          market->px_exponent,
          market->size_decimals,
          price)) {
    error = "price is invalid for the selected market grid";
    return false;
  }
  if (!api_client::qty_utils::parse_qty_decimal(
          std::string_view(modify_qty_input_), market->size_decimals, qty) ||
      qty == 0) {
    error = "qty must be a positive decimal amount representable at size_decimals";
    return false;
  }
  if (qty > order.remaining_qty) {
    error = "qty cannot exceed current remaining qty";
    return false;
  }
  if (order.original_iat == 0 || order.client_instruction_id == 0) {
    error = "working order is missing original signed identity";
    return false;
  }
  if (order.side != "BID" && order.side != "ASK" && order.side != "Buy" && order.side != "Sell") {
    error = "working order side is invalid";
    return false;
  }
  if (order.order_type > static_cast<uint64_t>(OrderMode::Market)) {
    error = "working order type is invalid";
    return false;
  }
  return true;
}

SymbolView const *PriceLadderComponent::find_selected_book(UiSnapshot const &snapshot) const {
  int const index = find_selected_book_index(snapshot);
  if (index < 0) {
    return nullptr;
  }
  return &snapshot.books[static_cast<size_t>(index)];
}

SymbolView const *PriceLadderComponent::find_book(UiSnapshot const &snapshot, uint32_t symbol) {
  for (SymbolView const &book : snapshot.books) {
    if (book.feed_id == symbol) {
      return &book;
    }
  }
  return nullptr;
}

int PriceLadderComponent::find_selected_book_index(UiSnapshot const &snapshot) const {
  uint32_t const symbol = selected_symbol();
  for (size_t i = 0; i < snapshot.books.size(); ++i) {
    if (snapshot.books[i].feed_id == symbol) {
      return static_cast<int>(i);
    }
  }
  return -1;
}

ftxui::Element PriceLadderComponent::render_header(UiSnapshot const &snapshot) {
  std::vector<ftxui::Element> rows;
  rows.push_back(ftxui::text("api_client ladder") | ftxui::bold);
  rows.push_back(ftxui::text("wallet: " + snapshot.wallet_pubkey));
  rows.push_back(ftxui::text("ws:     " + snapshot.ws_url));
  rows.push_back(ftxui::text("status: " + snapshot.connection_status));
  rows.push_back(ftxui::text(
      "auth:   " + snapshot.auth_status +
      "  fees: maker=" + format_fee_rate_bps(snapshot.maker_fee_ppm) +
      " bps taker=" + format_fee_rate_bps(snapshot.taker_fee_ppm) +
      " bps"));
  rows.push_back(ftxui::text("acct:   " + snapshot.account_status));
  if (snapshot.gateway_rtt_samples != 0) {
    rows.push_back(ftxui::text(
        "gw-rtt: " + format_avg_latency(snapshot.gateway_rtt_avg_ns, snapshot.gateway_rtt_samples)));
  }
  if (snapshot.seq_match_latency_samples != 0) {
    rows.push_back(ftxui::text(
        "seq-match latency: " +
        format_avg_latency(snapshot.seq_match_latency_avg_ns, snapshot.seq_match_latency_samples)));
  }
  if (!snapshot.last_notice.empty()) {
    rows.push_back(ftxui::text("last:   " + snapshot.last_notice));
  }
  return ftxui::window(ftxui::text("Session"), ftxui::vbox(std::move(rows)));
}

ftxui::Element PriceLadderComponent::render_book(BookRenderData const &book_data) {
  SymbolView const &book = *book_data.book;
  std::vector<ftxui::Element> rows;

  if (book.asks.empty() && book.bids.empty()) {
    rows.push_back(ftxui::text("waiting for book...") | ftxui::dim);
  } else {
    for (size_t i = book.asks.size(); i > 0; --i) {
      rows.push_back(render_ask_row(book.asks[i - 1], book, book_data.price_width));
    }
    rows.push_back(ftxui::separator());
    rows.push_back(render_mid_row(book, book_data.price_width));
    rows.push_back(ftxui::separator());
    for (LadderRow const &row : book.bids) {
      rows.push_back(render_bid_row(row, book, book_data.price_width));
    }
  }

  return ftxui::window(ftxui::text(book_data.title), ftxui::vbox(std::move(rows)));
}

ftxui::Element PriceLadderComponent::render_ask_row(
    LadderRow const &row,
    SymbolView const &book,
    int price_width) {
  return render_ladder_row(
             format_qty(row.ask_qty, book.size_decimals),
             format_book_price(book, row.price),
             std::string(kLadderQtyWidth, ' '),
             price_width) |
         ftxui::color(ftxui::Color::Red);
}

ftxui::Element PriceLadderComponent::render_bid_row(
    LadderRow const &row,
    SymbolView const &book,
    int price_width) {
  return render_ladder_row(
             std::string(kLadderQtyWidth, ' '),
             format_book_price(book, row.price),
             format_qty(row.bid_qty, book.size_decimals),
             price_width) |
         ftxui::color(ftxui::Color::Green);
}

ftxui::Element PriceLadderComponent::render_mid_row(SymbolView const &book, int price_width) {
  ftxui::Element row = render_ladder_row(
      std::string(kLadderQtyWidth, ' '),
      format_book_mid_price(book),
      std::string(kLadderQtyWidth, ' '),
      price_width);
  if (!book.has_mid) {
    return row | ftxui::dim;
  }
  return row | ftxui::bold | ftxui::color(ftxui::Color::Yellow);
}

MarketInfo const *PriceLadderComponent::find_market(uint32_t symbol) const {
  return find_market_info(client_.markets(), symbol);
}

std::string PriceLadderComponent::format_price(uint64_t price, MarketInfo const *market) {
  if (market == nullptr) {
    return std::to_string(price);
  }
  return api_client::price_grid::format_price(price, market->px_exponent);
}

std::string PriceLadderComponent::format_qty(double qty, uint8_t size_decimals) {
  std::ostringstream out;
  out << std::setw(kLadderQtyWidth) << std::fixed
      << std::setprecision(static_cast<int>(size_decimals)) << qty;
  return out.str();
}

std::string PriceLadderComponent::format_atomic_qty(uint64_t qty, MarketInfo const *market) {
  if (market == nullptr) {
    return std::to_string(qty);
  }
  return api_client::qty_utils::format_qty(qty, market->size_decimals);
}

std::string PriceLadderComponent::format_signed_atomic_qty(int64_t qty, MarketInfo const *market) {
  if (market == nullptr) {
    return std::to_string(qty);
  }
  return api_client::qty_utils::format_signed_qty(qty, market->size_decimals);
}

} // namespace

namespace api_client {

ftxui::Component make_price_ladder_view(PriceLadderClient &client) {
  return ftxui::Make<PriceLadderComponent>(client);
}

} // namespace api_client
