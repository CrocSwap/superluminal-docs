#pragma once

#include <algorithm>
#include <cstdint>
#include <functional>
#include <limits>
#include <map>
#include <string>
#include <string_view>
#include <vector>

#include "dfba_common/simdjson_utils.hpp"

namespace market_data {

constexpr size_t kMaxBufferedDeltas = 512;

struct WireLevel {
  uint64_t price{0};
  uint64_t qty{0};
};

enum class WireType {
  Unknown,
  Snapshot,
  Delta,
  Reset,
};

enum class BookType {
  Unknown,
  Maker,
  Taker,
};

struct WireMessage {
  WireType type{WireType::Unknown};
  BookType book_type{BookType::Unknown};
  uint32_t feed_id{0};
  uint64_t seq{0};
  uint64_t batch_id{0};
  uint64_t book_cursor{0};
  uint64_t prev_book_cursor{0};
  uint64_t unix_ns{0};
  uint64_t mark_price{0};
  std::vector<WireLevel> bids{};
  std::vector<WireLevel> asks{};
};

struct BookLevel {
  uint64_t price{0};
  uint64_t bid_qty{0};
  uint64_t ask_qty{0};
};

struct BookUpdate {
  enum class Kind {
    FullBook,
    DeltaLevels,
  };

  Kind kind{Kind::FullBook};
  std::vector<BookLevel> levels{};
  bool synced{false};
};

enum class SyncActionType {
  Noop,
  Emit,
  Gap,
};

struct SyncAction {
  SyncActionType type{SyncActionType::Noop};
  BookUpdate update{};
  uint64_t batch_id{0};
  uint64_t unix_ns{0};
  uint64_t mark_price{0};
};

class WireParser {
 public:
  static bool parse(std::string const &payload, WireMessage &out) {
    out = WireMessage{};

    simdjson::dom::parser parser;
    dfba::json::JsonObject object;
    std::string type;
    if (!dfba::json::parse_json_object(payload, parser, object) ||
        !dfba::json::extract_json_field(object, "type", type)) {
      return false;
    }
    return parse(type, object, out);
  }

  static bool parse(std::string const &type, dfba::json::JsonObject const &payload, WireMessage &out) {
    out = WireMessage{};

    if (type == "BookSnapshot") {
      out.type = WireType::Snapshot;
    } else if (type == "BookDelta") {
      out.type = WireType::Delta;
    } else if (type == "stream_reset") {
      out.type = WireType::Reset;
    } else {
      return false;
    }

    std::string book_type;
    if (!dfba::json::extract_json_field(payload, "bookType", book_type)) {
      return false;
    }
    out.book_type = parse_book_type(book_type);
    if (out.book_type == BookType::Unknown) {
      return false;
    }

    uint64_t feed_id = 0;
    if (out.type == WireType::Reset) {
      if (!dfba::json::extract_json_field(payload, "symbol", feed_id)) {
        return false;
      }
    } else {
      if (!dfba::json::extract_json_field(payload, "id", feed_id)) {
        return false;
      }
    }
    if (feed_id == 0 || feed_id > std::numeric_limits<uint32_t>::max()) {
      return false;
    }
    out.feed_id = static_cast<uint32_t>(feed_id);

    dfba::json::extract_json_field(payload, "seq", out.seq);
    dfba::json::extract_json_field(payload, "batch_id", out.batch_id);
    dfba::json::extract_json_field(payload, "book_cursor", out.book_cursor);
    dfba::json::extract_json_field(payload, "prev_book_cursor", out.prev_book_cursor);
    dfba::json::extract_json_field(payload, "matcher_unix_ns", out.unix_ns);
    dfba::json::extract_json_field(payload, "mark_price", out.mark_price);

    if (out.type == WireType::Reset) {
      return true;
    }

    if (!extract_levels_field(payload, "bids", out.bids)) {
      return false;
    }
    if (!extract_levels_field(payload, "asks", out.asks)) {
      return false;
    }
    return true;
  }

 private:
  static bool extract_levels_field(dfba::json::JsonObject const &object,
                                   std::string_view field,
                                   std::vector<WireLevel> &out) {
    out.clear();

    dfba::json::JsonArray levels;
    if (!dfba::json::extract_json_field(object, field, levels)) {
      return true;
    }

    for (dfba::json::JsonElement level_value : levels) {
      dfba::json::JsonObject level_object;
      if (level_value.get(level_object) != simdjson::SUCCESS) {
        return false;
      }

      WireLevel level;
      if (!dfba::json::extract_json_field(level_object, "price", level.price) ||
          !dfba::json::extract_json_field(level_object, "qty", level.qty)) {
        return false;
      }
      out.push_back(level);
    }
    return true;
  }

  static BookType parse_book_type(std::string const &value) {
    if (value == "maker") {
      return BookType::Maker;
    }
    if (value == "taker") {
      return BookType::Taker;
    }
    return BookType::Unknown;
  }
};

class BookSyncEngine {
 public:
  BookSyncEngine() = default;

  SyncAction handle_message(WireMessage const &msg) {
    if (msg.type == WireType::Snapshot) {
      return handle_snapshot(msg);
    }
    if (msg.type == WireType::Delta) {
      return handle_delta(msg);
    }
    if (msg.type == WireType::Reset) {
      return handle_reset();
    }
    return SyncAction{};
  }

 private:
  struct BufferedDelta {
    uint64_t prev_cursor{0};
    uint64_t cursor{0};
    WireMessage msg{};
  };

  struct BufferedDeltaCursorLess {
    bool operator()(BufferedDelta const &lhs, BufferedDelta const &rhs) const {
      return lhs.cursor < rhs.cursor;
    }
  };

  std::map<uint64_t, BookLevel, std::greater<uint64_t>> book_state_{};
  uint64_t book_cursor_{0};
  bool book_synced_{false};
  std::vector<BufferedDelta> buffered_deltas_{};
  std::vector<uint64_t> changed_prices_scratch_{};

  SyncAction handle_snapshot(WireMessage const &msg) {
    apply_snapshot(msg);
    SyncAction const sync = try_sync_from_snapshot(msg);
    if (sync.type != SyncActionType::Noop) {
      return sync;
    }
    buffered_deltas_.clear();
    book_synced_ = true;
    return emit_book(msg);
  }

  SyncAction handle_delta(WireMessage const &msg) {
    buffer_delta(msg);
    if (!book_synced_) {
      return SyncAction{};
    }

    if (book_cursor_ == 0 || msg.prev_book_cursor == 0 || msg.prev_book_cursor != book_cursor_) {
      book_state_.clear();
      book_cursor_ = 0;
      book_synced_ = false;
      return gap_action();
    }

    apply_delta(msg);
    prune_buffered_deltas_up_to(book_cursor_);
    return emit_delta_levels(msg);
  }

  SyncAction handle_reset() {
    book_state_.clear();
    book_cursor_ = 0;
    book_synced_ = false;
    buffered_deltas_.clear();
    return gap_action();
  }

  void apply_snapshot(WireMessage const &msg) {
    book_state_.clear();
    apply_bids(msg.bids);
    apply_asks(msg.asks);
    book_cursor_ = msg.book_cursor;
  }

  void apply_delta(WireMessage const &msg) {
    apply_bids(msg.bids);
    apply_asks(msg.asks);
    if (msg.book_cursor != 0) {
      book_cursor_ = msg.book_cursor;
    }
  }

  void apply_bids(std::vector<WireLevel> const &bids) {
    for (WireLevel const &level : bids) {
      BookLevel &entry = book_state_[level.price];
      entry.price = level.price;
      entry.bid_qty = level.qty;
      if (entry.bid_qty == 0 && entry.ask_qty == 0) {
        book_state_.erase(level.price);
      }
    }
  }

  void apply_asks(std::vector<WireLevel> const &asks) {
    for (WireLevel const &level : asks) {
      BookLevel &entry = book_state_[level.price];
      entry.price = level.price;
      entry.ask_qty = level.qty;
      if (entry.bid_qty == 0 && entry.ask_qty == 0) {
        book_state_.erase(level.price);
      }
    }
  }

  void buffer_delta(WireMessage const &msg) {
    if (msg.prev_book_cursor == 0 || msg.book_cursor == 0) {
      return;
    }
    buffered_deltas_.push_back(BufferedDelta{msg.prev_book_cursor, msg.book_cursor, msg});
    if (buffered_deltas_.size() > kMaxBufferedDeltas) {
      size_t const trim = buffered_deltas_.size() - kMaxBufferedDeltas;
      buffered_deltas_.erase(buffered_deltas_.begin(), buffered_deltas_.begin() + static_cast<long>(trim));
    }
  }

  void prune_buffered_deltas_up_to(uint64_t cursor) {
    if (cursor == 0) {
      return;
    }
    size_t write_index = 0;
    for (size_t i = 0; i < buffered_deltas_.size(); ++i) {
      if (buffered_deltas_[i].cursor > cursor) {
        if (write_index != i) {
          buffered_deltas_[write_index] = buffered_deltas_[i];
        }
        ++write_index;
      }
    }
    buffered_deltas_.resize(write_index);
  }

  static void collect_changed_prices(WireMessage const &msg, std::vector<uint64_t> &prices) {
    prices.clear();
    prices.reserve(msg.bids.size() + msg.asks.size());
    for (WireLevel const &level : msg.bids) {
      prices.push_back(level.price);
    }
    for (WireLevel const &level : msg.asks) {
      prices.push_back(level.price);
    }
    std::sort(prices.begin(), prices.end(), std::greater<uint64_t>{});
    prices.erase(std::unique(prices.begin(), prices.end()), prices.end());
  }

  SyncAction try_sync_from_snapshot(WireMessage const &snapshot) {
    uint64_t const base_cursor = book_cursor_;
    if (base_cursor == 0) {
      return SyncAction{};
    }

    std::vector<BufferedDelta> newer;
    newer.reserve(buffered_deltas_.size());
    for (BufferedDelta const &delta : buffered_deltas_) {
      if (delta.cursor > base_cursor) {
        newer.push_back(delta);
      }
    }

    if (newer.empty()) {
      book_synced_ = true;
      prune_buffered_deltas_up_to(book_cursor_);
      return emit_book(snapshot);
    }

    std::sort(newer.begin(), newer.end(), BufferedDeltaCursorLess{});

    size_t start_index = newer.size();
    for (size_t i = 0; i < newer.size(); ++i) {
      if (newer[i].prev_cursor == base_cursor) {
        start_index = i;
        break;
      }
    }
    if (start_index == newer.size()) {
      return SyncAction{};
    }

    uint64_t cursor = base_cursor;
    for (size_t i = start_index; i < newer.size(); ++i) {
      BufferedDelta const &delta = newer[i];
      if (delta.prev_cursor != cursor) {
        return SyncAction{};
      }
      apply_delta(delta.msg);
      cursor = book_cursor_;
    }

    book_synced_ = true;
    prune_buffered_deltas_up_to(book_cursor_);
    return emit_book(newer.back().msg);
  }

  SyncAction emit_book(WireMessage const &source) const {
    BookUpdate update;
    update.kind = BookUpdate::Kind::FullBook;
    update.synced = book_synced_;
    update.levels.reserve(book_state_.size());

    for (auto const &entry : book_state_) {
      update.levels.push_back(entry.second);
    }

    return SyncAction{
        SyncActionType::Emit,
        std::move(update),
        source.batch_id,
        source.unix_ns,
        source.mark_price};
  }

  SyncAction emit_delta_levels(WireMessage const &msg) {
    BookUpdate update;
    update.kind = BookUpdate::Kind::DeltaLevels;
    update.synced = book_synced_;

    collect_changed_prices(msg, changed_prices_scratch_);
    update.levels.reserve(changed_prices_scratch_.size());

    for (uint64_t price : changed_prices_scratch_) {
      auto const it = book_state_.find(price);
      if (it == book_state_.end()) {
        update.levels.push_back(BookLevel{price, 0, 0});
        continue;
      }
      update.levels.push_back(it->second);
    }

    return SyncAction{
        SyncActionType::Emit,
        std::move(update),
        msg.batch_id,
        msg.unix_ns,
        msg.mark_price};
  }

  static SyncAction gap_action() {
    return SyncAction{SyncActionType::Gap, BookUpdate{}, 0, 0, 0};
  }
};

} // namespace market_data
