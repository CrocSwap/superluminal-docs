#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace api_client {

constexpr uint16_t kDefaultPartitionId = 1;

struct Config {
  std::string ws_url;
  std::string keypair_path;
  uint16_t partition_id{kDefaultPartitionId};
  std::vector<uint32_t> feed_ids;
  uint64_t subaccount_id{0};
};

struct MarketInfo {
  uint32_t feed_id{0};
  std::string symbol{};
  std::string quote{};
  int16_t px_exponent{0};
  uint8_t size_decimals{0};
  std::string status{"active"};
  uint64_t tick_size{0};
  uint32_t max_funding_rate_e8{0};
  uint16_t initial_margin_bps{0};
  uint16_t maintenance_margin_bps{0};
  uint16_t transfer_margin_floor_bps{0};
};

inline std::string format_market_symbol(MarketInfo const &market) {
  if (market.symbol.empty()) {
    return {};
  }
  if (market.quote.empty()) {
    return market.symbol;
  }
  return market.symbol + "/" + market.quote;
}

struct LadderRow {
  uint64_t price{0};
  double bid_qty{0.0};
  double ask_qty{0.0};
};

struct SymbolView {
  uint32_t feed_id{0};
  std::string symbol{};
  int16_t px_exponent{0};
  uint8_t size_decimals{0};
  bool has_symbology{false};
  uint64_t seq{0};
  uint64_t unix_ns{0};
  bool synced{false};
  bool has_mid{false};
  uint64_t best_bid_price{0};
  uint64_t best_ask_price{0};
  bool has_mark_price{false};
  uint64_t mark_price{0};
  bool has_funding_index{false};
  int64_t funding_index_e8{0};
  std::vector<LadderRow> asks{};
  std::vector<LadderRow> bids{};
};

struct UiSnapshot {
  std::string wallet_pubkey{};
  std::string ws_url{};
  std::string connection_status{};
  std::string auth_status{};
  std::string account_status{};
  std::string last_notice{};
  std::string last_error{};
  std::vector<SymbolView> books{};
  double gateway_rtt_avg_ns{0.0};
  uint64_t gateway_rtt_samples{0};
  int32_t taker_fee_ppm{0};
  int32_t maker_fee_ppm{0};
  bool account_stream_started{false};
  bool has_account_snapshot{false};
  uint64_t account_last_seq{0};
  double seq_match_latency_avg_ns{0.0};
  uint64_t seq_match_latency_samples{0};

  struct PositionRow {
    uint32_t symbol{0};
    int64_t net_qty{0};
    int64_t cost_basis{0};
    int64_t pending_fees{0};
    int64_t funding_accrued{0};
    int64_t last_funding_index_e8{0};
    int64_t realized_pnl{0};
  };

  struct WorkingOrderRow {
    uint64_t external_order_id{0};
    uint64_t client_instruction_id{0};
    uint64_t original_iat{0};
    uint32_t symbol{0};
    std::string side{};
    std::string role{};
    std::string tif{};
    uint64_t price{0};
    uint64_t original_qty{0};
    uint64_t remaining_qty{0};
    uint64_t order_type{0};
    int32_t delta_ppm{0};
  };

  struct FillRow {
    uint64_t seq{0};
    uint64_t trade_id{0};
    uint64_t subaccount_id{0};
    uint64_t client_instruction_id{0};
    uint64_t external_order_id{0};
    uint32_t symbol{0};
    std::string side{};
    std::string role{};
    uint64_t price{0};
    uint64_t qty{0};
    uint64_t order_settled_qty{0};
    uint64_t event_unix_ns{0};
    uint64_t settle_delta_ns{0};
    bool has_order_settled_qty{false};
    bool has_event_unix_ns{false};
    bool has_settle_delta_ns{false};
    bool settled{false};
    bool adl_failed{false};
    uint64_t operation_nonce{0};
    uint64_t allocated_loss{0};
    uint32_t error_code{0};
    uint32_t workflow_error_code{0};
    uint32_t cleanup_error_code{0};
    uint8_t failure_stage{0};
  };

  struct AccountSubaccountRow {
    uint64_t subaccount_id{0};
    int64_t collateral_balance{0};
    int64_t accrued_fee{0};
    int64_t accrued_funding{0};
    std::string status{"active"};
    std::vector<PositionRow> positions{};
    std::vector<WorkingOrderRow> working_orders{};
  };

  std::vector<AccountSubaccountRow> subaccounts{};
  std::vector<FillRow> recent_fills{};
  std::vector<std::string> trade_lines{};
  std::vector<std::string> log_lines{};
};

enum class SessionPhase {
  Idle,
  AwaitingAuthChallenge,
  AwaitingAuthAck,
  Running,
  Failed,
  AuthExpired,
};

enum class OrderMode {
  GtcLimit = 0,
  MarkToMid = 1,
  Market = 2,
  IocLimit = 3,
};

enum class OrderRole {
  Maker = 0,
  Taker = 1,
};

struct OrderDraft {
  uint32_t symbol{0};
  OrderMode mode{OrderMode::GtcLimit};
  OrderRole role{OrderRole::Maker};
  bool is_sell{false};
  uint64_t qty{0};
  uint64_t price{0};
  int32_t delta_ppm{0};
};

} // namespace api_client
