#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "api_client_types.h"
#include "dfba_common/simdjson_utils.hpp"

namespace api_client {

struct AckMessage {
  std::string status{};
  std::string reason{};
  uint64_t client_instruction_id{0};
  uint64_t external_order_id{0};
  bool has_client_instruction_id{false};
  bool has_external_order_id{false};
};

struct AuthChallengeMessage {
  std::string wallet_pubkey{};
  std::string nonce{};
  std::string message{};
  uint64_t expires_unix_ms{0};
  bool has_expires_unix_ms{false};
};

struct CreateVaultStatusMessage {
  uint64_t client_instruction_id{0};
  uint64_t source_subaccount_id{0};
  uint64_t operation_subaccount_id{0};
  uint32_t vault_id{0};
  uint64_t status{0};
  uint64_t error_code{0};
  uint64_t total_vault_shares{0};
  std::string error_domain{};
  std::string error{};
  std::string error_message{};
  std::string onchain_signature{};
  bool has_total_vault_shares{false};
};

struct AuthExpiredMessage {
  std::string reason{};
};

struct PongMessage {
  uint64_t client_unix_ns{0};
};

struct AccountSnapshotMessage {
  struct Position {
    uint32_t symbol{0};
    int64_t net_qty{0};
    int64_t cost_basis{0};
    int64_t pending_fees{0};
    int64_t funding_accrued{0};
    int64_t last_funding_index_e8{0};
    int64_t realized_pnl{0};
  };

  struct WorkingOrder {
    uint64_t external_order_id{0};
    uint64_t client_instruction_id{0};
    uint64_t original_iat{0};
    uint32_t symbol{0};
    std::string side{};
    std::string role{};
    std::string tif{};
    uint64_t order_type{0};
    uint64_t price{0};
    uint64_t original_qty{0};
    uint64_t filled_qty{0};
    uint64_t remaining_qty{0};
    int64_t delta_ppm{0};
  };

  struct Subaccount {
    uint64_t subaccount_id{0};
    int64_t collateral_balance{0};
    int64_t accrued_fee{0};
    int64_t accrued_funding{0};
    std::string status{"active"};
    std::vector<Position> positions{};
    std::vector<WorkingOrder> working_orders{};
  };

  struct VaultAccount {
    uint32_t vault_id{0};
    uint64_t operation_subaccount_id{0};
    uint64_t leader_source_subaccount_id{0};
    uint64_t collateral_amount{0};
    uint64_t total_vault_shares{0};
    uint64_t last_seq{0};
  };

  uint64_t last_seq{0};
  std::vector<Subaccount> subaccounts{};
  std::vector<VaultAccount> vault_accounts{};
};

struct OrderAcceptedMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t external_order_id{0};
  uint64_t client_instruction_id{0};
  uint64_t client_unix_ns{0};
  uint64_t original_iat{0};
  uint64_t matcher_unix_ns{0};
  uint64_t sequencer_recv_unix_ns{0};
  uint32_t symbol{0};
  std::string side{};
  std::string role{};
  std::string tif{};
  uint64_t order_type{0};
  uint64_t price{0};
  uint64_t qty{0};
  int32_t delta_ppm{0};
  bool has_matcher_unix_ns{false};
  bool has_sequencer_recv_unix_ns{false};
};

struct OrderRejectMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t external_order_id{0};
  uint64_t client_instruction_id{0};
  uint64_t reason{0};
  uint64_t matcher_unix_ns{0};
  uint64_t sequencer_recv_unix_ns{0};
  uint64_t order_type{0};
  int64_t delta_ppm{0};
  uint32_t symbol{0};
  std::string side{};
  std::string role{};
  std::string tif{};
  uint64_t price{0};
  uint64_t qty{0};
  bool has_matcher_unix_ns{false};
  bool has_sequencer_recv_unix_ns{false};
};

struct LocalOrderRejectMessage {
  std::string reason{};
  uint64_t client_instruction_id{0};
  uint64_t external_order_id{0};
  uint64_t gateway_send_unix_ns{0};
  bool has_client_instruction_id{false};
  bool has_external_order_id{false};
  bool has_gateway_send_unix_ns{false};
};

struct FillEventMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t external_order_id{0};
  uint64_t client_instruction_id{0};
  uint64_t trade_id{0};
  uint64_t matcher_unix_ns{0};
  uint64_t sequencer_recv_unix_ns{0};
  uint64_t gateway_send_unix_ns{0};
  uint32_t symbol{0};
  std::string side{};
  std::string role{};
  uint64_t price{0};
  uint64_t qty{0};
  uint64_t remaining_qty{0};
  int64_t fee{0};
  uint8_t execution_mode{0};
  bool has_matcher_unix_ns{false};
  bool has_sequencer_recv_unix_ns{false};
  bool has_gateway_send_unix_ns{false};
  bool has_remaining_qty{false};
  bool has_fee{false};
  bool has_execution_mode{false};
};

struct AdlFailedMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t client_instruction_id{0};
  uint64_t external_order_id{0};
  uint64_t request_seq{0};
  uint64_t operation_nonce{0};
  uint64_t batch_id{0};
  uint64_t price{0};
  uint64_t qty{0};
  uint64_t allocated_loss{0};
  uint32_t market_id{0};
  uint32_t error_code{0};
  uint32_t workflow_error_code{0};
  uint32_t cleanup_error_code{0};
  uint8_t status{0};
  uint8_t failure_stage{0};
  std::string side{};
  std::string role{};
  std::string error_domain{};
  std::string error{};
  std::string error_message{};
};

struct CancelAckEventMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t external_order_id{0};
  uint64_t client_instruction_id{0};
  uint64_t reason{0};
  uint64_t matcher_unix_ns{0};
  uint64_t sequencer_recv_unix_ns{0};
  bool has_matcher_unix_ns{false};
  bool has_sequencer_recv_unix_ns{false};
};

struct CancelRejectEventMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t external_order_id{0};
  uint64_t client_instruction_id{0};
  uint64_t reason{0};
  uint64_t matcher_unix_ns{0};
  uint64_t sequencer_recv_unix_ns{0};
  bool has_matcher_unix_ns{false};
  bool has_sequencer_recv_unix_ns{false};
};

struct ModifyAckEventMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t external_order_id{0};
  uint64_t client_instruction_id{0};
  uint64_t original_client_instruction_id{0};
  uint64_t matcher_unix_ns{0};
  uint64_t sequencer_recv_unix_ns{0};
  uint32_t symbol{0};
  uint64_t price{0};
  uint64_t qty{0};
  int32_t delta_ppm{0};
  bool has_matcher_unix_ns{false};
  bool has_sequencer_recv_unix_ns{false};
};

struct ModifyRejectEventMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t external_order_id{0};
  uint64_t client_instruction_id{0};
  uint64_t original_client_instruction_id{0};
  uint64_t reason{0};
  uint64_t matcher_unix_ns{0};
  uint64_t sequencer_recv_unix_ns{0};
  bool has_matcher_unix_ns{false};
  bool has_sequencer_recv_unix_ns{false};
};

struct FillSettlementEventMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint64_t external_order_id{0};
  uint64_t gateway_send_unix_ns{0};
  uint32_t symbol{0};
  std::string side{};
  uint64_t price{0};
  uint64_t qty{0};
  int64_t fee{0};
  uint64_t status{0};
  uint64_t error_code{0};
  std::string error_domain{};
  std::string error{};
  std::string error_message{};
  std::string onchain_signature{};
  bool has_gateway_send_unix_ns{false};
  bool has_fee{false};
};

struct AccountFundingUpdateMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  uint32_t symbol{0};
  uint32_t market_id{0};
  int64_t prev_funding_index_e8{0};
  int64_t last_funding_index_e8{0};
  int64_t funding_delta{0};
  int64_t funding_accrued{0};
};

struct UserCollateralUpdateMessage {
  uint64_t seq{0};
  uint64_t subaccount_id{0};
  int64_t collateral_delta{0};
  int64_t collateral_balance{0};
  int64_t fee{0};
};

struct VaultOperationSubaccountCollateralChangeMessage {
  uint64_t seq{0};
  uint64_t client_instruction_id{0};
  uint64_t subaccount_id{0};
  uint64_t source_subaccount_id{0};
  uint64_t destination_subaccount_id{0};
  uint64_t operation_subaccount_id{0};
  std::string operation_subaccount_pubkey{};
  std::string vault_account_pubkey{};
  std::string participant_account_pubkey{};
  uint64_t deposit_amount{0};
  uint64_t minted_vault_shares{0};
  uint64_t requested_vault_shares{0};
  uint64_t actual_withdraw_amount{0};
  uint64_t leader_fee_amount{0};
  uint64_t previous_total_vault_shares{0};
  uint64_t total_vault_shares{0};
  uint64_t status{0};
  uint64_t error_code{0};
  std::string error_domain{};
  std::string error{};
  std::string error_message{};
  std::string onchain_signature{};
  uint64_t batch_id{0};
  uint64_t term{0};
};

struct FundingIndexMessage {
  struct Entry {
    uint32_t market_id{0};
    uint64_t perp_price{0};
    int64_t premium_e8{0};
    int64_t cum_funding_index_e8{0};
  };

  uint64_t seq{0};
  uint64_t oracle_price_batch_id{0};
  bool has_oracle_price_batch_id{false};
  std::vector<Entry> entries{};
};

struct TradeMessage {
  uint64_t seq{0};
  uint64_t batch_id{0};
  uint64_t matcher_unix_ns{0};
  uint64_t trade_id{0};
  uint64_t price{0};
  uint64_t qty{0};
  uint32_t symbol_id{0};
  std::string symbol{};
  std::string side{};
};

struct OrderHistoryMessage {
  struct Event {
    std::string event_type{};
    uint64_t client_instruction_id{0};
    uint64_t price{0};
    uint64_t qty{0};
    uint64_t trade_id{0};
    uint64_t event_unix_ns{0};
    uint64_t stream_seq{0};
  };

  struct Order {
    uint64_t external_order_id{0};
    uint64_t client_instruction_id{0};
    uint64_t subaccount_id{0};
    uint32_t symbol{0};
    std::string side{};
    std::string role{};
    uint64_t price{0};
    uint64_t settled_qty{0};
    uint64_t busted_qty{0};
    uint64_t last_event_seq{0};
    std::vector<Event> events{};
  };

  struct Adl {
    uint64_t operation_nonce{0};
    uint64_t request_seq{0};
    uint64_t batch_id{0};
    uint64_t subaccount_id{0};
    uint64_t fill_price{0};
    uint64_t fill_qty{0};
    uint64_t allocated_loss{0};
    uint64_t event_unix_ns{0};
    uint64_t last_event_seq{0};
    uint32_t market_id{0};
    uint32_t error_code{0};
    uint32_t workflow_error_code{0};
    uint32_t cleanup_error_code{0};
    uint8_t failure_stage{0};
    std::string side{};
    std::string role{};
    std::string status{};
  };

  std::string next_cursor{};
  std::vector<Order> orders{};
  std::vector<Adl> adl{};
};

class GatewayProtocolCodec {
 public:
  static bool parse_message_type(
      std::string const &payload,
      simdjson::dom::parser &parser,
      dfba::json::JsonObject &object,
      std::string &type);

  static bool decode_ack(dfba::json::JsonObject const &payload, AckMessage &ack);
  static bool decode_auth_challenge(
      dfba::json::JsonObject const &payload,
      AuthChallengeMessage &challenge);
  static bool decode_create_vault_status(
      dfba::json::JsonObject const &payload,
      CreateVaultStatusMessage &message);
  static bool decode_auth_expired(
      dfba::json::JsonObject const &payload,
      AuthExpiredMessage &message);
  static bool decode_pong(dfba::json::JsonObject const &payload, PongMessage &message);
  static bool decode_account_snapshot(
      dfba::json::JsonObject const &payload,
      AccountSnapshotMessage &message);
  static bool decode_order_accepted(
      dfba::json::JsonObject const &payload,
      OrderAcceptedMessage &message);
  static bool decode_fill_event(dfba::json::JsonObject const &payload, FillEventMessage &message);
  static bool decode_adl_failed(
      dfba::json::JsonObject const &payload,
      AdlFailedMessage &message);
  static bool decode_cancel_ack_event(
      dfba::json::JsonObject const &payload,
      CancelAckEventMessage &message);
  static bool decode_order_reject(
      dfba::json::JsonObject const &payload,
      OrderRejectMessage &message);
  static bool decode_local_order_reject(
      dfba::json::JsonObject const &payload,
      LocalOrderRejectMessage &message);
  static bool decode_cancel_reject_event(
      dfba::json::JsonObject const &payload,
      CancelRejectEventMessage &message);
  static bool decode_modify_ack_event(
      dfba::json::JsonObject const &payload,
      ModifyAckEventMessage &message);
  static bool decode_modify_reject_event(
      dfba::json::JsonObject const &payload,
      ModifyRejectEventMessage &message);
  static bool decode_fill_settlement_event(
      dfba::json::JsonObject const &payload,
      FillSettlementEventMessage &message);
  static bool decode_account_funding_update(
      dfba::json::JsonObject const &payload,
      AccountFundingUpdateMessage &message);
  static bool decode_user_collateral_update(
      dfba::json::JsonObject const &payload,
      UserCollateralUpdateMessage &message);
  static bool decode_vault_operation_subaccount_collateral_change(
      dfba::json::JsonObject const &payload,
      VaultOperationSubaccountCollateralChangeMessage &message);
  static bool decode_funding_index(
      dfba::json::JsonObject const &payload,
      FundingIndexMessage &message);
  static bool decode_trade(dfba::json::JsonObject const &payload, TradeMessage &message);
  static bool decode_order_history(
      dfba::json::JsonObject const &payload,
      OrderHistoryMessage &message);

  static std::string encode_signed_order(std::string_view msg_b64);
  static std::string encode_signed_cancel(std::string_view msg_b64);
  static std::string encode_signed_modify(std::string_view msg_b64);
  static std::string encode_signed_create_vault(std::string_view msg_b64);
  static std::string encode_ping(uint64_t client_unix_ns);
  static std::string encode_subscribe_market(uint32_t symbol);
  static std::string encode_subscribe_account();
  static std::string encode_get_order_history(uint32_t limit);
  static std::string encode_auth_wallet(std::string_view wallet_pubkey);
  static std::string encode_auth_response(std::string_view nonce,
                                          std::string_view signature_b64,
                                          bool is_delegate = false);
  static bool should_ignore_payload_type(std::string const &type);
};

} // namespace api_client
