#include "account_state.h"

#include <algorithm>
#include <limits>
#include <string>

namespace api_client {
namespace {

static bool working_order_external_id_less(
    UiSnapshot::WorkingOrderRow const &lhs,
    UiSnapshot::WorkingOrderRow const &rhs) {
  return lhs.external_order_id < rhs.external_order_id;
}

static bool position_symbol_less(UiSnapshot::PositionRow const &lhs, UiSnapshot::PositionRow const &rhs) {
  return lhs.symbol < rhs.symbol;
}

static bool fill_row_seq_greater(UiSnapshot::FillRow const &lhs, UiSnapshot::FillRow const &rhs) {
  return lhs.seq > rhs.seq;
}

static bool is_valid_side(std::string const &side) {
  return side == "BID" || side == "ASK";
}

static bool is_valid_role(std::string const &role) {
  return role.empty() || role == "MAKER" || role == "TAKER";
}

static bool is_valid_adl_role(std::string const &role) {
  return role == "target" || role == "counterparty";
}

static bool is_adl_fill(FillEventMessage const &message) {
  return message.has_execution_mode && message.execution_mode == 2;
}

static bool is_valid_fill_role(FillEventMessage const &message) {
  if (is_adl_fill(message)) {
    return is_valid_adl_role(message.role);
  }
  return is_valid_role(message.role);
}

static bool is_valid_adl_history_status(std::string const &status) {
  return status == "settled" || status == "failed";
}

static bool is_valid_tif(std::string const &tif) {
  return tif.empty() || tif == "GTC" || tif == "IOC";
}

static char const *order_reject_reason_name(uint64_t reason) {
  if (reason == 1) {
    return "missing_symbology";
  }
  if (reason == 2) {
    return "full";
  }
  if (reason == 3) {
    return "risk_rejected";
  }
  if (reason == 4) {
    return "risk_rejected_liquidation_not_active";
  }
  if (reason == 5) {
    return "risk_rejected_subaccount_not_active";
  }
  if (reason == 6) {
    return "risk_rejected_insufficient_free_collateral";
  }
  if (reason == 7) {
    return "risk_rejected_market_inactive";
  }
  return "unknown";
}

static char const *cancel_reject_reason_name(uint64_t reason) {
  if (reason == 1) {
    return "unknown_order";
  }
  if (reason == 2) {
    return "ioc_expired";
  }
  if (reason == 3) {
    return "missing_symbology";
  }
  return "unknown";
}

static char const *cancel_ack_reason_name(uint64_t reason) {
  if (reason == 5) {
    return "order_expired";
  }
  return "unknown";
}

static bool pow10_i128(uint32_t exp, __int128_t &out) {
  __int128_t value = 1;
  for (uint32_t i = 0; i < exp; ++i) {
    value *= 10;
  }
  out = value;
  return true;
}

static bool to_int64_checked(__int128_t value, int64_t &out) {
  if (value > static_cast<__int128_t>(std::numeric_limits<int64_t>::max()) ||
      value < static_cast<__int128_t>(std::numeric_limits<int64_t>::min())) {
    return false;
  }
  out = static_cast<int64_t>(value);
  return true;
}

static bool cost_basis_delta_usd(
    MarketInfo const *market,
    uint64_t price,
    int64_t signed_qty,
    int64_t &out) {
  if (market == nullptr) {
    out = 0;
    return true;
  }
  __int128_t scaled = static_cast<__int128_t>(price) * static_cast<__int128_t>(signed_qty);
  int const exponent = static_cast<int>(market->px_exponent) - static_cast<int>(market->size_decimals);
  if (exponent > -6) {
    __int128_t factor = 1;
    if (!pow10_i128(static_cast<uint32_t>(exponent + 6), factor)) {
      return false;
    }
    scaled *= factor;
  } else if (exponent < -6) {
    __int128_t divisor = 1;
    if (!pow10_i128(static_cast<uint32_t>(-6 - exponent), divisor) || divisor == 0) {
      return false;
    }
    scaled /= divisor;
  }
  return to_int64_checked(scaled, out);
}

static bool apply_position_delta(
    UiSnapshot::AccountSubaccountRow &subaccount,
    uint32_t symbol,
    std::string const &side,
    uint64_t qty,
    uint64_t price,
    int64_t fee,
    MarketInfo const *market,
    bool reverse_value,
    std::string &error) {
  if (!is_valid_side(side)) {
    error = "invalid fill side";
    return false;
  }
  if (qty > static_cast<uint64_t>(std::numeric_limits<int64_t>::max())) {
    error = "fill qty too large";
    return false;
  }
  bool const is_ask = side == "ASK";
  int64_t const signed_qty = static_cast<int64_t>(qty);
  int64_t const signed_position_qty = is_ask ? -signed_qty : signed_qty;
  int64_t cost_basis_delta = 0;
  if (!cost_basis_delta_usd(market, price, signed_position_qty, cost_basis_delta)) {
    error = "position cost basis overflow";
    return false;
  }
  int64_t const fee_delta = reverse_value ? -fee : fee;

  bool position_found = false;
  for (UiSnapshot::PositionRow &position : subaccount.positions) {
    if (position.symbol != symbol) {
      continue;
    }
    if (is_ask) {
      position.net_qty -= signed_qty;
    } else {
      position.net_qty += signed_qty;
    }
    position.cost_basis += cost_basis_delta;
    position.pending_fees += fee_delta;
    position_found = true;
    break;
  }
  if (!position_found) {
    int64_t net_qty = signed_qty;
    if (is_ask) {
      net_qty = -net_qty;
    }
    UiSnapshot::PositionRow row;
    row.symbol = symbol;
    row.net_qty = net_qty;
    row.cost_basis = cost_basis_delta;
    row.pending_fees = fee_delta;
    subaccount.positions.push_back(row);
  }
  std::sort(subaccount.positions.begin(), subaccount.positions.end(), position_symbol_less);
  error.clear();
  return true;
}

static bool recent_fill_matches_settlement(
    UiSnapshot::FillRow const &fill,
    FillSettlementEventMessage const &message) {
  if (fill.settled) {
    return false;
  }
  if (fill.external_order_id != message.external_order_id) {
    return false;
  }
  if (message.trade_id != 0 && fill.trade_id != message.trade_id) {
    return false;
  }
  if (fill.symbol != message.symbol) {
    return false;
  }
  if (fill.side != message.side) {
    return false;
  }
  if (fill.qty != message.qty) {
    return false;
  }
  if (message.price != 0 && fill.price != 0 && fill.price != message.price) {
    return false;
  }
  return true;
}

static UiSnapshot::FillRow *find_recent_fill_for_settlement(
    std::vector<UiSnapshot::FillRow> &recent_fills,
    FillSettlementEventMessage const &message) {
  for (auto it = recent_fills.rbegin(); it != recent_fills.rend(); ++it) {
    if (it->subaccount_id == message.subaccount_id && recent_fill_matches_settlement(*it, message)) {
      return &(*it);
    }
  }
  return nullptr;
}

static bool has_recent_fill_seq(
    std::vector<UiSnapshot::FillRow> const &recent_fills,
    uint64_t seq) {
  if (seq == 0) {
    return false;
  }
  for (UiSnapshot::FillRow const &fill : recent_fills) {
    if (fill.seq == seq) {
      return true;
    }
  }
  return false;
}

static void append_recent_fill(
    std::vector<UiSnapshot::FillRow> &recent_fills,
    FillEventMessage const &message,
    bool settled) {
  if (has_recent_fill_seq(recent_fills, message.seq)) {
    return;
  }
  recent_fills.insert(recent_fills.begin(), UiSnapshot::FillRow{
                                                message.seq,
                                                message.trade_id,
                                                message.subaccount_id,
                                                message.client_instruction_id,
                                                message.external_order_id,
                                                message.symbol,
                                                message.side,
                                                message.role,
                                                message.price,
                                                message.qty,
                                                0,
                                                message.gateway_send_unix_ns,
                                                0,
                                                false,
                                                message.has_gateway_send_unix_ns,
                                                false,
                                                settled,
                                            });
  if (recent_fills.size() > 20) {
    recent_fills.resize(20);
  }
}

static void append_recent_fill_row(
    std::vector<UiSnapshot::FillRow> &recent_fills,
    UiSnapshot::FillRow const &row) {
  if (row.seq == 0 || has_recent_fill_seq(recent_fills, row.seq)) {
    return;
  }
  recent_fills.push_back(row);
  std::sort(recent_fills.begin(), recent_fills.end(), fill_row_seq_greater);
  if (recent_fills.size() > 20) {
    recent_fills.resize(20);
  }
}

static void append_adl_history_row(
    std::vector<UiSnapshot::FillRow> &recent_fills,
    OrderHistoryMessage::Adl const &adl) {
  if (adl.operation_nonce == 0 || adl.last_event_seq == 0 || adl.market_id == 0 || adl.fill_qty == 0 ||
      !is_valid_side(adl.side) || !is_valid_adl_role(adl.role) || !is_valid_adl_history_status(adl.status)) [[unlikely]] {
    return;
  }
  UiSnapshot::FillRow row;
  row.seq = adl.last_event_seq;
  row.trade_id = adl.operation_nonce;
  row.subaccount_id = adl.subaccount_id;
  row.symbol = adl.market_id;
  row.side = adl.side;
  row.role = adl.role;
  row.price = adl.fill_price;
  row.qty = adl.fill_qty;
  row.event_unix_ns = adl.event_unix_ns;
  row.has_event_unix_ns = adl.event_unix_ns != 0;
  row.settled = adl.status == "settled";
  row.adl_failed = adl.status == "failed";
  row.operation_nonce = adl.operation_nonce;
  row.allocated_loss = adl.allocated_loss;
  row.error_code = adl.error_code;
  row.workflow_error_code = adl.workflow_error_code;
  row.cleanup_error_code = adl.cleanup_error_code;
  row.failure_stage = adl.failure_stage;
  append_recent_fill_row(recent_fills, row);
}

} // namespace

bool AccountState::should_ignore_snapshot(uint64_t seq) const {
  return last_seq_ != 0 && seq <= last_seq_;
}

bool AccountState::should_ignore_event(uint64_t seq) const {
  return seq != 0 && seq <= last_seq_;
}

void AccountState::record_seq_match_latency(uint64_t matcher_unix_ns, uint64_t sequencer_recv_unix_ns) {
  if (matcher_unix_ns < sequencer_recv_unix_ns) {
    return;
  }
  double const sample_ns = static_cast<double>(matcher_unix_ns - sequencer_recv_unix_ns);
  seq_match_latency_avg_.add_sample(sample_ns);
}

void AccountState::reset() {
  has_snapshot_ = false;
  last_seq_ = 0;
  seq_match_latency_avg_.reset();
  subaccounts_.clear();
  recent_fills_.clear();
}

void AccountState::populate_snapshot(UiSnapshot &snapshot) const {
  snapshot.has_account_snapshot = has_snapshot_;
  snapshot.account_last_seq = last_seq_;
  snapshot.subaccounts.clear();
  snapshot.subaccounts.reserve(subaccounts_.size());
  for (auto const &entry : subaccounts_) {
    snapshot.subaccounts.push_back(entry.second);
  }
  snapshot.recent_fills = recent_fills_;
  snapshot.seq_match_latency_avg_ns = seq_match_latency_avg_.mean();
  snapshot.seq_match_latency_samples = seq_match_latency_avg_.sample_count();
}

bool AccountState::find_working_order_cancel_info(
    uint64_t subaccount_id,
    uint64_t external_order_id,
    uint32_t &symbol,
    OrderRole &role) const {
  auto const subaccount_it = subaccounts_.find(subaccount_id);
  if (subaccount_it == subaccounts_.end()) {
    return false;
  }
  for (UiSnapshot::WorkingOrderRow const &order : subaccount_it->second.working_orders) {
    if (order.external_order_id == external_order_id) {
      symbol = order.symbol;
      role = order.role == "TAKER" ? OrderRole::Taker : OrderRole::Maker;
      return true;
    }
  }
  return false;
}

void AccountState::apply_snapshot(AccountSnapshotMessage const &message, std::string &notice) {
  if (should_ignore_snapshot(message.last_seq)) {
    notice = "ignored stale account snapshot seq=" + std::to_string(message.last_seq);
    return;
  }
  subaccounts_.clear();
  for (AccountSnapshotMessage::Subaccount const &subaccount : message.subaccounts) {
    UiSnapshot::AccountSubaccountRow row;
    row.subaccount_id = subaccount.subaccount_id;
    row.collateral_balance = subaccount.collateral_balance;
    row.accrued_fee = subaccount.accrued_fee;
    row.accrued_funding = subaccount.accrued_funding;
    row.status = subaccount.status;
    for (AccountSnapshotMessage::Position const &position : subaccount.positions) {
      if (position.symbol == 0) {
        notice = "ignored malformed account snapshot";
        return;
      }
      row.positions.push_back(UiSnapshot::PositionRow{
          position.symbol,
          position.net_qty,
          position.cost_basis,
          position.pending_fees,
          position.funding_accrued,
          position.last_funding_index_e8,
          position.realized_pnl,
      });
    }
    for (AccountSnapshotMessage::WorkingOrder const &order : subaccount.working_orders) {
      if (order.external_order_id == 0 || order.symbol == 0 || order.original_qty == 0 ||
          order.remaining_qty > order.original_qty ||
          order.filled_qty > order.original_qty - order.remaining_qty || !is_valid_side(order.side) ||
          !is_valid_role(order.role) || !is_valid_tif(order.tif)) {
        notice = "ignored malformed account snapshot";
        return;
      }
      row.working_orders.push_back(UiSnapshot::WorkingOrderRow{
          order.external_order_id,
          order.client_instruction_id,
          order.original_iat,
          order.symbol,
          order.side,
          order.role,
          order.tif,
          order.price,
          order.filled_qty + order.remaining_qty,
          order.remaining_qty,
          order.order_type,
          static_cast<int32_t>(order.delta_ppm),
          order.execution_mode,
      });
    }
    for (AccountSnapshotMessage::ConditionalGroup const &group : subaccount.conditional_groups) {
      row.conditional_groups.push_back(UiSnapshot::ConditionalGroupRow{
          group.group_external_order_id,
          group.client_instruction_id,
          0,
          group.symbol,
          group.qty,
          group.tp_trigger_price,
          group.sl_trigger_price,
          group.leg_flags,
          group.side,
          group.state,
          group.activation_mode,
      });
    }
    subaccounts_[row.subaccount_id] = std::move(row);
  }
  has_snapshot_ = true;
  last_seq_ = message.last_seq;
  notice = "account snapshot seq=" + std::to_string(message.last_seq);
}

void AccountState::apply_conditional_event(
    std::string const &type,
    ConditionalEventMessage const &message,
    std::string &notice) {
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale " + type + " seq=" + std::to_string(message.seq);
    return;
  }
  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;
  std::vector<UiSnapshot::ConditionalGroupRow> &groups = subaccount.conditional_groups;
  size_t index = 0;
  while (index < groups.size() &&
         groups[index].group_external_order_id != message.group_external_order_id) {
    ++index;
  }
  if (type == "ConditionalApproved") {
    UiSnapshot::ConditionalGroupRow group;
    group.group_external_order_id = message.group_external_order_id;
    group.client_instruction_id = message.client_instruction_id;
    group.symbol = message.symbol;
    group.qty = message.qty;
    group.tp_trigger_price = message.tp_trigger_price;
    group.sl_trigger_price = message.sl_trigger_price;
    group.leg_flags = message.leg_flags;
    group.side = message.side;
    group.state = message.state;
    group.activation_mode = message.activation_mode;
    if (index == groups.size()) {
      groups.push_back(std::move(group));
    } else {
      groups[index] = std::move(group);
    }
  } else if (type == "ConditionalTriggered") {
    if (index < groups.size()) {
      groups[index].state = "triggering";
      groups[index].selected_external_order_id = message.selected_external_order_id;
    }
  } else if (index < groups.size()) {
    groups.erase(groups.begin() + static_cast<std::ptrdiff_t>(index));
  }
  last_seq_ = message.seq;
  notice = type + " group=" + std::to_string(message.group_external_order_id);
}

void AccountState::apply_order_history(OrderHistoryMessage const &message, std::string &notice) {
  size_t added = 0;
  size_t adl_added = 0;
  for (OrderHistoryMessage::Order const &order : message.orders) {
    if (order.external_order_id == 0 || order.symbol == 0 || !is_valid_side(order.side) ||
        !is_valid_role(order.role)) {
      continue;
    }
    for (OrderHistoryMessage::Event const &event : order.events) {
      if (event.event_type != "filled" || event.qty == 0 || event.stream_seq == 0) {
        continue;
      }
      UiSnapshot::FillRow row;
      row.seq = event.stream_seq;
      row.trade_id = event.trade_id;
      row.subaccount_id = order.subaccount_id;
      row.client_instruction_id =
          event.client_instruction_id != 0 ? event.client_instruction_id : order.client_instruction_id;
      row.external_order_id = order.external_order_id;
      row.symbol = order.symbol;
      row.side = order.side;
      row.role = order.role;
      row.price = event.price != 0 ? event.price : order.price;
      row.qty = event.qty;
      row.order_settled_qty = order.settled_qty;
      row.event_unix_ns = event.event_unix_ns;
      row.has_order_settled_qty = true;
      row.has_event_unix_ns = event.event_unix_ns != 0;
      row.settled = order.busted_qty == 0 && order.settled_qty >= event.qty;
      bool const existed = has_recent_fill_seq(recent_fills_, row.seq);
      append_recent_fill_row(recent_fills_, row);
      if (!existed) {
        ++added;
      }
    }
  }
  for (OrderHistoryMessage::Adl const &adl : message.adl) {
    bool const existed = has_recent_fill_seq(recent_fills_, adl.last_event_seq);
    append_adl_history_row(recent_fills_, adl);
    if (!existed && has_recent_fill_seq(recent_fills_, adl.last_event_seq)) {
      ++adl_added;
    }
  }
  notice = "order history fills=" + std::to_string(added) + " adl=" + std::to_string(adl_added);
}

void AccountState::apply_order_accepted(OrderAcceptedMessage const &message, std::string &notice) {
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale order accepted seq=" + std::to_string(message.seq);
    return;
  }
  if (message.seq == 0 || message.external_order_id == 0 || message.symbol == 0 || message.qty == 0 ||
      !is_valid_side(message.side) || !is_valid_role(message.role) || !is_valid_tif(message.tif)) {
    notice = "ignored malformed order accepted";
    return;
  }
  if (message.has_matcher_unix_ns && message.has_sequencer_recv_unix_ns) {
    record_seq_match_latency(message.matcher_unix_ns, message.sequencer_recv_unix_ns);
  }
  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;
  bool replaced = false;
  for (UiSnapshot::WorkingOrderRow &order : subaccount.working_orders) {
    if (order.external_order_id == message.external_order_id) {
      order = UiSnapshot::WorkingOrderRow{
          message.external_order_id,
          message.client_instruction_id,
          message.original_iat,
          message.symbol,
          message.side,
          message.role,
          message.tif,
          message.price,
          message.qty,
          message.qty,
          message.order_type,
          static_cast<int32_t>(message.delta_ppm),
          message.execution_mode,
      };
      replaced = true;
      break;
    }
  }
  if (!replaced) {
    subaccount.working_orders.push_back(UiSnapshot::WorkingOrderRow{
        message.external_order_id,
        message.client_instruction_id,
        message.original_iat,
        message.symbol,
        message.side,
        message.role,
        message.tif,
        message.price,
        message.qty,
        message.qty,
        message.order_type,
        static_cast<int32_t>(message.delta_ppm),
        message.execution_mode,
    });
  }
  std::sort(subaccount.working_orders.begin(), subaccount.working_orders.end(), working_order_external_id_less);
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "order accepted oid=" + std::to_string(message.external_order_id);
}

void AccountState::apply_order_reject(OrderRejectMessage const &message, std::string &notice) {
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale order reject seq=" + std::to_string(message.seq);
    return;
  }
  if (message.seq == 0 ||
      (!message.side.empty() && !is_valid_side(message.side)) ||
      !is_valid_role(message.role) ||
      !is_valid_tif(message.tif)) {
    notice = "ignored malformed order reject";
    return;
  }
  if (message.has_matcher_unix_ns && message.has_sequencer_recv_unix_ns) {
    record_seq_match_latency(message.matcher_unix_ns, message.sequencer_recv_unix_ns);
  }
  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;
  for (size_t i = 0; i < subaccount.working_orders.size(); ++i) {
    if (subaccount.working_orders[i].external_order_id == message.external_order_id) {
      subaccount.working_orders.erase(subaccount.working_orders.begin() + static_cast<std::ptrdiff_t>(i));
      break;
    }
  }
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "order rejected oid=" + std::to_string(message.external_order_id) +
           " reason=" + order_reject_reason_name(message.reason) +
           " code=" + std::to_string(message.reason);
}

bool AccountState::apply_fill(
    FillEventMessage const &message,
    MarketInfo const *market,
    std::string &notice,
    std::string &error) {
  bool const adl = is_adl_fill(message);
  if (message.seq == 0 || (!adl && message.external_order_id == 0) || message.symbol == 0 || message.qty == 0 ||
      !is_valid_side(message.side) || !is_valid_fill_role(message)) {
    error = "malformed fill event";
    notice = "account stream update failed";
    return false;
  }
  if (should_ignore_event(message.seq)) {
    append_recent_fill(recent_fills_, message, adl);
    notice = adl ? "bootstrapped ADL fill seq=" + std::to_string(message.seq)
                 : "bootstrapped fill seq=" + std::to_string(message.seq);
    error.clear();
    return true;
  }
  if (message.qty > static_cast<uint64_t>(std::numeric_limits<int64_t>::max())) {
    error = "fill qty too large";
    notice = "account stream update failed";
    return false;
  }
  if (message.has_matcher_unix_ns && message.has_sequencer_recv_unix_ns) {
    record_seq_match_latency(message.matcher_unix_ns, message.sequencer_recv_unix_ns);
  }

  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;

  if (!apply_position_delta(
          subaccount,
          message.symbol,
          message.side,
          message.qty,
          message.price,
          message.has_fee ? message.fee : 0,
          market,
          false,
          error)) {
    notice = "account stream update failed";
    return false;
  }

  if (!adl) {
    for (size_t i = 0; i < subaccount.working_orders.size(); ++i) {
      UiSnapshot::WorkingOrderRow &order = subaccount.working_orders[i];
      if (order.external_order_id != message.external_order_id) {
        continue;
      }
      if (message.qty >= order.remaining_qty) {
        subaccount.working_orders.erase(subaccount.working_orders.begin() + static_cast<std::ptrdiff_t>(i));
      } else {
        order.remaining_qty -= message.qty;
      }
      break;
    }
  }

  append_recent_fill(recent_fills_, message, adl);
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = (adl ? "ADL fill trade=" : "fill trade=") + std::to_string(message.trade_id) +
           " qty=" + std::to_string(message.qty);
  error.clear();
  return true;
}

bool AccountState::apply_adl_failed(
    AdlFailedMessage const &message,
    std::string &notice,
    std::string &error) {
  if (message.seq == 0 || message.operation_nonce == 0 || message.market_id == 0 || message.qty == 0 ||
      message.status == 0 || !is_valid_side(message.side) || !is_valid_adl_role(message.role)) [[unlikely]] {
    error = "malformed ADL failed event";
    notice = "account stream update failed";
    return false;
  }

  UiSnapshot::FillRow row;
  row.seq = message.seq;
  row.trade_id = message.operation_nonce;
  row.subaccount_id = message.subaccount_id;
  row.client_instruction_id = message.client_instruction_id;
  row.external_order_id = message.external_order_id;
  row.symbol = message.market_id;
  row.side = message.side;
  row.role = message.role;
  row.price = message.price;
  row.qty = message.qty;
  row.adl_failed = true;
  row.operation_nonce = message.operation_nonce;
  row.allocated_loss = message.allocated_loss;
  row.error_code = message.error_code;
  row.workflow_error_code = message.workflow_error_code;
  row.cleanup_error_code = message.cleanup_error_code;
  row.failure_stage = message.failure_stage;
  bool const existed = has_recent_fill_seq(recent_fills_, row.seq);
  append_recent_fill_row(recent_fills_, row);
  if (!should_ignore_event(message.seq) && message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = (existed ? "ADL failure already recorded nonce=" : "ADL failed nonce=") +
           std::to_string(message.operation_nonce) + " error=" + std::to_string(message.error_code);
  error.clear();
  return true;
}

bool AccountState::apply_fill_settled(
    FillSettlementEventMessage const &message,
    MarketInfo const *market,
    std::string &notice,
    std::string &error) {
  if (message.seq == 0 || message.external_order_id == 0 || message.symbol == 0 || message.qty == 0 ||
      !is_valid_side(message.side)) {
    error = "malformed fill settled event";
    notice = "account stream update failed";
    return false;
  }
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale fill settled seq=" + std::to_string(message.seq);
    error.clear();
    return true;
  }
  if (message.reduce_only_adjustment &&
      (message.reduced_qty != 0 || message.fee != message.applied_fee)) {
    UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
    std::string const reverse_side = message.side == "ASK" ? "BID" : "ASK";
    int64_t fee_to_remove = 0;
    if (!to_int64_checked(static_cast<__int128_t>(message.fee) -
                              static_cast<__int128_t>(message.applied_fee),
                          fee_to_remove)) [[unlikely]] {
      error = "settlement fee adjustment overflow";
      notice = "account stream update failed";
      return false;
    }
    if (!apply_position_delta(subaccount, message.symbol, reverse_side,
                              message.reduced_qty, message.price, fee_to_remove,
                              market, true, error)) [[unlikely]] {
      notice = "account stream update failed";
      return false;
    }
  }
  UiSnapshot::FillRow *recent_fill = find_recent_fill_for_settlement(recent_fills_, message);
  if (recent_fill != nullptr) {
    recent_fill->order_settled_qty += message.reduce_only_adjustment
                                          ? message.settled_qty
                                          : message.qty;
    recent_fill->has_order_settled_qty = true;
    if (recent_fill->order_settled_qty >= recent_fill->qty) {
      recent_fill->settled = true;
    }
    if (message.reduce_only_adjustment) {
      recent_fill->settled = true;
    }
    if (recent_fill->has_event_unix_ns && message.has_gateway_send_unix_ns &&
        message.gateway_send_unix_ns >= recent_fill->event_unix_ns) {
      recent_fill->settle_delta_ns = message.gateway_send_unix_ns - recent_fill->event_unix_ns;
      recent_fill->has_settle_delta_ns = true;
    }
  }
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "fill settled oid=" + std::to_string(message.external_order_id) +
           " qty=" + std::to_string(message.qty);
  error.clear();
  return true;
}

bool AccountState::apply_fill_busted(
    FillSettlementEventMessage const &message,
    MarketInfo const *market,
    std::string &notice,
    std::string &error) {
  if (message.seq == 0 || message.external_order_id == 0 || message.symbol == 0 || message.qty == 0 ||
      !is_valid_side(message.side)) {
    error = "malformed fill busted event";
    notice = "account stream update failed";
    return false;
  }
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale fill busted seq=" + std::to_string(message.seq);
    error.clear();
    return true;
  }
  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;
  std::string reverse_side = message.side == "ASK" ? "BID" : "ASK";
  if (!apply_position_delta(
          subaccount,
          message.symbol,
          reverse_side,
          message.qty,
          message.price,
          message.has_fee ? message.fee : 0,
          market,
          true,
          error)) {
    notice = "account stream update failed";
    return false;
  }
  UiSnapshot::FillRow *recent_fill = find_recent_fill_for_settlement(recent_fills_, message);
  if (recent_fill != nullptr) {
    recent_fill->has_order_settled_qty = true;
  }
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "fill busted oid=" + std::to_string(message.external_order_id) +
           " qty=" + std::to_string(message.qty);
  error.clear();
  return true;
}

bool AccountState::apply_account_funding_update(
    AccountFundingUpdateMessage const &message,
    std::string &notice,
    std::string &error) {
  if (message.seq == 0 || message.market_id == 0 ||
      message.last_funding_index_e8 == message.prev_funding_index_e8) {
    error = "malformed funding update event";
    notice = "account stream update failed";
    return false;
  }
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale funding update seq=" + std::to_string(message.seq);
    error.clear();
    return true;
  }
  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;
  uint32_t const symbol = message.symbol != 0 ? message.symbol : message.market_id;
  for (UiSnapshot::PositionRow &position : subaccount.positions) {
    if (position.symbol != symbol) {
      continue;
    }
    position.funding_accrued = message.funding_accrued;
    position.last_funding_index_e8 = message.last_funding_index_e8;
    if (message.seq > last_seq_) {
      last_seq_ = message.seq;
    }
    notice = "funding update sym=" + std::to_string(message.market_id) +
             " delta=" + std::to_string(message.funding_delta);
    error.clear();
    return true;
  }
  UiSnapshot::PositionRow row;
  row.symbol = symbol;
  row.funding_accrued = message.funding_accrued;
  row.last_funding_index_e8 = message.last_funding_index_e8;
  subaccount.positions.push_back(row);
  std::sort(subaccount.positions.begin(), subaccount.positions.end(), position_symbol_less);
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "funding update sym=" + std::to_string(message.market_id) +
           " delta=" + std::to_string(message.funding_delta);
  error.clear();
  return true;
}

bool AccountState::apply_user_collateral_update(
    UserCollateralUpdateMessage const &message,
    std::string &notice,
    std::string &error) {
  if (message.seq == 0) {
    error = "malformed collateral update event";
    notice = "account stream update failed";
    return false;
  }
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale collateral update seq=" + std::to_string(message.seq);
    error.clear();
    return true;
  }
  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;
  subaccount.collateral_balance = message.collateral_balance;
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "collateral update subaccount=" + std::to_string(message.subaccount_id) +
           " delta=" + std::to_string(message.collateral_delta) +
           " total=" + std::to_string(message.collateral_balance) +
           " fee=" + std::to_string(message.fee);
  error.clear();
  return true;
}

bool AccountState::apply_inactive_position_settlement_status(
    InactivePositionSettlementStatusMessage const &message,
    std::string &notice,
    std::string &error) {
  if (message.seq == 0 || message.market_id == 0 || message.position_qty == 0) {
    error = "malformed inactive position status";
    notice = "account stream update failed";
    return false;
  }
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale inactive position status seq=" + std::to_string(message.seq);
    error.clear();
    return true;
  }
  if (message.status != 0 || message.error_code != 0) {
    last_seq_ = std::max(last_seq_, message.seq);
    notice = "inactive position settlement failed sym=" + std::to_string(message.market_id);
    error.clear();
    return true;
  }
  if (!message.audit_event_present || !message.has_collateral_balance) {
    error = "inactive position status is missing audit values";
    notice = "account stream update failed";
    return false;
  }
  auto const subaccount_it = subaccounts_.find(message.subaccount_id);
  if (subaccount_it == subaccounts_.end()) {
    error = "inactive position subaccount is missing";
    notice = "account stream update failed";
    return false;
  }
  auto &positions = subaccount_it->second.positions;
  auto position_it = positions.begin();
  for (; position_it != positions.end(); ++position_it) {
    if (position_it->symbol == message.market_id &&
        position_it->net_qty == message.position_qty) {
      break;
    }
  }
  if (position_it == positions.end()) {
    error = "inactive position does not match local state";
    notice = "account stream update failed";
    return false;
  }
  if (message.has_position_count_after && positions.size() - 1 != message.position_count_after) {
    error = "inactive position count does not match audit";
    notice = "account stream update failed";
    return false;
  }
  positions.erase(position_it);
  subaccount_it->second.collateral_balance = message.collateral_balance;
  subaccount_it->second.accrued_fee = message.fees_accrued_after;
  subaccount_it->second.accrued_funding = message.net_funding_after;
  last_seq_ = std::max(last_seq_, message.seq);
  notice = "inactive position settled sym=" + std::to_string(message.market_id);
  error.clear();
  return true;
}

void AccountState::apply_cancel_ack(CancelAckEventMessage const &message, std::string &notice) {
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale cancel ack seq=" + std::to_string(message.seq);
    return;
  }
  if (message.seq == 0 ||
      message.external_order_id == 0) {
    notice = "ignored malformed cancel ack";
    return;
  }
  if (message.has_matcher_unix_ns && message.has_sequencer_recv_unix_ns) {
    record_seq_match_latency(message.matcher_unix_ns, message.sequencer_recv_unix_ns);
  }
  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;
  for (size_t i = 0; i < subaccount.working_orders.size(); ++i) {
    if (subaccount.working_orders[i].external_order_id == message.external_order_id) {
      subaccount.working_orders.erase(subaccount.working_orders.begin() + static_cast<std::ptrdiff_t>(i));
      break;
    }
  }
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "cancel ack oid=" + std::to_string(message.external_order_id);
  if (message.reason != 0) {
    notice += " reason=" + std::string(cancel_ack_reason_name(message.reason)) +
              " code=" + std::to_string(message.reason);
  }
}

void AccountState::apply_cancel_reject(CancelRejectEventMessage const &message, std::string &notice) {
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale cancel reject seq=" + std::to_string(message.seq);
    return;
  }
  if (message.seq == 0 ||
      message.external_order_id == 0) {
    notice = "ignored malformed cancel reject";
    return;
  }
  if (message.has_matcher_unix_ns && message.has_sequencer_recv_unix_ns) {
    record_seq_match_latency(message.matcher_unix_ns, message.sequencer_recv_unix_ns);
  }
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "cancel rejected oid=" + std::to_string(message.external_order_id) +
           " reason=" + cancel_reject_reason_name(message.reason) +
           " code=" + std::to_string(message.reason);
}

void AccountState::apply_modify_ack(ModifyAckEventMessage const &message, std::string &notice) {
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale modify ack seq=" + std::to_string(message.seq);
    return;
  }
  if (message.seq == 0 ||
      message.external_order_id == 0 ||
      message.qty == 0) {
    notice = "ignored malformed modify ack";
    return;
  }
  if (message.has_matcher_unix_ns && message.has_sequencer_recv_unix_ns) {
    record_seq_match_latency(message.matcher_unix_ns, message.sequencer_recv_unix_ns);
  }
  UiSnapshot::AccountSubaccountRow &subaccount = subaccounts_[message.subaccount_id];
  subaccount.subaccount_id = message.subaccount_id;
  for (UiSnapshot::WorkingOrderRow &order : subaccount.working_orders) {
    if (order.external_order_id == message.external_order_id) {
      order.original_qty = order.original_qty - order.remaining_qty + message.qty;
      order.price = message.price;
      order.remaining_qty = message.qty;
      order.delta_ppm = message.delta_ppm;
      break;
    }
  }
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "modify ack oid=" + std::to_string(message.external_order_id);
}

void AccountState::apply_modify_reject(ModifyRejectEventMessage const &message, std::string &notice) {
  if (should_ignore_event(message.seq)) {
    notice = "ignored stale modify reject seq=" + std::to_string(message.seq);
    return;
  }
  if (message.seq == 0 ||
      message.external_order_id == 0) {
    notice = "ignored malformed modify reject";
    return;
  }
  if (message.has_matcher_unix_ns && message.has_sequencer_recv_unix_ns) {
    record_seq_match_latency(message.matcher_unix_ns, message.sequencer_recv_unix_ns);
  }
  if (message.seq > last_seq_) {
    last_seq_ = message.seq;
  }
  notice = "modify rejected oid=" + std::to_string(message.external_order_id) +
           " reason=" + std::to_string(message.reason);
}

} // namespace api_client
