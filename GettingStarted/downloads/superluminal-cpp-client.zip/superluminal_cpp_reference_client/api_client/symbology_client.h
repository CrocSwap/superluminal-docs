#pragma once

#include <cstdint>
#include <map>
#include <string>

#include "api_client_types.h"

namespace api_client {

struct SymbologySnapshot {
  uint64_t version{0};
  int32_t taker_fee_ppm{0};
  int32_t maker_fee_ppm{0};
  std::map<uint32_t, MarketInfo> markets{};
};

std::string derive_symbology_url(std::string const &ws_url);
bool parse_symbology_snapshot(std::string const &payload, SymbologySnapshot &out, std::string &error);
bool fetch_symbology_snapshot(std::string const &url, SymbologySnapshot &out, std::string &error);

} // namespace api_client
