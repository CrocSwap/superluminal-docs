#pragma once

#include <cstdint>
#include <map>
#include <string>
#include <vector>

#include "api_client_types.h"
#include "gateway_protocol_codec.h"
#include "running_avg.h"

namespace api_client {

class AccountState {
 public:
  void reset();
  void populate_snapshot(UiSnapshot &snapshot) const;
  bool find_working_order_cancel_info(uint64_t subaccount_id,
                                      uint64_t external_order_id,
                                      uint32_t &symbol,
                                      OrderRole &role) const;
  void apply_snapshot(AccountSnapshotMessage const &message, std::string &notice);
  void apply_order_history(OrderHistoryMessage const &message, std::string &notice);
  void apply_order_accepted(OrderAcceptedMessage const &message, std::string &notice);
  void apply_order_reject(OrderRejectMessage const &message, std::string &notice);
  bool apply_fill(FillEventMessage const &message, MarketInfo const *market, std::string &notice, std::string &error);
  bool apply_adl_failed(AdlFailedMessage const &message, std::string &notice, std::string &error);
  bool apply_fill_settled(FillSettlementEventMessage const &message, std::string &notice, std::string &error);
  bool apply_fill_busted(FillSettlementEventMessage const &message, MarketInfo const *market, std::string &notice, std::string &error);
  bool apply_account_funding_update(AccountFundingUpdateMessage const &message, std::string &notice, std::string &error);
  bool apply_user_collateral_update(UserCollateralUpdateMessage const &message, std::string &notice, std::string &error);
  void apply_cancel_ack(CancelAckEventMessage const &message, std::string &notice);
  void apply_cancel_reject(CancelRejectEventMessage const &message, std::string &notice);
  void apply_modify_ack(ModifyAckEventMessage const &message, std::string &notice);
  void apply_modify_reject(ModifyRejectEventMessage const &message, std::string &notice);

 private:
  void record_seq_match_latency(uint64_t matcher_unix_ns, uint64_t sequencer_recv_unix_ns);
  bool should_ignore_snapshot(uint64_t seq) const;
  bool should_ignore_event(uint64_t seq) const;
  bool has_snapshot_{false};
  uint64_t last_seq_{0};
  RunningAvg seq_match_latency_avg_{};
  std::map<uint64_t, UiSnapshot::AccountSubaccountRow> subaccounts_{};
  std::vector<UiSnapshot::FillRow> recent_fills_{};
};

} // namespace api_client
