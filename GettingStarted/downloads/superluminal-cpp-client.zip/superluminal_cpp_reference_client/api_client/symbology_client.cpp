#include "symbology_client.h"

#include <ixwebsocket/IXWebSocket.h>

#include <condition_variable>
#include <chrono>
#include <limits>
#include <mutex>
#include <string_view>

#include "dfba_common/simdjson_utils.hpp"

namespace {

using api_client::MarketInfo;
using api_client::SymbologySnapshot;
using dfba::json::JsonArray;
using dfba::json::JsonElement;
using dfba::json::JsonObject;

bool parse_market(JsonObject const &object, MarketInfo &out) {
  out = MarketInfo{};
  uint64_t feed_id = 0;
  if (!dfba::json::extract_json_field(object, "id", feed_id) ||
      feed_id == 0 ||
      feed_id > static_cast<uint64_t>(std::numeric_limits<uint32_t>::max())) {
    return false;
  }
  out.feed_id = static_cast<uint32_t>(feed_id);

  if (!dfba::json::extract_json_field(object, "symbol", out.symbol) ||
      out.symbol.empty()) {
    return false;
  }
  if (!dfba::json::extract_json_field(object, "quote", out.quote) ||
      out.quote.empty()) {
    return false;
  }

  int64_t px_exponent = 0;
  if (!dfba::json::extract_json_field(object, "px_exponent", px_exponent) ||
      px_exponent < static_cast<int64_t>(std::numeric_limits<int16_t>::min()) ||
      px_exponent > static_cast<int64_t>(std::numeric_limits<int16_t>::max())) {
    return false;
  }
  out.px_exponent = static_cast<int16_t>(px_exponent);

  uint64_t size_decimals = 0;
  if (!dfba::json::extract_json_field(object, "size_decimals", size_decimals) ||
      size_decimals > static_cast<uint64_t>(std::numeric_limits<uint8_t>::max())) {
    return false;
  }
  out.size_decimals = static_cast<uint8_t>(size_decimals);

  dfba::json::extract_json_field(object, "tick_size", out.tick_size);
  uint64_t max_funding_rate_e8 = 0;
  if (dfba::json::extract_json_field(object, "max_funding_rate_e8", max_funding_rate_e8)) {
    if (max_funding_rate_e8 > static_cast<uint64_t>(std::numeric_limits<uint32_t>::max())) {
      return false;
    }
    out.max_funding_rate_e8 = static_cast<uint32_t>(max_funding_rate_e8);
  }

  uint64_t initial_margin_bps = 0;
  if (dfba::json::extract_json_field(object, "initial_margin_bps", initial_margin_bps)) {
    if (initial_margin_bps > static_cast<uint64_t>(std::numeric_limits<uint16_t>::max())) {
      return false;
    }
    out.initial_margin_bps = static_cast<uint16_t>(initial_margin_bps);
  }

  uint64_t maintenance_margin_bps = 0;
  if (dfba::json::extract_json_field(object, "maintenance_margin_bps", maintenance_margin_bps)) {
    if (maintenance_margin_bps > static_cast<uint64_t>(std::numeric_limits<uint16_t>::max())) {
      return false;
    }
    out.maintenance_margin_bps = static_cast<uint16_t>(maintenance_margin_bps);
  }

  uint64_t transfer_margin_floor_bps = 0;
  if (dfba::json::extract_json_field(object, "transfer_margin_floor_bps", transfer_margin_floor_bps)) {
    if (transfer_margin_floor_bps > static_cast<uint64_t>(std::numeric_limits<uint16_t>::max())) {
      return false;
    }
    out.transfer_margin_floor_bps = static_cast<uint16_t>(transfer_margin_floor_bps);
  }
  dfba::json::extract_json_field(object, "change_count", out.change_count);

  std::string status;
  if (dfba::json::extract_json_field(object, "status", status)) {
    out.status = status;
    return true;
  }

  JsonElement active_value;
  if (dfba::json::find_json_field(object, "active", active_value) == simdjson::SUCCESS) {
    bool active = true;
    if (active_value.get(active) == simdjson::SUCCESS) {
      out.status = active ? "active" : "inactive";
    }
  }
  return true;
}

bool parse_markets_array(JsonArray const &markets, SymbologySnapshot &out) {
  for (JsonElement element : markets) {
    JsonObject market_object;
    if (element.get(market_object) != simdjson::SUCCESS) {
      return false;
    }

    MarketInfo market;
    if (!parse_market(market_object, market)) {
      return false;
    }
    out.markets[market.feed_id] = std::move(market);
  }
  return true;
}

bool extract_optional_i32_field(JsonObject const &object, std::string_view key, int32_t &out) {
  int64_t value = 0;
  if (!dfba::json::extract_json_field(object, key, value)) {
    return true;
  }
  if (value < static_cast<int64_t>(std::numeric_limits<int32_t>::min()) ||
      value > static_cast<int64_t>(std::numeric_limits<int32_t>::max())) {
    return false;
  }
  out = static_cast<int32_t>(value);
  return true;
}

struct SnapshotFetchState {
  SymbologySnapshot &snapshot;
  std::string &error;
  std::mutex mutex{};
  std::condition_variable ready{};
  bool has_symbology{false};
  bool has_exchange_config{false};
  bool failed{false};

  void operator()(ix::WebSocketMessagePtr const &message) {
    std::lock_guard<std::mutex> const lock(mutex);
    if (message->type == ix::WebSocketMessageType::Message) {
      if (message->str.find("\"type\":\"SymbologySnapshot\"") != std::string::npos) {
        has_symbology = api_client::parse_symbology_snapshot(message->str, snapshot, error);
        failed = !has_symbology;
      } else if (message->str.find("\"type\":\"ExchangeConfigSnapshot\"") != std::string::npos) {
        has_exchange_config = api_client::parse_exchange_config_snapshot(message->str, snapshot, error);
        failed = !has_exchange_config;
      }
    } else if (message->type == ix::WebSocketMessageType::Error) {
      error = "symbology websocket failed: " + message->errorInfo.reason;
      failed = true;
    } else if (message->type == ix::WebSocketMessageType::Close &&
               (!has_symbology || !has_exchange_config)) {
      error = "symbology websocket closed before initial snapshots";
      failed = true;
    }
    if (done()) {
      ready.notify_one();
    }
  }

  bool done() const {
    return failed || (has_symbology && has_exchange_config);
  }
};

struct SnapshotFetchReady {
  SnapshotFetchState const &state;

  bool operator()() const {
    return state.done();
  }
};

} // namespace

namespace api_client {

bool parse_symbology_snapshot(std::string const &payload, SymbologySnapshot &out, std::string &error) {
  out = SymbologySnapshot{};

  simdjson::dom::parser parser;
  JsonElement root;
  if (parser.parse(payload).get(root) != simdjson::SUCCESS) {
    error = "symbology response was not valid json";
    return false;
  }

  JsonArray markets;
  if (root.get(markets) == simdjson::SUCCESS) {
    if (!parse_markets_array(markets, out)) {
      error = "symbology response contained an invalid market";
      return false;
    }
    if (out.markets.empty()) {
      error = "symbology response contained no markets";
      return false;
    }
    return true;
  }

  JsonObject object;
  if (root.get(object) != simdjson::SUCCESS) {
    error = "symbology response root must be an object or array";
    return false;
  }

  dfba::json::extract_json_field(object, "version", out.version);
  JsonElement markets_value;
  if (dfba::json::find_json_field(object, "markets", markets_value) != simdjson::SUCCESS ||
      markets_value.get(markets) != simdjson::SUCCESS) {
    error = "symbology response missing markets";
    return false;
  }

  if (!parse_markets_array(markets, out)) {
    error = "symbology response contained an invalid market";
    return false;
  }
  if (out.markets.empty()) {
    error = "symbology response contained no markets";
    return false;
  }
  return true;
}

bool parse_symbology_market_update(std::string const &payload, MarketInfo &out, std::string &error) {
  simdjson::dom::parser parser;
  JsonElement root;
  JsonObject object;
  JsonElement market_value;
  JsonObject market_object;
  if (parser.parse(payload).get(root) != simdjson::SUCCESS ||
      root.get(object) != simdjson::SUCCESS ||
      dfba::json::find_json_field(object, "market", market_value) != simdjson::SUCCESS ||
      market_value.get(market_object) != simdjson::SUCCESS ||
      !parse_market(market_object, out)) {
    error = "symbology market update contained an invalid market";
    return false;
  }
  return true;
}

bool parse_exchange_config_snapshot(
    std::string const &payload,
    SymbologySnapshot &out,
    std::string &error) {
  simdjson::dom::parser parser;
  JsonElement root;
  JsonObject object;
  if (parser.parse(payload).get(root) != simdjson::SUCCESS ||
      root.get(object) != simdjson::SUCCESS ||
      !extract_optional_i32_field(object, "taker_fee_ppm", out.taker_fee_ppm) ||
      !extract_optional_i32_field(object, "maker_fee_ppm", out.maker_fee_ppm)) {
    error = "exchange config snapshot contained invalid fee ppm";
    return false;
  }
  return true;
}

bool fetch_symbology_snapshot(
    std::string const &ws_url,
    SymbologySnapshot &out,
    std::string &error) {
  ix::WebSocket websocket;
  SnapshotFetchState state{out, error};
  websocket.disableAutomaticReconnection();
  websocket.setUrl(ws_url);
  websocket.setOnMessageCallback(std::ref(state));
  websocket.start();
  {
    std::unique_lock<std::mutex> lock(state.mutex);
    if (!state.ready.wait_for(lock, std::chrono::seconds(10), SnapshotFetchReady{state})) {
      error = "timed out waiting for gateway configuration snapshots";
      state.failed = true;
    }
  }
  websocket.stop();
  return !state.failed && state.has_symbology && state.has_exchange_config;
}

} // namespace api_client
