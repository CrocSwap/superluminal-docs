#include "symbology_client.h"

#include <ixwebsocket/IXHttpClient.h>
#include <ixwebsocket/IXUrlParser.h>

#include <limits>
#include <string_view>

#include "dfba_common/simdjson_utils.hpp"

namespace {

using api_client::MarketInfo;
using api_client::SymbologySnapshot;
using dfba::json::JsonArray;
using dfba::json::JsonElement;
using dfba::json::JsonObject;

bool parse_market(JsonObject const &object, MarketInfo &out) {
  out = MarketInfo{};
  uint64_t feed_id = 0;
  if (!dfba::json::extract_json_field(object, "id", feed_id) ||
      feed_id == 0 ||
      feed_id > static_cast<uint64_t>(std::numeric_limits<uint32_t>::max())) {
    return false;
  }
  out.feed_id = static_cast<uint32_t>(feed_id);

  if (!dfba::json::extract_json_field(object, "symbol", out.symbol) ||
      out.symbol.empty()) {
    return false;
  }
  if (!dfba::json::extract_json_field(object, "quote", out.quote) ||
      out.quote.empty()) {
    return false;
  }

  int64_t px_exponent = 0;
  if (!dfba::json::extract_json_field(object, "px_exponent", px_exponent) ||
      px_exponent < static_cast<int64_t>(std::numeric_limits<int16_t>::min()) ||
      px_exponent > static_cast<int64_t>(std::numeric_limits<int16_t>::max())) {
    return false;
  }
  out.px_exponent = static_cast<int16_t>(px_exponent);

  uint64_t size_decimals = 0;
  if (!dfba::json::extract_json_field(object, "size_decimals", size_decimals) ||
      size_decimals > static_cast<uint64_t>(std::numeric_limits<uint8_t>::max())) {
    return false;
  }
  out.size_decimals = static_cast<uint8_t>(size_decimals);

  dfba::json::extract_json_field(object, "tick_size", out.tick_size);
  uint64_t max_funding_rate_e8 = 0;
  if (dfba::json::extract_json_field(object, "max_funding_rate_e8", max_funding_rate_e8)) {
    if (max_funding_rate_e8 > static_cast<uint64_t>(std::numeric_limits<uint32_t>::max())) {
      return false;
    }
    out.max_funding_rate_e8 = static_cast<uint32_t>(max_funding_rate_e8);
  }

  uint64_t initial_margin_bps = 0;
  if (dfba::json::extract_json_field(object, "initial_margin_bps", initial_margin_bps)) {
    if (initial_margin_bps > static_cast<uint64_t>(std::numeric_limits<uint16_t>::max())) {
      return false;
    }
    out.initial_margin_bps = static_cast<uint16_t>(initial_margin_bps);
  }

  uint64_t maintenance_margin_bps = 0;
  if (dfba::json::extract_json_field(object, "maintenance_margin_bps", maintenance_margin_bps)) {
    if (maintenance_margin_bps > static_cast<uint64_t>(std::numeric_limits<uint16_t>::max())) {
      return false;
    }
    out.maintenance_margin_bps = static_cast<uint16_t>(maintenance_margin_bps);
  }

  uint64_t transfer_margin_floor_bps = 0;
  if (dfba::json::extract_json_field(object, "transfer_margin_floor_bps", transfer_margin_floor_bps)) {
    if (transfer_margin_floor_bps > static_cast<uint64_t>(std::numeric_limits<uint16_t>::max())) {
      return false;
    }
    out.transfer_margin_floor_bps = static_cast<uint16_t>(transfer_margin_floor_bps);
  }

  std::string status;
  if (dfba::json::extract_json_field(object, "status", status)) {
    out.status = status;
    return true;
  }

  JsonElement active_value;
  if (dfba::json::find_json_field(object, "active", active_value) == simdjson::SUCCESS) {
    bool active = true;
    if (active_value.get(active) == simdjson::SUCCESS) {
      out.status = active ? "active" : "inactive";
    }
  }
  return true;
}

bool parse_markets_array(JsonArray const &markets, SymbologySnapshot &out) {
  for (JsonElement element : markets) {
    JsonObject market_object;
    if (element.get(market_object) != simdjson::SUCCESS) {
      return false;
    }

    MarketInfo market;
    if (!parse_market(market_object, market)) {
      return false;
    }
    out.markets[market.feed_id] = std::move(market);
  }
  return true;
}

bool extract_optional_i32_field(JsonObject const &object, std::string_view key, int32_t &out) {
  int64_t value = 0;
  if (!dfba::json::extract_json_field(object, key, value)) {
    return true;
  }
  if (value < static_cast<int64_t>(std::numeric_limits<int32_t>::min()) ||
      value > static_cast<int64_t>(std::numeric_limits<int32_t>::max())) {
    return false;
  }
  out = static_cast<int32_t>(value);
  return true;
}

} // namespace

namespace api_client {

std::string derive_symbology_url(std::string const &ws_url) {
  std::string protocol;
  std::string host;
  std::string path;
  std::string query;
  int port = 0;
  if (!ix::UrlParser::parse(ws_url, protocol, host, path, query, port)) {
    return "/v1/symbology";
  }

  if (protocol == "ws") {
    protocol = "http";
  } else if (protocol == "wss") {
    protocol = "https";
  }

  std::string out = protocol + "://" + host;
  bool const default_http_port = protocol == "http" && port == 80;
  bool const default_https_port = protocol == "https" && port == 443;
  if (port > 0 && !default_http_port && !default_https_port) {
    out += ":" + std::to_string(port);
  }
  out += "/v1/symbology";
  return out;
}

bool parse_symbology_snapshot(std::string const &payload, SymbologySnapshot &out, std::string &error) {
  out = SymbologySnapshot{};

  simdjson::dom::parser parser;
  JsonElement root;
  if (parser.parse(payload).get(root) != simdjson::SUCCESS) {
    error = "symbology response was not valid json";
    return false;
  }

  JsonArray markets;
  if (root.get(markets) == simdjson::SUCCESS) {
    if (!parse_markets_array(markets, out)) {
      error = "symbology response contained an invalid market";
      return false;
    }
    if (out.markets.empty()) {
      error = "symbology response contained no markets";
      return false;
    }
    return true;
  }

  JsonObject object;
  if (root.get(object) != simdjson::SUCCESS) {
    error = "symbology response root must be an object or array";
    return false;
  }

  dfba::json::extract_json_field(object, "version", out.version);
  if (!extract_optional_i32_field(object, "taker_fee_ppm", out.taker_fee_ppm) ||
      !extract_optional_i32_field(object, "maker_fee_ppm", out.maker_fee_ppm)) {
    error = "symbology response contained invalid fee ppm";
    return false;
  }

  JsonElement markets_value;
  if (dfba::json::find_json_field(object, "markets", markets_value) != simdjson::SUCCESS ||
      markets_value.get(markets) != simdjson::SUCCESS) {
    error = "symbology response missing markets";
    return false;
  }

  if (!parse_markets_array(markets, out)) {
    error = "symbology response contained an invalid market";
    return false;
  }
  if (out.markets.empty()) {
    error = "symbology response contained no markets";
    return false;
  }
  return true;
}

bool fetch_symbology_snapshot(std::string const &url, SymbologySnapshot &out, std::string &error) {
  ix::HttpClient client;
  ix::HttpRequestArgsPtr args = client.createRequest(url, ix::HttpClient::kGet);
  args->compress = false;
  args->extraHeaders["Accept"] = "application/json";

  ix::HttpResponsePtr const response = client.get(url, args);
  if (response == nullptr) {
    error = "symbology request returned no response";
    return false;
  }
  if (response->errorCode != ix::HttpErrorCode::Ok) {
    error = "symbology request failed: " + response->errorMsg;
    return false;
  }
  if (response->statusCode != 200) {
    error = "symbology request failed status=" + std::to_string(response->statusCode);
    return false;
  }
  return parse_symbology_snapshot(response->body, out, error);
}

} // namespace api_client
