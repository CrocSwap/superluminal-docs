#pragma once

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <limits>
#include <string>
#include <string_view>

namespace api_client::price_grid {

constexpr uint8_t kDefaultMaxPriceDecimals = 6;

inline int decimal_digits10(uint64_t value) {
  int digits = 1;
  while (value >= 10U) {
    value /= 10U;
    ++digits;
  }
  return digits;
}

inline bool pow10_u64(uint32_t exp, uint64_t &out) {
  uint64_t value = 1;
  for (uint32_t i = 0; i < exp; ++i) {
    if (value > (std::numeric_limits<uint64_t>::max() / 10U)) {
      return false;
    }
    value *= 10U;
  }
  out = value;
  return true;
}

inline bool parse_price_decimal(std::string_view text, int16_t px_exponent, uint64_t &out);

inline bool is_price_on_grid(uint64_t price, int16_t px_exponent, uint8_t size_decimals) {
  if (price == 0) {
    return false;
  }
  if (px_exponent >= 0) {
    return true;
  }

  int const max_decimal_places =
      static_cast<int>(kDefaultMaxPriceDecimals) - static_cast<int>(size_decimals);
  if (max_decimal_places < 0) {
    return false;
  }

  uint64_t normalized_price = price;
  int decimal_places = static_cast<int>(-px_exponent);
  while (decimal_places > 0 && (normalized_price % 10U) == 0U) {
    normalized_price /= 10U;
    --decimal_places;
  }
  if (decimal_places > max_decimal_places) {
    return false;
  }
  if (decimal_places == 0) {
    return true;
  }
  return decimal_digits10(normalized_price) <= 5;
}

inline bool price_grid_step(int16_t px_exponent, uint8_t size_decimals, uint64_t &out) {
  if (px_exponent >= 0) {
    out = 1;
    return true;
  }

  int const max_decimal_places =
      static_cast<int>(kDefaultMaxPriceDecimals) - static_cast<int>(size_decimals);
  if (max_decimal_places < 0) {
    return false;
  }

  int const required_zeros =
      std::max(0, static_cast<int>(-px_exponent) - max_decimal_places);
  if (required_zeros == 0) {
    out = 1;
    return true;
  }
  return pow10_u64(static_cast<uint32_t>(required_zeros), out);
}

inline bool matching_price_step(uint64_t price, int16_t px_exponent, uint8_t size_decimals, uint64_t &out) {
  if (price == 0) {
    return false;
  }
  if (px_exponent >= 0) {
    out = 1;
    return true;
  }

  int const max_decimal_places =
      static_cast<int>(kDefaultMaxPriceDecimals) - static_cast<int>(size_decimals);
  if (max_decimal_places < 0) {
    return false;
  }

  int const min_trailing_zeros =
      std::max(0, static_cast<int>(-px_exponent) - max_decimal_places);
  int const sig_zeros = std::max(0, decimal_digits10(price) - 5);
  int const required_zeros = std::max(min_trailing_zeros, sig_zeros);
  if (required_zeros == 0) {
    out = 1;
    return true;
  }
  return pow10_u64(static_cast<uint32_t>(required_zeros), out);
}

inline bool snap_price_to_grid(
    uint64_t price,
    bool round_up,
    int16_t px_exponent,
    uint8_t size_decimals,
    uint64_t &out) {
  if (price == 0) {
    return false;
  }
  if (is_price_on_grid(price, px_exponent, size_decimals)) {
    out = price;
    return true;
  }
  if (px_exponent >= 0) {
    out = price;
    return true;
  }

  uint64_t step = 1;
  if (!matching_price_step(price, px_exponent, size_decimals, step)) {
    return false;
  }

  uint64_t const rem = price % step;
  uint64_t snapped = price;
  if (!round_up) {
    snapped -= rem;
    if (snapped == 0) {
      return false;
    }
  } else if (rem != 0U) {
    uint64_t const add = step - rem;
    if (snapped > (std::numeric_limits<uint64_t>::max() - add)) {
      return false;
    }
    snapped += add;
  }

  if (!is_price_on_grid(snapped, px_exponent, size_decimals)) {
    return false;
  }
  out = snapped;
  return true;
}

inline bool parse_signed_price_delta_decimal(
    std::string_view text,
    int16_t px_exponent,
    int32_t &out) {
  size_t start = 0;
  while (start < text.size() && std::isspace(static_cast<unsigned char>(text[start])) != 0) {
    ++start;
  }
  size_t end = text.size();
  while (end > start && std::isspace(static_cast<unsigned char>(text[end - 1])) != 0) {
    --end;
  }
  if (start == end) {
    return false;
  }

  int sign = 1;
  if (text[start] == '+' || text[start] == '-') {
    sign = text[start] == '-' ? -1 : 1;
    ++start;
  }
  if (start == end) {
    return false;
  }

  uint64_t magnitude = 0;
  if (!parse_price_decimal(text.substr(start, end - start), px_exponent, magnitude) ||
      magnitude > static_cast<uint64_t>(std::numeric_limits<int32_t>::max())) {
    return false;
  }
  out = static_cast<int32_t>(sign * static_cast<int32_t>(magnitude));
  return true;
}

inline std::string trim_decimal_zeros(std::string out, size_t min_decimal_places) {
  size_t const dot = out.find('.');
  if (dot == std::string::npos) {
    if (min_decimal_places != 0U) {
      out.append(1U, '.');
      out.append(min_decimal_places, '0');
    }
    return out;
  }
  while (out.size() > dot + 1U + min_decimal_places && out.back() == '0') {
    out.pop_back();
  }
  if (!out.empty() && out.back() == '.') {
    out.pop_back();
  }
  size_t const final_dot = out.find('.');
  size_t const decimal_places =
      final_dot == std::string::npos ? 0U : out.size() - final_dot - 1U;
  if (decimal_places < min_decimal_places) {
    if (final_dot == std::string::npos) {
      out.append(1U, '.');
    }
    out.append(min_decimal_places - decimal_places, '0');
  }
  return out;
}

inline std::string format_price(uint64_t price, int16_t px_exponent) {
  std::string digits = std::to_string(price);
  if (px_exponent >= 0) {
    digits.append(static_cast<size_t>(px_exponent), '0');
    return trim_decimal_zeros(std::move(digits), 2U);
  }

  size_t const decimal_places = static_cast<size_t>(-px_exponent);
  if (digits.size() <= decimal_places) {
    digits.insert(0, decimal_places - digits.size() + 1U, '0');
  }
  digits.insert(digits.size() - decimal_places, 1U, '.');
  return trim_decimal_zeros(std::move(digits), 2U);
}

inline std::string format_mid_price(uint64_t best_bid_price, uint64_t best_ask_price, int16_t px_exponent) {
  if (best_bid_price > (std::numeric_limits<uint64_t>::max() - best_ask_price)) {
    return "n/a";
  }
  uint64_t const sum = best_bid_price + best_ask_price;
  if ((sum % 2U) == 0U) {
    return format_price(sum / 2U, px_exponent);
  }
  if (sum > (std::numeric_limits<uint64_t>::max() / 5U)) {
    return "n/a";
  }
  return format_price(sum * 5U, static_cast<int16_t>(px_exponent - 1));
}

inline bool parse_price_decimal(std::string_view text, int16_t px_exponent, uint64_t &out) {
  size_t start = 0;
  while (start < text.size() && std::isspace(static_cast<unsigned char>(text[start])) != 0) {
    ++start;
  }
  size_t end = text.size();
  while (end > start && std::isspace(static_cast<unsigned char>(text[end - 1])) != 0) {
    --end;
  }
  if (start == end) {
    return false;
  }

  size_t dot = std::string_view::npos;
  uint64_t mantissa = 0;
  int decimals = 0;
  bool saw_digit = false;
  for (size_t i = start; i < end; ++i) {
    char const ch = text[i];
    if (ch == '.') {
      if (dot != std::string_view::npos) {
        return false;
      }
      dot = i;
      continue;
    }
    if (std::isdigit(static_cast<unsigned char>(ch)) == 0) {
      return false;
    }
    uint64_t const digit = static_cast<uint64_t>(ch - '0');
    saw_digit = true;
    if (mantissa > ((std::numeric_limits<uint64_t>::max() - digit) / 10U)) {
      return false;
    }
    mantissa = mantissa * 10U + digit;
    if (dot != std::string_view::npos) {
      ++decimals;
    }
  }

  if (!saw_digit) {
    return false;
  }
  if (mantissa == 0) {
    out = 0;
    return true;
  }

  int const scale_adjust = decimals + static_cast<int>(px_exponent);
  if (scale_adjust < 0) {
    uint64_t scale = 0;
    if (!pow10_u64(static_cast<uint32_t>(-scale_adjust), scale)) {
      return false;
    }
    if (mantissa > (std::numeric_limits<uint64_t>::max() / scale)) {
      return false;
    }
    out = mantissa * scale;
    return true;
  }

  uint64_t scale = 0;
  if (!pow10_u64(static_cast<uint32_t>(scale_adjust), scale)) {
    return false;
  }
  if (scale == 0U || (mantissa % scale) != 0U) {
    return false;
  }
  out = mantissa / scale;
  return true;
}

} // namespace api_client::price_grid
