#pragma once

#include <cstdint>
#include <map>
#include <string>
#include <vector>

#include <ftxui/component/component.hpp>

#include "api_client_types.h"

namespace api_client {

class PriceLadderClient {
 public:
  virtual ~PriceLadderClient() = default;

  virtual UiSnapshot snapshot() const = 0;
  virtual std::vector<uint32_t> const &feed_ids() const = 0;
  virtual std::map<uint32_t, MarketInfo> const &markets() const = 0;
  virtual bool submit_order(OrderDraft const &draft, std::string &error) = 0;
  virtual bool submit_conditional_group(ConditionalGroupDraft const &draft, std::string &error) = 0;
  virtual bool submit_conditional_parent(uint64_t subaccount_id,
                                         uint64_t group_external_order_id,
                                         OrderDraft const &draft,
                                         std::string &error) = 0;
  virtual bool submit_conditional_cancel(uint64_t subaccount_id,
                                         UiSnapshot::ConditionalGroupRow const &group,
                                         std::string &error) = 0;
  virtual bool submit_cancel(uint64_t subaccount_id, uint64_t external_order_id, std::string &error) = 0;
  virtual bool submit_modify(uint64_t subaccount_id,
                             UiSnapshot::WorkingOrderRow const &order,
                             uint64_t price,
                             uint64_t qty,
                             std::string &error) = 0;
  virtual void request_stop() = 0;
};

ftxui::Component make_price_ladder_view(PriceLadderClient &client);

} // namespace api_client
