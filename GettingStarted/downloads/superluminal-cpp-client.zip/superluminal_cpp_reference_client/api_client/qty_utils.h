#pragma once

#include <cctype>
#include <cstdint>
#include <limits>
#include <string>
#include <string_view>

namespace api_client::qty_utils {

inline bool pow10_u64(uint8_t exp, uint64_t &out) {
  uint64_t value = 1;
  for (uint8_t i = 0; i < exp; ++i) {
    if (value > (std::numeric_limits<uint64_t>::max() / 10U)) {
      return false;
    }
    value *= 10U;
  }
  out = value;
  return true;
}

inline bool parse_uint64_strict(std::string_view text, uint64_t &value) {
  if (text.empty()) {
    return false;
  }
  value = 0;
  for (char const ch : text) {
    if (std::isdigit(static_cast<unsigned char>(ch)) == 0) {
      return false;
    }
    uint64_t const digit = static_cast<uint64_t>(ch - '0');
    if (value > (std::numeric_limits<uint64_t>::max() - digit) / 10U) {
      return false;
    }
    value = value * 10U + digit;
  }
  return true;
}

inline bool parse_qty_decimal(std::string_view text, uint8_t size_decimals, uint64_t &value) {
  size_t start = 0;
  while (start < text.size() && std::isspace(static_cast<unsigned char>(text[start])) != 0) {
    ++start;
  }
  size_t end = text.size();
  while (end > start && std::isspace(static_cast<unsigned char>(text[end - 1])) != 0) {
    --end;
  }
  if (start == end) {
    return false;
  }
  text = text.substr(start, end - start);

  size_t const dot = text.find('.');
  if (dot != std::string_view::npos && text.find('.', dot + 1) != std::string_view::npos) {
    return false;
  }

  std::string_view const whole_part = dot == std::string_view::npos ? text : text.substr(0, dot);
  std::string_view const frac_part = dot == std::string_view::npos ? std::string_view{} : text.substr(dot + 1);
  if (whole_part.empty() && frac_part.empty()) {
    return false;
  }
  if (frac_part.size() > size_decimals) {
    return false;
  }

  uint64_t scale = 0;
  if (!pow10_u64(size_decimals, scale)) {
    return false;
  }

  uint64_t whole = 0;
  if (!whole_part.empty() && !parse_uint64_strict(whole_part, whole)) {
    return false;
  }

  uint64_t frac = 0;
  uint64_t frac_scale = scale;
  for (char const ch : frac_part) {
    if (std::isdigit(static_cast<unsigned char>(ch)) == 0) {
      return false;
    }
    frac_scale /= 10U;
    frac += static_cast<uint64_t>(ch - '0') * frac_scale;
  }

  if (whole > (std::numeric_limits<uint64_t>::max() - frac) / scale) {
    return false;
  }
  value = whole * scale + frac;
  return true;
}

inline std::string format_qty(uint64_t value, uint8_t size_decimals) {
  std::string digits = std::to_string(value);
  if (size_decimals == 0) {
    return digits;
  }

  size_t const decimals = static_cast<size_t>(size_decimals);
  if (digits.size() <= decimals) {
    digits.insert(0, decimals - digits.size() + 1U, '0');
  }
  size_t const point = digits.size() - decimals;
  digits.insert(point, 1U, '.');

  while (!digits.empty() && digits.back() == '0') {
    digits.pop_back();
  }
  if (!digits.empty() && digits.back() == '.') {
    digits.pop_back();
  }
  if (digits.empty()) {
    return "0";
  }
  return digits;
}

inline std::string format_signed_qty(int64_t value, uint8_t size_decimals) {
  bool const negative = value < 0;
  uint64_t const magnitude = negative
                                 ? static_cast<uint64_t>(-(value + 1)) + 1U
                                 : static_cast<uint64_t>(value);
  std::string out = format_qty(magnitude, size_decimals);
  if (negative && out != "0") {
    out.insert(out.begin(), '-');
  }
  return out;
}

inline double qty_to_double(uint64_t value, uint8_t size_decimals) {
  uint64_t scale = 0;
  if (!pow10_u64(size_decimals, scale) || scale == 0) {
    return 0.0;
  }
  return static_cast<double>(value) / static_cast<double>(scale);
}

} // namespace api_client::qty_utils
