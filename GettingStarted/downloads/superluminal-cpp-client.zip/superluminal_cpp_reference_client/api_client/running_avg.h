#pragma once

#include <cstdint>

namespace api_client {

class RunningAvg {
 public:
  void reset() {
    sample_count_ = 0;
    mean_ = 0.0;
  }

  void add_sample(double sample) {
    ++sample_count_;
    if (sample_count_ == 1) {
      mean_ = sample;
      return;
    }
    mean_ += (sample - mean_) / static_cast<double>(sample_count_);
  }

  bool has_samples() const {
    return sample_count_ != 0;
  }

  uint64_t sample_count() const {
    return sample_count_;
  }

  double mean() const {
    return mean_;
  }

 private:
  uint64_t sample_count_{0};
  double mean_{0.0};
};

} // namespace api_client
