#include "gateway_protocol_codec.h"

#include <charconv>
#include <limits>
#include <string_view>

namespace api_client {

using dfba::json::extract_json_field;
using dfba::json::find_json_field;
using dfba::json::JsonArray;
using dfba::json::JsonElement;
using dfba::json::JsonObject;
using dfba::json::JsonObjectBuilder;
using dfba::json::parse_json_object;

namespace {

bool extract_decimal_identifier_value(JsonElement const &value, uint64_t &out) {
  std::string_view text;
  if (value.get(text) != simdjson::SUCCESS || text.empty()) [[unlikely]] {
    return false;
  }
  char const *const end = text.data() + text.size();
  auto const result = std::from_chars(text.data(), end, out);
  return result.ec == std::errc{} && result.ptr == end;
}

bool extract_optional_decimal_identifier(
    JsonObject const &payload,
    std::string_view field,
    uint64_t &out,
    bool &present) {
  JsonElement value;
  simdjson::error_code const error = find_json_field(payload, field, value);
  if (error == simdjson::NO_SUCH_FIELD) {
    present = false;
    return true;
  }
  if (error != simdjson::SUCCESS) [[unlikely]] {
    return false;
  }
  present = true;
  return extract_decimal_identifier_value(value, out);
}

bool extract_optional_decimal_identifier(
    JsonObject const &payload,
    std::string_view field,
    uint64_t &out) {
  bool present = false;
  return extract_optional_decimal_identifier(payload, field, out, present);
}

bool extract_required_decimal_identifier(
    JsonObject const &payload,
    std::string_view field,
    uint64_t &out) {
  bool present = false;
  return extract_optional_decimal_identifier(payload, field, out, present) && present;
}

bool extract_optional_external_order_id(
    JsonObject const &payload,
    std::string_view field,
    uint64_t &out,
    bool &present) {
  JsonElement value;
  simdjson::error_code const error = find_json_field(payload, field, value);
  if (error == simdjson::NO_SUCH_FIELD) {
    present = false;
    return true;
  }
  if (error != simdjson::SUCCESS) [[unlikely]] {
    return false;
  }
  present = true;
  return value.get(out) == simdjson::SUCCESS;
}

bool extract_optional_external_order_id(
    JsonObject const &payload,
    std::string_view field,
    uint64_t &out) {
  bool present = false;
  return extract_optional_external_order_id(payload, field, out, present);
}

bool extract_required_external_order_id(
    JsonObject const &payload,
    std::string_view field,
    uint64_t &out) {
  bool present = false;
  return extract_optional_external_order_id(payload, field, out, present) && present && out != 0;
}

bool extract_required_u32(JsonObject const &payload, std::string_view field, uint32_t &out) {
  uint64_t value = 0;
  if (!extract_json_field(payload, field, value) ||
      value > static_cast<uint64_t>(std::numeric_limits<uint32_t>::max())) {
    return false;
  }
  out = static_cast<uint32_t>(value);
  return true;
}

bool extract_optional_u32(JsonObject const &payload, std::string_view field, uint32_t &out) {
  uint64_t value = 0;
  if (!extract_json_field(payload, field, value)) {
    return false;
  }
  if (value > static_cast<uint64_t>(std::numeric_limits<uint32_t>::max())) {
    return false;
  }
  out = static_cast<uint32_t>(value);
  return true;
}

bool extract_optional_u8(JsonObject const &payload, std::string_view field, uint8_t &out) {
  uint64_t value = 0;
  if (!extract_json_field(payload, field, value)) {
    return false;
  }
  if (value > static_cast<uint64_t>(std::numeric_limits<uint8_t>::max())) {
    return false;
  }
  out = static_cast<uint8_t>(value);
  return true;
}

} // namespace

bool GatewayProtocolCodec::parse_message_type(
    std::string const &payload,
    simdjson::dom::parser &parser,
    JsonObject &object,
    std::string &type) {
  return parse_json_object(payload, parser, object) && extract_json_field(object, "type", type);
}

bool GatewayProtocolCodec::decode_ack(JsonObject const &payload, AckMessage &ack) {
  ack = AckMessage{};
  if (!extract_json_field(payload, "status", ack.status)) {
    return false;
  }
  extract_json_field(payload, "reason", ack.reason);
  return extract_optional_decimal_identifier(
             payload,
             "client_instruction_id",
             ack.client_instruction_id,
             ack.has_client_instruction_id) &&
         extract_optional_external_order_id(
             payload,
             "external_order_id",
             ack.external_order_id,
             ack.has_external_order_id);
}

bool GatewayProtocolCodec::decode_auth_challenge(
    JsonObject const &payload,
    AuthChallengeMessage &challenge) {
  if (!extract_json_field(payload, "wallet_pubkey", challenge.wallet_pubkey) ||
      !extract_json_field(payload, "nonce", challenge.nonce) ||
      !extract_json_field(payload, "message", challenge.message)) {
    return false;
  }
  challenge.has_expires_unix_ms = extract_json_field(payload, "expires_unix_ms", challenge.expires_unix_ms);
  return challenge.has_expires_unix_ms;
}

bool GatewayProtocolCodec::decode_create_vault_status(
    JsonObject const &payload,
    CreateVaultStatusMessage &message) {
  message = CreateVaultStatusMessage{};
  uint64_t vault_id = 0;
  uint64_t source_subaccount_id = 0;
  if (!extract_required_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id) ||
      !extract_json_field(payload, "operation_subaccount_id", message.operation_subaccount_id) ||
      !extract_json_field(payload, "status", message.status) ||
      !extract_json_field(payload, "error_code", message.error_code)) [[unlikely]] {
    return false;
  }
  if (extract_json_field(payload, "source_subaccount_id", source_subaccount_id)) {
    message.source_subaccount_id = source_subaccount_id;
  }
  if (extract_json_field(payload, "vault_id", vault_id)) {
    if (vault_id > static_cast<uint64_t>(std::numeric_limits<uint32_t>::max())) {
      return false;
    }
    message.vault_id = static_cast<uint32_t>(vault_id);
  }
  message.has_total_vault_shares =
      extract_json_field(payload, "total_vault_shares", message.total_vault_shares);
  extract_json_field(payload, "error_domain", message.error_domain);
  extract_json_field(payload, "error", message.error);
  extract_json_field(payload, "error_message", message.error_message);
  extract_json_field(payload, "onchain_signature", message.onchain_signature);
  return true;
}

bool GatewayProtocolCodec::decode_auth_expired(
    JsonObject const &payload,
    AuthExpiredMessage &message) {
  return extract_json_field(payload, "reason", message.reason);
}

bool GatewayProtocolCodec::decode_pong(JsonObject const &payload, PongMessage &message) {
  message = PongMessage{};
  return extract_json_field(payload, "client_unix_ns", message.client_unix_ns);
}

bool GatewayProtocolCodec::decode_account_snapshot(
    JsonObject const &payload,
    AccountSnapshotMessage &message) {
  message = AccountSnapshotMessage{};
  if (!extract_json_field(payload, "last_seq", message.last_seq)) {
    return false;
  }

  JsonArray subaccounts;
  if (!extract_json_field(payload, "subaccounts", subaccounts)) {
    return false;
  }

  for (JsonElement subaccount_value : subaccounts) {
    JsonObject subaccount_object;
    if (subaccount_value.get(subaccount_object) != simdjson::SUCCESS) {
      return false;
    }

    AccountSnapshotMessage::Subaccount subaccount;
    if (!extract_json_field(subaccount_object, "subaccount_id", subaccount.subaccount_id)) {
      return false;
    }
    extract_json_field(subaccount_object, "collateral_balance", subaccount.collateral_balance);
    extract_json_field(subaccount_object, "accrued_fee", subaccount.accrued_fee);
    extract_json_field(subaccount_object, "accrued_funding", subaccount.accrued_funding);
    extract_json_field(subaccount_object, "status", subaccount.status);

    JsonArray positions;
    if (!extract_json_field(subaccount_object, "positions", positions)) {
      return false;
    }
    for (JsonElement position_value : positions) {
      JsonObject position_object;
      if (position_value.get(position_object) != simdjson::SUCCESS) {
        return false;
      }
      AccountSnapshotMessage::Position position;
      if (!extract_required_u32(position_object, "symbol", position.symbol) ||
          !extract_json_field(position_object, "net_qty", position.net_qty) ||
          !extract_json_field(position_object, "cost_basis", position.cost_basis)) {
        return false;
      }
      extract_json_field(position_object, "pending_fees", position.pending_fees);
      extract_json_field(position_object, "realized_pnl", position.realized_pnl);
      extract_json_field(position_object, "funding_accrued", position.funding_accrued);
      extract_json_field(position_object, "last_funding_index_e8", position.last_funding_index_e8);
      subaccount.positions.push_back(position);
    }

    JsonArray working_orders;
    if (!extract_json_field(subaccount_object, "working_orders", working_orders)) {
      return false;
    }
    for (JsonElement working_order_value : working_orders) {
      JsonObject working_order_object;
      if (working_order_value.get(working_order_object) != simdjson::SUCCESS) {
        return false;
      }
      AccountSnapshotMessage::WorkingOrder order;
      if (!extract_required_external_order_id(working_order_object, "external_order_id", order.external_order_id) ||
          !extract_required_decimal_identifier(working_order_object, "client_instruction_id", order.client_instruction_id) ||
          !extract_required_u32(working_order_object, "symbol", order.symbol) ||
          !extract_json_field(working_order_object, "filled_qty", order.filled_qty) ||
          !extract_json_field(working_order_object, "remaining_qty", order.remaining_qty)) [[unlikely]] {
        return false;
      }
      if (!extract_json_field(working_order_object, "original_iat", order.original_iat)) {
        extract_json_field(working_order_object, "timestamp", order.original_iat);
      }
      if (!extract_json_field(working_order_object, "original_qty", order.original_qty)) {
        order.original_qty = order.remaining_qty;
      }
      extract_json_field(working_order_object, "side", order.side);
      extract_json_field(working_order_object, "role", order.role);
      extract_json_field(working_order_object, "tif", order.tif);
      extract_json_field(working_order_object, "order_type", order.order_type);
      extract_json_field(working_order_object, "price", order.price);
      extract_json_field(working_order_object, "delta_ppm", order.delta_ppm);
      subaccount.working_orders.push_back(order);
    }

    message.subaccounts.push_back(std::move(subaccount));
  }

  JsonElement vault_accounts_value;
  simdjson::error_code const vault_accounts_err =
      find_json_field(payload, "vault_accounts", vault_accounts_value);
  if (vault_accounts_err == simdjson::SUCCESS) {
    JsonArray vault_accounts;
    if (vault_accounts_value.get(vault_accounts) != simdjson::SUCCESS) {
      return false;
    }
    for (JsonElement vault_value : vault_accounts) {
      JsonObject vault_object;
      if (vault_value.get(vault_object) != simdjson::SUCCESS) {
        return false;
      }
      AccountSnapshotMessage::VaultAccount vault;
      if (!extract_required_u32(vault_object, "vault_id", vault.vault_id) ||
          !extract_json_field(vault_object, "operation_subaccount_id", vault.operation_subaccount_id) ||
          !extract_json_field(vault_object, "leader_source_subaccount_id", vault.leader_source_subaccount_id) ||
          !extract_json_field(vault_object, "collateral_amount", vault.collateral_amount) ||
          !extract_json_field(vault_object, "total_vault_shares", vault.total_vault_shares) ||
          !extract_json_field(vault_object, "last_seq", vault.last_seq)) {
        return false;
      }
      message.vault_accounts.push_back(vault);
    }
  } else if (vault_accounts_err != simdjson::NO_SUCH_FIELD) {
    return false;
  }
  return true;
}

bool GatewayProtocolCodec::decode_order_accepted(
    JsonObject const &payload,
    OrderAcceptedMessage &message) {
  message = OrderAcceptedMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id) ||
      !extract_required_external_order_id(payload, "external_order_id", message.external_order_id) ||
      !extract_required_u32(payload, "symbol", message.symbol) ||
      !extract_json_field(payload, "side", message.side) ||
      !extract_json_field(payload, "qty", message.qty)) {
    return false;
  }
  if (!extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id)) [[unlikely]] {
    return false;
  }
  extract_json_field(payload, "role", message.role);
  extract_json_field(payload, "tif", message.tif);
  extract_json_field(payload, "order_type", message.order_type);
  extract_json_field(payload, "price", message.price);
  int64_t delta_ppm = 0;
  if (!extract_json_field(payload, "delta_ppm", delta_ppm) ||
      delta_ppm < static_cast<int64_t>(std::numeric_limits<int32_t>::min()) ||
      delta_ppm > static_cast<int64_t>(std::numeric_limits<int32_t>::max())) [[unlikely]] {
    return false;
  }
  message.delta_ppm = static_cast<int32_t>(delta_ppm);
  if (extract_json_field(payload, "client_unix_ns", message.client_unix_ns) &&
      message.client_unix_ns >= 1000000000ULL) {
    message.original_iat = message.client_unix_ns / 1000000000ULL;
  }
  message.has_matcher_unix_ns =
      extract_json_field(payload, "matcher_unix_ns", message.matcher_unix_ns);
  message.has_sequencer_recv_unix_ns =
      extract_json_field(payload, "sequencer_recv_unix_ns", message.sequencer_recv_unix_ns);
  return true;
}

bool GatewayProtocolCodec::decode_order_reject(
    JsonObject const &payload,
    OrderRejectMessage &message) {
  message = OrderRejectMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id)) {
    return false;
  }
  if (!extract_optional_external_order_id(payload, "external_order_id", message.external_order_id) ||
      !extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id)) [[unlikely]] {
    return false;
  }
  extract_json_field(payload, "reason", message.reason);
  extract_optional_u32(payload, "symbol", message.symbol);
  extract_json_field(payload, "side", message.side);
  extract_json_field(payload, "role", message.role);
  extract_json_field(payload, "tif", message.tif);
  extract_json_field(payload, "order_type", message.order_type);
  extract_json_field(payload, "price", message.price);
  extract_json_field(payload, "qty", message.qty);
  extract_json_field(payload, "delta_ppm", message.delta_ppm);
  message.has_matcher_unix_ns =
      extract_json_field(payload, "matcher_unix_ns", message.matcher_unix_ns);
  message.has_sequencer_recv_unix_ns =
      extract_json_field(payload, "sequencer_recv_unix_ns", message.sequencer_recv_unix_ns);
  return true;
}

bool GatewayProtocolCodec::decode_local_order_reject(
    JsonObject const &payload,
    LocalOrderRejectMessage &message) {
  message = LocalOrderRejectMessage{};
  if (!extract_json_field(payload, "reason", message.reason)) {
    return false;
  }
  if (!extract_optional_decimal_identifier(
          payload,
          "client_instruction_id",
          message.client_instruction_id,
          message.has_client_instruction_id) ||
      !extract_optional_external_order_id(
          payload,
          "external_order_id",
          message.external_order_id,
          message.has_external_order_id)) [[unlikely]] {
    return false;
  }
  message.has_gateway_send_unix_ns =
      extract_json_field(payload, "gateway_send_unix_ns", message.gateway_send_unix_ns);
  return true;
}

bool GatewayProtocolCodec::decode_fill_event(JsonObject const &payload, FillEventMessage &message) {
  message = FillEventMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id) ||
      !extract_required_u32(payload, "symbol", message.symbol) ||
      !extract_json_field(payload, "side", message.side) ||
      !extract_json_field(payload, "qty", message.qty)) {
    return false;
  }
  if (!extract_optional_external_order_id(payload, "external_order_id", message.external_order_id) ||
      !extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id)) [[unlikely]] {
    return false;
  }
  extract_json_field(payload, "trade_id", message.trade_id);
  extract_json_field(payload, "role", message.role);
  extract_json_field(payload, "price", message.price);
  message.has_remaining_qty = extract_json_field(payload, "remaining_qty", message.remaining_qty);
  message.has_fee = extract_json_field(payload, "fee", message.fee);
  message.has_execution_mode = extract_optional_u8(payload, "execution_mode", message.execution_mode);
  message.has_matcher_unix_ns =
      extract_json_field(payload, "matcher_unix_ns", message.matcher_unix_ns);
  message.has_sequencer_recv_unix_ns =
      extract_json_field(payload, "sequencer_recv_unix_ns", message.sequencer_recv_unix_ns);
  message.has_gateway_send_unix_ns =
      extract_json_field(payload, "gateway_send_unix_ns", message.gateway_send_unix_ns);
  return message.external_order_id != 0 || message.execution_mode != 0;
}

bool GatewayProtocolCodec::decode_adl_failed(
    JsonObject const &payload,
    AdlFailedMessage &message) {
  message = AdlFailedMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id) ||
      !extract_json_field(payload, "operation_nonce", message.operation_nonce) ||
      !extract_required_u32(payload, "market_id", message.market_id) ||
      !extract_json_field(payload, "side", message.side) ||
      !extract_json_field(payload, "role", message.role) ||
      !extract_optional_u8(payload, "status", message.status)) [[unlikely]] {
    return false;
  }
  if (!extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id) ||
      !extract_optional_external_order_id(payload, "external_order_id", message.external_order_id)) [[unlikely]] {
    return false;
  }
  extract_json_field(payload, "request_seq", message.request_seq);
  extract_json_field(payload, "batch_id", message.batch_id);
  extract_json_field(payload, "price", message.price);
  extract_json_field(payload, "qty", message.qty);
  extract_json_field(payload, "allocated_loss", message.allocated_loss);
  extract_optional_u32(payload, "error_code", message.error_code);
  extract_optional_u32(payload, "workflow_error_code", message.workflow_error_code);
  extract_optional_u32(payload, "cleanup_error_code", message.cleanup_error_code);
  extract_optional_u8(payload, "failure_stage", message.failure_stage);
  extract_json_field(payload, "error_domain", message.error_domain);
  extract_json_field(payload, "error", message.error);
  extract_json_field(payload, "error_message", message.error_message);
  return message.seq != 0 && message.operation_nonce != 0 && message.status != 0;
}

bool GatewayProtocolCodec::decode_cancel_ack_event(
    JsonObject const &payload,
    CancelAckEventMessage &message) {
  message = CancelAckEventMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id)) {
    return false;
  }
  if (!extract_optional_external_order_id(payload, "external_order_id", message.external_order_id) ||
      !extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id)) [[unlikely]] {
    return false;
  }
  extract_json_field(payload, "reason", message.reason);
  message.has_matcher_unix_ns =
      extract_json_field(payload, "matcher_unix_ns", message.matcher_unix_ns);
  message.has_sequencer_recv_unix_ns =
      extract_json_field(payload, "sequencer_recv_unix_ns", message.sequencer_recv_unix_ns);
  return message.external_order_id != 0;
}

bool GatewayProtocolCodec::decode_cancel_reject_event(
    JsonObject const &payload,
    CancelRejectEventMessage &message) {
  message = CancelRejectEventMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id)) {
    return false;
  }
  if (!extract_optional_external_order_id(payload, "external_order_id", message.external_order_id) ||
      !extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id)) [[unlikely]] {
    return false;
  }
  extract_json_field(payload, "reason", message.reason);
  message.has_matcher_unix_ns =
      extract_json_field(payload, "matcher_unix_ns", message.matcher_unix_ns);
  message.has_sequencer_recv_unix_ns =
      extract_json_field(payload, "sequencer_recv_unix_ns", message.sequencer_recv_unix_ns);
  return message.external_order_id != 0;
}

bool GatewayProtocolCodec::decode_modify_ack_event(
    JsonObject const &payload,
    ModifyAckEventMessage &message) {
  message = ModifyAckEventMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id)) {
    return false;
  }
  if (!extract_optional_external_order_id(payload, "external_order_id", message.external_order_id) ||
      !extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id) ||
      !extract_optional_decimal_identifier(
          payload, "original_client_instruction_id", message.original_client_instruction_id)) [[unlikely]] {
    return false;
  }
  extract_optional_u32(payload, "symbol", message.symbol);
  extract_json_field(payload, "price", message.price);
  extract_json_field(payload, "qty", message.qty);
  int64_t delta_ppm = 0;
  if (!extract_json_field(payload, "delta_ppm", delta_ppm) ||
      delta_ppm < static_cast<int64_t>(std::numeric_limits<int32_t>::min()) ||
      delta_ppm > static_cast<int64_t>(std::numeric_limits<int32_t>::max())) [[unlikely]] {
    return false;
  }
  message.delta_ppm = static_cast<int32_t>(delta_ppm);
  message.has_matcher_unix_ns =
      extract_json_field(payload, "matcher_unix_ns", message.matcher_unix_ns);
  message.has_sequencer_recv_unix_ns =
      extract_json_field(payload, "sequencer_recv_unix_ns", message.sequencer_recv_unix_ns);
  return message.external_order_id != 0 && message.qty != 0;
}

bool GatewayProtocolCodec::decode_modify_reject_event(
    JsonObject const &payload,
    ModifyRejectEventMessage &message) {
  message = ModifyRejectEventMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id)) {
    return false;
  }
  if (!extract_optional_external_order_id(payload, "external_order_id", message.external_order_id) ||
      !extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id) ||
      !extract_optional_decimal_identifier(
          payload, "original_client_instruction_id", message.original_client_instruction_id)) [[unlikely]] {
    return false;
  }
  extract_json_field(payload, "reason", message.reason);
  message.has_matcher_unix_ns =
      extract_json_field(payload, "matcher_unix_ns", message.matcher_unix_ns);
  message.has_sequencer_recv_unix_ns =
      extract_json_field(payload, "sequencer_recv_unix_ns", message.sequencer_recv_unix_ns);
  return message.external_order_id != 0;
}

bool GatewayProtocolCodec::decode_fill_settlement_event(
    JsonObject const &payload,
    FillSettlementEventMessage &message) {
  message = FillSettlementEventMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id) ||
      !extract_required_external_order_id(payload, "external_order_id", message.external_order_id) ||
      !extract_required_u32(payload, "symbol", message.symbol) ||
      !extract_json_field(payload, "side", message.side) ||
      !extract_json_field(payload, "qty", message.qty)) {
    return false;
  }
  extract_json_field(payload, "price", message.price);
  extract_json_field(payload, "status", message.status);
  extract_json_field(payload, "error_code", message.error_code);
  extract_json_field(payload, "error_domain", message.error_domain);
  extract_json_field(payload, "error", message.error);
  extract_json_field(payload, "error_message", message.error_message);
  extract_json_field(payload, "onchain_signature", message.onchain_signature);
  message.has_fee = extract_json_field(payload, "fee", message.fee);
  message.has_gateway_send_unix_ns =
      extract_json_field(payload, "gateway_send_unix_ns", message.gateway_send_unix_ns);
  return true;
}

bool GatewayProtocolCodec::decode_account_funding_update(
    JsonObject const &payload,
    AccountFundingUpdateMessage &message) {
  message = AccountFundingUpdateMessage{};
  uint64_t market_id = 0;
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id) ||
      !extract_json_field(payload, "market_id", market_id)) {
    return false;
  }
  if (market_id > std::numeric_limits<uint32_t>::max()) {
    return false;
  }
  message.market_id = static_cast<uint32_t>(market_id);
  message.symbol = static_cast<uint32_t>(message.market_id);
  extract_optional_u32(payload, "symbol", message.symbol);
  extract_json_field(payload, "prev_funding_index_e8", message.prev_funding_index_e8);
  extract_json_field(payload, "last_funding_index_e8", message.last_funding_index_e8);
  extract_json_field(payload, "funding_delta", message.funding_delta);
  extract_json_field(payload, "funding_accrued", message.funding_accrued);
  return true;
}

bool GatewayProtocolCodec::decode_user_collateral_update(
    JsonObject const &payload,
    UserCollateralUpdateMessage &message) {
  message = UserCollateralUpdateMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id) ||
      !extract_json_field(payload, "collateral_delta", message.collateral_delta) ||
      !extract_json_field(payload, "collateral_balance", message.collateral_balance)) {
    return false;
  }
  extract_json_field(payload, "fee", message.fee);
  return true;
}

bool GatewayProtocolCodec::decode_vault_operation_subaccount_collateral_change(
    JsonObject const &payload,
    VaultOperationSubaccountCollateralChangeMessage &message) {
  message = VaultOperationSubaccountCollateralChangeMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "subaccount_id", message.subaccount_id) ||
      !extract_json_field(payload, "operation_subaccount_id", message.operation_subaccount_id) ||
      !extract_json_field(payload, "status", message.status) ||
      !extract_json_field(payload, "error_code", message.error_code)) {
    return false;
  }
  if (!extract_optional_decimal_identifier(payload, "client_instruction_id", message.client_instruction_id)) [[unlikely]] {
    return false;
  }
  extract_json_field(payload, "source_subaccount_id", message.source_subaccount_id);
  extract_json_field(payload, "destination_subaccount_id", message.destination_subaccount_id);
  extract_json_field(payload, "operation_subaccount_pubkey", message.operation_subaccount_pubkey);
  extract_json_field(payload, "vault_account_pubkey", message.vault_account_pubkey);
  extract_json_field(payload, "participant_account_pubkey", message.participant_account_pubkey);
  extract_json_field(payload, "deposit_amount", message.deposit_amount);
  extract_json_field(payload, "minted_vault_shares", message.minted_vault_shares);
  extract_json_field(payload, "requested_vault_shares", message.requested_vault_shares);
  extract_json_field(payload, "actual_withdraw_amount", message.actual_withdraw_amount);
  extract_json_field(payload, "leader_fee_amount", message.leader_fee_amount);
  extract_json_field(payload, "previous_total_vault_shares", message.previous_total_vault_shares);
  extract_json_field(payload, "total_vault_shares", message.total_vault_shares);
  extract_json_field(payload, "error_domain", message.error_domain);
  extract_json_field(payload, "error", message.error);
  extract_json_field(payload, "error_message", message.error_message);
  extract_json_field(payload, "onchain_signature", message.onchain_signature);
  extract_json_field(payload, "batch_id", message.batch_id);
  extract_json_field(payload, "term", message.term);
  return true;
}

bool GatewayProtocolCodec::decode_funding_index(
    JsonObject const &payload,
    FundingIndexMessage &message) {
  message = FundingIndexMessage{};
  if (!extract_json_field(payload, "seq", message.seq)) {
    return false;
  }
  message.has_oracle_price_batch_id =
      extract_json_field(payload, "oracle_price_batch_id", message.oracle_price_batch_id);

  JsonArray entries;
  if (!extract_json_field(payload, "entries", entries)) {
    return false;
  }

  for (JsonElement entry_value : entries) {
    JsonObject entry_object;
    if (entry_value.get(entry_object) != simdjson::SUCCESS) {
      return false;
    }

    FundingIndexMessage::Entry entry;
    uint64_t market_id = 0;
    if (!extract_json_field(entry_object, "market_id", market_id) ||
        !extract_json_field(entry_object, "cum_funding_index_e8", entry.cum_funding_index_e8)) {
      return false;
    }
    if (market_id > std::numeric_limits<uint32_t>::max()) {
      return false;
    }
    entry.market_id = static_cast<uint32_t>(market_id);
    extract_json_field(entry_object, "perp_price", entry.perp_price);
    extract_json_field(entry_object, "premium_e8", entry.premium_e8);
    message.entries.push_back(entry);
  }
  return true;
}

bool GatewayProtocolCodec::decode_trade(JsonObject const &payload, TradeMessage &message) {
  message = TradeMessage{};
  if (!extract_json_field(payload, "seq", message.seq) ||
      !extract_json_field(payload, "batch_id", message.batch_id) ||
      !extract_json_field(payload, "matcher_unix_ns", message.matcher_unix_ns) ||
      !extract_required_u32(payload, "id", message.symbol_id) ||
      !extract_json_field(payload, "side", message.side) ||
      !extract_json_field(payload, "price", message.price) ||
      !extract_json_field(payload, "qty", message.qty)) {
    return false;
  }
  extract_json_field(payload, "trade_id", message.trade_id);
  extract_json_field(payload, "symbol", message.symbol);
  return true;
}

bool GatewayProtocolCodec::decode_order_history(
    JsonObject const &payload,
    OrderHistoryMessage &message) {
  message = OrderHistoryMessage{};
  extract_json_field(payload, "next_cursor", message.next_cursor);

  JsonArray orders;
  if (!extract_json_field(payload, "orders", orders)) {
    return false;
  }

  for (JsonElement order_value : orders) {
    JsonObject order_object;
    if (order_value.get(order_object) != simdjson::SUCCESS) {
      return false;
    }

    OrderHistoryMessage::Order order;
    if (!extract_required_external_order_id(order_object, "external_order_id", order.external_order_id) ||
        !extract_json_field(order_object, "subaccount_id", order.subaccount_id) ||
        !extract_required_u32(order_object, "symbol", order.symbol) ||
        !extract_json_field(order_object, "last_event_seq", order.last_event_seq)) [[unlikely]] {
      return false;
    }
    if (!extract_optional_decimal_identifier(order_object, "client_instruction_id", order.client_instruction_id)) [[unlikely]] {
      return false;
    }
    extract_json_field(order_object, "side", order.side);
    extract_json_field(order_object, "role", order.role);
    extract_json_field(order_object, "price", order.price);
    extract_json_field(order_object, "settled_qty", order.settled_qty);
    extract_json_field(order_object, "busted_qty", order.busted_qty);

    JsonArray events;
    if (!extract_json_field(order_object, "events", events)) {
      return false;
    }
    for (JsonElement event_value : events) {
      JsonObject event_object;
      if (event_value.get(event_object) != simdjson::SUCCESS) {
        return false;
      }

      OrderHistoryMessage::Event event;
      if (!extract_json_field(event_object, "event_type", event.event_type) ||
          !extract_json_field(event_object, "event_unix_ns", event.event_unix_ns) ||
          !extract_json_field(event_object, "stream_seq", event.stream_seq)) {
        return false;
      }
      if (!extract_optional_decimal_identifier(event_object, "client_instruction_id", event.client_instruction_id)) [[unlikely]] {
        return false;
      }
      extract_json_field(event_object, "price", event.price);
      extract_json_field(event_object, "qty", event.qty);
      extract_json_field(event_object, "trade_id", event.trade_id);
      order.events.push_back(event);
    }
    message.orders.push_back(std::move(order));
  }

  JsonElement adl_value;
  if (find_json_field(payload, "adl", adl_value) == simdjson::SUCCESS) {
    JsonArray adl_records;
    if (adl_value.get(adl_records) != simdjson::SUCCESS) [[unlikely]] {
      return false;
    }
    for (JsonElement adl_value : adl_records) {
      JsonObject adl_object;
      if (adl_value.get(adl_object) != simdjson::SUCCESS) [[unlikely]] {
        return false;
      }

      OrderHistoryMessage::Adl adl;
      if (!extract_json_field(adl_object, "operation_nonce", adl.operation_nonce) ||
          !extract_json_field(adl_object, "subaccount_id", adl.subaccount_id) ||
          !extract_required_u32(adl_object, "market_id", adl.market_id) ||
          !extract_json_field(adl_object, "side", adl.side) ||
          !extract_json_field(adl_object, "role", adl.role) ||
          !extract_json_field(adl_object, "fill_price", adl.fill_price) ||
          !extract_json_field(adl_object, "fill_qty", adl.fill_qty) ||
          !extract_json_field(adl_object, "allocated_loss", adl.allocated_loss) ||
          !extract_json_field(adl_object, "status", adl.status) ||
          !extract_json_field(adl_object, "last_event_seq", adl.last_event_seq)) [[unlikely]] {
        return false;
      }
      extract_json_field(adl_object, "request_seq", adl.request_seq);
      extract_json_field(adl_object, "batch_id", adl.batch_id);
      extract_optional_u32(adl_object, "error_code", adl.error_code);
      extract_optional_u32(adl_object, "workflow_error_code", adl.workflow_error_code);
      extract_optional_u32(adl_object, "cleanup_error_code", adl.cleanup_error_code);
      extract_optional_u8(adl_object, "failure_stage", adl.failure_stage);
      extract_json_field(adl_object, "event_unix_ns", adl.event_unix_ns);
      message.adl.push_back(std::move(adl));
    }
  }
  return true;
}

std::string GatewayProtocolCodec::encode_signed_order(std::string_view msg_b64) {
  JsonObjectBuilder payload;
  payload.string_field("type", "signed_order");
  payload.string_field("msg_b64", msg_b64);
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_signed_cancel(std::string_view msg_b64) {
  JsonObjectBuilder payload;
  payload.string_field("type", "signed_cancel");
  payload.string_field("msg_b64", msg_b64);
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_signed_modify(std::string_view msg_b64) {
  JsonObjectBuilder payload;
  payload.string_field("type", "signed_modify");
  payload.string_field("msg_b64", msg_b64);
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_signed_create_vault(std::string_view msg_b64) {
  JsonObjectBuilder payload;
  payload.string_field("type", "signed_create_vault");
  payload.string_field("msg_b64", msg_b64);
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_ping(uint64_t client_unix_ns) {
  JsonObjectBuilder payload;
  payload.string_field("type", "ping");
  payload.uint64_field("client_unix_ns", client_unix_ns);
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_subscribe_market(uint32_t symbol) {
  JsonObjectBuilder payload;
  payload.string_field("type", "subscribe_market");
  payload.uint64_field("symbol", symbol);
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_subscribe_account() {
  JsonObjectBuilder payload;
  payload.string_field("type", "subscribe_account");
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_get_order_history(uint32_t limit) {
  JsonObjectBuilder payload;
  payload.string_field("type", "get_order_history");
  payload.uint64_field("limit", limit);
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_auth_wallet(std::string_view wallet_pubkey) {
  JsonObjectBuilder payload;
  payload.string_field("type", "auth_wallet");
  payload.string_field("wallet_pubkey", wallet_pubkey);
  payload.uint64_field("expiry_seconds", 0);
  return std::move(payload).finish();
}

std::string GatewayProtocolCodec::encode_auth_response(
    std::string_view nonce,
    std::string_view signature_b64,
    bool is_delegate) {
  JsonObjectBuilder payload;
  payload.string_field("type", "auth_response");
  payload.string_field("nonce", nonce);
  payload.string_field("signature_b64", signature_b64);
  if (is_delegate) {
    payload.bool_field("is_delegate", true);
  }
  return std::move(payload).finish();
}

bool GatewayProtocolCodec::should_ignore_payload_type(std::string const &type) {
  if (type == "BatchCommit") {
    return true;
  }
  return false;
}

} // namespace api_client
