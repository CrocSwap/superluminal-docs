#include "api_client_signer.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <vector>

#include <sodium.h>

namespace api_client {
namespace {

constexpr size_t kSolanaPubkeyBytes = 32;
constexpr size_t kOrderV1Bytes = 37;
constexpr size_t kOrderProofBytes = 191;
constexpr size_t kCancelV2Bytes = 21;
constexpr size_t kCancelProofBytes = 175;
constexpr size_t kModifyV1Bytes = 61;
constexpr size_t kModifyProofBytes = 215;
constexpr size_t kCreateVaultV1Bytes = 40;
constexpr size_t kCreateVaultProofBytes = 194;
constexpr uint64_t kOrderExpirySeconds = 300;
constexpr uint64_t kGtcOrderExpirySeconds = 30ULL * 24ULL * 60ULL * 60ULL;
constexpr uint64_t kCreateVaultExpirySeconds = 300;
constexpr int32_t kMarketMaxSlippagePpm = 1'000'000;
constexpr char kOrderDomain[] = "AETHEON_ORDER_V1";
constexpr char kCancelDomain[] = "AETHEON_CANCEL_V2";
constexpr char kModifyDomain[] = "AETHEON_MODIFY_V1";
constexpr char kCreateVaultDomain[] = "AETHEON_CREATE_VAULT_V1";

static std::string encode_base64(unsigned char const *data, size_t len) {
  std::string out(sodium_base64_ENCODED_LEN(len, sodium_base64_VARIANT_ORIGINAL), '\0');
  sodium_bin2base64(out.data(), out.size(), data, len, sodium_base64_VARIANT_ORIGINAL);
  out.resize(std::strlen(out.c_str()));
  return out;
}

static void append_u16_le(std::vector<unsigned char> &out, uint16_t value) {
  out.push_back(static_cast<unsigned char>(value & 0xffU));
  out.push_back(static_cast<unsigned char>((value >> 8U) & 0xffU));
}

static void append_u32_le(std::vector<unsigned char> &out, uint32_t value) {
  out.push_back(static_cast<unsigned char>(value & 0xffU));
  out.push_back(static_cast<unsigned char>((value >> 8U) & 0xffU));
  out.push_back(static_cast<unsigned char>((value >> 16U) & 0xffU));
  out.push_back(static_cast<unsigned char>((value >> 24U) & 0xffU));
}

static void append_u64_le(std::vector<unsigned char> &out, uint64_t value) {
  for (int i = 0; i < 8; ++i) {
    out.push_back(static_cast<unsigned char>((value >> (i * 8)) & 0xffU));
  }
}

static void append_i32_le(std::vector<unsigned char> &out, int32_t value) {
  append_u32_le(out, static_cast<uint32_t>(value));
}

static uint64_t current_unix_seconds() {
  return static_cast<uint64_t>(
      std::chrono::duration_cast<std::chrono::seconds>(
          std::chrono::system_clock::now().time_since_epoch())
          .count());
}

static void validate_order_draft(OrderDraft const &draft) {
  if (draft.mode == OrderMode::Market) {
    if (draft.delta_ppm < 0) [[unlikely]] {
      throw std::invalid_argument("market order slippage must be nonnegative");
    }
    if (draft.price == 0 && draft.delta_ppm != 0) [[unlikely]] {
      throw std::invalid_argument("market order slippage requires a reference price");
    }
    if (draft.price != 0 && draft.delta_ppm == 0) [[unlikely]] {
      throw std::invalid_argument("market order reference price requires non-zero slippage");
    }
    if (draft.delta_ppm > kMarketMaxSlippagePpm) [[unlikely]] {
      throw std::invalid_argument("market order slippage must not exceed 1000000 ppm");
    }
  }
}

static uint64_t order_expiry_unix_seconds(uint64_t iat_sec,
                                          uint8_t tif,
                                          uint64_t order_expiry_seconds) {
  if (order_expiry_seconds != 0) {
    return iat_sec + order_expiry_seconds;
  }
  if (tif == 1) {
    return iat_sec + kGtcOrderExpirySeconds;
  }
  return iat_sec + kOrderExpirySeconds;
}

} // namespace

std::string ApiClientSigner::sign_auth_challenge_base64(
    std::string const &message,
    wallet_codec::Keypair const &keypair) {
  std::array<unsigned char, crypto_sign_BYTES> signature{};
  if (crypto_sign_detached(signature.data(),
                           nullptr,
                           reinterpret_cast<unsigned char const *>(message.data()),
                           message.size(),
                           keypair.secret_key.data()) != 0) {
    throw std::runtime_error("failed to sign auth challenge");
  }
  return encode_base64(signature.data(), signature.size());
}

std::vector<unsigned char> ApiClientSigner::build_signed_order_proof_raw(
    wallet_codec::Keypair const &keypair,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t request_id,
    uint8_t execution_mode,
    OrderDraft const &draft) {
  return build_signed_order_proof_raw_for_sender(
      keypair,
      keypair.public_key,
      partition_id,
      subaccount_id,
      request_id,
      execution_mode,
      draft);
}

std::vector<unsigned char> ApiClientSigner::build_signed_order_proof_raw_for_sender(
    wallet_codec::Keypair const &signing_keypair,
    std::array<unsigned char, 32> const &sender_pubkey,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t request_id,
    uint8_t execution_mode,
    OrderDraft const &draft,
    uint64_t order_expiry_seconds) {
  validate_order_draft(draft);
  uint64_t const now_sec = current_unix_seconds();
  std::vector<unsigned char> order_bytes;
  order_bytes.reserve(kOrderV1Bytes);
  append_u32_le(order_bytes, draft.symbol);
  append_u64_le(order_bytes, draft.price);
  append_u64_le(order_bytes, draft.qty);

  uint8_t tif = 1;
  uint8_t order_type = 0;
  if (draft.mode == OrderMode::GtcLimit) {
    tif = 1;
    order_type = 0;
  } else if (draft.mode == OrderMode::MarkToMid) {
    tif = 1;
    order_type = 1;
  } else if (draft.mode == OrderMode::Market) {
    tif = 0;
    order_type = 2;
  } else if (draft.mode == OrderMode::IocLimit) {
    tif = 0;
    order_type = 0;
  }

  order_bytes.push_back(tif);
  order_bytes.push_back(order_type);
  order_bytes.push_back(execution_mode);
  order_bytes.push_back(
      draft.role == OrderRole::Taker ? 1U : 0U);
  append_i32_le(order_bytes, draft.delta_ppm);
  order_bytes.push_back(draft.is_sell ? 1U : 0U);
  append_u64_le(order_bytes, request_id);

  if (order_bytes.size() != kOrderV1Bytes) {
    throw std::runtime_error("internal error: invalid order payload size");
  }

  uint64_t const exp_sec = order_expiry_unix_seconds(now_sec, tif, order_expiry_seconds);

  std::vector<unsigned char> payload;
  payload.reserve(sizeof(kOrderDomain) + 32U + 2U + 8U + 8U + 8U + kOrderV1Bytes);
  payload.insert(payload.end(), kOrderDomain, kOrderDomain + std::strlen(kOrderDomain));
  payload.push_back(0U);
  payload.insert(payload.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(payload, partition_id);
  append_u64_le(payload, subaccount_id);
  append_u64_le(payload, now_sec);
  append_u64_le(payload, exp_sec);
  payload.insert(payload.end(), order_bytes.begin(), order_bytes.end());

  std::array<unsigned char, crypto_sign_BYTES> signature{};
  if (crypto_sign_detached(signature.data(),
                           nullptr,
                           payload.data(),
                           payload.size(),
                           signing_keypair.secret_key.data()) != 0) {
    throw std::runtime_error("failed to sign order proof");
  }

  std::vector<unsigned char> proof;
  proof.reserve(kOrderProofBytes);
  proof.insert(proof.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(proof, partition_id);
  append_u64_le(proof, subaccount_id);
  append_u64_le(proof, now_sec);
  append_u64_le(proof, exp_sec);
  proof.insert(proof.end(), order_bytes.begin(), order_bytes.end());
  proof.insert(proof.end(), signing_keypair.public_key.begin(), signing_keypair.public_key.end());
  proof.insert(proof.end(), signature.begin(), signature.end());
  if (proof.size() != kOrderProofBytes) {
    throw std::runtime_error("internal error: invalid signed order proof size");
  }

  return proof;
}

std::string ApiClientSigner::build_signed_order_proof_base64(
    wallet_codec::Keypair const &keypair,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t request_id,
    OrderDraft const &draft) {
  return build_signed_order_proof_base64_for_sender(
      keypair,
      keypair.public_key,
      partition_id,
      subaccount_id,
      request_id,
      draft);
}

std::string ApiClientSigner::build_signed_order_proof_base64_for_sender(
    wallet_codec::Keypair const &signing_keypair,
    std::array<unsigned char, 32> const &sender_pubkey,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t request_id,
    OrderDraft const &draft) {
  std::vector<unsigned char> const proof = build_signed_order_proof_raw_for_sender(
      signing_keypair,
      sender_pubkey,
      partition_id,
      subaccount_id,
      request_id,
      0U,
      draft);
  return encode_base64(proof.data(), proof.size());
}

std::string ApiClientSigner::build_signed_order_proof_base64_for_sender_at(
    wallet_codec::Keypair const &signing_keypair,
    std::array<unsigned char, 32> const &sender_pubkey,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t request_id,
    uint64_t iat_sec,
    OrderDraft const &draft,
    uint64_t order_expiry_seconds) {
  validate_order_draft(draft);
  std::vector<unsigned char> order_bytes;
  order_bytes.reserve(kOrderV1Bytes);
  append_u32_le(order_bytes, draft.symbol);
  append_u64_le(order_bytes, draft.price);
  append_u64_le(order_bytes, draft.qty);

  uint8_t tif = 1;
  uint8_t order_type = 0;
  if (draft.mode == OrderMode::GtcLimit) {
    tif = 1;
    order_type = 0;
  } else if (draft.mode == OrderMode::MarkToMid) {
    tif = 1;
    order_type = 1;
  } else if (draft.mode == OrderMode::Market) {
    tif = 0;
    order_type = 2;
  } else if (draft.mode == OrderMode::IocLimit) {
    tif = 0;
    order_type = 0;
  }

  order_bytes.push_back(tif);
  order_bytes.push_back(order_type);
  order_bytes.push_back(0U);
  order_bytes.push_back(draft.role == OrderRole::Taker ? 1U : 0U);
  append_i32_le(order_bytes, draft.delta_ppm);
  order_bytes.push_back(draft.is_sell ? 1U : 0U);
  append_u64_le(order_bytes, request_id);
  if (order_bytes.size() != kOrderV1Bytes) {
    throw std::runtime_error("internal error: invalid order payload size");
  }

  uint64_t const exp_sec = order_expiry_unix_seconds(iat_sec, tif, order_expiry_seconds);

  std::vector<unsigned char> payload;
  payload.reserve(sizeof(kOrderDomain) + 32U + 2U + 8U + 8U + 8U + kOrderV1Bytes);
  payload.insert(payload.end(), kOrderDomain, kOrderDomain + std::strlen(kOrderDomain));
  payload.push_back(0U);
  payload.insert(payload.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(payload, partition_id);
  append_u64_le(payload, subaccount_id);
  append_u64_le(payload, iat_sec);
  append_u64_le(payload, exp_sec);
  payload.insert(payload.end(), order_bytes.begin(), order_bytes.end());

  std::array<unsigned char, crypto_sign_BYTES> signature{};
  if (crypto_sign_detached(signature.data(),
                           nullptr,
                           payload.data(),
                           payload.size(),
                           signing_keypair.secret_key.data()) != 0) {
    throw std::runtime_error("failed to sign order proof");
  }

  std::vector<unsigned char> proof;
  proof.reserve(kOrderProofBytes);
  proof.insert(proof.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(proof, partition_id);
  append_u64_le(proof, subaccount_id);
  append_u64_le(proof, iat_sec);
  append_u64_le(proof, exp_sec);
  proof.insert(proof.end(), order_bytes.begin(), order_bytes.end());
  proof.insert(proof.end(), signing_keypair.public_key.begin(), signing_keypair.public_key.end());
  proof.insert(proof.end(), signature.begin(), signature.end());
  if (proof.size() != kOrderProofBytes) {
    throw std::runtime_error("internal error: invalid signed order proof size");
  }
  return encode_base64(proof.data(), proof.size());
}

std::string ApiClientSigner::build_signed_cancel_proof_base64(
    wallet_codec::Keypair const &keypair,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t external_order_id,
    uint64_t request_id,
    uint32_t symbol,
    OrderRole role) {
  return build_signed_cancel_proof_base64_for_sender(
      keypair,
      keypair.public_key,
      partition_id,
      subaccount_id,
      external_order_id,
      request_id,
      symbol,
      role);
}

std::string ApiClientSigner::build_signed_cancel_proof_base64_for_sender(
    wallet_codec::Keypair const &signing_keypair,
    std::array<unsigned char, 32> const &sender_pubkey,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t external_order_id,
    uint64_t request_id,
    uint32_t symbol,
    OrderRole role) {
  return build_signed_cancel_proof_base64_for_sender_at(
      signing_keypair,
      sender_pubkey,
      partition_id,
      subaccount_id,
      external_order_id,
      request_id,
      current_unix_seconds(),
      symbol,
      role);
}

std::string ApiClientSigner::build_signed_cancel_proof_base64_for_sender_at(
    wallet_codec::Keypair const &signing_keypair,
    std::array<unsigned char, 32> const &sender_pubkey,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t external_order_id,
    uint64_t request_id,
    uint64_t iat_sec,
    uint32_t symbol,
    OrderRole role) {
  std::vector<unsigned char> cancel_bytes;
  cancel_bytes.reserve(kCancelV2Bytes);
  append_u64_le(cancel_bytes, external_order_id);
  append_u64_le(cancel_bytes, request_id);
  append_u32_le(cancel_bytes, symbol);
  cancel_bytes.push_back(role == OrderRole::Taker ? 1U : 0U);
  if (cancel_bytes.size() != kCancelV2Bytes) {
    throw std::runtime_error("internal error: invalid cancel payload size");
  }

  uint64_t const exp_sec = iat_sec + kOrderExpirySeconds;

  std::vector<unsigned char> payload;
  payload.reserve(std::strlen(kCancelDomain) + 1U + 32U + 2U + 8U + 8U + 8U + kCancelV2Bytes);
  payload.insert(payload.end(), kCancelDomain, kCancelDomain + std::strlen(kCancelDomain));
  payload.push_back(0U);
  payload.insert(payload.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(payload, partition_id);
  append_u64_le(payload, subaccount_id);
  append_u64_le(payload, iat_sec);
  append_u64_le(payload, exp_sec);
  payload.insert(payload.end(), cancel_bytes.begin(), cancel_bytes.end());

  std::array<unsigned char, crypto_sign_BYTES> signature{};
  if (crypto_sign_detached(signature.data(),
                           nullptr,
                           payload.data(),
                           payload.size(),
                           signing_keypair.secret_key.data()) != 0) {
    throw std::runtime_error("failed to sign cancel proof");
  }

  std::vector<unsigned char> proof;
  proof.reserve(kCancelProofBytes);
  proof.insert(proof.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(proof, partition_id);
  append_u64_le(proof, subaccount_id);
  append_u64_le(proof, iat_sec);
  append_u64_le(proof, exp_sec);
  proof.insert(proof.end(), cancel_bytes.begin(), cancel_bytes.end());
  proof.insert(proof.end(), signing_keypair.public_key.begin(), signing_keypair.public_key.end());
  proof.insert(proof.end(), signature.begin(), signature.end());
  if (proof.size() != kCancelProofBytes) {
    throw std::runtime_error("internal error: invalid signed cancel proof size");
  }

  return encode_base64(proof.data(), proof.size());
}

std::string ApiClientSigner::build_signed_modify_proof_base64(
    wallet_codec::Keypair const &keypair,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t external_order_id,
    uint64_t request_id,
    uint64_t original_iat,
    uint64_t original_request_id,
    uint32_t symbol,
    OrderRole role,
    bool is_sell,
    uint8_t tif,
    uint8_t order_type,
    uint8_t execution_mode,
    uint64_t price,
    uint64_t qty,
    int32_t delta_ppm) {
  return build_signed_modify_proof_base64_for_sender(
      keypair,
      keypair.public_key,
      partition_id,
      subaccount_id,
      external_order_id,
      request_id,
      original_iat,
      original_request_id,
      symbol,
      role,
      is_sell,
      tif,
      order_type,
      execution_mode,
      price,
      qty,
      delta_ppm);
}

std::string ApiClientSigner::build_signed_modify_proof_base64_for_sender(
    wallet_codec::Keypair const &signing_keypair,
    std::array<unsigned char, 32> const &sender_pubkey,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t external_order_id,
    uint64_t request_id,
    uint64_t original_iat,
    uint64_t original_request_id,
    uint32_t symbol,
    OrderRole role,
    bool is_sell,
    uint8_t tif,
    uint8_t order_type,
    uint8_t execution_mode,
    uint64_t price,
    uint64_t qty,
    int32_t delta_ppm) {
  return build_signed_modify_proof_base64_for_sender_at(
      signing_keypair,
      sender_pubkey,
      partition_id,
      subaccount_id,
      external_order_id,
      request_id,
      current_unix_seconds(),
      original_iat,
      original_request_id,
      symbol,
      role,
      is_sell,
      tif,
      order_type,
      execution_mode,
      price,
      qty,
      delta_ppm,
      kOrderExpirySeconds);
}

std::string ApiClientSigner::build_signed_modify_proof_base64_for_sender_at(
    wallet_codec::Keypair const &signing_keypair,
    std::array<unsigned char, 32> const &sender_pubkey,
    uint16_t partition_id,
    uint64_t subaccount_id,
    uint64_t external_order_id,
    uint64_t request_id,
    uint64_t iat_sec,
    uint64_t original_iat,
    uint64_t original_request_id,
    uint32_t symbol,
    OrderRole role,
    bool is_sell,
    uint8_t tif,
    uint8_t order_type,
    uint8_t execution_mode,
    uint64_t price,
    uint64_t qty,
    int32_t delta_ppm,
    uint64_t order_expiry_seconds) {
  std::vector<unsigned char> modify_bytes;
  modify_bytes.reserve(kModifyV1Bytes);
  append_u64_le(modify_bytes, external_order_id);
  append_u64_le(modify_bytes, request_id);
  append_u64_le(modify_bytes, original_iat);
  append_u64_le(modify_bytes, original_request_id);
  append_u32_le(modify_bytes, symbol);
  modify_bytes.push_back(role == OrderRole::Taker ? 1U : 0U);
  modify_bytes.push_back(is_sell ? 1U : 0U);
  modify_bytes.push_back(tif);
  modify_bytes.push_back(order_type);
  modify_bytes.push_back(execution_mode);
  append_u64_le(modify_bytes, price);
  append_u64_le(modify_bytes, qty);
  append_i32_le(modify_bytes, delta_ppm);
  if (modify_bytes.size() != kModifyV1Bytes) {
    throw std::runtime_error("internal error: invalid modify payload size");
  }

  if (iat_sec == 0 || iat_sec < original_iat) {
    throw std::runtime_error("modify iat must not be earlier than original_iat");
  }
  if (order_expiry_seconds == 0 ||
      iat_sec > std::numeric_limits<uint64_t>::max() - order_expiry_seconds) {
    throw std::runtime_error("invalid modify expiry");
  }
  uint64_t const exp_sec = iat_sec + order_expiry_seconds;

  std::vector<unsigned char> payload;
  payload.reserve(std::strlen(kModifyDomain) + 1U + 32U + 2U + 8U + 8U + 8U + kModifyV1Bytes);
  payload.insert(payload.end(), kModifyDomain, kModifyDomain + std::strlen(kModifyDomain));
  payload.push_back(0U);
  payload.insert(payload.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(payload, partition_id);
  append_u64_le(payload, subaccount_id);
  append_u64_le(payload, iat_sec);
  append_u64_le(payload, exp_sec);
  payload.insert(payload.end(), modify_bytes.begin(), modify_bytes.end());

  std::array<unsigned char, crypto_sign_BYTES> signature{};
  if (crypto_sign_detached(signature.data(),
                           nullptr,
                           payload.data(),
                           payload.size(),
                           signing_keypair.secret_key.data()) != 0) {
    throw std::runtime_error("failed to sign modify proof");
  }

  std::vector<unsigned char> proof;
  proof.reserve(kModifyProofBytes);
  proof.insert(proof.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(proof, partition_id);
  append_u64_le(proof, subaccount_id);
  append_u64_le(proof, iat_sec);
  append_u64_le(proof, exp_sec);
  proof.insert(proof.end(), modify_bytes.begin(), modify_bytes.end());
  proof.insert(proof.end(), signing_keypair.public_key.begin(), signing_keypair.public_key.end());
  proof.insert(proof.end(), signature.begin(), signature.end());
  if (proof.size() != kModifyProofBytes) {
    throw std::runtime_error("internal error: invalid signed modify proof size");
  }

  return encode_base64(proof.data(), proof.size());
}

std::string ApiClientSigner::build_signed_create_vault_proof_base64(
    wallet_codec::Keypair const &keypair,
    uint16_t partition_id,
    uint64_t source_subaccount_id,
    uint32_t vault_id,
    uint64_t operation_subaccount_id,
    uint64_t requested_vault_collateral,
    uint64_t vault_creation_fee,
    uint64_t request_id) {
  return build_signed_create_vault_proof_base64_for_sender(
      keypair,
      keypair.public_key,
      partition_id,
      source_subaccount_id,
      vault_id,
      operation_subaccount_id,
      requested_vault_collateral,
      vault_creation_fee,
      request_id);
}

std::string ApiClientSigner::build_signed_create_vault_proof_base64_for_sender(
    wallet_codec::Keypair const &signing_keypair,
    std::array<unsigned char, 32> const &sender_pubkey,
    uint16_t partition_id,
    uint64_t source_subaccount_id,
    uint32_t vault_id,
    uint64_t operation_subaccount_id,
    uint64_t requested_vault_collateral,
    uint64_t vault_creation_fee,
    uint64_t request_id) {
  if (operation_subaccount_id == 0 ||
      source_subaccount_id == operation_subaccount_id ||
      requested_vault_collateral == 0 ||
      request_id == 0) {
    throw std::runtime_error("invalid create vault proof fields");
  }

  std::vector<unsigned char> create_vault_bytes;
  create_vault_bytes.reserve(kCreateVaultV1Bytes);
  append_u32_le(create_vault_bytes, vault_id);
  append_u32_le(create_vault_bytes, 0U);
  append_u64_le(create_vault_bytes, operation_subaccount_id);
  append_u64_le(create_vault_bytes, requested_vault_collateral);
  append_u64_le(create_vault_bytes, vault_creation_fee);
  append_u64_le(create_vault_bytes, request_id);
  if (create_vault_bytes.size() != kCreateVaultV1Bytes) {
    throw std::runtime_error("internal error: invalid create vault payload size");
  }

  uint64_t const now_sec = static_cast<uint64_t>(
      std::chrono::duration_cast<std::chrono::seconds>(
          std::chrono::system_clock::now().time_since_epoch())
          .count());
  uint64_t const exp_sec = now_sec + kCreateVaultExpirySeconds;

  std::vector<unsigned char> payload;
  payload.reserve(std::strlen(kCreateVaultDomain) + 1U + 32U + 2U + 8U + 8U + 8U + kCreateVaultV1Bytes);
  payload.insert(payload.end(), kCreateVaultDomain, kCreateVaultDomain + std::strlen(kCreateVaultDomain));
  payload.push_back(0U);
  payload.insert(payload.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(payload, partition_id);
  append_u64_le(payload, source_subaccount_id);
  append_u64_le(payload, now_sec);
  append_u64_le(payload, exp_sec);
  payload.insert(payload.end(), create_vault_bytes.begin(), create_vault_bytes.end());

  std::array<unsigned char, crypto_sign_BYTES> signature{};
  if (crypto_sign_detached(signature.data(),
                           nullptr,
                           payload.data(),
                           payload.size(),
                           signing_keypair.secret_key.data()) != 0) {
    throw std::runtime_error("failed to sign create vault proof");
  }

  std::vector<unsigned char> proof;
  proof.reserve(kCreateVaultProofBytes);
  proof.insert(proof.end(), sender_pubkey.begin(), sender_pubkey.end());
  append_u16_le(proof, partition_id);
  append_u64_le(proof, source_subaccount_id);
  append_u64_le(proof, now_sec);
  append_u64_le(proof, exp_sec);
  proof.insert(proof.end(), create_vault_bytes.begin(), create_vault_bytes.end());
  proof.insert(proof.end(), signing_keypair.public_key.begin(), signing_keypair.public_key.end());
  proof.insert(proof.end(), signature.begin(), signature.end());
  if (proof.size() != kCreateVaultProofBytes) {
    throw std::runtime_error("internal error: invalid signed create vault proof size");
  }

  return encode_base64(proof.data(), proof.size());
}

} // namespace api_client
