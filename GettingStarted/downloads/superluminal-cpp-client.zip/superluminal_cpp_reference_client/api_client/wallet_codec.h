#pragma once

#include <algorithm>
#include <array>
#include <cstring>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include <sodium.h>

#include "dfba_common/simdjson_utils.hpp"

namespace wallet_codec {

struct Keypair {
  std::array<unsigned char, crypto_sign_SECRETKEYBYTES> secret_key{};
  std::array<unsigned char, crypto_sign_PUBLICKEYBYTES> public_key{};
};

class WalletCodec {
 public:
  static Keypair load_keypair(std::string const &path) {
    std::vector<unsigned char> const bytes = parse_keypair_bytes(read_text_file(path));

    Keypair keypair;
    std::copy(bytes.begin(), bytes.end(), keypair.secret_key.begin());
    if (crypto_sign_ed25519_sk_to_pk(keypair.public_key.data(), keypair.secret_key.data()) != 0) {
      throw std::runtime_error("libsodium failed to derive public key");
    }

    unsigned char const *expected_public = keypair.secret_key.data() + crypto_sign_PUBLICKEYBYTES;
    if (std::memcmp(expected_public, keypair.public_key.data(), crypto_sign_PUBLICKEYBYTES) != 0) {
      throw std::runtime_error("keypair file public key does not match secret key");
    }

    return keypair;
  }

  static std::string encode_base58(unsigned char const *data, size_t len) {
    size_t zeros = 0;
    while (zeros < len && data[zeros] == 0U) {
      ++zeros;
    }

    std::vector<unsigned char> digits((len - zeros) * 138 / 100 + 1, 0U);
    size_t digits_len = 0;

    for (size_t i = zeros; i < len; ++i) {
      unsigned int carry = data[i];
      size_t j = 0;
      while (j < digits_len) {
        carry += static_cast<unsigned int>(digits[j]) << 8U;
        digits[j] = static_cast<unsigned char>(carry % 58U);
        carry /= 58U;
        ++j;
      }
      while (carry > 0U) {
        digits[digits_len++] = static_cast<unsigned char>(carry % 58U);
        carry /= 58U;
      }
    }

    std::string out(zeros, '1');
    for (size_t i = 0; i < digits_len; ++i) {
      out.push_back(kBase58Alphabet[digits[digits_len - 1 - i]]);
    }
    if (out.empty()) {
      return "1";
    }
    return out;
  }

  static std::vector<unsigned char> decode_base58(std::string const &text) {
    size_t zeros = 0;
    while (zeros < text.size() && text[zeros] == '1') {
      ++zeros;
    }

    std::vector<unsigned char> bytes((text.size() - zeros) * 733 / 1000 + 1, 0U);
    size_t bytes_len = 0;

    for (size_t i = zeros; i < text.size(); ++i) {
      unsigned int carry = base58_index(text[i]);
      size_t j = 0;
      while (j < bytes_len) {
        carry += static_cast<unsigned int>(bytes[j]) * 58U;
        bytes[j] = static_cast<unsigned char>(carry & 0xffU);
        carry >>= 8U;
        ++j;
      }
      while (carry > 0U) {
        bytes[bytes_len++] = static_cast<unsigned char>(carry & 0xffU);
        carry >>= 8U;
      }
    }

    std::vector<unsigned char> out(zeros, 0U);
    out.reserve(zeros + bytes_len);
    for (size_t i = 0; i < bytes_len; ++i) {
      out.push_back(bytes[bytes_len - 1 - i]);
    }
    return out;
  }

 private:
  static constexpr char kBase58Alphabet[] = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

  static std::string read_text_file(std::string const &path) {
    std::ifstream in(path);
    if (!in) {
      throw std::runtime_error("failed to open keypair file: " + path);
    }
    std::ostringstream contents;
    contents << in.rdbuf();
    return contents.str();
  }

  static std::vector<unsigned char> parse_keypair_bytes(std::string const &json_text) {
    simdjson::dom::parser parser;
    dfba::json::JsonElement root;
    if (parser.parse(json_text).get(root) != simdjson::SUCCESS) {
      throw std::runtime_error("keypair file must be a JSON array");
    }

    dfba::json::JsonArray bytes;
    if (root.get(bytes) != simdjson::SUCCESS) {
      throw std::runtime_error("keypair file must be a JSON array");
    }

    std::vector<unsigned char> out;
    out.reserve(crypto_sign_SECRETKEYBYTES);
    for (dfba::json::JsonElement value : bytes) {
      uint64_t byte = 0;
      if (value.get(byte) != simdjson::SUCCESS) {
        throw std::runtime_error("invalid keypair byte in JSON array");
      }
      if (byte > 255U) {
        throw std::runtime_error("keypair byte out of range");
      }
      out.push_back(static_cast<unsigned char>(byte));
    }

    if (out.size() != crypto_sign_SECRETKEYBYTES) {
      throw std::runtime_error("keypair file must contain 64 bytes");
    }
    return out;
  }

  static unsigned int base58_index(char c) {
    char const *found = std::strchr(kBase58Alphabet, c);
    if (found == nullptr) {
      throw std::runtime_error("invalid base58 character");
    }
    return static_cast<unsigned int>(found - kBase58Alphabet);
  }
};

} // namespace wallet_codec
