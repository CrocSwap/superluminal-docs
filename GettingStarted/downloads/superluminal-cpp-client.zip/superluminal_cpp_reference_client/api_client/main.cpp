#include <csignal>
#include <cctype>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <ctime>
#include <ftxui/component/component.hpp>
#include <ftxui/component/screen_interactive.hpp>
#include <ixwebsocket/IXNetSystem.h>
#include <ixwebsocket/IXWebSocket.h>
#include <sodium.h>

#include <atomic>
#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

#include "account_state.h"
#include "api_client_signer.h"
#include "api_client_types.h"
#include "book_sync.h"
#include "dfba_common/build_info_print.hpp"
#include "gateway_protocol_codec.h"
#include "price_grid.h"
#include "price_ladder_view.h"
#include "qty_utils.h"
#include "running_avg.h"
#include "dfba_common/simdjson_utils.hpp"
#include "symbology_client.h"
#include "wallet_codec.h"

namespace {

constexpr size_t kLevelsPerSide = 10;
constexpr char kApiClientLogPath[] = "api_client_log";
constexpr auto kPingInterval = std::chrono::milliseconds(100);
constexpr uint32_t kInitialOrderHistoryLimit = 100;

std::atomic<bool> g_stop_requested(false);
using api_client::AccountFundingUpdateMessage;
using api_client::AccountSnapshotMessage;
using api_client::AccountState;
using api_client::AckMessage;
using api_client::AdlFailedMessage;
using api_client::ApiClientSigner;
using api_client::AuthChallengeMessage;
using api_client::AuthExpiredMessage;
using api_client::CancelAckEventMessage;
using api_client::ConditionalEventMessage;
using api_client::ConditionalGroupDraft;
using api_client::Config;
using api_client::FillEventMessage;
using api_client::FillSettlementEventMessage;
using api_client::FundingIndexMessage;
using api_client::GatewayProtocolCodec;
using api_client::InactivePositionSettlementStatusMessage;
using api_client::LadderRow;
using api_client::LocalOrderRejectMessage;
using api_client::MarketInfo;
using api_client::ModifyAckEventMessage;
using api_client::ModifyRejectEventMessage;
using api_client::OrderAcceptedMessage;
using api_client::OrderDraft;
using api_client::OrderHistoryMessage;
using api_client::OrderMode;
using api_client::OrderRejectMessage;
using api_client::PongMessage;
using api_client::PriceLadderClient;
using api_client::SessionPhase;
using api_client::SymbologySnapshot;
using api_client::SymbolView;
using api_client::TradeMessage;
using api_client::UiSnapshot;
using api_client::UserCollateralUpdateMessage;
using dfba::json::JsonObject;

void append_bounded_line(
    std::vector<std::string> &lines,
    size_t max_lines,
    std::string line) {
  lines.push_back(std::move(line));
  if (lines.size() > max_lines) {
    lines.erase(
        lines.begin(),
        lines.begin() +
            static_cast<std::ptrdiff_t>(lines.size() - max_lines));
  }
}

std::string format_trade_qty(uint64_t qty, bool has_market, uint8_t size_decimals) {
  if (!has_market) {
    return std::to_string(qty);
  }
  return api_client::qty_utils::format_qty(qty, size_decimals);
}

std::string format_trade_price(
    uint64_t price,
    bool has_market,
    int16_t px_exponent) {
  if (!has_market) {
    return std::to_string(price);
  }
  return api_client::price_grid::format_price(price, px_exponent);
}

std::string utc_log_timestamp() {
  auto const now = std::chrono::system_clock::now();
  auto const millis = std::chrono::duration_cast<std::chrono::milliseconds>(
                          now.time_since_epoch())
                          .count() %
                      1000;
  std::time_t const seconds = std::chrono::system_clock::to_time_t(now);
  std::tm tm{};
  gmtime_r(&seconds, &tm);

  char buffer[96];
  std::snprintf(
      buffer,
      sizeof(buffer),
      "%04d-%02d-%02dT%02d:%02d:%02d.%03lldZ",
      tm.tm_year + 1900,
      tm.tm_mon + 1,
      tm.tm_mday,
      tm.tm_hour,
      tm.tm_min,
      tm.tm_sec,
      static_cast<long long>(millis));
  return std::string(buffer);
}

class ApiClient : public PriceLadderClient {
 public:
  explicit ApiClient(Config config, wallet_codec::Keypair wallet_keypair, std::string wallet_pubkey)
      : config_(std::move(config)),
        wallet_keypair_(std::move(wallet_keypair)),
        wallet_pubkey_(std::move(wallet_pubkey)) {
  }

  int run() {
    if (!ix::initNetSystem()) {
      throw std::runtime_error("ix::initNetSystem failed");
    }
    open_log_file();
    load_symbology_or_throw();

    configure_websocket();
    ftxui::ScreenInteractive screen = ftxui::ScreenInteractive::Fullscreen();
    {
      std::lock_guard<std::mutex> lock(mu_);
      screen_ = &screen;
      exit_loop_ = screen.ExitLoopClosure();
      connection_status_ = "connecting";
      last_notice_ = "waiting for market data";
      append_log_locked("connecting websocket");
    }

    websocket_.start();
    std::thread stop_thread(&ApiClient::monitor_shutdown, this);
    std::thread ping_thread(&ApiClient::ping_loop, this);

    ftxui::Component component = api_client::make_price_ladder_view(*this);
    screen.Loop(component);

    g_stop_requested.store(true);
    websocket_.stop();
    done_.store(true);

    if (stop_thread.joinable()) {
      stop_thread.join();
    }
    if (ping_thread.joinable()) {
      ping_thread.join();
    }

    std::string fatal_exit_message;
    {
      std::lock_guard<std::mutex> lock(mu_);
      fatal_exit_message = fatal_exit_message_;
      screen_ = nullptr;
      exit_loop_ = std::function<void()>();
    }

    if (!fatal_exit_message.empty()) {
      std::cerr << "fatal: " << fatal_exit_message << "\n";
    }

    ix::uninitNetSystem();
    return error_seen_.load() ? 1 : 0;
  }

  UiSnapshot snapshot() const override {
    std::lock_guard<std::mutex> lock(mu_);
    UiSnapshot out;
    out.wallet_pubkey = wallet_pubkey_;
    out.ws_url = config_.ws_url;
    out.connection_status = connection_status_;
    out.auth_status = auth_status_;
    out.account_status = account_status_;
    out.last_notice = last_notice_;
    out.last_error = last_error_;
    out.gateway_rtt_avg_ns = gateway_rtt_avg_.mean();
    out.gateway_rtt_samples = gateway_rtt_avg_.sample_count();
    out.taker_fee_ppm = taker_fee_ppm_;
    out.maker_fee_ppm = maker_fee_ppm_;
    out.account_stream_started = account_stream_started_;
    out.books.reserve(books_.size());
    for (auto const &entry : books_) {
      out.books.push_back(entry.second);
    }
    account_state_.populate_snapshot(out);
    out.trade_lines = trade_lines_;
    out.log_lines = log_lines_;
    return out;
  }

  std::vector<uint32_t> const &feed_ids() const override {
    return config_.feed_ids;
  }

  std::map<uint32_t, MarketInfo> const &markets() const override {
    return symbology_;
  }

  bool submit_order(OrderDraft const &draft, std::string &error) override {
    uint64_t request_id = 0;
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (phase_ != SessionPhase::Running) {
        error = "session is not ready for orders";
        return false;
      }
      if (connection_status_ != "connected") {
        error = "websocket is not connected";
        return false;
      }
      if (auth_status_ != "authenticated") {
        error = "wallet is not authenticated";
        return false;
      }
      request_id = allocate_request_id_locked();
      if (request_id == 0) {
        error = "failed to allocate request id";
        return false;
      }
    }

    uint64_t const iat_sec = current_system_clock_unix_ns() / 1000000000ULL;
    if (iat_sec == 0) {
      error = "failed to allocate order iat";
      return false;
    }

    std::string msg_b64;
    try {
      msg_b64 = ApiClientSigner::build_signed_order_proof_base64_for_sender_at(
          wallet_keypair_,
          wallet_keypair_.public_key,
          config_.partition_id,
          config_.subaccount_id,
          request_id,
          iat_sec,
          draft);
    } catch (std::exception const &ex) {
      error = ex.what();
      return false;
    }

    {
      std::lock_guard<std::mutex> lock(mu_);
      pending_order_iats_[request_id] = iat_sec;
    }
    if (!send_text_message(GatewayProtocolCodec::encode_signed_order(msg_b64), "signed_order")) {
      std::lock_guard<std::mutex> lock(mu_);
      pending_order_iats_.erase(request_id);
      error = "failed to send signed order";
      return false;
    }

    {
      std::lock_guard<std::mutex> lock(mu_);
      last_error_.clear();
      last_notice_ = "sent signed_order";
    }
    notify_ui();
    return true;
  }

  bool submit_conditional_group(ConditionalGroupDraft const &draft, std::string &error) override {
    uint64_t request_id = 0;
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (phase_ != SessionPhase::Running || connection_status_ != "connected" ||
          auth_status_ != "authenticated") [[unlikely]] {
        error = "session is not ready for orders";
        return false;
      }
      request_id = allocate_request_id_locked();
      if (request_id == 0) [[unlikely]] {
        error = "failed to allocate request id";
        return false;
      }
    }
    std::string msg_b64;
    try {
      msg_b64 = ApiClientSigner::build_signed_conditional_group_proof_base64_for_sender_at(
          wallet_keypair_, wallet_keypair_.public_key, config_.partition_id,
          config_.subaccount_id, request_id, current_system_clock_unix_ns() / 1000000000ULL,
          draft);
    } catch (std::exception const &ex) {
      error = ex.what();
      return false;
    }
    if (!send_text_message(GatewayProtocolCodec::encode_signed_conditional_group(msg_b64),
                           "signed_conditional_group")) [[unlikely]] {
      error = "failed to send signed conditional group";
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      last_error_.clear();
      last_notice_ = "sent TP/SL group request=" + std::to_string(request_id);
    }
    notify_ui();
    return true;
  }

  bool submit_conditional_parent(uint64_t subaccount_id,
                                 uint64_t group_external_order_id,
                                 OrderDraft const &draft,
                                 std::string &error) override {
    uint64_t request_id = 0;
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (phase_ != SessionPhase::Running || connection_status_ != "connected" ||
          auth_status_ != "authenticated") [[unlikely]] {
        error = "session is not ready for orders";
        return false;
      }
      request_id = allocate_request_id_locked();
      if (request_id == 0) [[unlikely]] {
        error = "failed to allocate request id";
        return false;
      }
    }
    uint64_t const iat_sec = current_system_clock_unix_ns() / 1000000000ULL;
    std::string msg_b64;
    try {
      msg_b64 = ApiClientSigner::build_signed_order_proof_base64_for_sender_at(
          wallet_keypair_, wallet_keypair_.public_key, config_.partition_id,
          subaccount_id, request_id, iat_sec, draft);
    } catch (std::exception const &ex) {
      error = ex.what();
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      pending_order_iats_[request_id] = iat_sec;
    }
    if (!send_text_message(GatewayProtocolCodec::encode_signed_conditional_parent(
                               group_external_order_id, msg_b64),
                           "signed_conditional_parent")) [[unlikely]] {
      std::lock_guard<std::mutex> lock(mu_);
      pending_order_iats_.erase(request_id);
      error = "failed to send signed conditional parent";
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      last_error_.clear();
      last_notice_ = "sent TP/SL parent for group=" + std::to_string(group_external_order_id);
    }
    notify_ui();
    return true;
  }

  bool submit_conditional_cancel(uint64_t subaccount_id,
                                 UiSnapshot::ConditionalGroupRow const &group,
                                 std::string &error) override {
    bool const active = group.state == "triggering" || group.state == "active";
    uint64_t const external_order_id = active ? group.selected_external_order_id
                                              : group.group_external_order_id;
    if (external_order_id == 0) [[unlikely]] {
      error = "active child ID unavailable; cancel it from Working Orders";
      return false;
    }
    uint64_t request_id = 0;
    uint32_t symbol = group.symbol;
    api_client::OrderRole role = api_client::OrderRole::Taker;
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (phase_ != SessionPhase::Running || connection_status_ != "connected" ||
          auth_status_ != "authenticated") [[unlikely]] {
        error = "session is not ready for orders";
        return false;
      }
      if (active && !account_state_.find_working_order_cancel_info(
                        subaccount_id, external_order_id, symbol, role)) [[unlikely]] {
        error = "active child is not accepted as a working order yet";
        return false;
      }
      request_id = allocate_request_id_locked();
      if (request_id == 0) [[unlikely]] {
        error = "failed to allocate request id";
        return false;
      }
    }
    std::string msg_b64;
    try {
      msg_b64 = ApiClientSigner::build_signed_cancel_proof_base64(
          wallet_keypair_, config_.partition_id, subaccount_id, external_order_id,
          request_id, symbol, role);
    } catch (std::exception const &ex) {
      error = ex.what();
      return false;
    }
    std::string const command = active
                                    ? GatewayProtocolCodec::encode_signed_cancel(msg_b64)
                                    : GatewayProtocolCodec::encode_signed_conditional_cancel(msg_b64);
    if (!send_text_message(command, active ? "signed_cancel" : "signed_conditional_cancel")) [[unlikely]] {
      error = "failed to send conditional cancellation";
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      last_error_.clear();
      last_notice_ = "sent TP/SL cancel id=" + std::to_string(external_order_id);
    }
    notify_ui();
    return true;
  }

  bool submit_cancel(uint64_t subaccount_id, uint64_t external_order_id, std::string &error) override {
    uint64_t request_id = 0;
    uint32_t symbol = 0;
    api_client::OrderRole role = api_client::OrderRole::Maker;
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (phase_ != SessionPhase::Running) {
        error = "session is not ready for orders";
        return false;
      }
      if (connection_status_ != "connected") {
        error = "websocket is not connected";
        return false;
      }
      if (auth_status_ != "authenticated") {
        error = "wallet is not authenticated";
        return false;
      }
      if (!account_state_.find_working_order_cancel_info(subaccount_id, external_order_id, symbol, role)) {
        error = "working order not found";
        return false;
      }
      request_id = allocate_request_id_locked();
      if (request_id == 0) {
        error = "failed to allocate request id";
        return false;
      }
    }
    std::string msg_b64;
    try {
      msg_b64 = ApiClientSigner::build_signed_cancel_proof_base64(
          wallet_keypair_, config_.partition_id, subaccount_id, external_order_id, request_id, symbol, role);
    } catch (std::exception const &ex) {
      error = ex.what();
      return false;
    }

    if (!send_text_message(GatewayProtocolCodec::encode_signed_cancel(msg_b64), "signed_cancel")) {
      error = "failed to send signed cancel";
      return false;
    }

    {
      std::lock_guard<std::mutex> lock(mu_);
      last_error_.clear();
      last_notice_ = "sent signed_cancel oid=" + std::to_string(external_order_id);
    }
    notify_ui();
    return true;
  }

  bool submit_modify(uint64_t subaccount_id,
                     UiSnapshot::WorkingOrderRow const &order,
                     uint64_t price,
                     uint64_t qty,
                     std::string &error) override {
    uint64_t request_id = 0;
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (phase_ != SessionPhase::Running) {
        error = "session is not ready for orders";
        return false;
      }
      if (connection_status_ != "connected") {
        error = "websocket is not connected";
        return false;
      }
      if (auth_status_ != "authenticated") {
        error = "wallet is not authenticated";
        return false;
      }
      request_id = allocate_request_id_locked();
      if (request_id == 0) {
        error = "failed to allocate request id";
        return false;
      }
    }

    uint8_t const tif = order.tif == "IOC" ? 0U : 1U;
    api_client::OrderRole const role = order.role == "TAKER" ? api_client::OrderRole::Taker : api_client::OrderRole::Maker;
    bool const is_sell = order.side == "ASK";
    std::string msg_b64;
    try {
      msg_b64 = ApiClientSigner::build_signed_modify_proof_base64(
          wallet_keypair_,
          config_.partition_id,
          subaccount_id,
          order.external_order_id,
          request_id,
          order.original_iat,
          order.client_instruction_id,
          order.symbol,
          role,
          is_sell,
          tif,
          static_cast<uint8_t>(order.order_type),
          order.execution_mode,
          price,
          qty,
          order.delta_ppm);
    } catch (std::exception const &ex) {
      error = ex.what();
      return false;
    }

    if (!send_text_message(GatewayProtocolCodec::encode_signed_modify(msg_b64), "signed_modify")) {
      error = "failed to send signed modify";
      return false;
    }

    {
      std::lock_guard<std::mutex> lock(mu_);
      last_error_.clear();
      last_notice_ = "sent signed_modify oid=" + std::to_string(order.external_order_id);
    }
    notify_ui();
    return true;
  }

  void request_stop() override {
    g_stop_requested.store(true);
    request_exit_loop();
  }

 private:
  struct SymbolBookState {
    market_data::BookSyncEngine maker_engine{};
    market_data::BookSyncEngine taker_engine{};
    std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> maker_book{};
    std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> taker_book{};
    std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> combined_levels{};
    bool maker_synced{false};
    bool taker_synced{false};
    uint64_t highest_seq{0};
    uint64_t highest_unix_ns{0};
    bool has_mark_price{false};
    uint64_t mark_price{0};
    bool has_funding_index{false};
    int64_t funding_index_e8{0};
  };

  mutable std::mutex mu_;
  Config config_;
  wallet_codec::Keypair wallet_keypair_{};
  std::string wallet_pubkey_;
  ix::WebSocket websocket_;
  std::map<uint32_t, SymbolBookState> book_states_{};
  std::map<uint32_t, SymbolView> books_{};
  std::map<uint32_t, MarketInfo> symbology_{};
  int32_t taker_fee_ppm_{0};
  int32_t maker_fee_ppm_{0};
  std::string connection_status_{"idle"};
  std::string auth_status_{"unauthenticated"};
  std::string account_status_{"idle"};
  std::string last_notice_{};
  std::string last_error_{};
  std::string fatal_exit_message_{};
  bool account_stream_started_{false};
  AccountState account_state_{};
  std::vector<std::string> trade_lines_{};
  std::vector<std::string> log_lines_{};
  std::ofstream log_file_{};
  SessionPhase phase_{SessionPhase::Idle};
  bool auth_wallet_ack_received_{false};
  bool market_subscriptions_started_{false};
  uint64_t next_request_id_{0};
  std::map<uint64_t, uint64_t> pending_order_iats_{};
  ftxui::ScreenInteractive *screen_{nullptr};
  std::function<void()> exit_loop_{};
  std::atomic<bool> done_{false};
  std::atomic<bool> error_seen_{false};
  api_client::RunningAvg gateway_rtt_avg_{};
  static constexpr size_t kMaxTradeLines = 200;
  static constexpr size_t kMaxLogLines = 200;

  void open_log_file() {
    log_file_.open(kApiClientLogPath, std::ios::out | std::ios::trunc);
    if (!log_file_.is_open()) {
      throw std::runtime_error("failed to open api_client_log");
    }
  }

  void load_symbology_or_throw() {
    SymbologySnapshot snapshot;
    std::string error;
    if (!api_client::fetch_symbology_snapshot(config_.ws_url, snapshot, error)) {
      throw std::runtime_error("failed to fetch symbology from gateway websocket: " + error);
    }

    if (config_.feed_ids.empty()) {
      config_.feed_ids = active_feed_ids(snapshot);
      if (config_.feed_ids.empty()) {
        throw std::runtime_error("gateway symbology has no active markets");
      }
    } else {
      validate_configured_feed_ids(snapshot);
    }

    {
      std::lock_guard<std::mutex> lock(mu_);
      taker_fee_ppm_ = snapshot.taker_fee_ppm;
      maker_fee_ppm_ = snapshot.maker_fee_ppm;
      symbology_ = std::move(snapshot.markets);
      initialize_books_locked();
      append_log_locked("loaded symbology from gateway websocket");
    }
  }

  static std::vector<uint32_t> active_feed_ids(SymbologySnapshot const &snapshot) {
    std::vector<uint32_t> feed_ids;
    feed_ids.reserve(snapshot.markets.size());
    for (auto const &entry : snapshot.markets) {
      if (entry.second.status == "active") {
        feed_ids.push_back(entry.first);
      }
    }
    return feed_ids;
  }

  void validate_configured_feed_ids(SymbologySnapshot const &snapshot) const {
    for (uint32_t feed_id : config_.feed_ids) {
      auto const it = snapshot.markets.find(feed_id);
      if (it == snapshot.markets.end()) {
        throw std::runtime_error("configured feed_id " + std::to_string(feed_id) + " missing from symbology");
      }
      if (it->second.status != "active") {
        throw std::runtime_error(
            "configured feed_id " + std::to_string(feed_id) + " is not active in symbology");
      }
    }
  }

  void initialize_books_locked() {
    books_.clear();
    book_states_.clear();
    for (uint32_t feed_id : config_.feed_ids) {
      SymbolView view;
      view.feed_id = feed_id;
      apply_market_info(view, find_market_info_locked(feed_id));
      books_.emplace(feed_id, view);
      book_states_.emplace(feed_id, SymbolBookState{});
    }
  }

  MarketInfo const *find_market_info_locked(uint32_t feed_id) const {
    auto const it = symbology_.find(feed_id);
    if (it == symbology_.end()) {
      return nullptr;
    }
    return &it->second;
  }

  std::string format_feed_label_locked(uint32_t feed_id) const {
    MarketInfo const *market = find_market_info_locked(feed_id);
    if (market == nullptr || market->symbol.empty()) {
      return std::to_string(feed_id);
    }
    return std::to_string(feed_id) + "=" + format_market_symbol(*market);
  }

  static void apply_market_info(SymbolView &view, MarketInfo const *market) {
    view.has_symbology = market != nullptr;
    if (market == nullptr) {
      view.symbol.clear();
      view.px_exponent = 0;
      view.size_decimals = 0;
      return;
    }
    view.symbol = format_market_symbol(*market);
    view.px_exponent = market->px_exponent;
    view.size_decimals = market->size_decimals;
  }

  void configure_websocket() {
    websocket_.disablePerMessageDeflate();
    websocket_.disableAutomaticReconnection();
    websocket_.setUrl(config_.ws_url);
    websocket_.setOnMessageCallback(
        std::bind(&ApiClient::handle_websocket_message, this, std::placeholders::_1));
  }

  void append_log_locked(std::string const &line) {
    std::string const timestamped_line = utc_log_timestamp() + " " + line;
    append_bounded_line(log_lines_, kMaxLogLines, timestamped_line);
    if (log_file_.is_open()) {
      log_file_ << timestamped_line << '\n';
      log_file_.flush();
    }
  }

  void log_message(std::string const &line) {
    {
      std::lock_guard<std::mutex> lock(mu_);
      append_log_locked(line);
    }
    notify_ui();
  }

  void handle_websocket_message(ix::WebSocketMessagePtr const &msg) {
    if (msg == nullptr) {
      return;
    }

    if (msg->type == ix::WebSocketMessageType::Open) {
      handle_open();
      return;
    }
    if (msg->type == ix::WebSocketMessageType::Message) {
      handle_text_message(msg->str);
      return;
    }
    if (msg->type == ix::WebSocketMessageType::Error) {
      handle_error(msg->errorInfo.reason);
      return;
    }
    if (msg->type == ix::WebSocketMessageType::Close) {
      handle_close(msg->closeInfo.code, msg->closeInfo.reason);
      return;
    }
  }

  void handle_open() {
    {
      std::lock_guard<std::mutex> lock(mu_);
      connection_status_ = "connected";
      auth_status_ = "authenticating";
      account_status_ = "waiting for auth";
      last_error_.clear();
      last_notice_ = "authenticating wallet";
      account_stream_started_ = false;
      account_state_.reset();
      phase_ = SessionPhase::AwaitingAuthChallenge;
      auth_wallet_ack_received_ = false;
      market_subscriptions_started_ = false;
      gateway_rtt_avg_.reset();
    }
    log_message("websocket open");
    if (!send_auth_wallet_request()) {
      return;
    }
    notify_ui();
  }

  void handle_text_message(std::string const &payload) {
    simdjson::dom::parser parser;
    JsonObject object;
    std::string type;
    if (GatewayProtocolCodec::parse_message_type(payload, parser, object, type)) {
      if (type == "pong") {
        if (handle_pong_message(object)) {
          return;
        }
        log_message("decode failed type=pong payload=" + payload);
        return;
      }
      if (type == "Trade") {
        if (handle_trade_message(object)) {
          return;
        }
        log_message("decode failed type=Trade payload=" + payload);
        return;
      }
      if (GatewayProtocolCodec::should_ignore_payload_type(type)) {
        return;
      }
      if (type != "BookSnapshot" && type != "BookDelta" && type != "stream_reset") {
        log_message("recv type=" + type);
      }
      if (type == "ack") {
        if (handle_ack_message(object)) {
          return;
        }
        log_message("decode failed type=ack payload=" + payload);
      } else if (type == "auth_challenge") {
        if (handle_auth_challenge_message(object)) {
          return;
        }
        log_message("decode failed type=auth_challenge payload=" + payload);
      } else if (type == "auth_expired") {
        if (handle_auth_expired_message(object)) {
          return;
        }
        log_message("decode failed type=auth_expired payload=" + payload);
      } else if (type == "session_preempted") {
        if (handle_session_preempted_message(object)) {
          return;
        }
        log_message("decode failed type=session_preempted payload=" + payload);
      } else if (type == "AccountSnapshot") {
        if (handle_account_snapshot_message(object)) {
          return;
        }
        log_message("decode failed type=AccountSnapshot payload=" + payload);
      } else if (type == "ConditionalApproved" || type == "ConditionalTriggered" ||
                 type == "ConditionalExpired" || type == "ConditionalCancelled" ||
                 type == "ConditionalInvalidated" || type == "ConditionalCompleted") {
        if (handle_conditional_event(object, type)) {
          return;
        }
        log_message("decode failed type=" + type + " payload=" + payload);
      } else if (type == "order_history") {
        if (handle_order_history_message(object)) {
          return;
        }
        log_message("decode failed type=order_history payload=" + payload);
      } else if (type == "OrderAccepted") {
        if (handle_order_accepted_message(object)) {
          return;
        }
        log_message("decode failed type=OrderAccepted payload=" + payload);
      } else if (type == "OrderReject") {
        if (handle_order_reject_message(object)) {
          return;
        }
        if (handle_local_order_reject_message(object)) {
          return;
        }
        log_message("decode failed type=OrderReject payload=" + payload);
      } else if (type == "Fill") {
        if (handle_fill_event(object)) {
          return;
        }
        log_message("decode failed type=Fill payload=" + payload);
      } else if (type == "AdlFailed") {
        if (handle_adl_failed_message(object)) {
          return;
        }
        log_message("decode failed type=AdlFailed payload=" + payload);
      } else if (type == "FillSettled") {
        if (handle_fill_settlement_event(object, false)) {
          return;
        }
        log_message("decode failed type=FillSettled payload=" + payload);
      } else if (type == "FillBusted") {
        if (handle_fill_settlement_event(object, true)) {
          return;
        }
        log_message("decode failed type=FillBusted payload=" + payload);
      } else if (type == "AccountFundingUpdate") {
        if (handle_account_funding_update(object)) {
          return;
        }
        log_message("decode failed type=AccountFundingUpdate payload=" + payload);
      } else if (type == "UserCollateralUpdate") {
        if (handle_user_collateral_update(object)) {
          return;
        }
        log_message("decode failed type=UserCollateralUpdate payload=" + payload);
      } else if (type == "InactivePositionSettlementStatus") {
        if (handle_inactive_position_settlement_status(object)) {
          return;
        }
        log_message("decode failed type=InactivePositionSettlementStatus payload=" + payload);
      } else if (type == "FundingIndex") {
        if (handle_funding_index_message(object)) {
          return;
        }
        log_message("decode failed type=FundingIndex payload=" + payload);
      } else if (type == "CancelAck") {
        if (handle_cancel_ack_event(object)) {
          return;
        }
        log_message("decode failed type=CancelAck payload=" + payload);
      } else if (type == "CancelReject") {
        if (handle_cancel_reject_event(object)) {
          return;
        }
        log_message("decode failed type=CancelReject payload=" + payload);
      } else if (type == "ModifyAck") {
        if (handle_modify_ack_event(object)) {
          return;
        }
        log_message("decode failed type=ModifyAck payload=" + payload);
      } else if (type == "ModifyReject") {
        if (handle_modify_reject_event(object)) {
          return;
        }
        log_message("decode failed type=ModifyReject payload=" + payload);
      } else if (type == "AccountSnapshotError") {
        log_message("recv AccountSnapshotError payload=" + payload);
        {
          std::lock_guard<std::mutex> lock(mu_);
          last_notice_ = truncate_notice(payload);
        }
        notify_ui();
        return;
      }
    }

    market_data::WireMessage msg;
    if (market_data::WireParser::parse(payload, msg)) {
      apply_market_data(msg);
      return;
    }

    {
      std::lock_guard<std::mutex> lock(mu_);
      last_notice_ = truncate_notice(payload);
    }
    log_message("unhandled payload=" + payload);
    notify_ui();
  }

  void handle_error(std::string const &reason) {
    {
      std::lock_guard<std::mutex> lock(mu_);
      connection_status_ = "error";
      last_error_ = reason;
      last_notice_ = "websocket error";
      gateway_rtt_avg_.reset();
      append_log_locked("websocket error: " + reason);
    }
    error_seen_.store(true);
    done_.store(true);
    notify_ui();
    request_exit_loop();
  }

  void handle_close(uint16_t code, std::string const &reason) {
    {
      std::lock_guard<std::mutex> lock(mu_);
      connection_status_ = "closed";
      if (phase_ != SessionPhase::AuthExpired && phase_ != SessionPhase::Failed) {
        auth_status_ = "disconnected";
      }
      last_notice_ = "closed code=" + std::to_string(code) + " reason=" + reason;
      gateway_rtt_avg_.reset();
      append_log_locked("websocket close code=" + std::to_string(code) + " reason=" + reason);
    }
    done_.store(true);
    notify_ui();
    request_exit_loop();
  }

  std::string subscribe_message(uint32_t symbol) const {
    return GatewayProtocolCodec::encode_subscribe_market(symbol);
  }

  std::string subscribe_account_message() const {
    return GatewayProtocolCodec::encode_subscribe_account();
  }

  bool send_text_message(std::string const &payload, std::string const &context) {
    ix::WebSocketSendInfo const info = websocket_.send(payload);
    if (info.success) {
      log_message("send " + context);
      return true;
    }
    handle_error(context + " send failed");
    return false;
  }

  bool send_auth_wallet_request() {
    return send_text_message(GatewayProtocolCodec::encode_auth_wallet(wallet_pubkey_), "auth_wallet");
  }

  bool send_ping_request() {
    uint64_t send_monotonic_ns = 0;
    if (!current_monotonic_ns(send_monotonic_ns)) {
      return false;
    }
    ix::WebSocketSendInfo const info = websocket_.send(
        GatewayProtocolCodec::encode_ping(send_monotonic_ns));
    return info.success;
  }

  bool send_auth_response(AuthChallengeMessage const &challenge) {
    std::string const signature_b64 =
        ApiClientSigner::sign_auth_challenge_base64(challenge.message, wallet_keypair_);
    return send_text_message(
        GatewayProtocolCodec::encode_auth_response(challenge.nonce, signature_b64),
        "auth_response");
  }

  bool send_subscribe_account_request() {
    return send_text_message(subscribe_account_message(), "subscribe_account");
  }

  bool send_order_history_request() {
    return send_text_message(
        GatewayProtocolCodec::encode_get_order_history(kInitialOrderHistoryLimit),
        "get_order_history");
  }

  bool send_resubscribe_market_request(uint32_t symbol) {
    return send_text_message(subscribe_message(symbol), "resubscribe_market");
  }

  void fail_and_exit(std::string const &summary, std::string const &detail) {
    std::string message = summary;
    if (!detail.empty()) {
      message += ": " + detail;
    }

    {
      std::lock_guard<std::mutex> lock(mu_);
      account_status_ = "failed";
      last_error_ = message;
      last_notice_ = summary;
      fatal_exit_message_ = message;
      phase_ = SessionPhase::Failed;
      append_log_locked(message);
    }
    error_seen_.store(true);
    done_.store(true);
    notify_ui();
    request_exit_loop();
  }

  void start_market_subscriptions() {
    std::vector<uint32_t> feed_ids;
    bool start_account_stream = false;
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (market_subscriptions_started_) {
        return;
      }
      market_subscriptions_started_ = true;
      start_account_stream = !account_stream_started_;
      account_stream_started_ = true;
      phase_ = SessionPhase::Running;
      feed_ids = config_.feed_ids;
    }

    if (start_account_stream) {
      if (!send_subscribe_account_request()) {
        return;
      }
      if (!send_order_history_request()) {
        return;
      }
      {
        std::lock_guard<std::mutex> lock(mu_);
        last_notice_ = "subscribed account stream";
      }
      notify_ui();
    }

    for (uint32_t feed_id : feed_ids) {
      if (!send_text_message(subscribe_message(feed_id), "subscribe_market")) {
        return;
      }
      {
        std::lock_guard<std::mutex> lock(mu_);
        last_notice_ = "subscribed feed_id=" + format_feed_label_locked(feed_id);
      }
      notify_ui();
    }
  }

  void resubscribe_market_after_gap(uint32_t feed_id) {
    if (!send_resubscribe_market_request(feed_id)) {
      return;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      last_notice_ = "re-subscribed feed_id=" + format_feed_label_locked(feed_id) + " after book gap";
    }
    notify_ui();
  }

  bool handle_ack_message(JsonObject const &payload) {
    AckMessage ack;
    if (!GatewayProtocolCodec::decode_ack(payload, ack)) {
      return false;
    }

    bool start_subscriptions = false;
    bool notify = false;
    std::string fatal_bootstrap_error;
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (ack.status == "accepted") {
        if (!auth_wallet_ack_received_ &&
            (phase_ == SessionPhase::AwaitingAuthChallenge || phase_ == SessionPhase::AwaitingAuthAck)) {
          auth_wallet_ack_received_ = true;
          last_notice_ = "wallet challenge issued";
          notify = true;
        } else if (phase_ == SessionPhase::AwaitingAuthAck) {
          auth_status_ = "authenticated";
          account_status_ = "subscribing";
          last_error_.clear();
          last_notice_ = "wallet authenticated";
          phase_ = SessionPhase::Running;
          notify = true;
          start_subscriptions = true;
        } else {
          notify = true;
        }
      } else if (ack.status == "rejected" || ack.status == "busy") {
        bool const auth_phase =
            phase_ == SessionPhase::AwaitingAuthChallenge || phase_ == SessionPhase::AwaitingAuthAck;
        if (auth_phase) {
          auth_status_ = ack.status == "busy" ? "busy" : "rejected";
          account_status_ = "blocked";
          last_error_ = "authentication failed: " + ack.reason;
          last_notice_ = "wallet authentication failed";
          phase_ = SessionPhase::Failed;
        } else {
          if (!ack.reason.empty()) {
            last_error_ = ack.reason;
          }
          last_notice_ = "ack " + ack.status;
        }
        notify = true;
      } else {
        last_notice_ = "ack " + ack.status;
        notify = true;
      }
    }

    if (notify) {
      notify_ui();
    }
    if (!fatal_bootstrap_error.empty()) {
      fail_and_exit("account bootstrap failed", fatal_bootstrap_error);
      return true;
    }
    if (start_subscriptions) {
      start_market_subscriptions();
      return true;
    }
    return true;
  }

  bool handle_auth_challenge_message(JsonObject const &payload) {
    AuthChallengeMessage challenge;
    if (!GatewayProtocolCodec::decode_auth_challenge(payload, challenge)) {
      return false;
    }
    if (challenge.wallet_pubkey != wallet_pubkey_) {
      {
        std::lock_guard<std::mutex> lock(mu_);
        auth_status_ = "rejected";
        account_status_ = "blocked";
        last_error_ = "auth challenge wallet mismatch";
        last_notice_ = "wallet authentication failed";
        phase_ = SessionPhase::Failed;
      }
      notify_ui();
      return true;
    }
    if (challenge.has_expires_unix_ms &&
        challenge.expires_unix_ms <= static_cast<uint64_t>(
                                         std::chrono::duration_cast<std::chrono::milliseconds>(
                                             std::chrono::system_clock::now().time_since_epoch())
                                             .count())) {
      {
        std::lock_guard<std::mutex> lock(mu_);
        auth_status_ = "expired";
        account_status_ = "blocked";
        last_error_ = "received expired auth challenge";
        last_notice_ = "wallet authentication failed";
        phase_ = SessionPhase::Failed;
      }
      notify_ui();
      return true;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      auth_status_ = "signing challenge";
      last_notice_ = "signing auth challenge";
      phase_ = SessionPhase::AwaitingAuthAck;
    }
    notify_ui();
    try {
      if (!send_auth_response(challenge)) {
        return true;
      }
    } catch (std::exception const &ex) {
      {
        std::lock_guard<std::mutex> lock(mu_);
        auth_status_ = "failed";
        account_status_ = "blocked";
        last_error_ = ex.what();
        last_notice_ = "wallet authentication failed";
        phase_ = SessionPhase::Failed;
      }
      notify_ui();
      return true;
    }
    return true;
  }

  bool handle_auth_expired_message(JsonObject const &payload) {
    AuthExpiredMessage message;
    if (!GatewayProtocolCodec::decode_auth_expired(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      auth_status_ = "expired";
      last_notice_ = "auth expired: " + message.reason;
      phase_ = SessionPhase::AuthExpired;
    }
    notify_ui();
    return true;
  }

  bool handle_session_preempted_message(JsonObject const &payload) {
    std::string reason;
    if (!dfba::json::extract_json_field(payload, "reason", reason)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      connection_status_ = "preempted";
      auth_status_ = "preempted";
      account_status_ = "preempted";
      last_notice_ = "session preempted: " + reason;
      last_error_.clear();
      phase_ = SessionPhase::Failed;
    }
    notify_ui();
    return true;
  }

  bool handle_pong_message(JsonObject const &payload) {
    PongMessage message;
    if (!GatewayProtocolCodec::decode_pong(payload, message)) {
      return false;
    }

    uint64_t recv_monotonic_ns = 0;
    if (!current_monotonic_ns(recv_monotonic_ns)) {
      return true;
    }
    if (recv_monotonic_ns < message.client_unix_ns) {
      return true;
    }

    {
      std::lock_guard<std::mutex> lock(mu_);
      gateway_rtt_avg_.add_sample(
          static_cast<double>(recv_monotonic_ns - message.client_unix_ns));
    }
    notify_ui();
    return true;
  }

  bool handle_trade_message(JsonObject const &payload) {
    TradeMessage message;
    if (!GatewayProtocolCodec::decode_trade(payload, message)) {
      return false;
    }

    std::string symbol_label;
    bool has_market = false;
    int16_t px_exponent = 0;
    uint8_t size_decimals = 0;
    {
      std::lock_guard<std::mutex> lock(mu_);
      MarketInfo const *market = find_market_info_locked(message.symbol_id);
      if (!message.symbol.empty()) {
        symbol_label = std::to_string(message.symbol_id) + " " + message.symbol;
      } else {
        symbol_label = format_feed_label_locked(message.symbol_id);
      }
      if (market != nullptr) {
        has_market = true;
        px_exponent = market->px_exponent;
        size_decimals = market->size_decimals;
      }
    }

    std::ostringstream out;
    out << "seq=" << message.seq;
    if (message.trade_id != 0) {
      out << " trade=" << message.trade_id;
    }
    out << " sym=" << symbol_label;
    out << " " << message.side;
    out << " qty=" << format_trade_qty(message.qty, has_market, size_decimals);
    out << " px=" << format_trade_price(message.price, has_market, px_exponent);

    {
      std::lock_guard<std::mutex> lock(mu_);
      append_bounded_line(trade_lines_, kMaxTradeLines, out.str());
    }
    notify_ui();
    return true;
  }

  bool handle_account_snapshot_message(JsonObject const &payload) {
    AccountSnapshotMessage message;
    if (!GatewayProtocolCodec::decode_account_snapshot(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      account_state_.apply_snapshot(message, last_notice_);
    }
    notify_ui();
    return true;
  }

  bool handle_conditional_event(JsonObject const &payload, std::string const &type) {
    ConditionalEventMessage message;
    if (!GatewayProtocolCodec::decode_conditional_event(payload, message)) [[unlikely]] {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      account_state_.apply_conditional_event(type, message, last_notice_);
    }
    notify_ui();
    return true;
  }

  bool handle_order_history_message(JsonObject const &payload) {
    OrderHistoryMessage message;
    if (!GatewayProtocolCodec::decode_order_history(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      account_state_.apply_order_history(message, last_notice_);
    }
    notify_ui();
    return true;
  }

  bool handle_order_accepted_message(JsonObject const &payload) {
    OrderAcceptedMessage message;
    if (!GatewayProtocolCodec::decode_order_accepted(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      auto const pending_it = pending_order_iats_.find(message.client_instruction_id);
      if (pending_it != pending_order_iats_.end()) {
        if (message.original_iat == 0) {
          message.original_iat = pending_it->second;
        }
        pending_order_iats_.erase(pending_it);
      }
      account_state_.apply_order_accepted(message, last_notice_);
    }
    notify_ui();
    return true;
  }

  bool handle_order_reject_message(JsonObject const &payload) {
    OrderRejectMessage message;
    if (!GatewayProtocolCodec::decode_order_reject(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      pending_order_iats_.erase(message.client_instruction_id);
      account_state_.apply_order_reject(message, last_notice_);
    }
    notify_ui();
    return true;
  }

  bool handle_local_order_reject_message(JsonObject const &payload) {
    LocalOrderRejectMessage message;
    if (!GatewayProtocolCodec::decode_local_order_reject(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (message.has_client_instruction_id) {
        pending_order_iats_.erase(message.client_instruction_id);
      }
      std::string notice = "order rejected";
      if (message.has_external_order_id) {
        notice += " oid=" + std::to_string(message.external_order_id);
      }
      if (message.has_client_instruction_id) {
        notice += " cid=" + std::to_string(message.client_instruction_id);
      }
      if (!message.reason.empty()) {
        notice += " reason=" + message.reason;
      }
      last_notice_ = truncate_notice(notice);
    }
    notify_ui();
    return true;
  }

  bool handle_fill_event(JsonObject const &payload) {
    FillEventMessage message;
    if (!GatewayProtocolCodec::decode_fill_event(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      (void)account_state_.apply_fill(message, find_market_info_locked(message.symbol), last_notice_, last_error_);
    }
    notify_ui();
    return true;
  }

  bool handle_adl_failed_message(JsonObject const &payload) {
    AdlFailedMessage message;
    if (!GatewayProtocolCodec::decode_adl_failed(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      (void)account_state_.apply_adl_failed(message, last_notice_, last_error_);
    }
    notify_ui();
    return true;
  }

  bool handle_fill_settlement_event(JsonObject const &payload, bool busted) {
    FillSettlementEventMessage message;
    if (!GatewayProtocolCodec::decode_fill_settlement_event(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      MarketInfo const *market = find_market_info_locked(message.symbol);
      bool const ok = busted ? account_state_.apply_fill_busted(message, market, last_notice_, last_error_)
                             : account_state_.apply_fill_settled(message, market, last_notice_, last_error_);
      (void)ok;
    }
    notify_ui();
    return true;
  }

  bool handle_account_funding_update(JsonObject const &payload) {
    AccountFundingUpdateMessage message;
    if (!GatewayProtocolCodec::decode_account_funding_update(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      if (account_state_.apply_account_funding_update(message, last_notice_, last_error_)) {
        apply_funding_index_locked(message.market_id, message.last_funding_index_e8);
      }
    }
    notify_ui();
    return true;
  }

  bool handle_user_collateral_update(JsonObject const &payload) {
    UserCollateralUpdateMessage message;
    if (!GatewayProtocolCodec::decode_user_collateral_update(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      (void)account_state_.apply_user_collateral_update(message, last_notice_, last_error_);
    }
    notify_ui();
    return true;
  }

  bool handle_inactive_position_settlement_status(JsonObject const &payload) {
    InactivePositionSettlementStatusMessage message;
    if (!GatewayProtocolCodec::decode_inactive_position_settlement_status(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      (void)account_state_.apply_inactive_position_settlement_status(
          message, last_notice_, last_error_);
    }
    notify_ui();
    return true;
  }

  bool handle_funding_index_message(JsonObject const &payload) {
    FundingIndexMessage message;
    if (!GatewayProtocolCodec::decode_funding_index(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      size_t updated = 0;
      for (FundingIndexMessage::Entry const &entry : message.entries) {
        if (apply_funding_index_locked(entry.market_id, entry.cum_funding_index_e8)) {
          ++updated;
        }
      }
      last_notice_ = "funding index seq=" + std::to_string(message.seq) +
                     " markets=" + std::to_string(updated);
    }
    notify_ui();
    return true;
  }

  bool apply_funding_index_locked(uint32_t market_id, int64_t funding_index_e8) {
    uint32_t const feed_id = market_id;
    auto state_it = book_states_.find(feed_id);
    auto view_it = books_.find(feed_id);
    if (state_it == book_states_.end() || view_it == books_.end()) {
      return false;
    }
    state_it->second.has_funding_index = true;
    state_it->second.funding_index_e8 = funding_index_e8;
    view_it->second.has_funding_index = true;
    view_it->second.funding_index_e8 = funding_index_e8;
    return true;
  }

  bool handle_cancel_ack_event(JsonObject const &payload) {
    CancelAckEventMessage message;
    if (!GatewayProtocolCodec::decode_cancel_ack_event(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      account_state_.apply_cancel_ack(message, last_notice_);
    }
    notify_ui();
    return true;
  }

  bool handle_cancel_reject_event(JsonObject const &payload) {
    api_client::CancelRejectEventMessage message;
    if (!GatewayProtocolCodec::decode_cancel_reject_event(payload, message)) [[unlikely]] {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      account_state_.apply_cancel_reject(message, last_notice_);
    }
    notify_ui();
    return true;
  }

  bool handle_modify_ack_event(JsonObject const &payload) {
    ModifyAckEventMessage message;
    if (!GatewayProtocolCodec::decode_modify_ack_event(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      account_state_.apply_modify_ack(message, last_notice_);
    }
    notify_ui();
    return true;
  }

  bool handle_modify_reject_event(JsonObject const &payload) {
    ModifyRejectEventMessage message;
    if (!GatewayProtocolCodec::decode_modify_reject_event(payload, message)) {
      return false;
    }
    {
      std::lock_guard<std::mutex> lock(mu_);
      account_state_.apply_modify_reject(message, last_notice_);
    }
    notify_ui();
    return true;
  }

  void apply_market_data(market_data::WireMessage const &msg) {
    market_data::SyncAction action;
    bool notify = false;
    {
      std::lock_guard<std::mutex> lock(mu_);
      SymbolBookState &state = book_states_[msg.feed_id];
      if (msg.type == market_data::WireType::Snapshot || msg.type == market_data::WireType::Delta) {
        state.highest_seq = std::max(state.highest_seq, msg.seq);
        state.highest_unix_ns = std::max(state.highest_unix_ns, msg.unix_ns);
        if (msg.mark_price != 0) {
          state.has_mark_price = true;
          state.mark_price = msg.mark_price;
        }
      }
      action = apply_market_data_to_symbol_book_locked(state, msg);
      MarketInfo const *market = find_market_info_locked(msg.feed_id);
      SymbolView &view = books_[msg.feed_id];
      if (action.type == market_data::SyncActionType::Noop) {
        apply_market_info(view, market);
        view.feed_id = msg.feed_id;
        view.seq = state.highest_seq;
        view.unix_ns = state.highest_unix_ns;
        view.has_mark_price = state.has_mark_price;
        view.mark_price = state.mark_price;
        notify = true;
      } else {
        view = build_symbol_view(msg.feed_id, state, market);
        if (action.type == market_data::SyncActionType::Emit) {
          last_notice_ = "book update feed_id=" + format_feed_label_locked(msg.feed_id);
        } else if (action.type == market_data::SyncActionType::Gap) {
          last_notice_ = "book gap feed_id=" + format_feed_label_locked(msg.feed_id);
        }
        notify = true;
      }
    }
    if (action.type == market_data::SyncActionType::Gap) {
      resubscribe_market_after_gap(msg.feed_id);
      return;
    }
    if (notify) {
      notify_ui();
    }
  }

  static market_data::BookSyncEngine &select_book_engine(
      SymbolBookState &state,
      market_data::BookType book_type) {
    if (book_type == market_data::BookType::Taker) {
      return state.taker_engine;
    }
    return state.maker_engine;
  }

  static std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> &select_leg_book(
      SymbolBookState &state,
      market_data::BookType book_type) {
    if (book_type == market_data::BookType::Taker) {
      return state.taker_book;
    }
    return state.maker_book;
  }

  static bool &select_leg_synced(SymbolBookState &state, market_data::BookType book_type) {
    if (book_type == market_data::BookType::Taker) {
      return state.taker_synced;
    }
    return state.maker_synced;
  }

  static void apply_combined_level_delta(
      std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> &combined_levels,
      uint64_t price,
      uint64_t old_bid_qty,
      uint64_t old_ask_qty,
      uint64_t new_bid_qty,
      uint64_t new_ask_qty) {
    if (old_bid_qty == new_bid_qty && old_ask_qty == new_ask_qty) {
      return;
    }

    auto it = combined_levels.find(price);
    market_data::BookLevel next{};
    if (it != combined_levels.end()) {
      next = it->second;
    } else {
      next.price = price;
    }

    if (new_bid_qty >= old_bid_qty) {
      next.bid_qty += new_bid_qty - old_bid_qty;
    } else {
      next.bid_qty -= old_bid_qty - new_bid_qty;
    }

    if (new_ask_qty >= old_ask_qty) {
      next.ask_qty += new_ask_qty - old_ask_qty;
    } else {
      next.ask_qty -= old_ask_qty - new_ask_qty;
    }

    if (next.bid_qty == 0 && next.ask_qty == 0) {
      if (it != combined_levels.end()) {
        combined_levels.erase(it);
      }
      return;
    }

    if (it != combined_levels.end()) {
      it->second = next;
      return;
    }
    combined_levels.emplace(price, next);
  }

  static void apply_leg_full_book(
      std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> &combined_levels,
      std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> &leg_book,
      std::vector<market_data::BookLevel> const &next_levels) {
    auto prev_it = leg_book.begin();
    size_t next_index = 0;

    while (prev_it != leg_book.end() || next_index < next_levels.size()) {
      bool const have_prev = prev_it != leg_book.end();
      bool const have_next = next_index < next_levels.size();

      if (have_prev && (!have_next || prev_it->first > next_levels[next_index].price)) {
        market_data::BookLevel const &prev_level = prev_it->second;
        apply_combined_level_delta(
            combined_levels,
            prev_level.price,
            prev_level.bid_qty,
            prev_level.ask_qty,
            0,
            0);
        auto erase_it = prev_it;
        ++prev_it;
        leg_book.erase(erase_it);
        continue;
      }

      if (have_next && (!have_prev || next_levels[next_index].price > prev_it->first)) {
        market_data::BookLevel const &next_level = next_levels[next_index];
        apply_combined_level_delta(
            combined_levels,
            next_level.price,
            0,
            0,
            next_level.bid_qty,
            next_level.ask_qty);
        leg_book[next_level.price] = next_level;
        ++next_index;
        continue;
      }

      market_data::BookLevel const &prev_level = prev_it->second;
      market_data::BookLevel const &next_level = next_levels[next_index];
      apply_combined_level_delta(
          combined_levels,
          prev_level.price,
          prev_level.bid_qty,
          prev_level.ask_qty,
          next_level.bid_qty,
          next_level.ask_qty);
      prev_it->second = next_level;
      ++prev_it;
      ++next_index;
    }
  }

  static void apply_leg_level_changes(
      std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> &combined_levels,
      std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> &leg_book,
      std::vector<market_data::BookLevel> const &changed_levels) {
    for (market_data::BookLevel const &level : changed_levels) {
      uint64_t old_bid_qty = 0;
      uint64_t old_ask_qty = 0;
      auto const it = leg_book.find(level.price);
      if (it != leg_book.end()) {
        old_bid_qty = it->second.bid_qty;
        old_ask_qty = it->second.ask_qty;
      }

      apply_combined_level_delta(
          combined_levels,
          level.price,
          old_bid_qty,
          old_ask_qty,
          level.bid_qty,
          level.ask_qty);

      if (level.bid_qty == 0 && level.ask_qty == 0) {
        if (it != leg_book.end()) {
          leg_book.erase(it);
        }
        continue;
      }
      leg_book[level.price] = level;
    }
  }

  static void store_book_update(
      SymbolBookState &state,
      market_data::BookType book_type,
      market_data::BookUpdate update) {
    std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> &leg_book =
        select_leg_book(state, book_type);
    if (update.kind == market_data::BookUpdate::Kind::DeltaLevels) {
      apply_leg_level_changes(state.combined_levels, leg_book, update.levels);
    } else {
      apply_leg_full_book(state.combined_levels, leg_book, update.levels);
    }
    select_leg_synced(state, book_type) = update.synced;
  }

  static void clear_book_update(SymbolBookState &state, market_data::BookType book_type) {
    std::map<uint64_t, market_data::BookLevel, std::greater<uint64_t>> &leg_book =
        select_leg_book(state, book_type);
    apply_leg_full_book(state.combined_levels, leg_book, std::vector<market_data::BookLevel>{});
    select_leg_synced(state, book_type) = false;
  }

  static market_data::SyncAction apply_market_data_to_symbol_book_locked(
      SymbolBookState &state,
      market_data::WireMessage const &msg) {
    market_data::BookSyncEngine &engine = select_book_engine(state, msg.book_type);
    market_data::SyncAction action = engine.handle_message(msg);
    if (action.type == market_data::SyncActionType::Emit) {
      store_book_update(state, msg.book_type, std::move(action.update));
      return action;
    }
    if (action.type == market_data::SyncActionType::Gap) {
      clear_book_update(state, msg.book_type);
      return action;
    }
    return action;
  }

  static SymbolView build_symbol_view(
      uint32_t feed_id,
      SymbolBookState const &state,
      MarketInfo const *market) {
    SymbolView view;
    view.feed_id = feed_id;
    apply_market_info(view, market);
    view.seq = state.highest_seq;
    view.unix_ns = state.highest_unix_ns;
    view.synced = state.maker_synced && state.taker_synced;
    view.has_mark_price = state.has_mark_price;
    view.mark_price = state.mark_price;
    view.has_funding_index = state.has_funding_index;
    view.funding_index_e8 = state.funding_index_e8;

    for (auto it = state.combined_levels.rbegin(); it != state.combined_levels.rend(); ++it) {
      if (it->second.ask_qty == 0) {
        continue;
      }
      if (view.asks.size() >= kLevelsPerSide) {
        break;
      }
      view.asks.push_back(LadderRow{
          it->second.price,
          0.0,
          market == nullptr ? static_cast<double>(it->second.ask_qty)
                            : api_client::qty_utils::qty_to_double(
                                  it->second.ask_qty, market->size_decimals),
      });
    }

    for (auto const &entry : state.combined_levels) {
      market_data::BookLevel const &level = entry.second;
      if (level.bid_qty == 0) {
        continue;
      }
      if (view.bids.size() >= kLevelsPerSide) {
        break;
      }
      view.bids.push_back(LadderRow{
          level.price,
          market == nullptr ? static_cast<double>(level.bid_qty)
                            : api_client::qty_utils::qty_to_double(
                                  level.bid_qty, market->size_decimals),
          0.0,
      });
    }

    market_data::BookLevel const *best_bid = nullptr;
    for (auto const &entry : state.combined_levels) {
      if (entry.second.bid_qty > 0) {
        best_bid = &entry.second;
        break;
      }
    }

    market_data::BookLevel const *best_ask = nullptr;
    for (auto it = state.combined_levels.rbegin(); it != state.combined_levels.rend(); ++it) {
      if (it->second.ask_qty > 0) {
        best_ask = &it->second;
        break;
      }
    }

    if (best_bid != nullptr && best_ask != nullptr) {
      view.has_mid = true;
      view.best_bid_price = best_bid->price;
      view.best_ask_price = best_ask->price;
    }

    return view;
  }

  static std::string truncate_notice(std::string const &payload) {
    if (payload.size() <= 120) {
      return payload;
    }
    return payload.substr(0, 117) + "...";
  }

  uint64_t allocate_request_id_locked() {
    if (next_request_id_ == 0) {
      uint64_t seed = 0;
      if (!current_realtime_ns(seed) || seed == 0) {
        seed = current_system_clock_unix_ns();
      }
      if (seed == 0) {
        return 0;
      }
      next_request_id_ = seed;
      return next_request_id_;
    }
    if (next_request_id_ == std::numeric_limits<uint64_t>::max()) {
      return 0;
    }
    ++next_request_id_;
    return next_request_id_;
  }

  void notify_ui() {
    ftxui::ScreenInteractive *screen = nullptr;
    {
      std::lock_guard<std::mutex> lock(mu_);
      screen = screen_;
    }
    if (screen != nullptr) {
      screen->PostEvent(ftxui::Event::Custom);
    }
  }

  void request_exit_loop() {
    std::function<void()> exit;
    {
      std::lock_guard<std::mutex> lock(mu_);
      exit = exit_loop_;
    }
    if (exit) {
      exit();
    }
  }

  void monitor_shutdown() {
    while (!g_stop_requested.load() && !done_.load()) {
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    request_exit_loop();
  }

  void ping_loop() {
    while (!g_stop_requested.load() && !done_.load()) {
      bool connected = false;
      {
        std::lock_guard<std::mutex> lock(mu_);
        connected = connection_status_ == "connected";
      }
      if (connected) {
        send_ping_request();
      }
      std::this_thread::sleep_for(kPingInterval);
    }
  }

  static bool current_monotonic_ns(uint64_t &out) {
    timespec ts{};
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
      return false;
    }
    out = static_cast<uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<uint64_t>(ts.tv_nsec);
    return true;
  }

  static bool current_realtime_ns(uint64_t &out) {
    timespec ts{};
    if (clock_gettime(CLOCK_REALTIME, &ts) != 0 || ts.tv_sec < 0 || ts.tv_nsec < 0) {
      return false;
    }
    uint64_t const seconds = static_cast<uint64_t>(ts.tv_sec);
    uint64_t const nsec = static_cast<uint64_t>(ts.tv_nsec);
    uint64_t const ns_per_second = 1000000000ULL;
    uint64_t const max_value = std::numeric_limits<uint64_t>::max();
    if (seconds > (max_value - nsec) / ns_per_second) {
      return false;
    }
    out = seconds * ns_per_second + nsec;
    return true;
  }

  static uint64_t current_system_clock_unix_ns() {
    auto const count = std::chrono::duration_cast<std::chrono::nanoseconds>(
                           std::chrono::system_clock::now().time_since_epoch())
                           .count();
    if (count <= 0) {
      return 0;
    }
    return static_cast<uint64_t>(count);
  }
};

void signal_handler(int) {
  g_stop_requested.store(true);
}

void print_usage(char const *argv0) {
  std::cerr << "Usage: " << argv0
            << " --ws <ws://host:port/path|wss://host/path> --keypair <path>"
            << " [--subaccount_id N] [--feed_ids 1,2,...]"
            << " [--partition_id u16]\n"
            << "Default: subscribe to every active market from gateway symbology.\n";
}

std::vector<uint32_t> parse_symbols(std::string const &raw_symbols) {
  std::vector<uint32_t> out;
  std::stringstream stream(raw_symbols);
  std::string token;
  while (std::getline(stream, token, ',')) {
    size_t start = 0;
    while (start < token.size() && std::isspace(static_cast<unsigned char>(token[start])) != 0) {
      ++start;
    }
    size_t end = token.size();
    while (end > start && std::isspace(static_cast<unsigned char>(token[end - 1])) != 0) {
      --end;
    }
    if (start == end) {
      continue;
    }
    unsigned long const value = std::stoul(token.substr(start, end - start));
    if (value == 0UL || value > std::numeric_limits<uint32_t>::max()) {
      throw std::runtime_error("feed_ids must be in [1, 4294967295]");
    }
    out.push_back(static_cast<uint32_t>(value));
  }
  if (out.empty()) {
    throw std::runtime_error("--feed_ids must include at least one id");
  }
  return out;
}

Config parse_args(int argc, char **argv) {
  Config cfg;

  for (int i = 1; i < argc; ++i) {
    std::string_view const arg(argv[i]);
    if (arg == "--ws") {
      if (i + 1 >= argc) {
        throw std::runtime_error("--ws requires a value");
      }
      cfg.ws_url = argv[++i];
      continue;
    }
    if (arg == "--keypair") {
      if (i + 1 >= argc) {
        throw std::runtime_error("--keypair requires a value");
      }
      cfg.keypair_path = argv[++i];
      continue;
    }
    if (arg == "--feed_ids" || arg == "--symbols") {
      if (i + 1 >= argc) {
        throw std::runtime_error("--feed_ids requires a value");
      }
      cfg.feed_ids = parse_symbols(argv[++i]);
      continue;
    }
    if (arg == "--subaccount_id") {
      if (i + 1 >= argc) {
        throw std::runtime_error("--subaccount_id requires a value");
      }
      cfg.subaccount_id = std::stoull(argv[++i]);
      continue;
    }
    if (arg == "--partition_id") {
      if (i + 1 >= argc) {
        throw std::runtime_error("--partition_id requires a value");
      }
      cfg.partition_id = static_cast<uint16_t>(std::strtoul(argv[++i], nullptr, 0));
      continue;
    }
    if (arg == "--help" || arg == "-h") {
      print_usage(argv[0]);
      std::exit(0);
    }
    throw std::runtime_error("unknown argument: " + std::string(arg));
  }

  if (cfg.ws_url.empty()) {
    throw std::runtime_error("--ws is required");
  }
  if (cfg.keypair_path.empty()) {
    throw std::runtime_error("--keypair is required");
  }
  if (cfg.ws_url.rfind("ws://", 0) != 0 &&
      cfg.ws_url.rfind("wss://", 0) != 0) {
    throw std::runtime_error("--ws must use ws:// or wss://");
  }
  return cfg;
}

} // namespace

int main(int argc, char **argv) {
  if (aethon::print_version_if_requested(argc, argv)) {
    return 0;
  }

  try {
    if (sodium_init() < 0) {
      throw std::runtime_error("libsodium initialization failed");
    }

    std::signal(SIGINT, signal_handler);
    std::signal(SIGTERM, signal_handler);

    Config const cfg = parse_args(argc, argv);
    wallet_codec::Keypair const keypair = wallet_codec::WalletCodec::load_keypair(cfg.keypair_path);
    std::string const wallet_pubkey =
        wallet_codec::WalletCodec::encode_base58(keypair.public_key.data(), keypair.public_key.size());

    ApiClient client(cfg, keypair, wallet_pubkey);
    return client.run();
  } catch (std::exception const &ex) {
    std::cerr << "error: " << ex.what() << "\n";
    return 1;
  }
}
