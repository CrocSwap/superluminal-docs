#pragma once

#include <cstdint>
#include <array>
#include <string>
#include <vector>

#include "api_client_types.h"
#include "wallet_codec.h"

namespace api_client {

class ApiClientSigner {
 public:
  static std::string sign_auth_challenge_base64(
      std::string const &message,
      wallet_codec::Keypair const &keypair);

  static std::string build_signed_order_proof_base64(
      wallet_codec::Keypair const &keypair,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t request_id,
      OrderDraft const &draft);

  static std::string build_signed_order_proof_base64_for_sender(
      wallet_codec::Keypair const &signing_keypair,
      std::array<unsigned char, 32> const &sender_pubkey,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t request_id,
      OrderDraft const &draft);

  static std::string build_signed_order_proof_base64_for_sender_at(
      wallet_codec::Keypair const &signing_keypair,
      std::array<unsigned char, 32> const &sender_pubkey,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t request_id,
      uint64_t iat_sec,
      OrderDraft const &draft,
      uint64_t order_expiry_seconds = 0);

  static std::vector<unsigned char> build_signed_order_proof_raw(
      wallet_codec::Keypair const &keypair,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t request_id,
      uint8_t execution_mode,
      OrderDraft const &draft);

  static std::vector<unsigned char> build_signed_order_proof_raw_for_sender(
      wallet_codec::Keypair const &signing_keypair,
      std::array<unsigned char, 32> const &sender_pubkey,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t request_id,
      uint8_t execution_mode,
      OrderDraft const &draft,
      uint64_t order_expiry_seconds = 0);

  static std::string build_signed_cancel_proof_base64(
      wallet_codec::Keypair const &keypair,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t external_order_id,
      uint64_t request_id,
      uint32_t symbol,
      OrderRole role);

  static std::string build_signed_cancel_proof_base64_for_sender(
      wallet_codec::Keypair const &signing_keypair,
      std::array<unsigned char, 32> const &sender_pubkey,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t external_order_id,
      uint64_t request_id,
      uint32_t symbol,
      OrderRole role);

  static std::string build_signed_cancel_proof_base64_for_sender_at(
      wallet_codec::Keypair const &signing_keypair,
      std::array<unsigned char, 32> const &sender_pubkey,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t external_order_id,
      uint64_t request_id,
      uint64_t iat_sec,
      uint32_t symbol,
      OrderRole role);

  static std::string build_signed_modify_proof_base64(
      wallet_codec::Keypair const &keypair,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t external_order_id,
      uint64_t request_id,
      uint64_t original_iat,
      uint64_t original_request_id,
      uint32_t symbol,
      OrderRole role,
      bool is_sell,
      uint8_t tif,
      uint8_t order_type,
      uint8_t execution_mode,
      uint64_t price,
      uint64_t qty,
      int32_t delta_ppm);

  static std::string build_signed_modify_proof_base64_for_sender(
      wallet_codec::Keypair const &signing_keypair,
      std::array<unsigned char, 32> const &sender_pubkey,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t external_order_id,
      uint64_t request_id,
      uint64_t original_iat,
      uint64_t original_request_id,
      uint32_t symbol,
      OrderRole role,
      bool is_sell,
      uint8_t tif,
      uint8_t order_type,
      uint8_t execution_mode,
      uint64_t price,
      uint64_t qty,
      int32_t delta_ppm);

  static std::string build_signed_modify_proof_base64_for_sender_at(
      wallet_codec::Keypair const &signing_keypair,
      std::array<unsigned char, 32> const &sender_pubkey,
      uint16_t partition_id,
      uint64_t subaccount_id,
      uint64_t external_order_id,
      uint64_t request_id,
      uint64_t iat_sec,
      uint64_t original_iat,
      uint64_t original_request_id,
      uint32_t symbol,
      OrderRole role,
      bool is_sell,
      uint8_t tif,
      uint8_t order_type,
      uint8_t execution_mode,
      uint64_t price,
      uint64_t qty,
      int32_t delta_ppm,
      uint64_t order_expiry_seconds);

  static std::string build_signed_create_vault_proof_base64(
      wallet_codec::Keypair const &keypair,
      uint16_t partition_id,
      uint64_t source_subaccount_id,
      uint32_t vault_id,
      uint64_t operation_subaccount_id,
      uint64_t requested_vault_collateral,
      uint64_t vault_creation_fee,
      uint64_t request_id);

  static std::string build_signed_create_vault_proof_base64_for_sender(
      wallet_codec::Keypair const &signing_keypair,
      std::array<unsigned char, 32> const &sender_pubkey,
      uint16_t partition_id,
      uint64_t source_subaccount_id,
      uint32_t vault_id,
      uint64_t operation_subaccount_id,
      uint64_t requested_vault_collateral,
      uint64_t vault_creation_fee,
      uint64_t request_id);
};

} // namespace api_client
