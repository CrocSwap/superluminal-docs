# Superluminal Python Starting Guide

This bundle contains the standalone Python reference client, account-funding
utilities, and generated public API documentation.

Start here:

- `python_gateway_client/docs/index.html`
- `python_gateway_client/funding-tools/README.md`
- `python_gateway_client/README.md`

The Python client installs its pinned runtime dependencies into
`python_gateway_client/.venv` using:

```bash
cd python_gateway_client
./scripts/bootstrap_venv.sh
```

Then run:

```bash
./.venv/bin/sl-tui --version
./.venv/bin/sl-tui --help
```
