# Superluminal Python Reference Client

This directory is self-contained. The local Python environment is created under
`.venv`, and pip's cache is kept under `.pip-cache`.

Exported reference-client bundles are distributed under the MIT License
included in this directory as `LICENSE`.

## Client Install

From this directory:

```bash
./scripts/bootstrap_venv.sh
```

That creates `.venv` locally and installs pinned runtime dependencies from PyPI.
It does not install into system Python.

Confirm the installed client before connecting:

```bash
./.venv/bin/sl-tui --version
```

Run the TUI with:

```bash
./.venv/bin/sl-tui \
  --ws wss://testnet.slx.fi/ws \
  --keypair client_kp.json \
  --feed-id 1 \
  --subaccount 0
```

In Market mode, enter a reference price with 1..1000000 parts-per-million
slippage for a protected order. Leave both fields blank for an unrestricted
market order.

Choose **Reduce only** to submit a reducing order. The TP/SL controls accept
one or both trigger prices and a protected quantity; repeat **Create TP/SL**
to create multiple groups. For parent-fill protection, wait for approval,
enter the group ID, then submit a normal opposite-side parent with quantity
at least the group's. The reusable `GatewayClient` also exposes
`submit_conditional_group`, `submit_conditional_parent`, and
`cancel_conditional_group`.

Exported client archives include a self-contained `deposit:address` command
under `funding-tools`. Run it before starting a Python client if Superluminal
asks you to register an EVM deposit address: a newer authenticated session
preempts the existing one. Request testnet collateral from the Superluminal
team through your onboarding channel. Open `docs/index.html` in the exported
archive for the complete sequence.

## Developer Setup

```bash
./scripts/bootstrap_venv.sh --dev
./scripts/run_checks.sh
```

`--dev` installs pinned runtime dependencies plus developer tools such as
`mypy`, `ruff`, and `build`.

## Repository packaging

This section applies only to a full repository checkout. The packaging script
is omitted from exported client archives because the client does not need it.

Build a zip that contains source and scripts, but not the local `.venv`:

```bash
./scripts/build_client_zip.sh
```

The output is written under `client-dist/`.

The zip also includes generated public HTML under `docs` and the
self-contained deposit-address utility under `funding-tools`.
