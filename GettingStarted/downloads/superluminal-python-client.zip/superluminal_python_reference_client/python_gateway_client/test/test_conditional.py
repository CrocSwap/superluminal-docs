from __future__ import annotations

import base64
import json
import struct
import unittest
from unittest.mock import patch

from nacl.signing import SigningKey

from dfba_client.client import GatewayClient
from dfba_client.codec import decode_gateway_message
from dfba_client.ingestion import IngestionEngine
from dfba_client.signer import Keypair, build_signed_conditional_group_proof_base64
from dfba_client.types import (
    AccountSubaccountRow,
    ClientConfig,
    ConditionalGroupDraft,
    ConditionalGroupRow,
    ExecutionMode,
    MarketInfo,
    OrderDraft,
    OrderMode,
    OrderRole,
    SessionPhase,
    WorkingOrderRow,
)


class ConditionalProofTest(unittest.TestCase):
    def test_immediate_tp_only_proof_has_wire_fields_and_valid_signature(self) -> None:
        keypair = Keypair(SigningKey(bytes(range(1, 33))))
        draft = ConditionalGroupDraft(7, 200_000, True, True, tp_trigger_price=5_100_000, tp_trigger_sources=3)
        with patch("dfba_client.signer.time.time", return_value=1_710_000_000):
            proof = base64.b64decode(build_signed_conditional_group_proof_base64(keypair, 1, 2, 3, draft))
        self.assertEqual(len(proof), 196)
        self.assertEqual(struct.unpack_from("<Q", proof, 50)[0], 1_710_000_000 + draft.expiry_seconds)
        self.assertEqual(struct.unpack_from("<I", proof, 58)[0], 7)
        self.assertEqual(struct.unpack_from("<Q", proof, 62)[0], 200_000)
        self.assertEqual(proof[70:76], bytes((1, 1, 3, 0, 1, 1)))
        self.assertEqual(struct.unpack_from("<Q", proof, 76)[0], 5_100_000)
        self.assertEqual(struct.unpack_from("<Q", proof, 84)[0], 0)
        self.assertEqual(struct.unpack_from("<Q", proof, 92)[0], 3)
        keypair.signing_key.verify_key.verify(b"AETHEON_COND_V1\0" + proof[:100], proof[132:])

    def test_parent_sl_only_and_invalid_leg_pair(self) -> None:
        keypair = Keypair(SigningKey(bytes(range(1, 33))))
        draft = ConditionalGroupDraft(7, 2, False, False, sl_trigger_price=90, sl_trigger_sources=3)
        proof = base64.b64decode(build_signed_conditional_group_proof_base64(keypair, 1, 2, 3, draft))
        self.assertEqual(proof[70:76], bytes((0, 2, 0, 3, 1, 0)))
        with self.assertRaisesRegex(ValueError, "reversed"):
            build_signed_conditional_group_proof_base64(
                keypair, 1, 2, 3,
                ConditionalGroupDraft(7, 2, True, True, 90, 100, 3, 3),
            )


class ConditionalClientTest(unittest.IsolatedAsyncioTestCase):
    async def test_submission_parent_binding_and_cancellation(self) -> None:
        sent: list[dict[str, object]] = []
        config = ClientConfig("ws://local/ws", "unused", (7,), 2)
        client = GatewayClient(config, keypair=Keypair(SigningKey(bytes(range(1, 33)))))
        client.ingestion = IngestionEngine(config, {7: MarketInfo(7, "BTC", "USDC", -2, 5)}, "wallet")
        client.ingestion.phase = SessionPhase.RUNNING
        client.ingestion.connection_status = "connected"
        client.ingestion.auth_status = "authenticated"

        async def sender(payload: str) -> None:
            sent.append(json.loads(payload))

        client.attach_sender(sender)
        await client.submit_conditional_group(ConditionalGroupDraft(7, 2, True, False, 110, 0, 3))
        self.assertEqual(sent[-1]["type"], "signed_conditional_group")
        self.assertEqual(sent[-1]["version"], 1)

        group_id = 9_007_199_254_740_993
        subaccount = AccountSubaccountRow(2)
        subaccount.conditional_groups.append(ConditionalGroupRow(
            group_id, 42, 7, 2, "ASK", "waiting_parent", "parent_fill", 1, 110, 0,
        ))
        client.ingestion.account_state.subaccounts[2] = subaccount
        parent = OrderDraft(7, OrderMode.GTC_LIMIT, OrderRole.MAKER, False, 10, 100)
        await client.submit_conditional_parent(group_id, parent)
        self.assertEqual(sent[-1]["type"], "signed_conditional_parent")
        self.assertEqual(sent[-1]["conditional_group_external_order_id"], str(group_id))
        with self.assertRaisesRegex(ValueError, "qty >="):
            await client.submit_conditional_parent(group_id, OrderDraft(
                7, OrderMode.GTC_LIMIT, OrderRole.MAKER, False, 1, 100,
            ))
        with self.assertRaisesRegex(ValueError, "normal mode"):
            await client.submit_conditional_parent(group_id, OrderDraft(
                7, OrderMode.GTC_LIMIT, OrderRole.MAKER, False, 10, 100,
                execution_mode=ExecutionMode.REDUCE_ONLY,
            ))
        await client.cancel_conditional_group(group_id)
        self.assertEqual(sent[-1]["type"], "signed_conditional_cancel")
        group = subaccount.conditional_groups[0]
        group.state = "triggering"
        group.selected_external_order_id = 202
        subaccount.working_orders.append(WorkingOrderRow(
            202, 43, 1_710_000_000, 7, "ASK", "TAKER", "GTC", 110, 2, 2, 4,
        ))
        await client.cancel_conditional_group(group_id)
        self.assertEqual(sent[-1]["type"], "signed_cancel")

    async def test_snapshot_and_lifecycle_reconcile_group(self) -> None:
        config = ClientConfig("ws://local/ws", "unused", (7,), 2)
        engine = IngestionEngine(config, {}, "wallet")
        snapshot = decode_gateway_message(json.dumps({
            "type": "AccountSnapshot", "last_seq": 10,
            "subaccounts": [{"subaccount_id": 2, "working_orders": [{
                "external_order_id": 300, "client_instruction_id": "301",
                "symbol": 7, "side": "ASK", "role": "TAKER", "tif": "GTC",
                "price": 110, "original_qty": 2, "remaining_qty": 2,
                "execution_mode": 4,
            }], "conditional_groups": [{
                "version": 1, "activation_mode": "parent_fill", "group_external_order_id": 101,
                "client_instruction_id": "9007199254740993", "symbol": 7, "qty": 2,
                "side": "ASK", "state": "waiting_parent", "leg_flags": 1,
                "tp_trigger_price": 110,
            }]}],
        }))
        engine.apply(snapshot)
        group = engine.snapshot().subaccounts[0].conditional_groups[0]
        self.assertEqual(group.client_instruction_id, 9_007_199_254_740_993)
        self.assertEqual(group.state, "waiting_parent")
        self.assertEqual(engine.snapshot().subaccounts[0].working_orders[0].execution_mode, 4)

        triggered = decode_gateway_message(json.dumps({
            "type": "ConditionalTriggered", "version": 1, "seq": 11,
            "subaccount_id": 2, "group_external_order_id": 101,
            "selected_leg": 1, "selected_external_order_id": 202,
        }))
        engine.apply(triggered)
        group = engine.snapshot().subaccounts[0].conditional_groups[0]
        self.assertEqual((group.state, group.selected_external_order_id), ("triggering", 202))
        completed = decode_gateway_message(json.dumps({
            "type": "ConditionalCompleted", "version": 1, "seq": 12,
            "subaccount_id": 2, "group_external_order_id": 101,
        }))
        engine.apply(completed)
        self.assertEqual(engine.snapshot().subaccounts[0].conditional_groups, [])

    async def test_approval_creates_group_and_unsupported_version_is_rejected(self) -> None:
        config = ClientConfig("ws://local/ws", "unused", (7,), 2)
        engine = IngestionEngine(config, {}, "wallet")
        approval = {
            "type": "ConditionalApproved", "version": 1, "seq": 20,
            "subaccount_id": 2, "group_external_order_id": 101,
            "client_instruction_id": "9007199254740993", "symbol": 7,
            "qty": 2, "side": "ASK", "state": "waiting_parent",
            "activation_mode": "parent_fill", "leg_flags": 1,
            "tp_trigger_price": 110,
        }
        engine.apply(decode_gateway_message(json.dumps(approval)))
        group = engine.snapshot().subaccounts[0].conditional_groups[0]
        self.assertEqual((group.state, group.qty), ("waiting_parent", 2))
        approval["version"] = 2
        with self.assertRaisesRegex(ValueError, "unsupported conditional event version"):
            decode_gateway_message(json.dumps(approval))
