from __future__ import annotations

import unittest

from dfba_client.codec import decode_gateway_message
from dfba_client.commands import (
    encode_signed_create_vault,
    encode_signed_deposit_vault,
    encode_signed_transfer_subaccount,
    encode_signed_withdraw_vault,
    encode_user_deposit_address,
)
from dfba_client.messages import (
    AccountFundingUpdateMessage,
    AccountSnapshotErrorMessage,
    AccountSnapshotMessage,
    AckMessage,
    AdlStatusMessage,
    BookSnapshotMessage,
    CancelAckMessage,
    CreateVaultStatusMessage,
    DepositVaultStatusMessage,
    FillMessage,
    ModifyAckMessage,
    OrderAcceptedMessage,
    OrderRejectMessage,
    TransferSubaccountStatusMessage,
    UnknownMessage,
    UserCollateralUpdateMessage,
    UserDepositAddressStatusMessage,
    VaultOperationStatusMessage,
    WithdrawStatusMessage,
)
from dfba_client.types import BookType, DecodeError


class CodecTest(unittest.TestCase):
    def test_adl_settled_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"type":"AdlSettled","seq":123,"subaccount_id":7,"role":"target",'
            '"client_instruction_id":"41","external_order_id":42,"request_seq":100,'
            '"operation_nonce":101,"batch_id":9,"market_id":3,"price":95000,'
            '"qty":10,"allocated_loss":5000,"counterparty_subaccount_id":8,'
            '"status":2,"error_code":0,"onchain_signature":"sig"}'
        )
        self.assertIsInstance(msg, AdlStatusMessage)
        assert isinstance(msg, AdlStatusMessage)
        self.assertEqual(msg.message_type, "AdlSettled")
        self.assertEqual(msg.role, "target")
        self.assertEqual(msg.market_id, 3)
        self.assertEqual(msg.qty, 10)
        self.assertEqual(msg.allocated_loss, 5000)
        self.assertEqual(msg.onchain_signature, "sig")

    def test_adl_failed_decoder_preserves_detailed_errors(self) -> None:
        msg = decode_gateway_message(
            '{"type":"AdlFailed","seq":124,"subaccount_id":8,"role":"counterparty",'
            '"market_id":3,"price":95000,"qty":10,"error_code":6087,'
            '"workflow_error_code":20005,"cleanup_error_code":20007,"failure_stage":5,'
            '"error_domain":"svm","error":"AdlCounterpartyMaintenanceBreach",'
            '"error_message":"counterparty below maintenance"}'
        )
        self.assertIsInstance(msg, AdlStatusMessage)
        assert isinstance(msg, AdlStatusMessage)
        self.assertEqual(msg.message_type, "AdlFailed")
        self.assertEqual(msg.role, "counterparty")
        self.assertEqual(msg.error_code, 6087)
        self.assertEqual(msg.workflow_error_code, 20005)
        self.assertEqual(msg.cleanup_error_code, 20007)
        self.assertEqual(msg.failure_stage, 5)
        self.assertEqual(msg.error, "AdlCounterpartyMaintenanceBreach")

    def test_ack_decoder_reads_reason_and_order_ids(self) -> None:
        msg = decode_gateway_message(
            '{"type":"ack","status":"rejected","reason":"risk_rejected",'
            '"client_instruction_id":"12","external_order_id":34}'
        )
        self.assertIsInstance(msg, AckMessage)
        assert isinstance(msg, AckMessage)
        self.assertEqual(msg.status, "rejected")
        self.assertEqual(msg.reason, "risk_rejected")
        self.assertEqual(msg.client_instruction_id, 12)
        self.assertEqual(msg.external_order_id, 34)

    def test_ack_decoder_rejects_unstable_order_identifier_types(self) -> None:
        with self.assertRaisesRegex(DecodeError, "client_instruction_id must be a decimal string"):
            decode_gateway_message(
                '{"type":"ack","status":"rejected",'
                '"client_instruction_id":12,"external_order_id":34}'
            )
        with self.assertRaisesRegex(DecodeError, "external_order_id must be an integer"):
            decode_gateway_message(
                '{"type":"ack","status":"rejected",'
                '"client_instruction_id":"12","external_order_id":"34"}'
            )

    def test_ack_decoder_accepts_full_range_decimal_client_instruction_id(self) -> None:
        msg = decode_gateway_message(
            '{"type":"ack","status":"rejected",'
            '"client_instruction_id":"9223372036854775814",'
            '"external_order_id":123456}'
        )
        self.assertIsInstance(msg, AckMessage)
        assert isinstance(msg, AckMessage)
        self.assertEqual(msg.client_instruction_id, 9_223_372_036_854_775_814)
        self.assertEqual(msg.external_order_id, 123_456)

    def test_signed_create_vault_encoder_uses_live_gateway_command(self) -> None:
        self.assertEqual(encode_signed_create_vault("abc"), '{"type":"signed_create_vault","msg_b64":"abc"}')

    def test_signed_deposit_vault_encoder_uses_live_gateway_command(self) -> None:
        self.assertEqual(encode_signed_deposit_vault("abc"), '{"type":"signed_deposit_vault","msg_b64":"abc"}')

    def test_signed_withdraw_vault_encoder_uses_live_gateway_command(self) -> None:
        self.assertEqual(encode_signed_withdraw_vault("abc"), '{"type":"signed_withdraw_vault","msg_b64":"abc"}')

    def test_signed_transfer_subaccount_encoder_uses_live_gateway_command(self) -> None:
        self.assertEqual(
            encode_signed_transfer_subaccount("abc"),
            '{"type":"signed_transfer_subaccount","msg_b64":"abc"}',
        )

    def test_user_deposit_address_encoder_uses_live_gateway_command(self) -> None:
        self.assertEqual(
            encode_user_deposit_address(7),
            '{"type":"user_deposit_address","subaccount_id":7}',
        )

    def test_create_vault_status_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"type":"CreateVaultStatus","client_instruction_id":"77",'
            '"source_subaccount_id":1,"operation_subaccount_id":2,'
            '"vault_id":3,"status":0,"error_code":0,"total_vault_shares":123456}'
        )
        self.assertIsInstance(msg, CreateVaultStatusMessage)
        assert isinstance(msg, CreateVaultStatusMessage)
        self.assertEqual(msg.vault_id, 3)
        self.assertEqual(msg.total_vault_shares, 123456)

    def test_deposit_vault_status_decoder_accepts_zero_source_subaccount(self) -> None:
        msg = decode_gateway_message(
            '{"type":"DepositVaultStatus","client_instruction_id":"77",'
            '"source_subaccount_id":0,"vault_account_pubkey":"vault",'
            '"deposit_amount":1000,"status":0,"error_code":0}'
        )
        self.assertIsInstance(msg, DepositVaultStatusMessage)
        assert isinstance(msg, DepositVaultStatusMessage)
        self.assertEqual(msg.source_subaccount_id, 0)
        self.assertEqual(msg.deposit_amount, 1000)
        self.assertEqual(msg.insurance_payback, 0)
        self.assertEqual(msg.actual_deposit, 1000)

    def test_vault_operation_status_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"type":"VaultOperationSubaccountCollateralChange","client_instruction_id":"77",'
            '"subaccount_id":2,"source_subaccount_id":0,"destination_subaccount_id":3,'
            '"operation_subaccount_id":9,"operation_subaccount_pubkey":"op",'
            '"vault_account_pubkey":"vault","participant_account_pubkey":"participant",'
            '"deposit_amount":1000,"minted_vault_shares":900,'
            '"requested_vault_shares":100,"actual_withdraw_amount":95,'
            '"leader_fee_amount":5,"previous_total_vault_shares":10000,'
            '"total_vault_shares":10900,"status":0,"error_code":0,'
            '"batch_id":8,"term":2}'
        )
        self.assertIsInstance(msg, VaultOperationStatusMessage)
        assert isinstance(msg, VaultOperationStatusMessage)
        self.assertEqual(msg.source_subaccount_id, 0)
        self.assertEqual(msg.destination_subaccount_id, 3)
        self.assertEqual(msg.operation_subaccount_id, 9)
        self.assertEqual(msg.deposit_amount, 1000)
        self.assertEqual(msg.minted_vault_shares, 900)
        self.assertEqual(msg.requested_vault_shares, 100)
        self.assertEqual(msg.actual_withdraw_amount, 95)
        self.assertEqual(msg.leader_fee_amount, 5)
        self.assertEqual(msg.total_vault_shares, 10900)

    def test_transfer_subaccount_status_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"type":"TransferSubaccountStatus","client_instruction_id":"77",'
            '"source_subaccount_id":1,"target_subaccount_id":2,'
            '"transfer_amount":123456,"status":0,"error_code":0,"batch_id":99}'
        )
        self.assertIsInstance(msg, TransferSubaccountStatusMessage)
        assert isinstance(msg, TransferSubaccountStatusMessage)
        self.assertEqual(msg.source_subaccount_id, 1)
        self.assertEqual(msg.target_subaccount_id, 2)
        self.assertEqual(msg.transfer_amount, 123456)
        self.assertEqual(msg.batch_id, 99)

    def test_vault_and_transfer_status_decoders_accept_string_client_instruction_id(self) -> None:
        request_id = "9223372036854775814"
        create = decode_gateway_message(
            '{"type":"CreateVaultStatus","client_instruction_id":"' + request_id + '",'
            '"source_subaccount_id":1,"operation_subaccount_id":2,'
            '"vault_id":3,"status":0,"error_code":0}'
        )
        withdraw = decode_gateway_message(
            '{"type":"WithdrawVaultStatus","client_instruction_id":"' + request_id + '",'
            '"subaccount_id":2,"source_subaccount_id":0,"destination_subaccount_id":3,'
            '"operation_subaccount_id":2,"vault_account_pubkey":"vault",'
            '"status":0,"error_code":0}'
        )
        transfer = decode_gateway_message(
            '{"type":"TransferSubaccountStatus","client_instruction_id":"' + request_id + '",'
            '"source_subaccount_id":1,"target_subaccount_id":2,'
            '"transfer_amount":123456,"status":0,"error_code":0}'
        )
        for message in (create, withdraw, transfer):
            self.assertEqual(message.client_instruction_id, int(request_id))

    def test_order_accepted_decoder_uses_stable_order_identifier_types(self) -> None:
        request_id = "9223372036854775814"
        msg = decode_gateway_message(
            '{"type":"OrderAccepted","seq":1,"subaccount_id":2,'
            '"external_order_id":123456,'
            '"client_instruction_id":"' + request_id + '",'
            '"symbol":3,"side":"BID","role":"TAKER","tif":"IOC","qty":4}'
        )
        self.assertIsInstance(msg, OrderAcceptedMessage)
        assert isinstance(msg, OrderAcceptedMessage)
        self.assertEqual(msg.client_instruction_id, int(request_id))
        self.assertEqual(msg.external_order_id, 123_456)

    def test_decoder_rejects_decimal_strings_for_non_identifier_fields(self) -> None:
        with self.assertRaisesRegex(DecodeError, "seq must be an integer"):
            decode_gateway_message(
                '{"type":"Trade","seq":"1","trade_id":2,"price":3,"qty":4,'
                '"id":5,"symbol":"BTC","side":"BID"}'
            )

    def test_identifier_decoder_rejects_non_decimal_string(self) -> None:
        with self.assertRaisesRegex(DecodeError, "client_instruction_id must be a decimal string"):
            decode_gateway_message(
                '{"type":"CreateVaultStatus","client_instruction_id":"one",'
                '"source_subaccount_id":1,"operation_subaccount_id":2,'
                '"vault_id":3,"status":0,"error_code":0}'
            )

    def test_user_collateral_update_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"seq":72,"type":"UserCollateralUpdate","subaccount_id":7,'
            '"collateral_delta":1000,"collateral_balance":9000,'
            '"actual_deposit":1000,"total_deposit":1000,"insurance_payback":0,"fee":1}'
        )
        self.assertIsInstance(msg, UserCollateralUpdateMessage)
        assert isinstance(msg, UserCollateralUpdateMessage)
        self.assertEqual(msg.subaccount_id, 7)
        self.assertEqual(msg.collateral_delta, 1000)
        self.assertEqual(msg.collateral_balance, 9000)
        self.assertEqual(msg.total_deposit, 1000)
        self.assertEqual(msg.fee, 1)

    def test_user_deposit_address_status_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"seq":73,"type":"UserDepositAddressStatus","subaccount_id":7,'
            '"client_unix_ns":123,"gateway_recv_unix_ns":456,"sequencer_recv_unix_ns":789}'
        )
        self.assertIsInstance(msg, UserDepositAddressStatusMessage)
        assert isinstance(msg, UserDepositAddressStatusMessage)
        self.assertEqual(msg.subaccount_id, 7)
        self.assertEqual(msg.gateway_recv_unix_ns, 456)

    def test_withdraw_status_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"seq":73,"type":"WithdrawStatus","client_instruction_id":"77",'
            '"subaccount_id":7,"requested_withdraw_amount":1000,'
            '"actual_withdraw_amount":1000,"status":0,"error_code":0,'
            '"batch_id":9,"term":2,"onchain_signature":"abc"}'
        )
        self.assertIsInstance(msg, WithdrawStatusMessage)
        assert isinstance(msg, WithdrawStatusMessage)
        self.assertEqual(msg.client_instruction_id, 77)
        self.assertEqual(msg.subaccount_id, 7)
        self.assertEqual(msg.requested_withdraw_amount, 1000)
        self.assertEqual(msg.actual_withdraw_amount, 1000)
        self.assertEqual(msg.status, 0)
        self.assertEqual(msg.onchain_signature, "abc")

    def test_account_snapshot_decoder_reads_position_cost_basis(self) -> None:
        msg = decode_gateway_message(
            '{"type":"AccountSnapshot","last_seq":77,"subaccounts":[{"subaccount_id":7,'
            '"collateral_balance":123456789,"accrued_fee":4,"accrued_funding":-25,'
            '"positions":[{"symbol":1,"net_qty":10,"cost_basis":1234560,"realized_pnl":99}],'
            '"working_orders":[],"filled_orders":[]}],'
            '"vault_accounts":[{"vault_account_pubkey":"vault","vault_id":3,"operation_subaccount_id":7,'
            '"leader_source_subaccount_id":0,"collateral_amount":123456789,'
            '"total_vault_shares":120000000,"last_seq":76}]}'
        )
        self.assertIsInstance(msg, AccountSnapshotMessage)
        assert isinstance(msg, AccountSnapshotMessage)
        self.assertEqual(msg.last_seq, 77)
        self.assertEqual(msg.subaccounts[0].collateral_balance, 123456789)
        self.assertEqual(msg.subaccounts[0].accrued_fee, 4)
        self.assertEqual(msg.subaccounts[0].accrued_funding, -25)
        self.assertEqual(msg.subaccounts[0].positions[0].cost_basis, 1234560)
        self.assertEqual(msg.subaccounts[0].positions[0].realized_pnl, 99)
        self.assertEqual(len(msg.vault_accounts), 1)
        self.assertEqual(msg.vault_accounts[0].vault_id, 3)
        self.assertEqual(msg.vault_accounts[0].operation_subaccount_id, 7)

    def test_account_snapshot_decoder_accepts_missing_account_arrays(self) -> None:
        msg = decode_gateway_message(
            '{"type":"AccountSnapshot","last_seq":77,'
            '"subaccounts":[{"subaccount_id":7,"collateral_balance":123456789}]}'
        )
        self.assertIsInstance(msg, AccountSnapshotMessage)
        assert isinstance(msg, AccountSnapshotMessage)
        self.assertEqual(msg.subaccounts[0].collateral_balance, 123456789)
        self.assertEqual(msg.subaccounts[0].positions, ())
        self.assertEqual(msg.subaccounts[0].working_orders, ())
        self.assertEqual(msg.subaccounts[0].filled_orders, ())

    def test_book_snapshot_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"type":"BookSnapshot","seq":101,"bookType":"maker","id":7,"symbol":"BTC",'
            '"book_cursor":5000,"matcher_unix_ns":171,"bids":[{"price":100,"qty":5}],'
            '"asks":[{"price":101,"qty":3}]}'
        )
        self.assertIsInstance(msg, BookSnapshotMessage)
        assert isinstance(msg, BookSnapshotMessage)
        self.assertEqual(msg.book_type, BookType.MAKER)
        self.assertEqual(msg.bids[0].price, 100)

    def test_order_reject_decoder_reads_notifier_event(self) -> None:
        msg = decode_gateway_message(
            '{"seq":51,"type":"OrderReject","reason":3,"subaccount_id":7,'
            '"external_order_id":88,"client_instruction_id":"99","symbol":1,'
            '"side":"BID","role":"TAKER","tif":"IOC","order_type":1,'
            '"price":12345,"qty":50,"delta_ppm":-7}'
        )
        self.assertIsInstance(msg, OrderRejectMessage)
        assert isinstance(msg, OrderRejectMessage)
        self.assertEqual(msg.reason, 3)
        self.assertEqual(msg.delta_ppm, -7)

    def test_fill_decoder_reads_liquidation_execution_mode(self) -> None:
        msg = decode_gateway_message(
            '{"seq":54,"type":"Fill","subaccount_id":7,"client_instruction_id":"99",'
            '"trade_id":123,"symbol":1,"side":"ASK","role":"TAKER",'
            '"price":12345,"qty":50,"execution_mode":1}'
        )
        self.assertIsInstance(msg, FillMessage)
        assert isinstance(msg, FillMessage)
        self.assertEqual(msg.external_order_id, 0)
        self.assertEqual(msg.execution_mode, 1)

    def test_fill_decoder_reads_finalized_adl_fill(self) -> None:
        msg = decode_gateway_message(
            '{"seq":55,"type":"Fill","reason":1,"subaccount_id":7,'
            '"trade_id":101,"symbol":1,"side":"ASK","role":"target","execution_mode":2,'
            '"price":12345,"qty":50,"request_seq":100,"operation_nonce":101,'
            '"batch_id":9,"allocated_loss":5000,"onchain_signature":"sig",'
            '"counterparty_wallet":[1,2,3,4]}'
        )
        self.assertIsInstance(msg, FillMessage)
        assert isinstance(msg, FillMessage)
        self.assertEqual(msg.external_order_id, 0)
        self.assertEqual(msg.reason, 1)
        self.assertEqual(msg.execution_mode, 2)
        self.assertEqual(msg.role, "target")
        self.assertEqual(msg.operation_nonce, 101)
        self.assertEqual(msg.allocated_loss, 5000)
        self.assertEqual(msg.onchain_signature, "sig")
        self.assertEqual(msg.counterparty_wallet, (1, 2, 3, 4))

    def test_fill_decoder_rejects_invalid_adl_role(self) -> None:
        with self.assertRaises(DecodeError):
            decode_gateway_message(
                '{"seq":55,"type":"Fill","reason":1,"subaccount_id":7,'
                '"symbol":1,"side":"ASK","role":"TAKER","price":12345,"qty":50}'
            )

    def test_optional_event_symbol_range_accepts_uint32(self) -> None:
        order_reject = decode_gateway_message(
            '{"seq":51,"type":"OrderReject","reason":3,"subaccount_id":7,'
            '"external_order_id":88,"symbol":65536}'
        )
        modify_ack = decode_gateway_message(
            '{"seq":52,"type":"ModifyAck","subaccount_id":7,'
            '"external_order_id":88,"symbol":65536,"qty":10}'
        )
        self.assertIsInstance(order_reject, OrderRejectMessage)
        self.assertIsInstance(modify_ack, ModifyAckMessage)
        assert isinstance(order_reject, OrderRejectMessage)
        assert isinstance(modify_ack, ModifyAckMessage)
        self.assertEqual(order_reject.symbol, 65536)
        self.assertEqual(modify_ack.symbol, 65536)

    def test_invalid_integer_type_rejected(self) -> None:
        with self.assertRaises(DecodeError):
            decode_gateway_message('{"type":"pong","client_unix_ns":true}')

    def test_cancel_ack_decoder_reads_reason(self) -> None:
        msg = decode_gateway_message(
            '{"type":"CancelAck","seq":52,"reason":5,"subaccount_id":7,'
            '"external_order_id":88,"client_instruction_id":"99",'
            '"matcher_unix_ns":1003,"sequencer_recv_unix_ns":1001}'
        )
        self.assertIsInstance(msg, CancelAckMessage)
        assert isinstance(msg, CancelAckMessage)
        self.assertEqual(msg.seq, 52)
        self.assertEqual(msg.reason, 5)
        self.assertEqual(msg.subaccount_id, 7)
        self.assertEqual(msg.external_order_id, 88)
        self.assertEqual(msg.client_instruction_id, 99)
        self.assertEqual(msg.matcher_unix_ns, 1003)
        self.assertEqual(msg.sequencer_recv_unix_ns, 1001)

    def test_private_event_malformed_values_rejected_at_decode(self) -> None:
        bad_payloads = (
            '{"type":"CancelAck","seq":0,"subaccount_id":7,"external_order_id":88}',
            '{"type":"CancelReject","seq":1,"subaccount_id":7,"external_order_id":0}',
            '{"type":"ModifyAck","seq":1,"subaccount_id":7,"external_order_id":88,"qty":0}',
            '{"type":"ModifyReject","seq":0,"subaccount_id":7,"external_order_id":88}',
            '{"type":"Fill","seq":1,"subaccount_id":7,"external_order_id":88,'
            '"symbol":1,"side":"NOPE","qty":1}',
            '{"type":"FillSettled","seq":1,"subaccount_id":7,"external_order_id":88,'
            '"symbol":1,"side":"BID","qty":0}',
        )
        for payload in bad_payloads:
            with self.subTest(payload=payload):
                with self.assertRaises(DecodeError):
                    decode_gateway_message(payload)

    def test_account_funding_update_uses_market_id_as_symbol_fallback(self) -> None:
        msg = decode_gateway_message(
            '{"type":"AccountFundingUpdate","seq":1,"subaccount_id":7,"market_id":70000,'
            '"prev_funding_index_e8":5,"last_funding_index_e8":6}'
        )
        self.assertIsInstance(msg, AccountFundingUpdateMessage)
        assert isinstance(msg, AccountFundingUpdateMessage)
        self.assertEqual(msg.market_id, 70000)
        self.assertEqual(msg.symbol, 70000)

    def test_account_funding_update_accepts_uint32_optional_symbol(self) -> None:
        msg = decode_gateway_message(
            '{"type":"AccountFundingUpdate","seq":1,"subaccount_id":7,"market_id":17,'
            '"symbol":65536,"prev_funding_index_e8":5,"last_funding_index_e8":6}'
        )
        self.assertIsInstance(msg, AccountFundingUpdateMessage)
        assert isinstance(msg, AccountFundingUpdateMessage)
        self.assertEqual(msg.market_id, 17)
        self.assertEqual(msg.symbol, 65536)

    def test_account_funding_update_decodes_malformed_semantic_event_like_cpp(self) -> None:
        msg = decode_gateway_message(
            '{"type":"AccountFundingUpdate","seq":0,"subaccount_id":7,"market_id":0,'
            '"prev_funding_index_e8":5,"last_funding_index_e8":5}'
        )
        self.assertIsInstance(msg, AccountFundingUpdateMessage)
        assert isinstance(msg, AccountFundingUpdateMessage)
        self.assertEqual(msg.seq, 0)
        self.assertEqual(msg.market_id, 0)
        self.assertEqual(msg.prev_funding_index_e8, 5)
        self.assertEqual(msg.last_funding_index_e8, 5)

    def test_account_snapshot_error_decoder(self) -> None:
        msg = decode_gateway_message(
            '{"type":"AccountSnapshotError","wallet_pubkey":"wallet","message":"bad snapshot"}'
        )
        self.assertIsInstance(msg, AccountSnapshotErrorMessage)
        assert isinstance(msg, AccountSnapshotErrorMessage)
        self.assertEqual(msg.wallet_pubkey, "wallet")
        self.assertEqual(msg.message, "bad snapshot")

    def test_unknown_decoder_preserves_raw_payload_for_ingestion_notice(self) -> None:
        raw = '{"type":"FutureMessage","field":123}'
        msg = decode_gateway_message(raw)
        self.assertIsInstance(msg, UnknownMessage)
        assert isinstance(msg, UnknownMessage)
        self.assertEqual(msg.message_type, "FutureMessage")
        self.assertEqual(msg.payload, raw)


if __name__ == "__main__":
    unittest.main()
