from __future__ import annotations

import base64
import json
import unittest
from pathlib import Path
from unittest.mock import patch

import base58
from nacl.signing import SigningKey, VerifyKey

from dfba_client.codec import decode_gateway_message
from dfba_client.messages import (
    ModifyAckMessage,
    ModifyRejectMessage,
    OrderAcceptedMessage,
)
from dfba_client.signer import (
    Keypair,
    build_signed_cancel_proof_base64,
    build_signed_order_proof_base64,
    sign_auth_challenge_base64,
)
from dfba_client.types import OrderDraft, OrderMode, OrderRole


def _load_vectors() -> dict[str, object]:
    client_root = Path(__file__).resolve().parents[1]
    source_path = client_root.parent / "documentation/public/conformance/test-vectors.json"
    bundle_path = client_root / "docs/conformance/test-vectors.json"
    path = source_path if source_path.is_file() else bundle_path
    return json.loads(path.read_text(encoding="utf-8"))


class ConformanceVectorsTest(unittest.TestCase):
    def setUp(self) -> None:
        self.vectors = _load_vectors()
        key = self.vectors["test_key"]
        assert isinstance(key, dict)
        self.keypair = Keypair(SigningKey(bytes.fromhex(str(key["seed_hex"]))))
        self.assertEqual(self.keypair.public_key.hex(), key["public_key_hex"])
        self.assertEqual(
            base58.b58encode(self.keypair.public_key).decode("ascii"),
            key["public_key_base58"],
        )

    def test_authentication_signature(self) -> None:
        authentication = self.vectors["authentication"]
        assert isinstance(authentication, dict)
        message = str(authentication["message_utf8"])
        actual = sign_auth_challenge_base64(message, self.keypair)
        self.assertEqual(actual, authentication["signature_base64"])
        signature = base64.b64decode(actual)
        VerifyKey(self.keypair.public_key).verify(
            message.encode("utf-8"), signature
        )

    def test_signed_order(self) -> None:
        vector = self.vectors["signed_order"]
        assert isinstance(vector, dict)
        order = vector["order"]
        assert isinstance(order, dict)
        tif = int(str(order["tif"]))
        order_type = int(str(order["order_type"]))
        self.assertEqual((tif, order_type), (0, 0))
        role = int(str(order["role"]))
        self.assertIn(role, (0, 1))
        side = int(str(order["side"]))
        self.assertIn(side, (0, 1))
        self.assertEqual(int(str(order["execution_mode"])), 0)
        draft = OrderDraft(
            symbol=int(str(order["symbol"])),
            mode=OrderMode.IOC_LIMIT,
            role=OrderRole.TAKER if role == 1 else OrderRole.MAKER,
            is_sell=side == 1,
            qty=int(str(order["qty"])),
            price=int(str(order["price"])),
            delta_ppm=int(str(order["delta_ppm"])),
        )
        with patch("dfba_client.signer.time.time", return_value=int(str(vector["fixed_unix_seconds"]))):
            actual = build_signed_order_proof_base64(
                self.keypair,
                int(str(vector["partition_id"])),
                int(str(vector["subaccount_id"])),
                int(str(vector["request_id64"])),
                draft,
            )
        self.assertEqual(actual, vector["proof_base64"])
        self.assertEqual(len(base64.b64decode(actual)), int(str(vector["proof_length_bytes"])))

    def test_signed_cancel(self) -> None:
        vector = self.vectors["signed_cancel"]
        assert isinstance(vector, dict)
        role = int(str(vector["role"]))
        self.assertIn(role, (0, 1))
        with patch("dfba_client.signer.time.time", return_value=int(str(vector["fixed_unix_seconds"]))):
            actual = build_signed_cancel_proof_base64(
                self.keypair,
                int(str(vector["partition_id"])),
                int(str(vector["subaccount_id"])),
                int(str(vector["external_order_id"])),
                int(str(vector["request_id64"])),
                int(str(vector["symbol"])),
                OrderRole.TAKER if role == 1 else OrderRole.MAKER,
            )
        self.assertEqual(actual, vector["proof_base64"])
        self.assertEqual(len(base64.b64decode(actual)), int(str(vector["proof_length_bytes"])))

    def test_json_identifier_encoding_round_trips_exactly(self) -> None:
        encoding = self.vectors["json_identifier_encoding"]
        assert isinstance(encoding, dict)
        client_id = encoding["client_instruction_id"]
        original_client_id = encoding["original_client_instruction_id"]
        external_id = encoding["external_order_id"]
        assert isinstance(client_id, dict)
        assert isinstance(original_client_id, dict)
        assert isinstance(external_id, dict)
        self.assertIsInstance(client_id["wire_value"], str)
        self.assertIsInstance(original_client_id["wire_value"], str)
        self.assertIsInstance(external_id["wire_value"], int)
        accepted_raw = json.dumps(
            {
                "type": "OrderAccepted",
                "seq": 1,
                "subaccount_id": 0,
                "external_order_id": external_id["wire_value"],
                "client_instruction_id": client_id["wire_value"],
                "symbol": 1,
                "side": "BID",
                "qty": 1,
                "delta_ppm": 0,
            }
        )
        decoded = decode_gateway_message(accepted_raw)
        self.assertIsInstance(decoded, OrderAcceptedMessage)
        assert isinstance(decoded, OrderAcceptedMessage)
        self.assertEqual(
            str(decoded.client_instruction_id),
            client_id["required_decimal_round_trip"],
        )
        self.assertEqual(
            str(decoded.external_order_id),
            external_id["required_decimal_round_trip"],
        )
        modify_raw = json.dumps(
            {
                "type": "ModifyAck",
                "seq": 2,
                "subaccount_id": 0,
                "external_order_id": external_id["wire_value"],
                "client_instruction_id": client_id["wire_value"],
                "original_client_instruction_id": original_client_id["wire_value"],
                "qty": 1,
            }
        )
        modified = decode_gateway_message(modify_raw)
        self.assertIsInstance(modified, ModifyAckMessage)
        assert isinstance(modified, ModifyAckMessage)
        self.assertEqual(
            str(modified.original_client_instruction_id),
            original_client_id["required_decimal_round_trip"],
        )
        modify_reject_raw = json.dumps(
            {
                "type": "ModifyReject",
                "seq": 3,
                "subaccount_id": 0,
                "external_order_id": external_id["wire_value"],
                "client_instruction_id": client_id["wire_value"],
                "original_client_instruction_id": original_client_id["wire_value"],
                "reason": 1,
            }
        )
        rejected = decode_gateway_message(modify_reject_raw)
        self.assertIsInstance(rejected, ModifyRejectMessage)
        assert isinstance(rejected, ModifyRejectMessage)
        self.assertEqual(
            str(rejected.original_client_instruction_id),
            original_client_id["required_decimal_round_trip"],
        )


if __name__ == "__main__":
    unittest.main()
