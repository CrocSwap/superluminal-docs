from __future__ import annotations

import unittest
from dataclasses import replace

from dfba_client.account_state import AccountState
from dfba_client.messages import (
    AccountSnapshotMessage,
    AccountSubaccountMessage,
    AccountWorkingOrderMessage,
    CancelAckMessage,
    FillMessage,
    FillSettlementMessage,
    InactivePositionSettlementStatusMessage,
    ModifyAckMessage,
    ModifyRejectMessage,
    OrderAcceptedMessage,
)
from dfba_client.types import (
    AccountSubaccountRow,
    FilledOrderRow,
    FillReason,
    MarketInfo,
    PositionRow,
    WorkingOrderRow,
)


class AccountStateTest(unittest.TestCase):
    def test_accepted_order_keeps_identity_needed_for_modify(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        state.apply_order_accepted(OrderAcceptedMessage(
            seq=2, subaccount_id=1, external_order_id=88, client_instruction_id=99,
            symbol=7, side="ASK", role="TAKER", tif="GTC", order_type=0,
            price=10_000, qty=100, delta_ppm=0, execution_mode=4,
            original_iat=1_700_000_000,
        ))
        order = state.subaccounts[1].working_orders[0]
        self.assertEqual((order.original_iat, order.client_instruction_id, order.execution_mode),
                         (1_700_000_000, 99, 4))

    def test_snapshot_and_modify_ack_preserve_working_order_shape(self) -> None:
        state = AccountState()
        state.apply_snapshot(AccountSnapshotMessage(last_seq=1, subaccounts=(AccountSubaccountMessage(
            subaccount_id=1, status="active", owe_to_insurance=0, collateral_balance=0,
            accrued_fee=0, accrued_funding=0, positions=(), filled_orders=(),
            working_orders=(AccountWorkingOrderMessage(
                external_order_id=88, client_instruction_id=99, original_iat=1_700_000_000,
                symbol=7, side="ASK", role="TAKER", tif="GTC", order_type=1,
                price=0, original_qty=200, remaining_qty=100, delta_ppm=100,
                execution_mode=4,
            ),),
        ),)))
        order = state.subaccounts[1].working_orders[0]
        self.assertEqual((order.order_type, order.delta_ppm, order.execution_mode), (1, 100, 4))
        state.apply_modify_ack(ModifyAckMessage(
            seq=2, subaccount_id=1, external_order_id=88, client_instruction_id=101,
            symbol=7, price=0, qty=50, delta_ppm=250,
        ))
        self.assertEqual((order.order_type, order.delta_ppm, order.execution_mode), (1, 250, 4))

    def test_clipped_settlement_rebuilds_basis_after_interleaved_provisional_fill(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        subaccount = AccountSubaccountRow(1)
        subaccount.positions.append(PositionRow(7, 1, 100_000_000, 0, 0, 0, 0))
        state.subaccounts[1] = subaccount
        market = MarketInfo(7, "BTC", "USDC", 0, 0)
        for seq, order_id, trade_id, side, price, qty in (
            (2, 10, 30, "ASK", 120, 2),
            (3, 11, 31, "BID", 130, 1),
        ):
            ok, _, error = state.apply_fill(FillMessage(
                seq=seq, subaccount_id=1, external_order_id=order_id,
                client_instruction_id=20, trade_id=trade_id, symbol=7,
                side=side, role="TAKER", price=price, qty=qty, fee=0,
            ), market)
            self.assertTrue(ok, error)

        ok, _, error = state.apply_fill_settled(FillSettlementMessage(
            message_type="FillSettled", seq=4, subaccount_id=1,
            external_order_id=10, trade_id=30, symbol=7, side="ASK",
            price=120, qty=2, fee=0, settled_qty=1, reduced_qty=1,
            applied_fee=0, adjustment_reason="reduce_only",
            reduce_only_leg=True, limiting_leg=True, exhausted_leg=True,
        ), market)
        self.assertTrue(ok, error)
        self.assertEqual(
            (subaccount.positions[0].net_qty, subaccount.positions[0].cost_basis,
             subaccount.positions[0].realized_pnl),
            (1, 130_000_000, 20_000_000),
        )

    def test_settlement_matches_trade_id_when_equal_fills_settle_out_of_order(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        subaccount = AccountSubaccountRow(1)
        subaccount.positions.append(PositionRow(7, 2, 200_000_000, 0, 0, 0, 0))
        state.subaccounts[1] = subaccount
        market = MarketInfo(7, "BTC", "USDC", 0, 0)
        for seq, trade_id in ((2, 30), (3, 31)):
            ok, _, error = state.apply_fill(FillMessage(
                seq=seq, subaccount_id=1, external_order_id=10,
                client_instruction_id=20, trade_id=trade_id, symbol=7,
                side="ASK", role="TAKER", price=120, qty=1, fee=0,
            ), market)
            self.assertTrue(ok, error)

        ok, _, error = state.apply_fill_settled(FillSettlementMessage(
            message_type="FillSettled", seq=4, subaccount_id=1,
            external_order_id=10, trade_id=31, symbol=7, side="ASK",
            price=120, qty=1, fee=0,
        ), market)
        self.assertTrue(ok, error)
        self.assertEqual(
            [(fill.trade_id, fill.settled) for fill in state.recent_fills],
            [(31, True), (30, False)],
        )

    def test_snapshot_pending_fill_bust_does_not_reverse_settled_position(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        subaccount = AccountSubaccountRow(1)
        subaccount.positions.append(PositionRow(7, 1, 100_000_000, 0, 0, 0, 0))
        subaccount.filled_orders.append(FilledOrderRow(88, 99, 7, "BID", 130, 1, 1, 0, 0))
        state.subaccounts[1] = subaccount

        ok, _, error = state.apply_fill_busted(FillSettlementMessage(
            message_type="FillBusted", seq=2, subaccount_id=1,
            external_order_id=88, trade_id=10, symbol=7, side="BID",
            price=130, qty=1, fee=0,
        ), MarketInfo(7, "BTC", "USDC", 0, 0))
        self.assertTrue(ok, error)
        self.assertEqual(
            (subaccount.positions[0].net_qty, subaccount.positions[0].cost_basis),
            (1, 100_000_000),
        )

    def test_settled_notional_rounds_away_from_zero_in_usd_micro_units(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        market = MarketInfo(7, "BTC", "USDC", -8, 8)
        ok, _, error = state.apply_fill(FillMessage(
            seq=2, subaccount_id=1, external_order_id=10,
            client_instruction_id=20, trade_id=30, symbol=7,
            side="BID", role="TAKER", price=1, qty=1, fee=0,
        ), market)
        self.assertTrue(ok, error)
        ok, _, error = state.apply_fill_settled(FillSettlementMessage(
            message_type="FillSettled", seq=3, subaccount_id=1,
            external_order_id=10, trade_id=30, symbol=7,
            side="BID", price=1, qty=1, fee=0,
        ), market)
        self.assertTrue(ok, error)
        self.assertEqual(state.subaccounts[1].positions[0].cost_basis, 1)

    def test_reduce_only_settlement_reverses_clipped_provisional_qty_and_fee(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        subaccount = AccountSubaccountRow(1)
        subaccount.positions.append(PositionRow(7, 2, 200_000_000, 0, 0, 0, 0))
        state.subaccounts[1] = subaccount
        market = MarketInfo(7, "BTC", "USDC", 0, 0)
        ok, _, error = state.apply_fill(FillMessage(
            seq=2, subaccount_id=1, external_order_id=10, client_instruction_id=20,
            trade_id=30, symbol=7, side="ASK", role="TAKER", price=100,
            qty=3, fee=3000, execution_mode=4,
        ), market)
        self.assertTrue(ok, error)
        self.assertEqual(subaccount.positions[0].net_qty, -1)

        ok, _, error = state.apply_fill_settled(FillSettlementMessage(
            message_type="FillSettled", seq=3, subaccount_id=1,
            external_order_id=10, symbol=7, side="ASK", price=100,
            qty=3, fee=3000, settled_qty=2, reduced_qty=1,
            applied_fee=2000, adjustment_reason="reduce_only",
            reduce_only_leg=True, limiting_leg=True, exhausted_leg=True,
        ), market)
        self.assertTrue(ok, error)
        position = subaccount.positions[0]
        self.assertEqual((position.net_qty, position.cost_basis, position.pending_fees),
                         (0, 0, 2000))
        self.assertEqual(subaccount.filled_orders, [])
        self.assertEqual((state.recent_fills[0].settled_qty, state.recent_fills[0].reduced_qty),
                         (2, 1))

    def test_inactive_position_settlement_requires_matching_audit(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=20)
        subaccount = AccountSubaccountRow(7, collateral_balance=1000)
        subaccount.positions.append(PositionRow(1, 10, 100, 0, 0, 0, 0))
        subaccount.positions.append(PositionRow(3, -25, -300, 0, 0, 0, 0))
        state.subaccounts[7] = subaccount
        status = InactivePositionSettlementStatusMessage(
            seq=21,
            subaccount_id=7,
            symbol=3,
            market_id=3,
            position_index=0,
            position_qty=-24,
            workflow_change_count=9,
            status=0,
            error_code=0,
            audit_event_present=True,
            collateral_balance=1234,
            fees_accrued_after=5,
            net_funding_after=-6,
            position_count_after=1,
        )

        ok, _, error = state.apply_inactive_position_settlement_status(status)
        self.assertFalse(ok)
        self.assertEqual(error, "inactive position does not match local state")

        status = replace(status, position_qty=-25)
        ok, notice, error = state.apply_inactive_position_settlement_status(status)
        self.assertTrue(ok)
        self.assertEqual(notice, "inactive position settled sym=3")
        self.assertEqual(error, "")
        self.assertEqual(subaccount.collateral_balance, 1234)
        self.assertEqual(subaccount.accrued_fee, 5)
        self.assertEqual(subaccount.accrued_funding, -6)
        self.assertEqual([position.symbol for position in subaccount.positions], [1])
        self.assertEqual(state.last_seq, 21)

    def test_adl_fill_updates_position_as_finalized_without_pending_order(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        subaccount = AccountSubaccountRow(1)
        subaccount.positions.append(PositionRow(7, 10, 1_000_000_000, 0, 0, 0, 0))
        state.subaccounts[1] = subaccount

        ok, notice, error = state.apply_fill(
            FillMessage(
                seq=2,
                subaccount_id=1,
                external_order_id=0,
                client_instruction_id=0,
                trade_id=99,
                symbol=7,
                side="ASK",
                role="target",
                price=90,
                qty=4,
                reason=int(FillReason.ADL),
            ),
            MarketInfo(7, "BTC", "USDC", 0, 0),
        )

        self.assertTrue(ok)
        self.assertEqual(notice, "ADL fill trade=99 qty=4")
        self.assertEqual(error, "")
        self.assertEqual(subaccount.positions[0].net_qty, 6)
        self.assertEqual(subaccount.positions[0].cost_basis, 600_000_000)
        self.assertEqual(subaccount.positions[0].realized_pnl, -40_000_000)
        self.assertEqual(subaccount.filled_orders, [])
        self.assertTrue(state.recent_fills[0].settled)

    def test_fill_busted_reverses_original_fill_side(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        subaccount = AccountSubaccountRow(1)
        subaccount.positions.append(PositionRow(7, 7, 0, 0, 0, 0, 0))
        state.subaccounts[1] = subaccount
        market = MarketInfo(7, "BTC", "USDC", 0, 0)
        ok, _, error = state.apply_fill(FillMessage(
            seq=2, subaccount_id=1, external_order_id=88,
            client_instruction_id=99, trade_id=100, symbol=7,
            side="BID", role="TAKER", price=100, qty=3, fee=0,
        ), market)
        self.assertTrue(ok, error)
        self.assertEqual(subaccount.positions[0].net_qty, 10)

        ok, notice, error = state.apply_fill_busted(
            FillSettlementMessage(
                message_type="FillBusted",
                seq=3,
                subaccount_id=1,
                external_order_id=88,
                trade_id=100,
                symbol=7,
                side="BID",
                price=100,
                qty=3,
                fee=0,
            ),
            market,
        )

        self.assertTrue(ok)
        self.assertEqual(notice, "fill busted oid=88 qty=3")
        self.assertEqual(error, "")
        self.assertEqual(subaccount.positions[0].net_qty, 7)
        self.assertEqual(subaccount.filled_orders, [])

    def test_fill_settled_updates_last_price(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        subaccount = AccountSubaccountRow(1)
        subaccount.filled_orders.append(FilledOrderRow(88, 99, 7, "BID", 100, 10, 3, 7, 0))
        state.subaccounts[1] = subaccount

        ok, notice, error = state.apply_fill_settled(
            FillSettlementMessage(
                message_type="FillSettled",
                seq=2,
                subaccount_id=1,
                external_order_id=88,
                symbol=7,
                side="BID",
                price=105,
                qty=2,
                fee=0,
            )
        )

        self.assertTrue(ok)
        self.assertEqual(notice, "fill settled oid=88 qty=2")
        self.assertEqual(error, "")
        self.assertEqual(subaccount.filled_orders[0].last_price, 105)

    def test_modify_reject_notice_matches_cpp(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)

        notice = state.apply_modify_reject(
            ModifyRejectMessage(
                seq=2,
                subaccount_id=1,
                external_order_id=88,
                client_instruction_id=99,
                reason=7,
            )
        )

        self.assertEqual(notice, "modify rejected oid=88 reason=7")

    def test_cancel_ack_names_order_expired_reason(self) -> None:
        state = AccountState(has_snapshot=True, last_seq=1)
        subaccount = AccountSubaccountRow(1)
        subaccount.working_orders.append(
            WorkingOrderRow(88, 99, 1_700_000_000, 7, "BID", "MAKER", "GTC", 100, 10, 10)
        )
        state.subaccounts[1] = subaccount

        notice = state.apply_cancel_ack(
            CancelAckMessage(
                seq=2,
                subaccount_id=1,
                external_order_id=88,
                client_instruction_id=99,
                reason=5,
            )
        )

        self.assertEqual(notice, "cancel ack oid=88 reason=order_expired code=5")
        self.assertEqual(subaccount.working_orders, [])

    def test_snapshot_preserves_collateral_balance(self) -> None:
        state = AccountState()

        notice = state.apply_snapshot(
            AccountSnapshotMessage(
                last_seq=7,
                subaccounts=(
                    AccountSubaccountMessage(
                        subaccount_id=1,
                        status="active",
                        owe_to_insurance=0,
                        collateral_balance=123456789,
                        accrued_fee=0,
                        accrued_funding=0,
                        positions=(),
                        working_orders=(),
                        filled_orders=(),
                    ),
                ),
            )
        )

        self.assertEqual(notice, "account snapshot seq=7")
        self.assertEqual(state.subaccounts[1].collateral_balance, 123456789)


if __name__ == "__main__":
    unittest.main()
