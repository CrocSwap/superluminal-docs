from __future__ import annotations

import asyncio
import contextlib
import io
import queue
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from textual.app import App

from dfba_client.tui.app import (
    SocketWorker,
    StopIntent,
    SubmitOrderIntent,
    _build_conditional_group_draft,
    _build_modify_intent,
    _build_order_draft,
    _fill_status,
    _fill_summary,
    _format_mid_price,
    _format_position_pnl,
    _format_price,
    _order_preview,
    _parse_args,
    _run_tui,
    _visible_books,
)
from dfba_client.types import (
    UINT64_MAX,
    AccountSubaccountRow,
    ClientConfig,
    ExecutionMode,
    FillRow,
    MarketInfo,
    OrderDraft,
    OrderMode,
    OrderRole,
    PositionRow,
    SymbolView,
    UiSnapshot,
    WorkingOrderRow,
)


class WebsocketErrorClient:
    def __init__(self) -> None:
        self.recorded_errors: list[str] = []
        self._snapshot = UiSnapshot(connection_status="error", last_error="signed_order send failed")

    async def submit_order(self, _draft: OrderDraft) -> None:
        raise RuntimeError("socket down")

    def has_websocket_error(self) -> bool:
        return True

    def record_error(self, error: str) -> None:
        self.recorded_errors.append(error)

    def snapshot(self) -> UiSnapshot:
        return self._snapshot


class TuiAppHelperTest(unittest.TestCase):
    def test_modify_button_opens_editor_and_queues_intent(self) -> None:
        queued_worker: list[SocketWorker] = []

        def start(worker: SocketWorker) -> None:
            queued_worker.append(worker)
            subaccount = AccountSubaccountRow(1)
            subaccount.working_orders.append(WorkingOrderRow(
                88, 99, 1_700_000_000, 7, "ASK", "TAKER", "GTC",
                10_000, 200, 100, 4, 0, 0,
            ))
            worker._publish(UiSnapshot(
                account_stream_started=True, has_account_snapshot=True,
                books=(SymbolView(feed_id=7, symbol="BTC", px_exponent=-2,
                                  size_decimals=2, has_symbology=True),),
                subaccounts=(subaccount,),
            ))

        def run_smoke(app: App[None]) -> None:
            async def check() -> None:
                async with app.run_test() as pilot:
                    app.refresh_snapshot()  # type: ignore[attr-defined]
                    await pilot.pause()
                    await pilot.click("#modify_1_88")
                    self.assertTrue(app.query_one("#modify-editor").display)
                    app.query_one("#modify-value").value = "101"  # type: ignore[attr-defined]
                    app.query_one("#modify-qty").value = "0.5"  # type: ignore[attr-defined]
                    await pilot.click("#apply-modify")
                    await pilot.pause()
                    self.assertEqual(app.status.snapshot.last_error, "")  # type: ignore[attr-defined]
                    self.assertFalse(app.query_one("#modify-editor").display)
                    intent = queued_worker[0]._intent_queue.get_nowait()
                    self.assertEqual((intent.price, intent.qty), (10_100, 50))  # type: ignore[attr-defined]

            asyncio.run(check())

        config = ClientConfig("ws://local/ws", "unused", (7,), 1)
        with patch.object(SocketWorker, "start", start), patch.object(SocketWorker, "stop"), patch.object(App, "run", run_smoke):
            _run_tui(config)

    def test_modify_editor_keeps_order_mode_and_rejects_size_increase(self) -> None:
        order = WorkingOrderRow(88, 99, 1_700_000_000, 7, "ASK", "TAKER", "GTC",
                                10_000, 200, 100, 4, 0, 0)
        snap = UiSnapshot(books=(SymbolView(feed_id=7, symbol="BTC", px_exponent=-2,
                                            size_decimals=2, has_symbology=True),))
        intent = _build_modify_intent(snap, 1, order, "101", "0.5")
        self.assertEqual((intent.price, intent.qty, intent.delta_ppm), (10_100, 50, 0))
        self.assertEqual(intent.order.execution_mode, 4)
        with self.assertRaisesRegex(ValueError, "remaining"):
            _build_modify_intent(snap, 1, order, "101", "1.01")

    def test_mark_to_mid_modify_uses_delta_and_rejects_ioc(self) -> None:
        order = WorkingOrderRow(88, 99, 1_700_000_000, 7, "BID", "MAKER", "GTC",
                                0, 200, 100, 0, 1, 100)
        snap = UiSnapshot(books=(SymbolView(feed_id=7, symbol="BTC", px_exponent=-2,
                                            size_decimals=2, has_symbology=True),))
        intent = _build_modify_intent(snap, 1, order, "250", "0.5")
        self.assertEqual((intent.price, intent.qty, intent.delta_ppm), (0, 50, 250))
        order.tif = "IOC"
        with self.assertRaisesRegex(ValueError, "GTC"):
            _build_modify_intent(snap, 1, order, "250", "0.5")

    def test_tui_mounts_tp_sl_and_reduce_only_controls(self) -> None:
        def run_smoke(app: App[None]) -> None:
            async def check() -> None:
                async with app.run_test():
                    for selector in (
                        "#execution-options", "#create-group", "#submit-parent", "#cancel-group",
                    ):
                        self.assertIsNotNone(app.query_one(selector))

            asyncio.run(check())

        config = ClientConfig("ws://local/ws", "unused", (7,), 0)
        with patch.object(SocketWorker, "start"), patch.object(SocketWorker, "stop"), patch.object(App, "run", run_smoke):
            _run_tui(config)

    def test_ticket_builds_independent_tp_groups_and_reduce_only_order(self) -> None:
        app = SimpleNamespace(
            symbol=SimpleNamespace(value="7"),
            qty=SimpleNamespace(value="2"),
            price=SimpleNamespace(value="100"),
            delta=SimpleNamespace(value=""),
            side=SimpleNamespace(value="SELL"),
            role=SimpleNamespace(value="TAKER"),
            mode=SimpleNamespace(value="LIMIT"),
            tp_price=SimpleNamespace(value="110"),
            sl_price=SimpleNamespace(value=""),
            activation_index=0,
            selected_execution_mode=lambda: ExecutionMode.REDUCE_ONLY,
        )
        snap = UiSnapshot(books=(SymbolView(
            feed_id=7, symbol="BTC/USDC", px_exponent=-2,
            size_decimals=5, has_symbology=True, tick_size=5,
        ),))
        order = _build_order_draft(app, snap)
        self.assertEqual(order.execution_mode, ExecutionMode.REDUCE_ONLY)
        first = _build_conditional_group_draft(app, snap)
        self.assertEqual((first.qty, first.tp_trigger_price, first.sl_trigger_price), (200_000, 11_000, 0))
        app.qty.value = "3"
        app.tp_price.value = "120"
        second = _build_conditional_group_draft(app, snap)
        self.assertEqual((second.qty, second.tp_trigger_price), (300_000, 12_000))
        app.tp_price.value = "120.01"
        with self.assertRaisesRegex(ValueError, "market grid"):
            _build_conditional_group_draft(app, snap)

    def test_version_reports_aethon_version_and_source_commit(self) -> None:
        output = io.StringIO()
        with patch("sys.argv", ["sl-tui", "--version"]), contextlib.redirect_stdout(output):
            with self.assertRaises(SystemExit) as raised:
                _parse_args()

        self.assertEqual(raised.exception.code, 0)
        self.assertRegex(
            output.getvalue(),
            r"^sl-tui version \d+\.\d+\.\d+ commit [0-9a-f]{12}\n$",
        )

    def test_order_ticket_parses_decimal_qty_and_snaps_limit_price(self) -> None:
        app = SimpleNamespace(
            symbol=SimpleNamespace(value="7"),
            qty=SimpleNamespace(value="0.001"),
            price=SimpleNamespace(value="1000.00000015"),
            delta=SimpleNamespace(value=""),
            side=SimpleNamespace(value="BUY"),
            role=SimpleNamespace(value="MAKER"),
            mode=SimpleNamespace(value="LIMIT"),
        )
        snap = UiSnapshot(
            books=(
                SymbolView(
                    feed_id=7,
                    symbol="BTC/USDC",
                    px_exponent=-8,
                    size_decimals=5,
                    has_symbology=True,
                ),
            )
        )
        draft = _build_order_draft(app, snap)
        self.assertEqual(draft.symbol, 7)
        self.assertEqual(draft.mode, OrderMode.GTC_LIMIT)
        self.assertEqual(draft.role, OrderRole.MAKER)
        self.assertEqual(draft.qty, 100)
        self.assertEqual(draft.price, 100_000_000_000)

    def test_order_ticket_builds_protected_and_unrestricted_market_orders(self) -> None:
        snap = UiSnapshot(
            books=(
                SymbolView(
                    feed_id=7,
                    symbol="BTC/USDC",
                    px_exponent=-2,
                    size_decimals=5,
                    has_symbology=True,
                ),
            )
        )
        cases = (
            ("", "", 0, 0),
            ("100.50", "10000", 10_050, 10_000),
            ("100.50", "1000000", 10_050, 1_000_000),
        )
        for price, delta, expected_price, expected_delta in cases:
            with self.subTest(price=price, delta=delta):
                app = SimpleNamespace(
                    symbol=SimpleNamespace(value="7"),
                    qty=SimpleNamespace(value="0.001"),
                    price=SimpleNamespace(value=price),
                    delta=SimpleNamespace(value=delta),
                    side=SimpleNamespace(value="BUY"),
                    role=SimpleNamespace(value="TAKER"),
                    mode=SimpleNamespace(value="MARKET"),
                )
                draft = _build_order_draft(app, snap)
                self.assertEqual(draft.mode, OrderMode.MARKET)
                self.assertEqual(draft.role, OrderRole.TAKER)
                self.assertEqual(draft.price, expected_price)
                self.assertEqual(draft.delta_ppm, expected_delta)

        protected_app = SimpleNamespace(
            symbol=SimpleNamespace(value="7"),
            qty=SimpleNamespace(value="0.001"),
            price=SimpleNamespace(value="100.50"),
            delta=SimpleNamespace(value="10000"),
            side=SimpleNamespace(value="BUY"),
            role=SimpleNamespace(value="TAKER"),
            mode=SimpleNamespace(value="MARKET"),
        )
        self.assertIn(
            "market ref@100.50 slippage=10000 ppm",
            _order_preview(protected_app, snap),
        )

    def test_order_ticket_rejects_invalid_market_slippage(self) -> None:
        snap = UiSnapshot(
            books=(
                SymbolView(
                    feed_id=7,
                    symbol="BTC/USDC",
                    px_exponent=-2,
                    size_decimals=5,
                    has_symbology=True,
                ),
            )
        )
        cases = (
            ("", "1", "market order slippage requires a reference price"),
            ("100", "-1", "slippage must be a nonnegative integer ppm value"),
            ("100", "0", "market order reference price requires non-zero slippage"),
            ("100", "1000001", "slippage must not exceed 1000000 ppm"),
        )
        for price, delta, error in cases:
            with self.subTest(price=price, delta=delta):
                app = SimpleNamespace(
                    symbol=SimpleNamespace(value="7"),
                    qty=SimpleNamespace(value="0.001"),
                    price=SimpleNamespace(value=price),
                    delta=SimpleNamespace(value=delta),
                    side=SimpleNamespace(value="SELL"),
                    role=SimpleNamespace(value="TAKER"),
                    mode=SimpleNamespace(value="MARKET"),
                )
                with self.assertRaisesRegex(ValueError, error):
                    _build_order_draft(app, snap)

    def test_price_formatting_matches_cpp_visible_decimals(self) -> None:
        market = MarketInfo(7, "BTC", "USDC", -8, 5)
        self.assertEqual(_format_price(7_091_400_000_000, market), "70914.00")
        self.assertEqual(_format_mid_price(10_001, 10_002, -2), "100.015")

    def test_mid_and_position_pnl_overflow_match_cpp_na(self) -> None:
        market = MarketInfo(7, "BTC", "USDC", 0, 0)
        position = PositionRow(7, UINT64_MAX, 0, 0, 0, 0, 0)
        book = SymbolView(
            feed_id=7,
            px_exponent=0,
            size_decimals=0,
            has_symbology=True,
            has_mid=True,
            best_bid_price=UINT64_MAX,
            best_ask_price=1,
        )
        self.assertEqual(_format_mid_price(UINT64_MAX, 1, 0), "n/a")
        self.assertEqual(_format_position_pnl(position, book, market), "n/a")

    def test_visible_books_are_not_capped_to_three(self) -> None:
        snap = UiSnapshot(
            books=tuple(SymbolView(feed_id=feed_id) for feed_id in (1, 2, 3, 4))
        )

        self.assertEqual(tuple(book.feed_id for book in _visible_books(snap)), (1, 2, 3, 4))

    def test_recent_fill_helpers_split_execution_and_settlement(self) -> None:
        market = MarketInfo(7, "BTC", "USDC", -8, 5)
        fill = FillRow(
            seq=12,
            trade_id=34,
            subaccount_id=1,
            client_instruction_id=56,
            external_order_id=78,
            symbol=7,
            side="BUY",
            role="MAKER",
            price=7_645_000_000_000,
            qty=100,
            order_settled_qty=100,
            settle_delta_ns=1_250_000,
            has_order_settled_qty=True,
            has_settle_delta_ns=True,
            settled=True,
        )

        self.assertEqual(
            _fill_summary(fill, market),
            "seq=12 trade=34 oid=78 cid=56 sym=7 BTC/USDC BUY role=MAKER qty=0.001 px=76450.00",
        )
        self.assertEqual(
            _fill_status(fill, market),
            "settle=settled dt=1.25 ms order_settled_qty=0.001",
        )


class TuiSocketWorkerTest(unittest.IsolatedAsyncioTestCase):
    async def test_intent_pump_does_not_overwrite_websocket_send_error(self) -> None:
        snapshot_queue: queue.Queue[UiSnapshot] = queue.Queue(maxsize=2)
        intent_queue: queue.Queue[object] = queue.Queue(maxsize=2)
        config = ClientConfig(
            ws_url="ws://127.0.0.1:8080/ws",
            keypair_path="unused.json",
            feed_ids=(7,),
            subaccount_id=1,
        )
        worker = SocketWorker(config, snapshot_queue, intent_queue)  # type: ignore[arg-type]
        client = WebsocketErrorClient()
        intent_queue.put_nowait(
            SubmitOrderIntent(OrderDraft(7, OrderMode.GTC_LIMIT, OrderRole.MAKER, False, 1, 100))
        )
        intent_queue.put_nowait(StopIntent())

        await worker._pump_intents(client)  # type: ignore[arg-type]
        snapshot = snapshot_queue.get_nowait()

        self.assertEqual(client.recorded_errors, [])
        self.assertEqual(snapshot.last_error, "signed_order send failed")


if __name__ == "__main__":
    unittest.main()
