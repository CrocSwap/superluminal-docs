#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CLIENT_DIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"
VENV_DIR="${CLIENT_DIR}/.venv"
REQUIREMENTS="${CLIENT_DIR}/requirements.txt"
export PIP_CACHE_DIR="${CLIENT_DIR}/.pip-cache"

if [[ "${1:-}" == "--dev" ]]; then
  REQUIREMENTS="${CLIENT_DIR}/requirements-dev.txt"
  shift
fi
if [[ "$#" -gt 1 ]]; then
  echo "usage: $0 [--dev] [python-executable]" >&2
  exit 2
fi
PYTHON_BIN="${1:-python3}"

if [[ ! -d "${VENV_DIR}" ]]; then
  "${PYTHON_BIN}" -m venv "${VENV_DIR}"
fi

cd "${CLIENT_DIR}"
"${VENV_DIR}/bin/python" -m pip install -r "${REQUIREMENTS}"

echo "venv: ${VENV_DIR}"
echo "python: ${VENV_DIR}/bin/python"
echo "tui: ${VENV_DIR}/bin/sl-tui"
