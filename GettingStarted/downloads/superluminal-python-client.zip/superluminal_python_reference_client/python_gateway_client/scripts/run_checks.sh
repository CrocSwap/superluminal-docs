#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CLIENT_DIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"
PYTHON_BIN="${CLIENT_DIR}/.venv/bin/python"

if [[ ! -x "${PYTHON_BIN}" ]]; then
  echo "missing ${PYTHON_BIN}" >&2
  echo "run ./scripts/bootstrap_venv.sh --dev first" >&2
  exit 1
fi

PYTHONPATH="${CLIENT_DIR}" "${PYTHON_BIN}" -m unittest discover -s "${CLIENT_DIR}/test"
PYTHONPATH="${CLIENT_DIR}" "${PYTHON_BIN}" -m mypy --config-file "${CLIENT_DIR}/pyproject.toml" "${CLIENT_DIR}/dfba_client"
"${PYTHON_BIN}" -m ruff check "${CLIENT_DIR}/dfba_client" "${CLIENT_DIR}/test"
