#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
from decimal import Decimal, InvalidOperation

import websockets

from dfba_client import commands
from dfba_client.codec import decode_gateway_message
from dfba_client.messages import AckMessage, AuthChallengeMessage, TransferSubaccountStatusMessage
from dfba_client.signer import (
    build_signed_transfer_subaccount_proof_base64,
    load_keypair,
    sign_auth_challenge_base64,
)
from dfba_client.types import DecodeError

AMOUNT_SCALE = Decimal(1_000_000)
MAX_U64 = Decimal(2**64 - 1)


def parse_human_amount(value: str) -> int:
    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise argparse.ArgumentTypeError("amount must be a decimal number") from exc
    if not amount.is_finite() or amount <= 0:
        raise argparse.ArgumentTypeError("amount must be positive")
    raw = amount * AMOUNT_SCALE
    if raw != raw.to_integral_value():
        raise argparse.ArgumentTypeError("amount supports at most 6 decimal places")
    if raw > MAX_U64:
        raise argparse.ArgumentTypeError("amount is too large")
    return int(raw)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Submit signed_transfer_subaccount to a gateway WebSocket"
    )
    parser.add_argument(
        "--ws-url", required=True, help="Gateway WebSocket URL, for example ws://127.0.0.1:8080/ws"
    )
    parser.add_argument(
        "--keypair", required=True, help="Solana keypair JSON for the wallet signer"
    )
    parser.add_argument("--partition-id", type=lambda value: int(value, 0), required=True)
    parser.add_argument("--source-subaccount-id", type=lambda value: int(value, 0), required=True)
    parser.add_argument("--target-subaccount-id", type=lambda value: int(value, 0), required=True)
    parser.add_argument(
        "--amount",
        type=parse_human_amount,
        required=True,
        help="Human decimal amount, scaled by 10^6",
    )
    parser.add_argument("--request-id", type=lambda value: int(value, 0), required=True)
    parser.add_argument("--auth-expiry-seconds", type=int, default=300)
    return parser.parse_args()


async def main_async() -> int:
    args = parse_args()
    keypair = load_keypair(args.keypair)
    proof_b64 = build_signed_transfer_subaccount_proof_base64(
        keypair,
        args.partition_id,
        args.source_subaccount_id,
        args.target_subaccount_id,
        args.amount,
        args.request_id,
    )

    async with websockets.connect(args.ws_url) as ws:
        await ws.send(
            commands.encode_auth_wallet(keypair.public_key_base58, args.auth_expiry_seconds)
        )
        raw = await ws.recv()
        msg = decode_gateway_message(raw)
        if not isinstance(msg, AuthChallengeMessage):
            print("failed")
            return 1

        sig_b64 = sign_auth_challenge_base64(msg.message, keypair)
        await ws.send(commands.encode_auth_response(msg.nonce, sig_b64))
        raw = await ws.recv()
        ack = decode_gateway_message(raw)
        if not isinstance(ack, AckMessage) or ack.status != "accepted":
            print("failed")
            return 1

        await ws.send(commands.encode_subscribe_account())
        raw = await ws.recv()
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = {}
        if payload.get("type") == "ack" and payload.get("status") != "accepted":
            print("failed")
            return 3

        await ws.send(commands.encode_signed_transfer_subaccount(proof_b64))
        while True:
            raw = await ws.recv()
            try:
                message = decode_gateway_message(raw)
            except DecodeError:
                continue
            if (
                isinstance(message, TransferSubaccountStatusMessage)
                and message.client_instruction_id == args.request_id
            ):
                ok = message.status == 0 and message.error_code == 0
                if ok:
                    print("success")
                else:
                    print(f"failed error_code={message.error_code}")
                return 0 if ok else 2
            if isinstance(message, AckMessage) and message.status != "accepted":
                print("failed")
                return 3


def main() -> None:
    try:
        raise SystemExit(asyncio.run(main_async()))
    except Exception as exc:
        print("failed")
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
