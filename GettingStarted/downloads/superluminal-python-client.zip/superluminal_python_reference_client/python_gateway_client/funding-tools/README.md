# Superluminal Deposit-Address Utility

This directory contains the source for the deposit-address utility. It runs on
Linux, macOS, and Windows with Bun 1.3.14 or newer. No private key leaves the
local machine.

Install runtime dependencies:

```bash
bun install --production --frozen-lockfile
```

Request testnet collateral from the Superluminal team through the channel used
to onboard you. Provide your public Fogo wallet address and subaccount ID, not
your keypair. If asked to register an EVM deposit address, print it with:

```bash
bun run deposit:address --help
```

See `../docs/index.html` for the complete public documentation.
