import type { Dnum } from "dnum";

// A single settled funding event for the authenticated account, as returned by
// the gateway's `get_funding_history`.  Funding is exchanged periodically
// between longs and shorts; each event applies a `payment` for one market and
// advances the account's cumulative funding for that market.
//
// `id` is the gateway's `stream_seq` -- monotonic per account, so it doubles as
// the stable React key and the sort/dedup key the notifier paginates by.
//
// `payment` is the funding applied at this event (`funding_delta`) and `accrued`
// is the running cumulative funding for the market after it (`funding_accrued`).
// Both are signed USDC amounts carried as Dnum -- positive means the account
// received funding, negative means it paid -- so consumers format them like any
// other USDC value.
export type FundingEvent = {
  id: bigint;
  subaccountId: bigint;
  symbol: string;
  symbolId: number;
  timestamp: Date;
  payment: Dnum;
  accrued: Dnum;
};

export type FundingHistoryPage = {
  nextCursor: string | undefined;
  events: FundingEvent[];
};
