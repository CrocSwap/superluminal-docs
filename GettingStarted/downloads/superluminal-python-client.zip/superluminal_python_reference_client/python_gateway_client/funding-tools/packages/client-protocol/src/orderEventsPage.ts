import type { OrderEvent } from "./order";

// A page of an order's persisted lifecycle events, fetched on demand via the
// gateway's `get_order_events` command.  The flattened `get_order_history`
// page no longer inlines per-order events; consumers that want the full
// lifecycle (the widget's "Show Activity" panel) fetch it here keyed by
// `externalOrderId` + `marketId`.  `nextCursor` is `undefined` on the last
// page; pass it back verbatim to page older.  Events are newest-first by
// stream seq, matching the gateway's ordering.
export type OrderEventsPage = {
  externalOrderId: bigint;
  marketId: number;
  nextCursor: string | undefined;
  events: OrderEvent[];
};
