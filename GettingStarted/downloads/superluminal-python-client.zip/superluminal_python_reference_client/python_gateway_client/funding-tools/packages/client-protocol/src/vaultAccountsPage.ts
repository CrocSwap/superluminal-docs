import type { Dnum } from "dnum";

// Latest persisted performance snapshot for a vault, joined onto the vault
// listing by the notifier.  `totalVaultShares` and `totalEquity` are both
// 6-decimal quantities (shares are minted 1:1 with collateral at vault
// creation, per `contracts/svm/src/lib.rs`'s `create_vault`, and equity is
// USDC); `leaderSharePercentage` is the leader's ownership share of the vault
// (their shares as a percentage of the total), forwarded from the gateway as a
// decimal string and parsed here to a `Dnum` percentage.
export type VaultAccountPerf = {
  datetime: Date;
  totalVaultShares: Dnum;
  totalEquity: Dnum;
  leaderSharePercentage: Dnum;
};

// One vault as returned by the gateway's `get_vault_accounts` query.  The
// public listing carries the vault's on-chain identity (`vaultAccountPubkey`
// is what a `signed_deposit_vault` / `signed_withdraw_vault` targets), its
// leader, the operation subaccount collateral flows through, and the latest
// performance row when the notifier has one (`undefined` for a freshly created
// vault with no persisted perf yet).
export type VaultAccount = {
  vaultAccountId: bigint;
  vaultAccountPubkey: string;
  leaderPubkey: string;
  operationSubaccountPubkey: string;
  latestPerf: VaultAccountPerf | undefined;
  // When the vault was created, surfaced as its "age" in the catalog.  Mapped
  // from the gateway's `creation_dt`; `undefined` when the gateway doesn't send
  // it (an older deploy) or reports it as unknown.
  inceptionDate?: Date | undefined;
};

// A single page of the paginated `get_vault_accounts` response.  `nextCursor`
// is `undefined` on the last page, matching `OrderHistoryPage`.
export type VaultAccountsPage = {
  nextCursor: string | undefined;
  vaults: VaultAccount[];
};
