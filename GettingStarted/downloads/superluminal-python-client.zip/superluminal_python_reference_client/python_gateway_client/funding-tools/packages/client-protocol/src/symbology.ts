import { z } from "zod";

// Symbology snapshots and updates are delivered on the gateway WebSocket.

export const symbologyMarketSchema = z.object({
  change_count: z.number().default(0),
  id: z.number(),
  initial_margin_bps: z.number(),
  maintenance_margin_bps: z.number(),
  px_exponent: z.number(),
  // Quote currency this market is denominated against (e.g. "USDC").
  // Surfaced to the UI so the form's base/quote unit toggle doesn't have
  // to hardcode the dollar leg.
  quote: z.string(),
  size_decimals: z.number(),
  status: z
    .enum(["active", "deactivating", "settling", "inactive"])
    .default("active"),
  symbol: z.string(),
});

const symbologySchema = z.object({
  markets: z.array(symbologyMarketSchema),
  version: z.number(),
});

export type Symbology = z.infer<typeof symbologySchema>;

export const symbologyUpdateSchema = z.object({
  markets: z.array(symbologyMarketSchema),
  type: z.literal("SymbologyUpdate"),
  version: z.number(),
});

export type SymbologyUpdate = z.infer<typeof symbologyUpdateSchema>;

export const symbologySnapshotSchema = symbologySchema.extend({
  type: z.literal("SymbologySnapshot"),
});

export type SymbologySnapshot = z.infer<typeof symbologySnapshotSchema>;

export const symbologyMarketUpdateSchema = z.object({
  market: symbologyMarketSchema,
  type: z.literal("SymbologyMarketUpdate"),
});

export type SymbologyMarketUpdate = z.infer<typeof symbologyMarketUpdateSchema>;

export const marketUnsubscribedSchema = z.object({
  market_id: z.number(),
  reason: z.string(),
  type: z.literal("MarketUnsubscribed"),
});

export type MarketUnsubscribed = z.infer<typeof marketUnsubscribedSchema>;
