export const wsUrlToHttpUrl = (wsUrl: string): string =>
  wsUrl
    .replace(/^wss:\/\//, "https://")
    .replace(/^ws:\/\//, "http://")
    .replace(/\/ws\/?$/, "");
