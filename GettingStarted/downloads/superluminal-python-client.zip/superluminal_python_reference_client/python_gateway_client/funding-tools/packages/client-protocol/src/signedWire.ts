// Hand-written re-export of the generated signed-wire codec.  The output
// file is emitted by `bun run build:codegen` (driven by turbo's
// `build:codegen` task on `@aethon/client-protocol`, see ./turbo.json) into
// the gitignored `./generated/signedWire.ts` so it always tracks
// `protocol/idl/signed_wire.json`.  Routing every consumer through this
// module isolates the relative path -- future codegen relocations only edit
// one file -- and gives consumers (e.g. `@aethon/client-account`) a stable
// import surface exposed as the `@aethon/client-protocol/signedWire` subpath.
export * from "./generated/signedWire";
