import { z } from "zod";

export const exchangeEnvironmentSchema = z.enum([
  "unknown",
  "dev",
  "testnet",
  "prod",
]);

export const exchangeConfigSchema = z.object({
  deposit_withdraw_fee_usd: z.number().int().nonnegative(),
  environment: exchangeEnvironmentSchema,
  leader_fee_bps: z.number().int().nonnegative(),
  leader_share_bps: z.number().int().nonnegative(),
  maker_fee_ppm: z.number().int(),
  min_deposit_amount_usd: z.number().int().nonnegative(),
  min_vault_deposit_amount_usd: z.number().int().nonnegative(),
  taker_fee_ppm: z.number().int(),
  vault_creation_fee_usd: z.number().int().nonnegative(),
});

export type ExchangeConfig = z.infer<typeof exchangeConfigSchema>;
export type ExchangeEnvironment = z.infer<typeof exchangeEnvironmentSchema>;

export const exchangeConfigSnapshotSchema = exchangeConfigSchema.extend({
  type: z.literal("ExchangeConfigSnapshot"),
});
export type ExchangeConfigSnapshot = z.infer<
  typeof exchangeConfigSnapshotSchema
>;

export const exchangeConfigUpdateSchema = exchangeConfigSchema.extend({
  type: z.literal("ExchangeConfigUpdate"),
});
export type ExchangeConfigUpdate = z.infer<typeof exchangeConfigUpdateSchema>;
