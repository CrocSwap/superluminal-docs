import type { VaultAccountPerf } from "./vaultAccountsPage";

// One page of a vault's historical performance series, returned by the
// gateway's `get_vault_account_perf` query.  Each event is a persisted
// `vault_account_perf` row -- the same shape as a vault's `latestPerf` -- and
// the account persistor writes one per configured interval, so the series is a
// time-ordered equity/shares/leader-share history.  Events arrive newest-first
// on the wire, matching `FundingHistoryPage`; `nextCursor` is `undefined` on
// the last page.
export type VaultAccountPerfPage = {
  nextCursor: string | undefined;
  events: VaultAccountPerf[];
};
