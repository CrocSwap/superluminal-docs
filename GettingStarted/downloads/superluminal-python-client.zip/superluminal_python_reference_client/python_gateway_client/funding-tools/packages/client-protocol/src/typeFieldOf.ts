// Extract the `type` discriminant from a parsed wire message, or `undefined`
// when the value isn't an object with a string `type`. Shared by the account
// and market socket routers to tell a known-but-malformed payload from an
// unknown one.
export const typeFieldOf = (value: unknown): string | undefined => {
  if (value !== null && typeof value === "object" && "type" in value) {
    const type = (value as { type: unknown }).type;
    return typeof type === "string" ? type : undefined;
  } else {
    return undefined;
  }
};
