// Single source of truth for the wire's price-scaling sign convention.
//
// The gateway publishes prices as int64 mantissas plus a per-market
// `px_exponent`: `human = raw * 10^px_exponent` (px_exponent is negative in
// practice). The matching Dnum exponent -- i.e. the number of decimal places --
// is therefore the negation, `-px_exponent`. A positive `px_exponent` (prices
// quantized to units larger than one) yields a *negative* decimal count, which
// is why `Math.abs` is wrong: it silently agrees only while the exponent stays
// non-positive.
//
// Every consumer that needs price decimals from a symbology `px_exponent` MUST
// derive them through this function rather than re-writing the sign inline, so
// the convention can never drift between market surfaces again.
//
// Written `0 - pxExponent` rather than `-pxExponent` so a zero exponent yields
// `+0` instead of `-0` (numerically identical, but `-0` surprises strict
// equality and serialization).
export const priceDecimalsOf = (pxExponent: number): number => 0 - pxExponent;
