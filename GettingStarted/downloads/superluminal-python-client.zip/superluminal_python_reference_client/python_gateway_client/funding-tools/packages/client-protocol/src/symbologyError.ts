import { errorMessage } from "./errorMessage";

// Discriminant for `SymbologyError`. Each error type owns its own enum,
// co-located with the error, so a variant means exactly one thing and adding a
// variant only touches this error's own switch.
export enum SymbologyErrorType {
  Network,
  Parse,
  Unexpected,
}

// Typed failure channel for `fetchSymbology`. The three variants are the only
// ways a symbology fetch can fail: the gateway answered with a non-2xx status
// (`Network`), it answered with a body that failed the Zod schema (`Parse`),
// or the `fetch` call itself threw (`Unexpected`, carrying the opaque cause).
// The variant carries the opaque upstream detail (status, Zod message, thrown
// value) as a field; `displaySymbologyError` reconstructs the human string.
export const SymbologyError = {
  Network: (status: number) => ({
    status,
    type: SymbologyErrorType.Network as const,
  }),
  Parse: (message: string) => ({
    message,
    type: SymbologyErrorType.Parse as const,
  }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: SymbologyErrorType.Unexpected as const,
  }),
};

export type SymbologyError = ReturnType<
  (typeof SymbologyError)[keyof typeof SymbologyError]
>;

// Rust `Display`-trait analog: fold a `SymbologyError` back into the exact
// human string the old `Result<Symbology, string>` channel produced, so
// callers that surface the message (the account client, the public client's
// per-method displays) read identically.
export const displaySymbologyError = (err: SymbologyError): string => {
  switch (err.type) {
    case SymbologyErrorType.Network:
      return `symbology fetch failed: ${err.status}`;
    case SymbologyErrorType.Parse:
      return `symbology parse failed: ${err.message}`;
    case SymbologyErrorType.Unexpected:
      return errorMessage(err.cause, "symbology fetch failed");
  }
};
