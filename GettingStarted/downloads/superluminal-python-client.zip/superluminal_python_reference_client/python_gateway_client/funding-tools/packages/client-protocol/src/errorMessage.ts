// Extracts a human-readable message from an unknown thrown cause, falling back
// to the supplied string when the cause is not an `Error`.
export const errorMessage = (cause: unknown, fallback: string): string =>
  cause instanceof Error ? cause.message : fallback;
