// `Canceler` is the return shape every subscription factory in the client
// surface resolves to.  Calling it tears the subscription down (closes the
// underlying WS attachment on live, clears the scheduled tick on mock).
export type Canceler = () => void;
