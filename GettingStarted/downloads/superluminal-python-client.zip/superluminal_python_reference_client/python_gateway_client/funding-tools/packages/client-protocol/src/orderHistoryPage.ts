import type { Dnum } from "dnum";
import type { Order } from "./order";

type BackstopPosition = {
  symbolId: number;
  symbol: string;
  quantity: Dnum;
  bucketIndex: number;
  positionIndex: number;
};

type BackstopHistoryBase = {
  // Sequence of the confirmed event, not a matcher order ID.
  id: bigint;
  orderType: "backstop-transfer";
  status: "confirmed";
  events: [];
  timestamp: Date;
  nonce: bigint;
  subaccountId: bigint;
  sourceSubaccountId: bigint;
  bucketIndex: number;
  collateral: Dnum;
  complete: boolean;
  signature: string;
};

export type BackstopHistory = BackstopHistoryBase &
  (
    | {
        phase: "begin";
        absorbedFees: Dnum;
        sourceCollateralRemoved: Dnum;
        sourceFeesRemoved: Dnum;
        sourceNetFundingRemoved: Dnum;
        buckets: { subaccountId: bigint; collateral: Dnum }[];
        positions: (BackstopPosition & {
          costBasis: Dnum;
          fundingIndex: bigint;
        })[];
      }
    | {
        phase: "acquire";
        positions: (BackstopPosition & {
          costBasisDelta: Dnum;
          realizedPnlDelta: Dnum;
          fundingDelta: Dnum;
        })[];
      }
  );

export type HistoryEntry = Order | BackstopHistory;

export const historyEntryKey = (entry: HistoryEntry): string => {
  if (entry.orderType === "backstop-transfer") {
    return `backstop:${entry.id.toString()}`;
  } else {
    return `order:${entry.id.toString()}`;
  }
};

export type OrderHistoryPage = {
  nextCursor: string | undefined;
  orders: HistoryEntry[];
};
