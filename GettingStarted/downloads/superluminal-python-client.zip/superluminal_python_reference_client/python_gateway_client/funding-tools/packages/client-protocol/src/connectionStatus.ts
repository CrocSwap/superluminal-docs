import type { Canceler } from "./canceler";

// Aggregate health of the client's gateway sockets.  Each socket owner (a
// live market's WS, the authenticated account session) registers a reporter
// and feeds it that socket's lifecycle; subscribers see the worst status
// across every tracked socket.  A reporter that has been `clear`ed (its
// socket was deliberately closed) does not count against the aggregate --
// the indicator reports problems with *desired* connections, so "no sockets
// wanted" is `connected`.
export type ConnectionStatus = "connected" | "connecting" | "disconnected";

export type ConnectionStatusReporter = {
  report: (status: ConnectionStatus) => void;
  clear: () => void;
};

export type ConnectionStatusTracker = {
  register: () => ConnectionStatusReporter;
  subscribe: (onUpdate: (status: ConnectionStatus) => void) => Canceler;
};

const SEVERITY: Record<ConnectionStatus, number> = {
  connected: 0,
  connecting: 1,
  disconnected: 2,
};

export const worstConnectionStatus = (
  statuses: readonly ConnectionStatus[],
): ConnectionStatus =>
  statuses.reduce(
    (worst, status) => (SEVERITY[status] > SEVERITY[worst] ? status : worst),
    "connected",
  );

export const createConnectionStatusTracker = (): ConnectionStatusTracker => {
  const statuses = new Map<ConnectionStatusReporter, ConnectionStatus>();
  const subscribers = new Set<(status: ConnectionStatus) => void>();
  let aggregate: ConnectionStatus = "connected";

  const recompute = () => {
    const next = worstConnectionStatus([...statuses.values()]);
    if (next !== aggregate) {
      aggregate = next;
      for (const onUpdate of subscribers) {
        onUpdate(aggregate);
      }
    }
  };

  return {
    register: () => {
      const reporter: ConnectionStatusReporter = {
        clear: () => {
          statuses.delete(reporter);
          recompute();
        },
        report: (status) => {
          statuses.set(reporter, status);
          recompute();
        },
      };
      return reporter;
    },
    subscribe: (onUpdate) => {
      subscribers.add(onUpdate);
      onUpdate(aggregate);
      return () => {
        subscribers.delete(onUpdate);
      };
    },
  };
};
