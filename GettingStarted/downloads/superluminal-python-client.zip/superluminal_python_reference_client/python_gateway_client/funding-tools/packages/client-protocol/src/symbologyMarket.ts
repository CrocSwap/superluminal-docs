import { priceDecimalsOf } from "./priceDecimals";
import type { Symbology } from "./symbology";

// The wire market record as it arrives in the symbology payload, before any
// scaling/naming derivation.
type WireSymbologyMarket = Symbology["markets"][number];

// Canonical per-market view derived once from a wire symbology record.  Both
// `client-public` (market catalog + live market handles) and `client-account`
// (the state machine's scaling caches + the submit path's wire envelope) read
// their per-market fields off this shape rather than re-deriving decimals /
// quote / id from the raw wire record independently -- so the derivation rules
// (notably the `px_exponent` sign convention) live in exactly one place and
// can't drift between the two clients.
//
// `pxExponent` is carried raw alongside the derived `priceDecimals` because the
// account state machine's cost-basis math scales by `px_exponent - size_decimals`
// and needs the signed exponent, not just the decimal count.
export type SymbologyMarket = {
  changeCount: number;
  symbolId: number;
  symbol: string;
  quote: string;
  pxExponent: number;
  priceDecimals: number;
  sizeDecimals: number;
  initialMarginBps: number;
  maintenanceMarginBps: number;
  status: "active" | "deactivating" | "settling" | "inactive";
};

export const toSymbologyMarket = (
  market: WireSymbologyMarket,
): SymbologyMarket => ({
  changeCount: market.change_count,
  initialMarginBps: market.initial_margin_bps,
  maintenanceMarginBps: market.maintenance_margin_bps,
  priceDecimals: priceDecimalsOf(market.px_exponent),
  pxExponent: market.px_exponent,
  quote: market.quote,
  sizeDecimals: market.size_decimals,
  status: market.status,
  symbol: market.symbol,
  symbolId: market.id,
});
