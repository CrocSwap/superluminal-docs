import { z } from "zod";

const httpUrlSchema = z
  .url()
  .refine(
    (value) => value.startsWith("http://") || value.startsWith("https://"),
    { error: "URL must use http:// or https://" },
  );
const gatewayUrlSchema = httpUrlSchema.refine(
  (value) => {
    const url = new URL(value);
    return url.pathname === "/" && url.search === "" && url.hash === "";
  },
  { error: "--gateway must be an HTTP origin without a path" },
);
const unsignedIntegerSchema = z
  .string()
  .regex(/^\d+$/)
  .transform(Number)
  .pipe(z.int().nonnegative());
const subaccountSchema = z
  .string()
  .regex(/^\d+$/)
  .transform(BigInt)
  .pipe(z.bigint().max(18_446_744_073_709_551_615n));

export type PrepareDepositAddressCliArgs =
  | Readonly<{ kind: "help" }>
  | Readonly<{
      evmRpcUrl: string;
      gatewayHttpUrl: string;
      keypairPath: string;
      kind: "prepare";
      partitionId: number;
      subaccountId: bigint;
      websocketUrl: string;
    }>;

type RawCliValues = Readonly<{
  evmRpcUrl?: string;
  gatewayHttpUrl?: string;
  keypairPath?: string;
  partitionId?: string;
  subaccountId?: string;
}>;

const assertKnownArgument = (flag: string) => {
  const known = [
    "--evm-rpc",
    "--gateway",
    "--keypair",
    "--partition-id",
    "--subaccount",
  ].includes(flag);
  if (!known) {
    throw new Error(`unknown argument: ${flag}`);
  }
};

const assignArgument = (
  values: RawCliValues,
  flag: string,
  value: string,
): RawCliValues => {
  switch (flag) {
    case "--keypair":
      return { ...values, keypairPath: value };
    case "--gateway":
      return { ...values, gatewayHttpUrl: value };
    case "--evm-rpc":
      return { ...values, evmRpcUrl: value };
    case "--partition-id":
      return { ...values, partitionId: value };
    case "--subaccount":
      return { ...values, subaccountId: value };
    default:
      throw new Error(`unknown argument: ${flag}`);
  }
};

const parseRawCliValues = (
  argv: readonly string[],
  index = 0,
  values: RawCliValues = {},
): RawCliValues => {
  const flag = argv[index];
  if (flag === undefined) {
    return values;
  } else {
    assertKnownArgument(flag);
    const value = argv[index + 1];
    if (value === undefined || value.startsWith("--")) {
      throw new Error(`${flag} requires a value`);
    } else {
      return parseRawCliValues(
        argv,
        index + 2,
        assignArgument(values, flag, value),
      );
    }
  }
};

const requireValue = (value: string | undefined, flag: string): string => {
  if (value === undefined) {
    throw new Error(`${flag} is required`);
  } else {
    return value;
  }
};

const deriveWebsocketUrl = (gatewayHttpUrl: string): string => {
  const url = new URL("/ws", gatewayHttpUrl);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  return url.toString();
};

export const parsePrepareDepositAddressCliArgs = (
  argv: readonly string[],
): PrepareDepositAddressCliArgs => {
  if (argv.includes("--help") || argv.includes("-h")) {
    return { kind: "help" };
  } else {
    const values = parseRawCliValues(argv);
    const keypairPath = requireValue(values.keypairPath, "--keypair");
    const gatewayHttpUrl = gatewayUrlSchema.parse(
      requireValue(values.gatewayHttpUrl, "--gateway"),
    );
    return {
      evmRpcUrl: httpUrlSchema.parse(
        requireValue(values.evmRpcUrl, "--evm-rpc"),
      ),
      gatewayHttpUrl,
      keypairPath: z.string().min(1).parse(keypairPath),
      kind: "prepare",
      partitionId: unsignedIntegerSchema
        .pipe(z.number().max(65_535))
        .parse(requireValue(values.partitionId, "--partition-id")),
      subaccountId: subaccountSchema.parse(
        requireValue(values.subaccountId, "--subaccount"),
      ),
      websocketUrl: deriveWebsocketUrl(gatewayHttpUrl),
    };
  }
};
