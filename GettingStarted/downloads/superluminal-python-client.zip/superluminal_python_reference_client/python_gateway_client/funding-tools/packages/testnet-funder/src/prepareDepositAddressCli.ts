import type { AccountClient } from "@aethon/client-account";
import { createAccountClient as createDefaultAccountClient } from "@aethon/client-account";
import type { AuthSigner } from "@aethon/client-account/authSigner";
import type { DepositClient } from "@aethon/client-deposit";
import { createDepositClient as createDefaultDepositClient } from "@aethon/client-deposit";
import type { EvmDeploymentMetadata } from "./evmDeploymentApi";
import {
  fetchEvmChainId as fetchDefaultEvmChainId,
  fetchEvmDeploymentMetadata as fetchDefaultEvmDeploymentMetadata,
} from "./evmDeploymentApi";
import { loadKeypairAuthSigner as loadDefaultKeypairAuthSigner } from "./keypairAuthSigner";
import type {
  PrepareDepositAddressOptions,
  PreparedDepositAddress,
} from "./prepareDepositAddress";
import { prepareDepositAddress as prepareDefaultDepositAddress } from "./prepareDepositAddress";
import type { PrepareDepositAddressCliArgs } from "./prepareDepositAddressCliArgs";
import { parsePrepareDepositAddressCliArgs } from "./prepareDepositAddressCliArgs";

export const PREPARE_DEPOSIT_ADDRESS_USAGE = `Usage:
  bun run deposit:address \\
    --keypair <wallet.json> \\
    --gateway <http-origin> \\
    --evm-rpc <http-url> \\
    --partition-id <u16> \\
    --subaccount <u64>

Options:
  --keypair <path>        Solana-format Fogo keypair JSON
  --gateway <http-origin> Gateway origin, for example https://gateway.example
  --evm-rpc <http-url>    RPC for the deployment's EVM chain
  --partition-id <u16>    Gateway partition used to sign registration
  --subaccount <u64>      Trading subaccount to fund
  --help

This command registers and prints the deposit destination. It does not transfer funds.`;

type AccountClientFactory = (options: {
  partitionId: number;
  signer: AuthSigner;
  websocketUrl: string;
}) => AccountClient;

type DepositClientFactory = (options: {
  evmGatewayAddress: string;
  evmRpcUrl: string;
}) => DepositClient;

type PrepareDepositAddressCliDependencies = Readonly<{
  createAccountClient: AccountClientFactory;
  createDepositClient: DepositClientFactory;
  fetchEvmChainId: (evmRpcUrl: string) => Promise<bigint>;
  fetchEvmDeploymentMetadata: (
    gatewayHttpUrl: string,
  ) => Promise<EvmDeploymentMetadata>;
  loadKeypairAuthSigner: (path: string) => Promise<AuthSigner>;
  prepareDepositAddress: (
    options: PrepareDepositAddressOptions,
  ) => Promise<PreparedDepositAddress>;
  writeLine: (line: string) => void;
}>;

const writeStdoutLine = (line: string) => {
  process.stdout.write(`${line}\n`);
};

const defaultDependencies: PrepareDepositAddressCliDependencies = {
  createAccountClient: createDefaultAccountClient,
  createDepositClient: createDefaultDepositClient,
  fetchEvmChainId: fetchDefaultEvmChainId,
  fetchEvmDeploymentMetadata: fetchDefaultEvmDeploymentMetadata,
  loadKeypairAuthSigner: loadDefaultKeypairAuthSigner,
  prepareDepositAddress: prepareDefaultDepositAddress,
  writeLine: writeStdoutLine,
};

const printPreparedAddress = (
  prepared: PreparedDepositAddress,
  metadata: EvmDeploymentMetadata,
  chainId: bigint,
  writeLine: (line: string) => void,
) => {
  writeLine(`Fogo account:        ${prepared.walletAddress}`);
  writeLine(`Subaccount:          ${prepared.subaccountId}`);
  writeLine(`EVM chain ID:        ${chainId}`);
  writeLine(`Collateral token:    ${metadata.collateralAddress}`);
  writeLine(`EVM deposit address: ${prepared.depositAddress}`);
  writeLine("Deposit address ready.");
  writeLine(
    "Transfer only the listed collateral token on the listed EVM chain.",
  );
};

const runPreparation = async (
  args: Extract<PrepareDepositAddressCliArgs, { kind: "prepare" }>,
  dependencies: PrepareDepositAddressCliDependencies,
) => {
  const [signer, metadata, chainId] = await Promise.all([
    dependencies.loadKeypairAuthSigner(args.keypairPath),
    dependencies.fetchEvmDeploymentMetadata(args.gatewayHttpUrl),
    dependencies.fetchEvmChainId(args.evmRpcUrl),
  ]);
  const accountClient = dependencies.createAccountClient({
    partitionId: args.partitionId,
    signer,
    websocketUrl: args.websocketUrl,
  });
  const depositClient = dependencies.createDepositClient({
    evmGatewayAddress: metadata.gatewayAddress,
    evmRpcUrl: args.evmRpcUrl,
  });
  const prepared = await dependencies.prepareDepositAddress({
    accountClient,
    depositClient,
    subaccountId: args.subaccountId,
    walletAddress: signer.walletPublicKey,
  });
  printPreparedAddress(prepared, metadata, chainId, dependencies.writeLine);
};

export const runPrepareDepositAddressCli = async (
  argv: readonly string[],
  dependencies: PrepareDepositAddressCliDependencies = defaultDependencies,
) => {
  const args = parsePrepareDepositAddressCliArgs(argv);
  switch (args.kind) {
    case "help":
      dependencies.writeLine(PREPARE_DEPOSIT_ADDRESS_USAGE);
      break;
    case "prepare":
      await runPreparation(args, dependencies);
      break;
  }
};

const errorMessage = (error: unknown): string =>
  error instanceof Error ? error.message : String(error);

if (import.meta.main) {
  runPrepareDepositAddressCli(process.argv.slice(2)).catch((error: unknown) => {
    process.stderr.write(
      `Deposit-address preparation failed: ${errorMessage(error)}\n`,
    );
    process.exitCode = 1;
  });
}
