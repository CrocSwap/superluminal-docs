import { readFile } from "node:fs/promises";
import type { AuthSigner } from "@aethon/client-account/authSigner";
import { createKeyPairSignerFromBytes, signBytes } from "@solana/kit";
import { z } from "zod";

type ReadTextFile = (path: string) => Promise<string>;

const keypairSchema = z
  .array(z.int().min(0).max(255))
  .length(64, "keypair must contain exactly 64 bytes");

const readTextFile: ReadTextFile = (path) => readFile(path, "utf8");

export const loadKeypairAuthSigner = async (
  path: string,
  read: ReadTextFile = readTextFile,
): Promise<AuthSigner> => {
  const bytes = new Uint8Array(
    keypairSchema.parse(JSON.parse(await read(path))),
  );
  const keypairSigner = await createKeyPairSignerFromBytes(bytes);
  return {
    signMessage: (message) =>
      signBytes(keypairSigner.keyPair.privateKey, message),
    walletPublicKey: keypairSigner.address,
  };
};
