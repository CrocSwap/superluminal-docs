import type { AccountClient } from "@aethon/client-account";
import { displayConnectError } from "@aethon/client-account/connectError";
import { displayRegisterDepositAddressError } from "@aethon/client-account/registerDepositAddressError";
import type { DepositClient } from "@aethon/client-deposit";
import { displayGetUserDepositAddressError } from "@aethon/client-deposit/getUserDepositAddressError";
import type { Address } from "@solana/kit";

type PreparationAccountClient = Pick<
  AccountClient,
  "close" | "connect" | "registerUserDepositAddress"
>;

type PreparationDepositClient = Pick<DepositClient, "getUserDepositAddress">;

export type PrepareDepositAddressOptions = Readonly<{
  accountClient: PreparationAccountClient;
  depositClient: PreparationDepositClient;
  subaccountId: bigint;
  walletAddress: Address;
}>;

export type PreparedDepositAddress = Readonly<{
  depositAddress: string;
  subaccountId: bigint;
  walletAddress: Address;
}>;

export const prepareDepositAddress = async ({
  accountClient,
  depositClient,
  subaccountId,
  walletAddress,
}: PrepareDepositAddressOptions): Promise<PreparedDepositAddress> => {
  try {
    const connection = await accountClient.connect();
    connection.match({
      Err: (error) => {
        throw new Error(
          `gateway connection failed: ${displayConnectError(error)}`,
        );
      },
      Ok: () => true,
    });

    const registration =
      await accountClient.registerUserDepositAddress(subaccountId);
    registration.match({
      Err: (error) => {
        throw new Error(
          `deposit-address registration failed: ${displayRegisterDepositAddressError(error)}`,
        );
      },
      Ok: () => true,
    });

    const depositAddressResult = await depositClient.getUserDepositAddress(
      walletAddress,
      subaccountId,
    );
    const depositAddress = depositAddressResult.match({
      Err: (error) => {
        throw new Error(
          `deposit-address derivation failed: ${displayGetUserDepositAddressError(error)}`,
        );
      },
      Ok: (address) => address,
    });
    return { depositAddress, subaccountId, walletAddress };
  } finally {
    accountClient.close();
  }
};
