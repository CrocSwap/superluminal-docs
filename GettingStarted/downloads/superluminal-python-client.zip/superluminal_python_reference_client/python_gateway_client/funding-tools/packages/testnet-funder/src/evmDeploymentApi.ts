import { z } from "zod";

type Fetch = (input: string, init?: RequestInit) => Promise<Response>;

const evmAddressSchema = z.string().regex(/^0x[0-9a-fA-F]{40}$/);
const transactionHashSchema = z.string().regex(/^0x[0-9a-fA-F]{64}$/);

const evmAddressesSchema = z.object({
  collateral: evmAddressSchema,
  fee_recipient: evmAddressSchema,
  gateway: evmAddressSchema,
  user_deposit_init_code_hash: transactionHashSchema,
  version: z.int().nonnegative(),
});

const chainIdResponseSchema = z.union([
  z.object({
    id: z.number(),
    jsonrpc: z.literal("2.0"),
    result: z
      .string()
      .regex(/^0x[0-9a-fA-F]+$/)
      .transform(BigInt),
  }),
  z.object({
    error: z.object({ code: z.int(), message: z.string().min(1) }),
    id: z.number(),
    jsonrpc: z.literal("2.0"),
  }),
]);

export type EvmDeploymentMetadata = Readonly<{
  collateralAddress: string;
  gatewayAddress: string;
}>;

const assertOk = (response: Response, label: string) => {
  if (!response.ok) {
    throw new Error(`${label} failed with HTTP ${response.status}`);
  }
};

export const fetchEvmDeploymentMetadata = async (
  gatewayHttpUrl: string,
  fetchFn: Fetch = fetch,
): Promise<EvmDeploymentMetadata> => {
  const url = new URL("/v1/evm/addresses", gatewayHttpUrl).toString();
  const response = await fetchFn(url);
  assertOk(response, "EVM address metadata request");
  const metadata = evmAddressesSchema.parse(await response.json());
  return {
    collateralAddress: metadata.collateral,
    gatewayAddress: metadata.gateway,
  };
};

export const fetchEvmChainId = async (
  evmRpcUrl: string,
  fetchFn: Fetch = fetch,
): Promise<bigint> => {
  const response = await fetchFn(evmRpcUrl, {
    body: JSON.stringify({
      id: 1,
      jsonrpc: "2.0",
      method: "eth_chainId",
      params: [],
    }),
    headers: { "content-type": "application/json" },
    method: "POST",
  });
  assertOk(response, "EVM chain-id request");
  const body = chainIdResponseSchema.parse(await response.json());
  if ("error" in body) {
    throw new Error(`EVM chain-id request failed: ${body.error.message}`);
  } else {
    return body.result;
  }
};
