import type { MarketDecimals } from "./marketDecimals";

const tenPowBigInt = (n: number): bigint => 10n ** BigInt(n);

// Cost-basis delta in USDC e6 for one fill leg.  Mirrors the
// `__int128` math in `api_client/account_state.cpp::cost_basis_delta_usd`:
// scale `price * signed_qty` by `10 ^ (px_exponent - size_decimals + 6)`.
export const computeCostBasisDelta = (
  price: bigint,
  signedQty: bigint,
  decimals: MarketDecimals,
): bigint => {
  const product = price * signedQty;
  const exponent = decimals.pxExponent - decimals.sizeDecimals;
  if (exponent > -6) {
    return product * tenPowBigInt(exponent + 6);
  } else if (exponent < -6) {
    return product / tenPowBigInt(-6 - exponent);
  } else {
    return product;
  }
};
