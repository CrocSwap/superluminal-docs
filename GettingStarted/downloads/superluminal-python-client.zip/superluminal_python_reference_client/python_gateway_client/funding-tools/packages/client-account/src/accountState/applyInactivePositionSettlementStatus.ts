import type { InactivePositionSettlementStatusMessage } from "../wire/wireSchema";
import type { Subaccount } from "./subaccount";
import { positionAdjustedCollateralBalance } from "./subaccount";

export const applyInactivePositionSettlementStatus = (
  subaccounts: Map<bigint, Subaccount>,
  message: InactivePositionSettlementStatusMessage,
): bigint[] => {
  if (
    message.status !== 0 ||
    message.error_code !== 0 ||
    !message.audit_event_present ||
    message.collateral_balance === undefined ||
    message.settled_position_qty === undefined ||
    message.settled_position_qty === 0n
  ) {
    return [];
  }

  const subaccount = subaccounts.get(message.subaccount_id);
  const position = subaccount?.positions.get(message.market_id);
  if (
    subaccount === undefined ||
    position === undefined ||
    position.netQty !== message.settled_position_qty
  ) {
    return [];
  }

  subaccount.positions.delete(message.market_id);
  subaccount.pendingRealized = subaccount.pendingRealized.filter(
    (fill) => fill.symbolId !== message.market_id,
  );
  subaccount.collateralBalance = positionAdjustedCollateralBalance(
    message.collateral_balance,
    [...subaccount.positions.values()],
  );
  return [message.subaccount_id];
};
