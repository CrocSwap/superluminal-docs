import { errorMessage } from "@aethon/client-protocol/errorMessage";

// Discriminant for `SubmitVaultDepositError`. Owns its own enum. `SignedOut` is
// produced by the `useVaultDeposit` hook, the rest by the account client. There
// is no `Timeout`: the gateway is silent on deposit success, so grace-period
// silence resolves `Ok`, never a timeout error.
export enum SubmitVaultDepositErrorType {
  Validation,
  Disconnected,
  SignerRejected,
  Rejected,
  SignedOut,
}

// Typed failure channel for `AccountClient.submitVaultDeposit`. The target vault
// pubkey is validated before any I/O (`Validation`); then the signed command
// can fail because the session is gone (`Disconnected`), the signer refused
// (`SignerRejected`), or the gateway rejected the deposit (`Rejected`).
export const SubmitVaultDepositError = {
  Disconnected: () => ({
    type: SubmitVaultDepositErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: SubmitVaultDepositErrorType.Rejected as const,
  }),
  SignedOut: () => ({ type: SubmitVaultDepositErrorType.SignedOut as const }),
  SignerRejected: (cause: unknown) => ({
    cause,
    type: SubmitVaultDepositErrorType.SignerRejected as const,
  }),
  Validation: (message: string) => ({
    message,
    type: SubmitVaultDepositErrorType.Validation as const,
  }),
};

export type SubmitVaultDepositError = ReturnType<
  (typeof SubmitVaultDepositError)[keyof typeof SubmitVaultDepositError]
>;

export const displaySubmitVaultDepositError = (
  error: SubmitVaultDepositError,
): string => {
  switch (error.type) {
    case SubmitVaultDepositErrorType.Validation:
      return error.message;
    case SubmitVaultDepositErrorType.Disconnected:
      return "deposit session disconnected";
    case SubmitVaultDepositErrorType.SignerRejected:
      return errorMessage(error.cause, "signer rejected vault deposit");
    case SubmitVaultDepositErrorType.Rejected:
      return error.reason;
    case SubmitVaultDepositErrorType.SignedOut:
      return "Sign in to deposit";
  }
};
