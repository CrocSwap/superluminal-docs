import type { Address } from "@solana/kit";

// A signer the live account client uses to authenticate against the gateway:
// the SVM wallet public key it should identify as, plus a callback that
// produces an ed25519 signature over an arbitrary byte buffer.  The trading
// app wires this up against the Privy embedded SVM wallet; tests pass a
// hand-rolled signer.
export type AuthSigner = {
  walletPublicKey: Address;
  signMessage: (message: Uint8Array) => Promise<Uint8Array>;
};
