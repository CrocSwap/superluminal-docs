import {
  encodeContractCancelProofV2,
  encodeContractCancelV2,
} from "@aethon/client-protocol/signedWire";
import { Result } from "@cprussin/option-result";
import type { CancelConditionalOrderError as CancelConditionalOrderFailure } from "../cancelConditionalOrderError";
import { CancelConditionalOrderError } from "../cancelConditionalOrderError";
import { awaitConditionalCancelResolution } from "../session/awaitResolution";
import type { SignedCommandContext } from "./signedCommand";
import { SIGNED_TTL_SECONDS } from "./signedCommand";
import { base64Encode, buildCancelSignedMessage } from "./signMessage";

export type CancelConditionalOrderParams = Readonly<{
  groupId: bigint;
  subaccountId: bigint;
  symbol: number;
}>;

export const cancelConditionalOrder = (
  ctx: SignedCommandContext,
  params: CancelConditionalOrderParams,
): Promise<Result<true, CancelConditionalOrderFailure>> => {
  const iat = ctx.nowSeconds();
  const exp = iat + SIGNED_TTL_SECONDS;
  const requestId64 = ctx.generateRequestId();
  const cancelBytes = encodeContractCancelV2({
    externalOrderId: params.groupId,
    requestId64,
    role: 1,
    symbol: params.symbol,
  });
  const signMessage = buildCancelSignedMessage({
    cancelBytes,
    exp,
    iat,
    partitionId: ctx.partitionId,
    senderPubkey: ctx.senderPubkey,
    subaccountId: params.subaccountId,
  });
  return Result.wrapAsync(ctx.ensureAuthenticated()).then((sessionResult) =>
    sessionResult
      .mapErr(
        (): CancelConditionalOrderFailure =>
          CancelConditionalOrderError.Disconnected(),
      )
      .andThenAsync((socket) =>
        Result.wrapAsync(ctx.signer.signMessage(signMessage)).then(
          (signatureResult) =>
            signatureResult
              .mapErr(
                (cause): CancelConditionalOrderFailure =>
                  CancelConditionalOrderError.SignerRejected(
                    cause.match({
                      None: () => undefined,
                      Some: (value) => value,
                    }),
                  ),
              )
              .andThenAsync((signature) => {
                const proofBytes = encodeContractCancelProofV2({
                  cancelBytes,
                  exp,
                  iat,
                  partitionId: ctx.partitionId,
                  senderPubkey: ctx.senderPubkey,
                  signature,
                  signerPubkey: ctx.senderPubkey,
                  subaccountId: params.subaccountId,
                });
                const resolution =
                  awaitConditionalCancelResolution<CancelConditionalOrderFailure>(
                    socket,
                    requestId64,
                    params.groupId,
                    {
                      disconnected: CancelConditionalOrderError.Disconnected,
                      rejected: CancelConditionalOrderError.Rejected,
                      timeout: CancelConditionalOrderError.Timeout,
                    },
                  );
                socket.send(
                  JSON.stringify({
                    msg_b64: base64Encode(proofBytes),
                    type: "signed_conditional_cancel",
                    version: 1,
                  }),
                );
                return resolution;
              }),
        ),
      ),
  );
};
