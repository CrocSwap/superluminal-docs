import type { Result } from "@cprussin/option-result";
import { Err } from "@cprussin/option-result";
import { RegisterDepositAddressError } from "../registerDepositAddressError";
import { awaitUserDepositAddressResolution } from "../session/awaitResolution";

const encodeUserDepositAddress = (subaccountId: bigint): string =>
  `{"subaccount_id":${subaccountId},"type":"user_deposit_address"}`;

// Sends `user_deposit_address` over the authenticated session so the sequencer
// registers the (wallet, subaccountId) pair with the keeper. The listener is
// attached before `send` to avoid racing the keeper status on a slow event
// loop.
export const registerUserDepositAddress = (
  ensureAuthenticated: () => Promise<WebSocket>,
  subaccountId: bigint,
): Promise<Result<true, RegisterDepositAddressError>> =>
  ensureAuthenticated().then(
    (socket) => {
      const resolution =
        awaitUserDepositAddressResolution<RegisterDepositAddressError>(
          socket,
          subaccountId,
          {
            disconnected: RegisterDepositAddressError.Disconnected,
            rejected: RegisterDepositAddressError.Rejected,
            timeout: RegisterDepositAddressError.Timeout,
          },
        );
      socket.send(encodeUserDepositAddress(subaccountId));
      return resolution;
    },
    (): Result<true, RegisterDepositAddressError> =>
      Err(RegisterDepositAddressError.Disconnected()),
  );
