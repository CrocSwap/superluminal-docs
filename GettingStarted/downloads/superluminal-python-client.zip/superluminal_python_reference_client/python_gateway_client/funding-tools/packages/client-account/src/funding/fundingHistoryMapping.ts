import type {
  FundingEvent,
  FundingHistoryPage,
} from "@aethon/client-protocol/fundingHistoryPage";
import type { SymbologyMarket } from "@aethon/client-protocol/symbologyMarket";
import type { Dnum } from "dnum";
import { dateFromUnixNs } from "../orders/orderWireFields";
import type {
  FundingHistoryEvent,
  FundingHistoryWireEvent,
} from "./fundingHistoryWire";

// Wire -> domain mapping for the notifier's `get_funding_history` response.
// Unlike order history, funding events need no per-symbol decimals: funding is
// a USDC amount (fixed e6) and carries no market-scaled price/size.  The only
// symbology lookup is the market id -> symbol name join.  Kept separate from the
// socket lifecycle in `live.ts`: pure transport-to-domain translation.

// USDC amounts (collateral, cost basis, funding, fees) are wire-encoded at e6;
// match the `USDC_DECIMALS` constant used by the order-history mapping so the
// public surface stays uniform.
const USDC_DECIMALS = 6;

const toDnumUsdc = (raw: bigint): Dnum => [raw, USDC_DECIMALS];

const toFundingEvent = (
  wire: FundingHistoryWireEvent,
  marketsBySymbolId: ReadonlyMap<number, SymbologyMarket>,
): FundingEvent => {
  const market = marketsBySymbolId.get(wire.market_id);
  if (market === undefined) {
    throw new Error(
      `unknown market ${wire.market_id.toString()} in funding history; symbology cache missing entry`,
    );
  } else {
    return {
      accrued: toDnumUsdc(wire.funding_accrued),
      id: wire.stream_seq,
      payment: toDnumUsdc(wire.funding_delta),
      subaccountId: wire.subaccount_id,
      symbol: market.symbol,
      symbolId: wire.market_id,
      timestamp: dateFromUnixNs(wire.event_unix_ns),
    };
  }
};

export const toFundingHistoryPage = (
  wire: FundingHistoryEvent,
  marketsBySymbolId: ReadonlyMap<number, SymbologyMarket>,
): FundingHistoryPage => ({
  events: wire.events.map((event) => toFundingEvent(event, marketsBySymbolId)),
  nextCursor: wire.next_cursor,
});
