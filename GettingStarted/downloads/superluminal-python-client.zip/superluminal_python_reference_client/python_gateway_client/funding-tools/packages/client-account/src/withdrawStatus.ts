import type { WithdrawStatusMessage } from "./wire/wireSchema";

// Consumer-facing settlement result for a `signed_withdraw`. The wire form
// (snake_case, numeric `status`) stays internal to the account stream; this is
// the normalized shape the trading-app sees. `clientInstructionId` matches the
// `request_id_64` the client supplied, so consumers correlate by equality. The
// `settled`/`failed` split makes the failure-only fields (`rawStatus`,
// `errorCode`) and the success-only `onchainSignature` unrepresentable in the
// wrong state.
export type WithdrawStatus = {
  readonly clientInstructionId: bigint;
  readonly subaccountId: bigint;
  readonly seq: bigint;
} & (
  | { readonly kind: "settled"; readonly onchainSignature: string | undefined }
  | {
      readonly kind: "failed";
      readonly rawStatus: number;
      readonly errorCode: number | undefined;
    }
);

// Map a wire `WithdrawStatus` to its domain form at the subscription fan-out.
// A withdraw settled successfully only when it finalized on-chain
// (`status === 0`) AND carries no error (`error_code` 0/absent); a finalized
// status with a non-zero `error_code` means the withdraw was rejected and the
// server rolled back the debit, so it is a failure.  This mirrors both
// `risk_view::onWithdrawStatus` and the ledger path in `applyWithdrawStatus`.
export const toWithdrawStatus = (
  message: WithdrawStatusMessage,
): WithdrawStatus => {
  const base = {
    clientInstructionId: message.client_instruction_id,
    seq: message.seq,
    subaccountId: message.subaccount_id,
  };
  if (
    message.status === 0 &&
    (message.error_code === undefined || message.error_code === 0)
  ) {
    return {
      ...base,
      kind: "settled",
      onchainSignature: message.onchain_signature,
    };
  } else {
    return {
      ...base,
      errorCode: message.error_code,
      kind: "failed",
      rawStatus: message.status,
    };
  }
};
