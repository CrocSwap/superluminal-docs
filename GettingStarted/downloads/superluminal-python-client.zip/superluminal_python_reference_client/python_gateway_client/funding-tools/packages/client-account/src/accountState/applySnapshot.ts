import type { AccountSnapshotMessage } from "../wire/wireSchema";
import type { Subaccount } from "./subaccount";
import {
  positionAdjustedCollateralBalance,
  positionToInternal,
} from "./subaccount";

// The snapshot is authoritative for the subaccounts it carries; replace
// their state wholesale.  Subaccounts not in the snapshot are left
// untouched (the gateway re-sends a snapshot per subscribe).  The
// persistor applies `WithdrawStatus` debits before the snapshot is taken.
// Wire collateral is effective collateral, so normalize its current position
// fee/funding terms before the live state machine applies later deltas.
export const applySnapshot = (
  subaccounts: Map<bigint, Subaccount>,
  message: AccountSnapshotMessage,
): bigint[] =>
  message.subaccounts.map((wireSub) => {
    const positions = wireSub.positions.map(positionToInternal);
    const next: Subaccount = {
      collateralBalance: positionAdjustedCollateralBalance(
        wireSub.collateral_balance ?? 0n,
        positions,
      ),
      // The snapshot's realized PnL already reflects every settled fill, so
      // start with no pending realized; live `FillSettled` events after this
      // baseline accrue on top.
      pendingRealized: [],
      positions: new Map(
        positions.map((position) => [position.symbolId, position]),
      ),
    };
    subaccounts.set(wireSub.subaccount_id, next);
    return wireSub.subaccount_id;
  });
