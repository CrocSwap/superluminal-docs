import {
  CANCEL_DOMAIN_V2,
  CANCEL_V2_LEN,
  DEPOSIT_VAULT_DOMAIN_V1,
  DEPOSIT_VAULT_V1_LEN,
  encodeContractCancelProofV2,
  WITHDRAW_DOMAIN_V1,
  WITHDRAW_VAULT_DOMAIN_V1,
  WITHDRAW_VAULT_V1_LEN,
} from "@aethon/client-protocol/signedWire";

// Construction of the exact bytes the gateway signs and verifies for each
// signed command. Kept separate from the socket lifecycle in `live.ts`: these
// are pure byte/enum transforms. The `submit*` / `cancelOrder` methods build
// the proof envelope, hand the sign-message here to the signer, then re-encode
// the proof with the real signature before sending -- this module owns only the
// "what gets signed" half.

// Length of the payload-prefix portion of `ContractWithdrawProofV1`: the
// 234-byte wire layout is
// `sender_pubkey(32) || partition_id(2) || subaccount_id(8) || iat(8) ||
// exp(8) || withdraw_bytes(80) || signer_pubkey(32) || signature(64)`, and the
// gateway signs / verifies over the first 138 bytes (everything before
// signer_pubkey + signature), prefixed with the domain separator. See
// `dfba_gateway/signedproof/signedproof.go:473-475`.
const WITHDRAW_PROOF_PAYLOAD_PREFIX_LEN = 138;

// Same posture for `ContractCancelProofV2`: the IDL has no `cancel_payload_v2`
// analogue of `order_payload_v1`, so we splice the envelope by encoding a
// placeholder-signature proof and taking the leading payload bytes (everything
// before signer_pubkey(32) + signature(64)).
const CANCEL_SIGNED_PAYLOAD_LEN = 58 + CANCEL_V2_LEN;

const PLACEHOLDER_SIGNER = new Uint8Array(32);
const PLACEHOLDER_SIGNATURE = new Uint8Array(64);

// Splice the gateway's signed-payload prefix: `domain || 0x00 || proof[:len]`.
// The codegen emits a `*_payload` sign-message helper only for orders; withdraw
// and cancel have no analogue, so both hand-splice the identical envelope --
// this is the one place that pattern lives.
const buildSignedPayloadPrefix = (
  domain: Uint8Array,
  proofBytes: Uint8Array,
  prefixLen: number,
): Uint8Array => {
  const out = new Uint8Array(domain.length + 1 + prefixLen);
  out.set(domain, 0);
  out[domain.length] = 0x00;
  out.set(proofBytes.subarray(0, prefixLen), domain.length + 1);
  return out;
};

export const buildWithdrawSignMessage = (proofBytes: Uint8Array): Uint8Array =>
  buildSignedPayloadPrefix(
    WITHDRAW_DOMAIN_V1,
    proofBytes,
    WITHDRAW_PROOF_PAYLOAD_PREFIX_LEN,
  );

// The deposit/withdraw-vault proofs share the 58-byte envelope prefix
// (`sender_pubkey(32) || partition_id(2) || subaccount_id(8) || iat(8) ||
// exp(8)`, the same `signedProofPayloadOffset` the gateway uses in
// `dfba_gateway/signedproof/signedproof.go`) followed by the 48-byte inner
// vault payload; the gateway signs / verifies over that 106-byte prefix,
// domain-separated. Both ops reuse the identical splice, differing only in the
// domain constant.
const SIGNED_PROOF_PAYLOAD_OFFSET = 58;
const DEPOSIT_VAULT_PROOF_PAYLOAD_PREFIX_LEN =
  SIGNED_PROOF_PAYLOAD_OFFSET + DEPOSIT_VAULT_V1_LEN;
const WITHDRAW_VAULT_PROOF_PAYLOAD_PREFIX_LEN =
  SIGNED_PROOF_PAYLOAD_OFFSET + WITHDRAW_VAULT_V1_LEN;

export const buildDepositVaultSignMessage = (
  proofBytes: Uint8Array,
): Uint8Array =>
  buildSignedPayloadPrefix(
    DEPOSIT_VAULT_DOMAIN_V1,
    proofBytes,
    DEPOSIT_VAULT_PROOF_PAYLOAD_PREFIX_LEN,
  );

export const buildWithdrawVaultSignMessage = (
  proofBytes: Uint8Array,
): Uint8Array =>
  buildSignedPayloadPrefix(
    WITHDRAW_VAULT_DOMAIN_V1,
    proofBytes,
    WITHDRAW_VAULT_PROOF_PAYLOAD_PREFIX_LEN,
  );

// Build the bytes the gateway expects under `signed_cancel.msg_b64`. The
// on-chain validator parses
//   domain || 0x00 || sender_pubkey || partition_id || subaccount_id
//          || iat || exp || cancel_bytes
// out of the signed payload (see `contracts/svm/src/lib.rs`'s
// `parse_cancel_payload_v2_message`), but the codegen helper
// `buildCancelSignMessageV2` only signs `domain || 0x00 || cancel_bytes` -- so
// we encode a placeholder-signature `ContractCancelProofV2` and slice off the
// trailing 96 bytes (signer + sig) to recover the payload prefix the on-chain
// parser expects, without duplicating the field layout here.
export const buildCancelSignedMessage = (payload: {
  cancelBytes: Uint8Array;
  exp: bigint;
  iat: bigint;
  partitionId: number;
  senderPubkey: Uint8Array;
  subaccountId: bigint;
}): Uint8Array => {
  const proofBytes = encodeContractCancelProofV2({
    cancelBytes: payload.cancelBytes,
    exp: payload.exp,
    iat: payload.iat,
    partitionId: payload.partitionId,
    senderPubkey: payload.senderPubkey,
    signature: PLACEHOLDER_SIGNATURE,
    signerPubkey: PLACEHOLDER_SIGNER,
    subaccountId: payload.subaccountId,
  });
  return buildSignedPayloadPrefix(
    CANCEL_DOMAIN_V2,
    proofBytes,
    CANCEL_SIGNED_PAYLOAD_LEN,
  );
};

// Per-TIF order expiry on the wire. The matcher uses `exp` as the order's
// lifetime, separate from the gateway envelope's `iat+5s` freshness window.
// IOC: 5s matches the matcher's hard cap (effective_expiry_sec_) so the signed
// bytes are honest. GTC: uint64::MAX overflows the matcher's seconds->ns guard,
// so expiry tracking is skipped and the order rests indefinitely.
const IOC_EXP_TTL_SECONDS = 5n;
const NEVER_EXPIRES_EXP = (1n << 64n) - 1n;

export const orderExpFor = (iat: bigint, tif: "gtc" | "ioc"): bigint => {
  switch (tif) {
    case "gtc": {
      return NEVER_EXPIRES_EXP;
    }
    case "ioc": {
      return iat + IOC_EXP_TTL_SECONDS;
    }
  }
};

// Per-orderType wire-enum derivation. `order_type` is pinned by
// `protocol/idl/signed_wire.json` (`enums.order_type`). `role` is hardcoded to
// taker(1) for every client-submitted order: Aethon's matching engine is a
// dual-flow batch auction, so the auction itself classifies liquidity at
// clearing time -- the wire role field is not the client's call to make.
export const orderTypeWireConfig = (
  orderType: "market" | "limit" | "mark-to-mid",
): { orderType: number; role: number } => {
  switch (orderType) {
    case "limit": {
      return { orderType: 0, role: 1 };
    }
    case "mark-to-mid": {
      return { orderType: 1, role: 1 };
    }
    case "market": {
      return { orderType: 2, role: 1 };
    }
  }
};

export const tifWireValue = (tif: "gtc" | "ioc"): number => {
  switch (tif) {
    case "gtc": {
      return 1;
    }
    case "ioc": {
      return 0;
    }
  }
};

// 95-byte payloads (and 64-byte ed25519 signatures) sit well below the
// argument-spread limit so the `btoa(String.fromCharCode(...))` round-trip is
// safe -- the `authSession` already relies on the same pattern.
export const base64Encode = (bytes: Uint8Array): string =>
  btoa(String.fromCharCode(...bytes));
