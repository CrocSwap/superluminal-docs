import { Err, Ok, Result } from "@cprussin/option-result";
import type { SubmitBracketOrderError as SubmitBracketOrderFailure } from "../submitBracketOrderError";
import { SubmitBracketOrderError } from "../submitBracketOrderError";
import type { SubmitOrderError } from "../submitOrderError";
import type { EncodedConditionalOrder } from "../wire/encodeConditionalOrderWire";
import { cancelConditionalOrder } from "./cancelConditionalOrder";
import type { SignedCommandContext } from "./signedCommand";
import {
  prepareConditionalOrder,
  sendPreparedConditionalOrder,
} from "./submitConditionalOrder";
import type { SubmitOrderParams } from "./submitOrder";
import { prepareOrder, sendPreparedConditionalParent } from "./submitOrder";

type SubmitBracketOrderWireCommon = Readonly<{
  activationMode: "parent-fill" | "immediate";
  conditional: EncodedConditionalOrder;
  expiresAtUnixS: bigint;
  subaccountId: bigint;
}>;

export type SubmitBracketOrderWireParams = SubmitBracketOrderWireCommon &
  (
    | Readonly<{ activationMode: "immediate" }>
    | Readonly<{
        activationMode: "parent-fill";
        order: SubmitOrderParams;
      }>
  );

type ParentFillBracketWireParams = Extract<
  SubmitBracketOrderWireParams,
  { activationMode: "parent-fill" }
>;

const cleanupUnsentParent = (
  ctx: SignedCommandContext,
  params: ParentFillBracketWireParams,
  groupId: bigint,
  parentError: SubmitOrderError,
): Promise<Result<true, SubmitBracketOrderFailure>> =>
  cancelConditionalOrder(ctx, {
    groupId,
    subaccountId: params.order.subaccountId,
    symbol: params.order.symbol,
  }).then((cleanupResult) =>
    cleanupResult.match<Result<true, SubmitBracketOrderFailure>>({
      Err: (cleanupError) =>
        Err<true, SubmitBracketOrderFailure>(
          SubmitBracketOrderError.Cleanup(parentError, cleanupError),
        ),
      Ok: () =>
        Err<true, SubmitBracketOrderFailure>(
          SubmitBracketOrderError.Parent(parentError),
        ),
    }),
  );

const resolveParent = (
  ctx: SignedCommandContext,
  socket: WebSocket,
  params: ParentFillBracketWireParams,
  groupId: bigint,
  parentRequestId64: bigint,
): Promise<Result<true, SubmitBracketOrderFailure>> =>
  prepareOrder(ctx, params.order, parentRequestId64).then((preparedResult) =>
    preparedResult.match({
      Err: (parentError) =>
        cleanupUnsentParent(ctx, params, groupId, parentError),
      Ok: (parent) =>
        sendPreparedConditionalParent(socket, parent, groupId).then(
          (parentResult) =>
            parentResult.match({
              Err: (parentError) =>
                Promise.resolve(
                  Err(SubmitBracketOrderError.Parent(parentError)),
                ),
              Ok: () => Promise.resolve(Ok(true)),
            }),
        ),
    }),
  );

const submitPreparedBracket = (
  ctx: SignedCommandContext,
  socket: WebSocket,
  params: SubmitBracketOrderWireParams,
  groupRequestId64: bigint,
): Promise<Result<true, SubmitBracketOrderFailure>> =>
  prepareConditionalOrder(
    ctx,
    {
      ...params.conditional,
      activationMode: params.activationMode,
      expiresAtUnixS: params.expiresAtUnixS,
      subaccountId: params.subaccountId,
    },
    groupRequestId64,
  ).then((groupResult) =>
    groupResult
      .mapErr(
        (error): SubmitBracketOrderFailure =>
          SubmitBracketOrderError.Conditional(error),
      )
      .andThenAsync((group) =>
        sendPreparedConditionalOrder(socket, group).then((approvalResult) =>
          approvalResult
            .mapErr(
              (error): SubmitBracketOrderFailure =>
                SubmitBracketOrderError.Conditional(error),
            )
            .andThenAsync((groupId) => {
              switch (params.activationMode) {
                case "immediate":
                  return Promise.resolve(Ok(true));
                case "parent-fill":
                  return resolveParent(
                    ctx,
                    socket,
                    params,
                    groupId,
                    ctx.generateRequestId(),
                  );
              }
            }),
        ),
      ),
  );

export const submitBracketOrder = (
  ctx: SignedCommandContext,
  params: SubmitBracketOrderWireParams,
): Promise<Result<true, SubmitBracketOrderFailure>> => {
  const groupRequestId64 = ctx.generateRequestId();
  return Result.wrapAsync(ctx.ensureAuthenticated()).then((sessionResult) =>
    sessionResult
      .mapErr(
        (): SubmitBracketOrderFailure => SubmitBracketOrderError.Disconnected(),
      )
      .andThenAsync((socket) =>
        submitPreparedBracket(ctx, socket, params, groupRequestId64),
      ),
  );
};
