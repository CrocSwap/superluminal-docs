import { errorMessage } from "@aethon/client-protocol/errorMessage";

// Discriminant for `SubmitWithdrawError`. Owns its own enum. `SignedOut` is
// produced by the `useWithdraw` hook, the rest by the account client. There is
// no `Timeout`: the gateway is silent on withdraw success, so grace-period
// silence resolves `Ok`, never a timeout error.
export enum SubmitWithdrawErrorType {
  Validation,
  Disconnected,
  SignerRejected,
  Rejected,
  SignedOut,
}

// Typed failure channel for `AccountClient.submitWithdraw`. The destination EVM
// address is validated before any I/O (`Validation`); then the signed command
// can fail because the session is gone (`Disconnected`), the signer refused
// (`SignerRejected`), or the gateway rejected the withdraw (`Rejected`).
export const SubmitWithdrawError = {
  Disconnected: () => ({ type: SubmitWithdrawErrorType.Disconnected as const }),
  Rejected: (reason: string) => ({
    reason,
    type: SubmitWithdrawErrorType.Rejected as const,
  }),
  SignedOut: () => ({ type: SubmitWithdrawErrorType.SignedOut as const }),
  SignerRejected: (cause: unknown) => ({
    cause,
    type: SubmitWithdrawErrorType.SignerRejected as const,
  }),
  Validation: (message: string) => ({
    message,
    type: SubmitWithdrawErrorType.Validation as const,
  }),
};

export type SubmitWithdrawError = ReturnType<
  (typeof SubmitWithdrawError)[keyof typeof SubmitWithdrawError]
>;

export const displaySubmitWithdrawError = (
  error: SubmitWithdrawError,
): string => {
  switch (error.type) {
    case SubmitWithdrawErrorType.Validation:
      return error.message;
    case SubmitWithdrawErrorType.Disconnected:
      return "withdraw session disconnected";
    case SubmitWithdrawErrorType.SignerRejected:
      return errorMessage(error.cause, "signer rejected withdraw");
    case SubmitWithdrawErrorType.Rejected:
      return error.reason;
    case SubmitWithdrawErrorType.SignedOut:
      return "Sign in to withdraw";
  }
};
