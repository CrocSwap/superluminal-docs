import {
  cancelRejectReason,
  displayRejectReason,
  orderRejectReason,
} from "@aethon/client-protocol/rejectReason";
import type { Option, Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import { z } from "zod";
import { tryParseJson } from "../wire/tryParseJson";

// Request/response correlation over the authenticated WS: each waiter listens
// for the terminal frame(s) of one in-flight command and resolves a
// `Result<true, E>` in the caller's own typed error `E`. The waiter is
// parametrised by the caller's error constructors (`rejected` / `disconnected`
// / `timeout`) so the command-ack protocol stays generic while each method owns
// its enum. Listeners + timer are torn down on settle so a late frame can't
// leak into a future caller's wait.

// Terminal-failure constructors a socket waiter routes its three outcomes
// through, in the caller's own error type.
type AckErr<E extends NonNullable<unknown>> = {
  rejected: (reason: string) => E;
  disconnected: () => E;
  timeout: () => E;
};

// Mirrors `dfba_gateway.ClientAck`: post-auth command responses on the
// authenticated WS are typed `"ack"` (lowercase) with one of three statuses.
// `Ack` (capitalised) is reserved for the pre-auth handshake and is filtered
// out by the type literal here.
const commandAckSchema = z.object({
  reason: z.string().optional(),
  request_id: z.string().optional(),
  status: z.enum(["accepted", "rejected", "busy"]),
  type: z.literal("ack"),
});

const commandAckIsUncorrelated = (
  ack: z.infer<typeof commandAckSchema>,
): boolean => ack.request_id === undefined;

// `signed_cancel` mirrors `signed_order`'s "no generic ack on success" shape:
// the gateway only emits an `ack` on failure (`rejected` / `busy`), while a
// successful cancel surfaces later as a `CancelAck` event on the live account
// stream with the matching `external_order_id`.  These two (plus the
// typed-but-success-omitting `ack`) are the wait-for-this-set terminal signals.
const cancelAckSchema = z.object({
  external_order_id: z.number().int().nonnegative().safe().optional(),
  type: z.literal("CancelAck"),
});

const conditionalCancelledSchema = z.object({
  client_instruction_id: z.union([z.number(), z.string()]),
  group_external_order_id: z.union([z.number(), z.string()]),
  type: z.literal("ConditionalCancelled"),
  version: z.literal(1),
});

const conditionalCancelRejectedSchema = z.object({
  client_instruction_id: z.union([z.number(), z.string()]),
  external_order_id: z.union([z.number(), z.string()]),
  reason: z.number(),
  type: z.literal("CancelReject"),
});

// `signed_order` doesn't get a generic `ack` back -- the gateway streams the
// live order lifecycle directly (`OrderAccepted` on accept, then `Fill` /
// `FillSettled` as it executes, or `OrderReject` on rejection).  Each frame
// echoes the order's `client_instruction_id`, so `awaitOrderResolution`
// resolves on the first accept/reject *matching its request id*; everything
// after (Fill / FillSettled) is the live account stream's job and rides the
// same socket.
const orderAcceptedSchema = z.object({
  client_instruction_id: z.string().regex(/^\d+$/).optional(),
  type: z.literal("OrderAccepted"),
});
const conditionalApprovedSchema = z.object({
  client_instruction_id: z.union([z.number(), z.string()]).optional(),
  group_external_order_id: z.union([z.number(), z.string()]),
  type: z.literal("ConditionalApproved"),
  version: z.literal(1),
});
const orderRejectedSchema = z.object({
  client_instruction_id: z.string().regex(/^\d+$/).optional(),
  reason: z.union([z.string(), z.number()]).optional(),
  type: z.literal("OrderReject"),
});

const displayOrderRejectReason = (
  reason: string | number | undefined,
): string =>
  typeof reason === "number"
    ? displayRejectReason(orderRejectReason(reason))
    : (reason ?? "order rejected");

const userDepositAddressStatusSchema = z.object({
  subaccount_id: z.union([z.number(), z.string()]).optional(),
  type: z.literal("UserDepositAddressStatus"),
});

// Upper bound on how long we'll sit waiting for an ack before giving up and
// surfacing the failure to the UI.  10s is generous enough to absorb a slow
// gateway round-trip + sequencer hop without locking the user out of retrying
// when the ack genuinely never arrives.
const ACK_TIMEOUT_MS = 10_000;

// Generic socket waiter parametrised by the `match` predicate.  The predicate
// inspects each incoming JSON-parsed message and returns `Ok` / `Err` for a
// terminal outcome or `undefined` to keep waiting.  A socket close routes
// through `onClose`, the deadline through `onTimeout` -- both in the caller's
// own error type.
const awaitSocketResolution = <
  T extends NonNullable<unknown>,
  E extends NonNullable<unknown>,
>(
  socket: WebSocket,
  match: (raw: unknown) => Result<T, E> | undefined,
  onClose: () => E,
  onTimeout: () => E,
): Promise<Result<T, E>> =>
  new Promise<Result<T, E>>((resolve) => {
    const onMessage = (event: MessageEvent) => {
      tryParseJson(String(event.data)).match({
        None: () => {
          // Not JSON, so not a terminal frame for this wait; keep waiting.
        },
        Some: (rawJson) => {
          const outcome = match(rawJson);
          if (outcome !== undefined) {
            cleanup();
            resolve(outcome);
          }
        },
      });
    };
    const onCloseListener = () => {
      cleanup();
      resolve(Err<T, E>(onClose()));
    };
    const timeoutHandle = setTimeout(() => {
      cleanup();
      resolve(Err<T, E>(onTimeout()));
    }, ACK_TIMEOUT_MS);
    const cleanup = () => {
      clearTimeout(timeoutHandle);
      socket.removeEventListener("message", onMessage);
      socket.removeEventListener("close", onCloseListener);
    };
    socket.addEventListener("message", onMessage);
    socket.addEventListener("close", onCloseListener);
  });

export const awaitNextCommandAck = <E extends NonNullable<unknown>>(
  socket: WebSocket,
  err: AckErr<E>,
): Promise<Result<true, E>> =>
  awaitSocketResolution(
    socket,
    (raw) => {
      const parsed = commandAckSchema.safeParse(raw);
      if (parsed.success && commandAckIsUncorrelated(parsed.data)) {
        const { status, reason } = parsed.data;
        return status === "accepted"
          ? Ok(true)
          : Err(err.rejected(reason ?? status));
      } else {
        return undefined;
      }
    },
    err.disconnected,
    err.timeout,
  );

// `user_deposit_address` has no successful generic ack. The EVM keeper emits
// this status after registering its watch, and the gateway forwards it to the
// authenticated account stream. A gateway-level reject remains an ack.
export const awaitUserDepositAddressResolution = <
  E extends NonNullable<unknown>,
>(
  socket: WebSocket,
  subaccountId: bigint,
  err: AckErr<E>,
): Promise<Result<true, E>> =>
  awaitSocketResolution(
    socket,
    (raw) => {
      const status = userDepositAddressStatusSchema.safeParse(raw);
      if (
        status.success &&
        wireIdToBigint(status.data.subaccount_id) === subaccountId
      ) {
        return Ok(true);
      } else {
        const ack = commandAckSchema.safeParse(raw);
        return ack.success &&
          commandAckIsUncorrelated(ack.data) &&
          ack.data.status !== "accepted"
          ? Err(err.rejected(ack.data.reason ?? ack.data.status))
          : undefined;
      }
    },
    err.disconnected,
    err.timeout,
  );

// Reject reason for a post-auth command `ack`, or `undefined` for a
// non-JSON frame (`None`) / accepted ack / non-ack frame.  Request-scoped
// waiters pass `expectedRequestId`; a legacy uncorrelated reject ack still
// applies, while a reject with a different `request_id` belongs to another
// in-flight request and is ignored.
export const commandAckRejectReason = (
  rawJson: Option<NonNullable<unknown>>,
  expectedRequestId?: string | undefined,
): string | undefined =>
  rawJson.match({
    None: () => undefined,
    Some: (raw) => {
      const parsed = commandAckSchema.safeParse(raw);
      if (parsed.success && parsed.data.status !== "accepted") {
        const ackRequestId = parsed.data.request_id;
        return ackRequestId === undefined || ackRequestId === expectedRequestId
          ? (parsed.data.reason ?? parsed.data.status)
          : undefined;
      } else {
        return undefined;
      }
    },
  });

// Withdraw-ack failure constructors: withdraw has no timeout error because the
// gateway is silent on success, so grace-period silence resolves `Ok`.
type WithdrawAckErr<E extends NonNullable<unknown>> = {
  rejected: (reason: string) => E;
  disconnected: () => E;
};

// Waits for an ack with a bounded grace period.  Used for signed_withdraw,
// where the gateway only emits an ack on rejection or busy
// (`dfba_gateway/signed_message_handlers.go:682-703`) and the happy path is
// silence.  Returns `Ok(true)` if no ack arrives within `graceMs`,
// `Err(err.rejected(...))` for a rejection ack, and `Err(err.disconnected())`
// if the socket closes first.  Listener and timer are both torn down on settle
// so a late ack can't leak into a future caller's wait.
export const awaitWithdrawAck = <E extends NonNullable<unknown>>(
  socket: WebSocket,
  graceMs: number,
  err: WithdrawAckErr<E>,
): Promise<Result<true, E>> =>
  new Promise<Result<true, E>>((resolve) => {
    let settled = false;
    const settle = (r: Result<true, E>) => {
      if (!settled) {
        settled = true;
        cleanup();
        resolve(r);
      }
    };
    const onMessage = (event: MessageEvent) => {
      tryParseJson(String(event.data)).match({
        None: () => {
          // Not JSON, so not an ack; keep waiting out the grace period.
        },
        Some: (rawJson) => {
          const parsed = commandAckSchema.safeParse(rawJson);
          if (parsed.success && commandAckIsUncorrelated(parsed.data)) {
            const { status, reason } = parsed.data;
            settle(
              status === "accepted"
                ? Ok(true)
                : Err(err.rejected(reason ?? status)),
            );
          }
        },
      });
    };
    const onClose = () => {
      settle(Err(err.disconnected()));
    };
    const timeoutId = setTimeout(() => {
      settle(Ok(true));
    }, graceMs);
    const cleanup = () => {
      clearTimeout(timeoutId);
      socket.removeEventListener("message", onMessage);
      socket.removeEventListener("close", onClose);
    };
    socket.addEventListener("message", onMessage);
    socket.addEventListener("close", onClose);
  });

const wireIdToBigint = (
  wireId: number | string | undefined,
): bigint | undefined => {
  if (wireId === undefined) {
    return undefined;
  } else {
    return BigInt(wireId);
  }
};

const clientInstructionIdToBigint = (
  wireId: string | undefined,
): bigint | undefined => {
  if (wireId === undefined) {
    return undefined;
  } else {
    return BigInt(wireId);
  }
};

const externalOrderIdToBigint = (
  wireId: number | undefined,
): bigint | undefined => (wireId === undefined ? undefined : BigInt(wireId));

// Signed-order lifecycle waiter for the order carrying `requestId64` (the
// client-generated `request_id_64`, echoed back as `client_instruction_id`).
// Resolves on whichever of the following arrives first *for this order*:
//   - `OrderAccepted` whose `client_instruction_id` matches (Ok) -- sequencer-
//     confirmed accept.  Lifecycle frames for other in-flight orders are
//     ignored so a concurrent submission can't race-complete ours.
//   - `OrderReject` whose `client_instruction_id` matches (Err) -- sequencer-
//     confirmed reject.
//   - uncorrelated `ack` with a non-accepted status (Err) -- gateway-level
//     fast-fail before the order reaches the sequencer (e.g. "bad price").
//     ACKs carrying string `request_id` belong to paginated requests and are
//     ignored here.
// Downstream `Fill` / `FillSettled` updates are handled by the live account
// stream and don't terminate this wait.
export const awaitOrderResolution = <E extends NonNullable<unknown>>(
  socket: WebSocket,
  requestId64: bigint,
  err: AckErr<E>,
): Promise<Result<true, E>> =>
  awaitSocketResolution(
    socket,
    (raw) => {
      const accepted = orderAcceptedSchema.safeParse(raw);
      if (
        accepted.success &&
        clientInstructionIdToBigint(accepted.data.client_instruction_id) ===
          requestId64
      ) {
        return Ok(true);
      } else {
        const rejected = orderRejectedSchema.safeParse(raw);
        if (
          rejected.success &&
          clientInstructionIdToBigint(rejected.data.client_instruction_id) ===
            requestId64
        ) {
          return Err(
            err.rejected(displayOrderRejectReason(rejected.data.reason)),
          );
        } else {
          const ack = commandAckSchema.safeParse(raw);
          return ack.success &&
            commandAckIsUncorrelated(ack.data) &&
            ack.data.status !== "accepted"
            ? Err(err.rejected(ack.data.reason ?? ack.data.status))
            : undefined;
        }
      }
    },
    err.disconnected,
    err.timeout,
  );

export const awaitConditionalOrderResolution = <E extends NonNullable<unknown>>(
  socket: WebSocket,
  requestId64: bigint,
  err: AckErr<E>,
): Promise<Result<bigint, E>> =>
  awaitSocketResolution(
    socket,
    (raw) => {
      const approved = conditionalApprovedSchema.safeParse(raw);
      if (
        approved.success &&
        wireIdToBigint(approved.data.client_instruction_id) === requestId64
      ) {
        return Ok(BigInt(approved.data.group_external_order_id));
      } else {
        const rejected = orderRejectedSchema.safeParse(raw);
        if (
          rejected.success &&
          wireIdToBigint(rejected.data.client_instruction_id) === requestId64
        ) {
          return Err(
            err.rejected(displayOrderRejectReason(rejected.data.reason)),
          );
        } else {
          const ack = commandAckSchema.safeParse(raw);
          return ack.success &&
            commandAckIsUncorrelated(ack.data) &&
            ack.data.status !== "accepted"
            ? Err(err.rejected(ack.data.reason ?? ack.data.status))
            : undefined;
        }
      }
    },
    err.disconnected,
    err.timeout,
  );

// Signed-cancel lifecycle waiter.  Resolves on whichever of:
//   - `CancelAck` for the requested `externalOrderId` (Ok) -- sequencer-
//     confirmed cancel.  Other `CancelAck`s (different orders) are ignored so a
//     separate cancel in flight doesn't race-complete ours.
//   - `ack` with a non-accepted status (Err) -- gateway-level reject (the
//     gateway only emits an `ack` on failure for signed_cancel; successful
//     cancels surface via the live-stream `CancelAck`).
// The matcher-side `CancelReject` is not currently sent by the gateway account
// stream the trading-app subscribes to; gateway-level `ack` covers the
// fast-fail path.
export const awaitCancelResolution = <E extends NonNullable<unknown>>(
  socket: WebSocket,
  externalOrderId: bigint,
  err: AckErr<E>,
): Promise<Result<true, E>> =>
  awaitSocketResolution(
    socket,
    (raw) => {
      const cancelAck = cancelAckSchema.safeParse(raw);
      if (cancelAck.success) {
        return externalOrderIdToBigint(cancelAck.data.external_order_id) ===
          externalOrderId
          ? Ok(true)
          : undefined;
      } else {
        const ack = commandAckSchema.safeParse(raw);
        return ack.success &&
          commandAckIsUncorrelated(ack.data) &&
          ack.data.status !== "accepted"
          ? Err(err.rejected(ack.data.reason ?? ack.data.status))
          : undefined;
      }
    },
    err.disconnected,
    err.timeout,
  );

export const awaitConditionalCancelResolution = <
  E extends NonNullable<unknown>,
>(
  socket: WebSocket,
  requestId64: bigint,
  groupId: bigint,
  err: AckErr<E>,
): Promise<Result<true, E>> =>
  awaitSocketResolution(
    socket,
    (raw) => {
      const cancelled = conditionalCancelledSchema.safeParse(raw);
      if (
        cancelled.success &&
        wireIdToBigint(cancelled.data.client_instruction_id) === requestId64 &&
        wireIdToBigint(cancelled.data.group_external_order_id) === groupId
      ) {
        return Ok(true);
      } else {
        const rejected = conditionalCancelRejectedSchema.safeParse(raw);
        if (
          rejected.success &&
          wireIdToBigint(rejected.data.client_instruction_id) === requestId64 &&
          wireIdToBigint(rejected.data.external_order_id) === groupId
        ) {
          return Err(
            err.rejected(
              displayRejectReason(cancelRejectReason(rejected.data.reason)),
            ),
          );
        } else {
          const ack = commandAckSchema.safeParse(raw);
          return ack.success &&
            commandAckIsUncorrelated(ack.data) &&
            ack.data.status !== "accepted"
            ? Err(err.rejected(ack.data.reason ?? ack.data.status))
            : undefined;
        }
      }
    },
    err.disconnected,
    err.timeout,
  );
