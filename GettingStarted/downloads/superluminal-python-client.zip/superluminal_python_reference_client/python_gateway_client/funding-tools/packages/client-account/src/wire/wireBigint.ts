import { z } from "zod";

// General large wire integers land in `bigint`. Fields that the gateway
// explicitly exposes in dual number/string form use this schema. The dedicated
// order-identifier schemas below enforce their stable JSON types.
export const wireBigint = z
  .union([z.number(), z.string().regex(/^-?\d+$/)])
  .transform((value) =>
    typeof value === "string" ? BigInt(value) : BigInt(Math.round(value)),
  );

export const wireDecimalUint64 = z
  .string()
  .regex(/^\d+$/)
  .transform((value) => BigInt(value))
  .refine((value) => value <= 0xff_ff_ff_ff_ff_ff_ff_ffn);

export const wireExternalOrderId = z
  .number()
  .int()
  .positive()
  .safe()
  .transform((value) => BigInt(value));

export const wireOptionalExternalOrderId = z
  .number()
  .int()
  .nonnegative()
  .safe()
  .transform((value) => BigInt(value));
