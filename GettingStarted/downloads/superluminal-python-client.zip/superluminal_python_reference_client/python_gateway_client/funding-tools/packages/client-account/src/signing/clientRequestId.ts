// Generates a public-client-safe `request_id_64` for a signed gateway
// command. Bit 63 is reserved for system use across every signed-command
// variant, so a u64 with bit 63 set would be rejected at the gateway. The
// echoed `client_instruction_id` is a decimal JSON string, so all remaining
// 63 bits round-trip losslessly.
//
let lastTimestampRequestId = 0n;

export const generateTimestampRequestId64 = (
  nowMilliseconds: () => number = Date.now,
): bigint => {
  const candidate = BigInt(nowMilliseconds());
  const requestId =
    candidate > lastTimestampRequestId
      ? candidate
      : lastTimestampRequestId + 1n;
  lastTimestampRequestId = requestId;
  return requestId;
};

// The default source uses an epoch-millisecond timestamp and increments within
// a process when multiple signed requests share a millisecond. The injectable
// source remains available for deterministic tests.
const PUBLIC_REQUEST_ID_MASK = 0x7f_ff_ff_ff_ff_ff_ff_ffn;

// `crypto.getRandomValues` requires an `ArrayBufferView<ArrayBuffer>`; since
// TS 5.7 the typed-array element type is generic over `ArrayBufferLike` (which
// includes `SharedArrayBuffer`), so the buffer must be pinned to `ArrayBuffer`.
// `new BigUint64Array(1)` produces exactly `BigUint64Array<ArrayBuffer>`.
const defaultRng = (buf: BigUint64Array<ArrayBuffer>): void => {
  buf[0] = generateTimestampRequestId64();
};

export const generateClientRequestId64 = (
  rng: (buf: BigUint64Array<ArrayBuffer>) => void = defaultRng,
): bigint => {
  const buf = new BigUint64Array(1);
  rng(buf);
  const value = buf[0];
  // `buf` is constructed with length 1, so index 0 always exists; the check
  // only satisfies `noUncheckedIndexedAccess`, which cannot see the length.
  if (value === undefined) {
    throw new Error("BigUint64Array(1) yielded no element");
  } else {
    return value & PUBLIC_REQUEST_ID_MASK;
  }
};
