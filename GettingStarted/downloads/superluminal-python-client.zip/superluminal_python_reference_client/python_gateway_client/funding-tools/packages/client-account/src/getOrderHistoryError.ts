import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

// Discriminant for `GetOrderHistoryError`. Owns its own enum; the symbology
// failure wraps a typed `SymbologyError` (symbology must load to resolve the
// wire symbol ids in the response back to human names).
export enum GetOrderHistoryErrorType {
  Symbology,
  Disconnected,
  Rejected,
  Timeout,
  Unexpected,
}

// Typed failure channel for `AccountClient.getOrderHistory`. The request rides
// the authenticated session and needs symbology loaded to decode the page: a
// symbology fetch failure threads up as `Symbology`, an unavailable/closed
// session as `Disconnected`, a gateway `ack rejected` as `Rejected`, and no
// answer before the deadline as `Timeout`. `Unexpected` is the rejection-lifter
// target for the `useOrderHistory` hook, since the client is contractually
// non-throwing.
export const GetOrderHistoryError = {
  Disconnected: () => ({
    type: GetOrderHistoryErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: GetOrderHistoryErrorType.Rejected as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: GetOrderHistoryErrorType.Symbology as const,
  }),
  Timeout: () => ({ type: GetOrderHistoryErrorType.Timeout as const }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: GetOrderHistoryErrorType.Unexpected as const,
  }),
};

export type GetOrderHistoryError = ReturnType<
  (typeof GetOrderHistoryError)[keyof typeof GetOrderHistoryError]
>;

export const displayGetOrderHistoryError = (
  error: GetOrderHistoryError,
): string => {
  switch (error.type) {
    case GetOrderHistoryErrorType.Symbology:
      return displaySymbologyError(error.error);
    case GetOrderHistoryErrorType.Disconnected:
      return "order history session disconnected";
    case GetOrderHistoryErrorType.Rejected:
      return error.reason;
    case GetOrderHistoryErrorType.Timeout:
      return "order history request timed out";
    case GetOrderHistoryErrorType.Unexpected:
      return errorMessage(error.cause, "order history request failed");
  }
};
