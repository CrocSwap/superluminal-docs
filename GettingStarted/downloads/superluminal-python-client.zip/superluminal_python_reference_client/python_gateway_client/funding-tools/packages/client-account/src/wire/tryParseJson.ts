import { None, Option } from "@cprussin/option-result";

// Parse a JSON string, yielding `None` instead of throwing on malformed
// input.  The socket paths use this to skip frames that aren't JSON (or
// aren't the message a waiter is looking for) without aborting the wait --
// `None` is the "not a usable message" signal the callers are forced to
// branch on.  A frame encoding JSON `null` is folded into `None` too: no
// gateway message is a bare null, so it is never a usable frame either.
export const tryParseJson = (text: string): Option<NonNullable<unknown>> => {
  try {
    return Option.wrap(JSON.parse(text) as unknown);
  } catch {
    return None();
  }
};
