import type { Dnum } from "dnum";

export type ConditionalOrderTriggerSources =
  | "oracle"
  | "auction"
  | "oracle-and-auction";

export type ConditionalOrderGroupLeg = Readonly<{
  externalOrderId: bigint;
  limitPrice?: Dnum | undefined;
  triggerPrice: Dnum;
  triggerSources: ConditionalOrderTriggerSources;
}>;

type ConditionalOrderGroupBase = Readonly<{
  activationMode: "parent_fill" | "immediate";
  clientInstructionId: bigint;
  expiresAt: Date;
  groupId: bigint;
  side: "long" | "short";
  size: Dnum;
  stopLoss?: ConditionalOrderGroupLeg | undefined;
  subaccountId: bigint;
  symbol: string;
  symbolId: number;
  takeProfit?: ConditionalOrderGroupLeg | undefined;
}>;

type ConditionalOrderStatus =
  | Readonly<{ status: "armed" | "waiting_fill" | "waiting_parent" }>
  | Readonly<{
      selectedExternalOrderId: bigint;
      selectedLeg: "take-profit" | "stop-loss";
      status: "triggering";
    }>;

export type ConditionalOrderGroup = ConditionalOrderGroupBase &
  ConditionalOrderStatus;
