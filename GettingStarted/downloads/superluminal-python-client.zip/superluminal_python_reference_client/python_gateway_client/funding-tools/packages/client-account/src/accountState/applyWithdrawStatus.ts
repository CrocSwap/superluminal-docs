import type { WithdrawStatusMessage } from "../wire/wireSchema";
import type { Subaccount } from "./subaccount";
import { ensureSubaccount } from "./subaccount";

// `WithdrawStatus` is the authoritative collateral debit for a
// user-initiated withdraw: the persistor mirrors `actual_withdraw_amount`
// into `accounts.collateral_balance` when it processes the event, so the
// snapshot reflects the debit once the persistor has caught up.  In the
// live path the state machine applies the same debit ahead of the
// next snapshot so the user sees the balance update immediately --
// dedup against double-application is handled by the standard
// `dispatchSeqedEvent` seq guard (a replayed event whose `seq` is at
// or below `internals.lastSeq` is dropped).
//
// Server-side, `risk_view::onWithdrawStatus` treats a status as
// "settled successfully" only when BOTH `status === 0` (finalized) AND
// `error_code === 0` -- any non-zero error_code triggers a rollback of
// the debit it applied at `onWithdraw` time, even when the txn status
// itself is finalized (partial settlement, on-chain validation
// failure, etc.).  The notifier emits the raw status/error_code pair
// through to the client, so we must mirror the same conjunction or
// we'll over-debit a withdraw the server never actually completed.
//
// `actual_withdraw_amount` carries what actually debited the
// subaccount (which can differ from `requested_withdraw_amount` if the
// sequencer clamped the request to the available balance).
export const applyWithdrawStatus = (
  subaccounts: Map<bigint, Subaccount>,
  message: WithdrawStatusMessage,
): bigint[] => {
  if (
    message.status !== 0 ||
    (message.error_code !== undefined && message.error_code !== 0) ||
    message.actual_withdraw_amount === undefined ||
    message.actual_withdraw_amount <= 0n
  ) {
    return [];
  } else {
    const subaccount = ensureSubaccount(subaccounts, message.subaccount_id);
    subaccount.collateralBalance -= message.actual_withdraw_amount;
    return [message.subaccount_id];
  }
};
