import {
  encodeContractWithdrawVaultProofV1,
  encodeContractWithdrawVaultV1,
} from "@aethon/client-protocol/signedWire";
import { Err, Result } from "@cprussin/option-result";
import { awaitWithdrawAck } from "../session/awaitResolution";
import { SubmitVaultWithdrawError } from "../submitVaultWithdrawError";
import type { SignedCommandContext } from "./signedCommand";
import { SIGNED_TTL_SECONDS } from "./signedCommand";
import { base64Encode, buildWithdrawVaultSignMessage } from "./signMessage";
import { encodeVaultAccountPubkey } from "./vaultAccountPubkey";

export type SubmitVaultWithdrawParams = {
  // Base58 vault-account pubkey from the `vault_accounts` listing.
  vaultAccountPubkey: string;
  // Number of vault shares to redeem, in e6 wire units.  Withdraw is by share
  // count, matching the protocol's `vault_shares` field.
  shares: bigint;
  // Destination subaccount receiving the redeemed collateral.
  subaccountId: bigint;
};

const ZERO_SIGNATURE = new Uint8Array(64);

// Builds the `ContractWithdrawVaultProofV1` envelope, signs the WITHDRAW_VAULT-
// domain-prefixed payload prefix, and posts the base64-wrapped proof.  Symmetric
// to `submitVaultDeposit`: the gateway is silent on success (settlement lands
// later as a `WithdrawVaultStatus`) and only acks on rejection or busy, so
// `awaitWithdrawAck` resolves `Ok` after a bounded grace period of silence.
// The invalid-pubkey validation is surfaced as a typed
// `SubmitVaultWithdrawError` and this never throws.
export const submitVaultWithdraw = (
  ctx: SignedCommandContext,
  params: SubmitVaultWithdrawParams,
  ackGraceMs: number,
): Promise<Result<true, SubmitVaultWithdrawError>> => {
  type WithdrawResult = Result<true, SubmitVaultWithdrawError>;
  return encodeVaultAccountPubkey(params.vaultAccountPubkey).match<
    Promise<WithdrawResult>
  >({
    Err: (message) =>
      Promise.resolve(Err(SubmitVaultWithdrawError.Validation(message))),
    Ok: async (vaultAccountPubkey) => {
      const iat = ctx.nowSeconds();
      const requestId64 = ctx.generateRequestId();
      const withdrawVaultBytes = encodeContractWithdrawVaultV1({
        requestId64,
        vaultAccountPubkey,
        vaultShares: params.shares,
      });
      const envelope = {
        destinationSubaccountId: params.subaccountId,
        exp: iat + SIGNED_TTL_SECONDS,
        iat,
        partitionId: ctx.partitionId,
        senderPubkey: ctx.senderPubkey,
        signerPubkey: ctx.senderPubkey,
        withdrawVaultBytes,
      };
      const unsignedProofBytes = encodeContractWithdrawVaultProofV1({
        ...envelope,
        signature: ZERO_SIGNATURE,
      });
      const signMessage = buildWithdrawVaultSignMessage(unsignedProofBytes);
      const sessionResult = await Result.wrapAsync(ctx.ensureAuthenticated());
      return sessionResult
        .mapErr(
          (): SubmitVaultWithdrawError =>
            SubmitVaultWithdrawError.Disconnected(),
        )
        .andThenAsync(async (socket) => {
          const sigResult = await Result.wrapAsync(
            ctx.signer.signMessage(signMessage),
          );
          return sigResult
            .mapErr(
              (cause): SubmitVaultWithdrawError =>
                SubmitVaultWithdrawError.SignerRejected(
                  cause.match({ None: () => undefined, Some: (c) => c }),
                ),
            )
            .andThenAsync((signature) => {
              const signedProofBytes = encodeContractWithdrawVaultProofV1({
                ...envelope,
                signature,
              });
              const ackPromise = awaitWithdrawAck<SubmitVaultWithdrawError>(
                socket,
                ackGraceMs,
                {
                  disconnected: SubmitVaultWithdrawError.Disconnected,
                  rejected: SubmitVaultWithdrawError.Rejected,
                },
              );
              socket.send(
                JSON.stringify({
                  msg_b64: base64Encode(signedProofBytes),
                  type: "signed_withdraw_vault",
                }),
              );
              return ackPromise;
            });
        });
    },
  });
};
