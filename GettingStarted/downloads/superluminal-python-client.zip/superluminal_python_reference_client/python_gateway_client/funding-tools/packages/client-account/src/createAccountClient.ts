import type { AccountClient } from "./accountClient";
import type { LiveAccountClientOptions } from "./live";
import { createLiveAccountClient } from "./live";
import { createMockAccountClient } from "./mock";

// This module is the package entrypoint (`@aethon/client-account`): it holds
// the client factory and re-exports its companion types so the "construct and
// type the client" surface lives in one place. Domain types (raw
// positions, auth signer, session/withdraw/vault status) and the per-method
// error types are their own subpaths, not re-exported here.
export type {
  AccountClient,
  ConditionalOrderLeg,
  ConditionalTriggerSources,
  GetOrderHistoryOptions,
  SubmitBracketOrderParams,
  SubmitOrderParams,
} from "./accountClient";
export type { ConditionalOrderGroup } from "./conditionalOrder";
export type { LiveAccountClientOptions } from "./live";

// `createAccountClient` takes EITHER an empty options bag (mock) OR every
// field of `LiveAccountClientOptions` (live).  Using a discriminated union
// instead of `Partial<LiveAccountClientOptions>` makes "half-configured"
// states (e.g. `websocketUrl` without `signer`) unrepresentable -- TS rejects
// them at the call site rather than the factory having to crash at runtime.
type CreateAccountClientArgs = (
  | { websocketUrl?: undefined; signer?: undefined }
  | LiveAccountClientOptions
) & {
  createLiveClient?: typeof createLiveAccountClient;
  createMockClient?: typeof createMockAccountClient;
};

// `createAccountClient` mirrors `createPublicClient`: with no live options
// it returns the mock client, with every live option it returns the live
// client.  The type system rules out partial-config calls, so there's no
// runtime "awaiting auth" branch here -- that's the provider's job, since
// the absence of a signer is a render-time concern, not a factory concern.
export const createAccountClient = ({
  createLiveClient = createLiveAccountClient,
  createMockClient = createMockAccountClient,
  ...options
}: CreateAccountClientArgs = {}): AccountClient =>
  options.websocketUrl === undefined
    ? createMockClient()
    : createLiveClient(options);
