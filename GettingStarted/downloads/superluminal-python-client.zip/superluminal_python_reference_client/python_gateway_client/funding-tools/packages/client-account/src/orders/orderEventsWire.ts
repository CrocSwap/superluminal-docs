import { z } from "zod";
import {
  wireBigint,
  wireDecimalUint64,
  wireExternalOrderId,
} from "../wire/wireBigint";

// Wire-format Zod schema for the gateway's `order_events` event (response to
// `get_order_events`).  Validating at the boundary (per `docs/typescript/
// data.md`) lets the live client work in branded TS types instead of
// `unknown`.

// Per-order lifecycle event.  The gateway's append-only history persists
// every transition (`accepted` / `modified` / `filled` / `cancelled` /
// `rejected` / `settled` / `busted` / `reduced` / `cancel_rejected` /
// `modify_rejected`)
// and the page returns them newest-first by `stream_seq`.  The schema fans
// out per `event_type` so each variant requires exactly the fields that are
// mandatory for its transition (qty on accepted, price/qty on filled, qty on
// settled/busted) and admits the genuinely-optional rest (price on accepted,
// `trade_id` on filled, `fee`/`settlement_seq` on settled,
// `delta_ppm`/price/qty on mark-to-mid modifies, `reason_code` on
// rejects/cancels).  Fields a variant doesn't declare are stripped by Zod, so
// extra wire fields stay harmless.
const orderEventBaseFields = {
  client_instruction_id: wireDecimalUint64,
  event_unix_ns: wireBigint,
  stream_seq: wireBigint,
};

const orderEventWireSchema = z.discriminatedUnion("event_type", [
  z.object({
    ...orderEventBaseFields,
    event_type: z.literal("accepted"),
    price: wireBigint.optional(),
    qty: wireBigint,
  }),
  z.object({
    ...orderEventBaseFields,
    delta_ppm: z.number().optional(),
    event_type: z.literal("modified"),
    price: wireBigint.optional(),
    qty: wireBigint.optional(),
  }),
  z.object({
    ...orderEventBaseFields,
    event_type: z.literal("filled"),
    price: wireBigint,
    qty: wireBigint,
    trade_id: wireBigint.optional(),
  }),
  z.object({
    ...orderEventBaseFields,
    event_type: z.literal("cancelled"),
    reason_code: z.number().optional(),
  }),
  z.object({
    ...orderEventBaseFields,
    event_type: z.literal("rejected"),
    reason_code: z.number().optional(),
  }),
  z.object({
    ...orderEventBaseFields,
    event_type: z.literal("settled"),
    fee: wireBigint.optional(),
    qty: wireBigint,
    settlement_seq: wireBigint.optional(),
  }),
  z.object({
    ...orderEventBaseFields,
    error_code: z.number().optional(),
    error_message: z.string().optional(),
    event_type: z.literal("busted"),
    qty: wireBigint,
    reason_code: z.number().optional(),
  }),
  z.object({
    ...orderEventBaseFields,
    adjustment_reason: z.literal("reduce_only"),
    event_type: z.literal("reduced"),
    qty: wireBigint,
  }),
  z.object({
    ...orderEventBaseFields,
    event_type: z.literal("cancel_rejected"),
    reason_code: z.number().optional(),
  }),
  z.object({
    ...orderEventBaseFields,
    event_type: z.literal("modify_rejected"),
    reason_code: z.number().optional(),
  }),
]);

// `market_id` stays a `number` (mirroring the order-history schema's `symbol`)
// so the mapping can resolve it against the per-symbol decimals cache.
export const orderEventsEventSchema = z.object({
  events: z.array(orderEventWireSchema),
  external_order_id: wireExternalOrderId,
  market_id: z.number(),
  next_cursor: z.string().optional(),
  request_id: z.string().optional(),
  type: z.literal("order_events"),
});

export type OrderEventsEvent = z.infer<typeof orderEventsEventSchema>;
export type OrderEventWire = z.infer<typeof orderEventWireSchema>;
