import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import { getAddressEncoder, isAddress } from "@solana/kit";

// Converts a base58 vault-account pubkey (as carried on the `vault_accounts`
// listing) to the 32 raw bytes the `ContractDepositVaultV1` /
// `ContractWithdrawVaultV1` payloads embed.  The listing is validated gateway
// data, but the value crosses the UI-string boundary before reaching a signed
// command, so a malformed pubkey surfaces as an `Err` the caller must handle
// rather than throwing mid-encode.
export const encodeVaultAccountPubkey = (
  pubkey: string,
): Result<Uint8Array, string> => {
  if (isAddress(pubkey)) {
    return Ok(new Uint8Array(getAddressEncoder().encode(pubkey)));
  } else {
    return Err(`invalid vault account pubkey: ${pubkey}`);
  }
};
