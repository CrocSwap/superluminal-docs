import type { FundingEvent } from "@aethon/client-protocol/fundingHistoryPage";
import type {
  Order,
  OrderEvent,
  OrderStatus,
} from "@aethon/client-protocol/order";
import type {
  VaultAccount,
  VaultAccountPerf,
} from "@aethon/client-protocol/vaultAccountsPage";
import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import type { Dnum } from "dnum";
import { from, toNumber } from "dnum";
import { z } from "zod";
import type { AccountClient, GetOrderHistoryOptions } from "./accountClient";
import type { RawAccountPositions } from "./accountState/rawAccountPositions";
import { GetOrderHistoryError } from "./getOrderHistoryError";
import { orderHistoryQueryValidationReason } from "./orderHistoryQueryValidation";

// Artificial latency on the initial load so loading skeletons are visible in
// dev/preview builds (which use this mock client).
const INITIAL_LOAD_LATENCY_MS = 2000;

// Wire-format raw integers.  USDC quantities are e6; sizes are e8 (matching
// the mock symbology's `size_decimals: 8`).  Cost basis is signed and is
// `netQty * average entry price` in USDC e6.  Symbol IDs line up with the
// `MOCK_MARKETS` ordering in the mock public client
// (`packages/client-public/src/mock.ts`): 1=BTC, 2=ETH, 3=DOGE,
// 4=SOL, 5=XRP, 6=AVAX.
const E6 = 1_000_000n;
const E8 = 100_000_000n;

const mockRawAccountPositions: RawAccountPositions = {
  collateralBalance: 62_104_500_000n, // 62_104.5 USDC
  positions: [
    {
      // 1.25 BTC long @ 48_200 entry → cost basis = 60_250 USDC
      costBasis: 60_250n * E6,
      fundingAccrued: -42_150_000n, // -42.15 USDC
      netQty: (125n * E8) / 100n, // 1.25 BTC
      pendingFees: 0n,
      realizedPnl: 0n,
      symbolId: 1,
    },
    {
      // 16 ETH short @ 3_280 entry → cost basis = -52_480 USDC
      costBasis: -52_480n * E6,
      fundingAccrued: 18_720_000n, // 18.72 USDC
      netQty: -16n * E8,
      pendingFees: 0n,
      realizedPnl: 0n,
      symbolId: 2,
    },
    {
      // 150 SOL long @ 142 entry → cost basis = 21_300 USDC
      costBasis: 21_300n * E6,
      fundingAccrued: -8_500_000n, // -8.5 USDC
      netQty: 150n * E8,
      pendingFees: 0n,
      realizedPnl: 0n,
      symbolId: 4,
    },
    {
      // 75 AVAX long @ 22.5 entry → cost basis = 1_687.5 USDC
      costBasis: 1_687_500_000n,
      fundingAccrued: 5_100_000n, // 5.1 USDC
      netQty: 75n * E8,
      pendingFees: 0n,
      realizedPnl: 0n,
      symbolId: 6,
    },
  ],
};

const PRICE_DECIMALS = 2;
const SIZE_DECIMALS = 8;

const MOCK_SYMBOLS = [
  "BTC",
  "ETH",
  "SOL",
  "FOGO",
  "AVAX",
  "PYTH",
  "MATIC",
] as const;
type MockSymbol = (typeof MOCK_SYMBOLS)[number];
// Aligns with the mock public client's `MOCK_MARKETS` numbering for the
// overlapping subset (1=BTC, 2=ETH, 4=SOL, 6=AVAX); the four symbols
// without a real-market entry get synthetic ids so order rows still
// carry a non-zero symbolId.  The mock cancel path doesn't validate
// symbology, so the synthetic ids are sufficient for the trading-app
// preview build.  Keyed by `MockSymbol` so every symbol lookup is total.
const MOCK_SYMBOL_IDS: Record<MockSymbol, number> = {
  AVAX: 6,
  BTC: 1,
  ETH: 2,
  FOGO: 101,
  MATIC: 102,
  PYTH: 103,
  SOL: 4,
};
const MOCK_STATUSES: OrderStatus[] = [
  "busted",
  "unfilled",
  "partially_filled",
  "filled",
  "cancelled",
  "rejected",
];
const MOCK_SIDES: Array<"long" | "short"> = ["long", "short"];

const ORDERS_PER_STATUS = 40;
const ORDER_PAGE_SIZE = 20;

// Pagination latency for follow-up pages.  Initial load uses
// `INITIAL_LOAD_LATENCY_MS` so the skeleton state is visible on first paint.
const PAGINATION_LATENCY_MS = 500;

const getFilledSize = (status: OrderStatus, size: Dnum, i: number): Dnum => {
  switch (status) {
    case "filled":
      return size;
    case "partially_filled":
      return from((1 + (i % 10)) / 2, SIZE_DECIMALS);
    case "unfilled":
    case "busted":
    case "cancelled":
    case "rejected":
      return from(0, SIZE_DECIMALS);
  }
};

type OrderGenState = {
  id: bigint;
  seq: bigint;
  timeOffset: number;
  orders: Order[];
};

// Synthesize a lifecycle that mirrors the per-status outcome.  `seq` is
// threaded through as an explicit counter: accepted consumes seq+0,
// fill1 consumes seq+1 (tradeId = seq+2), fill2 consumes seq+2
// (tradeId = seq+3).  Cancelled/rejected also consume seq+3.
const generateEventsForStatus = (
  status: OrderStatus,
  seq: bigint,
  i: number,
  timestamp: Date,
  price: Dnum,
  size: Dnum,
): { events: OrderEvent[]; nextSeq: bigint } => {
  const half = from((1 + (i % 10)) / 2, SIZE_DECIMALS);
  const acceptedEvent: OrderEvent = {
    clientInstructionId: undefined,
    id: seq,
    kind: "accepted",
    price,
    size,
    timestamp: new Date(timestamp.getTime() + 100),
  };
  const fill1: OrderEvent = {
    clientInstructionId: undefined,
    id: seq + 1n,
    kind: "filled",
    price,
    size: half,
    timestamp: new Date(timestamp.getTime() + 1000),
    tradeId: seq + 2n,
  };
  const fill2: OrderEvent = {
    clientInstructionId: undefined,
    id: seq + 2n,
    kind: "filled",
    price: from(100 + i * 50 + 1, PRICE_DECIMALS),
    size: half,
    timestamp: new Date(timestamp.getTime() + 5000),
    tradeId: seq + 3n,
  };
  switch (status) {
    case "filled": {
      return { events: [acceptedEvent, fill1, fill2], nextSeq: seq + 3n };
    }
    case "busted": {
      return {
        events: [
          acceptedEvent,
          fill1,
          {
            clientInstructionId: undefined,
            errorCode: 1,
            errorMessage: "Settlement transaction failed",
            id: seq + 2n,
            kind: "busted",
            size: half,
            timestamp: new Date(timestamp.getTime() + 5000),
          },
        ],
        nextSeq: seq + 3n,
      };
    }
    case "partially_filled": {
      return { events: [acceptedEvent, fill1], nextSeq: seq + 3n };
    }
    case "unfilled": {
      return { events: [acceptedEvent], nextSeq: seq + 3n };
    }
    case "cancelled": {
      return {
        events: [
          acceptedEvent,
          {
            clientInstructionId: undefined,
            id: seq + 3n,
            kind: "cancelled",
            reasonCode: undefined,
            timestamp: new Date(timestamp.getTime() + 8000),
          },
        ],
        nextSeq: seq + 4n,
      };
    }
    case "rejected": {
      return {
        events: [
          {
            clientInstructionId: undefined,
            id: seq + 3n,
            kind: "rejected",
            reasonCode: 7,
            timestamp,
          },
        ],
        nextSeq: seq + 4n,
      };
    }
  }
};

const generateMockOrders = (): Order[] => {
  const pairs = MOCK_STATUSES.flatMap((status) =>
    Array.from({ length: ORDERS_PER_STATUS }, (_, i) => ({ i, status })),
  );
  return pairs.reduce<OrderGenState>(
    (acc, { status, i }) => {
      const symbol = MOCK_SYMBOLS[i % MOCK_SYMBOLS.length] as MockSymbol;
      const side = MOCK_SIDES[i % 2] as "long" | "short";
      const price = from(100 + i * 50, PRICE_DECIMALS);
      const size = from(1 + (i % 10), SIZE_DECIMALS);
      const filledSize = getFilledSize(status, size, i);
      const timestamp = new Date(Date.now() - acc.timeOffset * 600_000);
      const { events, nextSeq } = generateEventsForStatus(
        status,
        acc.seq,
        i,
        timestamp,
        price,
        size,
      );
      // Cycle through the three order types so the mock dataset
      // exercises every chip + extra-detail rendering path in the
      // Orders widget.
      const orderTypeCycle = ["limit", "market", "mark-to-mid"] as const;
      const orderType = orderTypeCycle[i % orderTypeCycle.length] as
        | "limit"
        | "market"
        | "mark-to-mid";
      // Terminal orders carry a closed timestamp (the gateway's
      // `closed_unix_ns`); take it from the last synthesized event so the
      // "Updated" column reads the real terminal time.  Open orders have none.
      const isTerminal =
        status === "filled" ||
        status === "busted" ||
        status === "cancelled" ||
        status === "rejected";
      const closedTimestamp = isTerminal ? events.at(-1)?.timestamp : undefined;
      return {
        id: acc.id + 1n,
        orders: [
          ...acc.orders,
          {
            closedTimestamp,
            deltaPpm:
              orderType === "mark-to-mid" ? (i % 5) * 100 - 200 : undefined,
            events,
            filledSize,
            id: acc.id,
            orderType,
            price,
            role: "taker",
            side,
            size,
            status,
            symbol,
            symbolId: MOCK_SYMBOL_IDS[symbol],
            timestamp,
          },
        ],
        seq: nextSeq,
        timeOffset: acc.timeOffset + 1,
      };
    },
    { id: 1001n, orders: [], seq: 5001n, timeOffset: 1 },
  ).orders;
};

const mockOrders = generateMockOrders();

const mockOrderHistoryCursorIntegerSchema = z
  .string()
  .regex(/^\d+$/)
  .transform(Number)
  .refine(Number.isSafeInteger);

const mockOrderHistoryCursorSchema = z
  .object({
    f: mockOrderHistoryCursorIntegerSchema.optional(),
    i: mockOrderHistoryCursorIntegerSchema,
    t: mockOrderHistoryCursorIntegerSchema.optional(),
  })
  .strict();

type MockOrderHistoryCursor =
  | Readonly<{ bindsCreationRange: false; startIndex: number }>
  | Readonly<{
      bindsCreationRange: true;
      options: GetOrderHistoryOptions;
      startIndex: number;
    }>;

const invalidMockOrderHistoryCursor = (): GetOrderHistoryError =>
  GetOrderHistoryError.Rejected("invalid_order_history_cursor");

const mockOrderHistoryOptions = (
  createdFromUnixS: number | undefined,
  createdToUnixS: number | undefined,
): GetOrderHistoryOptions => ({
  ...(createdFromUnixS === undefined ? {} : { createdFromUnixS }),
  ...(createdToUnixS === undefined ? {} : { createdToUnixS }),
});

const parseMockOrderHistoryCursor = (
  cursor: string,
): Result<MockOrderHistoryCursor, GetOrderHistoryError> => {
  const legacy = mockOrderHistoryCursorIntegerSchema.safeParse(cursor);
  if (legacy.success) {
    return Ok({ bindsCreationRange: false, startIndex: legacy.data });
  } else {
    const parsed = mockOrderHistoryCursorSchema.safeParse(
      Object.fromEntries(new URLSearchParams(cursor)),
    );
    if (parsed.success) {
      const options = mockOrderHistoryOptions(parsed.data.f, parsed.data.t);
      const validationReason = orderHistoryQueryValidationReason(options);
      return validationReason === undefined
        ? Ok({
            bindsCreationRange: true,
            options,
            startIndex: parsed.data.i,
          })
        : Err(invalidMockOrderHistoryCursor());
    } else {
      return Err(invalidMockOrderHistoryCursor());
    }
  }
};

const formatMockOrderHistoryCursor = (
  startIndex: number,
  options: GetOrderHistoryOptions | undefined,
): string => {
  const params = new URLSearchParams({ i: String(startIndex) });
  if (options?.createdFromUnixS !== undefined) {
    params.set("f", String(options.createdFromUnixS));
  }
  if (options?.createdToUnixS !== undefined) {
    params.set("t", String(options.createdToUnixS));
  }
  return params.toString();
};

type ResolvedMockOrderHistoryQuery = Readonly<{
  hasCursor: boolean;
  options: GetOrderHistoryOptions | undefined;
  startIndex: number;
}>;

const cursorBoundMatches = (
  requested: number | undefined,
  bound: number | undefined,
): boolean => requested === undefined || requested === bound;

const resolveMockOrderHistoryQuery = (
  optionsOrCursor: GetOrderHistoryOptions | string | undefined,
): Result<ResolvedMockOrderHistoryQuery, GetOrderHistoryError> => {
  const requestedOptions =
    typeof optionsOrCursor === "string" ? undefined : optionsOrCursor;
  const cursor = (
    typeof optionsOrCursor === "string"
      ? optionsOrCursor
      : optionsOrCursor?.cursor
  )?.trim();
  if (cursor === undefined || cursor === "") {
    return Ok({ hasCursor: false, options: requestedOptions, startIndex: 0 });
  } else {
    return parseMockOrderHistoryCursor(cursor).andThen((parsed) => {
      if (!parsed.bindsCreationRange) {
        return Ok({
          hasCursor: true,
          options: requestedOptions,
          startIndex: parsed.startIndex,
        });
      } else if (
        !cursorBoundMatches(
          requestedOptions?.createdFromUnixS,
          parsed.options.createdFromUnixS,
        ) ||
        !cursorBoundMatches(
          requestedOptions?.createdToUnixS,
          parsed.options.createdToUnixS,
        )
      ) {
        return Err(invalidMockOrderHistoryCursor());
      } else {
        return Ok({
          hasCursor: true,
          options: parsed.options,
          startIndex: parsed.startIndex,
        });
      }
    });
  }
};

const mockOrdersForHistoryQuery = (
  options: GetOrderHistoryOptions | undefined,
): Order[] =>
  mockOrders.filter((order) => {
    const createdUnixS = order.timestamp.getTime() / 1000;
    return (
      (options?.createdFromUnixS === undefined ||
        createdUnixS >= options.createdFromUnixS) &&
      (options?.createdToUnixS === undefined ||
        createdUnixS < options.createdToUnixS)
    );
  });

// Per-order lifecycle events, keyed by external order id and returned
// newest-first (the gateway's `get_order_events` ordering).  The synthesized
// events run oldest-first, so reverse once here.  The order-history page below
// serves flat rows with no inline events; the widget fetches these on demand.
const MOCK_ORDER_EVENTS_PAGE_SIZE = 20;
const mockEventsByOrderId = new Map(
  mockOrders.map((order) => [order.id, order.events.slice().reverse()]),
);

const FUNDING_EVENT_COUNT = 100;
const FUNDING_PAGE_SIZE = 20;
const MOCK_SUBACCOUNT_ID = 7n;

// Synthesize a running funding ledger: each event applies a small signed
// payment (alternating sign, scaled by index) and advances the per-market
// cumulative accrual.  USDC amounts are e6, matching the wire encoding the
// live mapping decodes.
type FundingGenState = { accrued: bigint; events: FundingEvent[] };

const generateMockFundingEvents = (): FundingEvent[] =>
  Array.from(
    { length: FUNDING_EVENT_COUNT },
    (_, i) => i,
  ).reduce<FundingGenState>(
    (acc, i) => {
      // Alternating sign so the widget exercises both the received (green)
      // and paid (red) rendering paths; magnitude grows slowly with index.
      const payment = BigInt((i % 2 === 0 ? 1 : -1) * (10_000 + i * 5000));
      const accrued = acc.accrued + payment;
      const symbol = MOCK_SYMBOLS[i % MOCK_SYMBOLS.length] as MockSymbol;
      return {
        accrued,
        events: [
          ...acc.events,
          {
            accrued: [accrued, 6],
            id: BigInt(FUNDING_EVENT_COUNT - i),
            payment: [payment, 6],
            subaccountId: MOCK_SUBACCOUNT_ID,
            symbol,
            symbolId: MOCK_SYMBOL_IDS[symbol],
            // Funding settles hourly; space events an hour apart, newest first.
            timestamp: new Date(Date.now() - i * 3_600_000),
          },
        ],
      };
    },
    { accrued: 0n, events: [] },
  ).events;

const mockFundingEvents = generateMockFundingEvents();

// Fixed vault catalog for the dev/preview build.  Values are the domain shape
// (`Dnum`s, not wire integers), mirroring what the live client produces after
// mapping.  `latestPerf` is present on funded vaults and `undefined` on the
// freshly-created one so the UI's empty-perf path is exercised in preview.
const MOCK_VAULTS: VaultAccount[] = [
  {
    // Oldest vault: a bit over a year old.
    inceptionDate: new Date("2025-05-20T12:00:00Z"),
    latestPerf: {
      datetime: new Date("2026-06-30T12:00:00Z"),
      leaderSharePercentage: from("20"),
      totalEquity: from(4_250_000, 6),
      totalVaultShares: from(4_000_000, 6),
    },
    leaderPubkey: "So11111111111111111111111111111111111111112",
    operationSubaccountPubkey: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
    vaultAccountId: 1n,
    vaultAccountPubkey: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  },
  {
    // A few months old.
    inceptionDate: new Date("2026-03-01T12:00:00Z"),
    latestPerf: {
      datetime: new Date("2026-06-30T12:00:00Z"),
      leaderSharePercentage: from("12.5"),
      totalEquity: from(980_500, 6),
      totalVaultShares: from(1_000_000, 6),
    },
    leaderPubkey: "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM",
    operationSubaccountPubkey: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    vaultAccountId: 2n,
    vaultAccountPubkey: "6dNVKMbfW7C8xw6d5uMKR9v3Fs9pXMbrNXhVe9pMs1B9",
  },
  {
    // Freshly created (days old): no persisted perf row yet.
    inceptionDate: new Date("2026-07-05T12:00:00Z"),
    latestPerf: undefined,
    leaderPubkey: "4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T",
    operationSubaccountPubkey: "GsbwXfJraMomNxBcpR3DBNxnKwbKKz62aAqDDbGfxZH7",
    vaultAccountId: 3n,
    vaultAccountPubkey: "AwRErBEFGTnohzfLeRSBH9HddQEy2oeRxnWLrbvFFh95",
  },
];

const VAULT_PAGE_SIZE = 20;

// Days of synthetic daily equity history returned per funded vault.  Fits in a
// single live page (the gateway caps at 100) and covers the widest window the
// vaults UI offers (90D).
const VAULT_PERF_DAYS = 90;
const DAY_MS = 86_400_000;

// Deterministic daily equity history for a funded vault, newest-first (matching
// the wire order the live client produces).  Equity walks back from the vault's
// latest `totalEquity` with a gentle per-vault drift -- gainers and losers
// alternate by vault id parity -- plus a small ripple so the preview sparklines
// aren't flat.  The freshly-created vault (no `latestPerf`) has no history.
const generateMockVaultPerf = (vault: VaultAccount): VaultAccountPerf[] => {
  const latest = vault.latestPerf;
  if (latest === undefined) {
    return [];
  } else {
    const latestMs = latest.datetime.getTime();
    const latestEquity = toNumber(latest.totalEquity);
    const direction = vault.vaultAccountId % 2n === 0n ? -1 : 1;
    return Array.from({ length: VAULT_PERF_DAYS }, (_, daysAgo) => {
      // daysAgo 0 is the newest point and reproduces the latest equity exactly.
      const drift = 1 - direction * (daysAgo * 0.004);
      const ripple = 1 + Math.sin(daysAgo / 5) * 0.01;
      return {
        datetime: new Date(latestMs - daysAgo * DAY_MS),
        leaderSharePercentage: latest.leaderSharePercentage,
        totalEquity: from(latestEquity * drift * ripple, 6),
        totalVaultShares: latest.totalVaultShares,
      };
    });
  }
};

const noopCanceler = () => {
  // No-op: the default subscription has no transport to tear down.
};

export const createMockAccountClient = (): AccountClient => ({
  cancelConditionalOrder: () => Promise.resolve(Ok(true)),
  // Same posture as `submitOrder`: no gateway, so cancels always
  // succeed.  Trading-app tests that need a specific outcome inject
  // their own stub client.
  cancelOrder: () => Promise.resolve(Ok(true)),
  close: () => {
    // No transport to release; the mock client lives entirely in memory.
  },
  // No transport, so there is nothing to (re-)establish.
  connect: () => Promise.resolve(Ok(true)),
  createConditionalOrderSubscription: (onUpdate) => {
    onUpdate([]);
    return () => undefined;
  },
  // The mock client has no transport, so it is always healthy.
  createConnectionStatusSubscription: (onUpdate) => {
    onUpdate("connected");
    return noopCanceler;
  },
  // The mock client doesn't simulate a streamed order lifecycle, so
  // this subscription is silent (no events ever fire).  Trading-app
  // tests that need the live behavior inject their own stub client.
  createOrderUpdateSubscription: () => noopCanceler,
  createRawAccountPositionsSubscription: (_subaccountId, onUpdate) => {
    const timeoutId = setTimeout(() => {
      onUpdate(mockRawAccountPositions);
    }, INITIAL_LOAD_LATENCY_MS);
    return Promise.resolve(() => {
      clearTimeout(timeoutId);
    });
  },
  // The mock gateway never ends a session, so no events are ever emitted.
  createSessionEndSubscription: () => noopCanceler,
  // No vault settlement status is ever emitted in mock mode; tests of
  // consumers inject their own stub client.  The canceler is a no-op.
  createVaultOperationStatusSubscription: () => Promise.resolve(noopCanceler),
  // Give the first mock vault a position (so the withdraw action + "your
  // position" render) and leave the rest empty (so the withdraw-hidden path
  // is exercised) in the dev/preview build.
  createVaultPositionsSubscription: (onUpdate) => {
    const firstVault = MOCK_VAULTS[0];
    const timeoutId = setTimeout(() => {
      onUpdate(
        firstVault === undefined
          ? new Map()
          : new Map([[firstVault.vaultAccountPubkey, 3_000_000n]]),
      );
    }, INITIAL_LOAD_LATENCY_MS);
    return () => {
      clearTimeout(timeoutId);
    };
  },
  // No WithdrawStatus is ever emitted in mock mode; tests of consumers
  // inject their own stub client.  The canceler is a no-op.
  createWithdrawStatusSubscription: () => Promise.resolve(noopCanceler),
  disconnect: () => {
    // No transport to close; the mock client lives entirely in memory.
  },
  getFundingHistory: (cursor) =>
    new Promise((resolve) => {
      setTimeout(
        () => {
          const startIndex =
            cursor === undefined ? 0 : Number.parseInt(cursor, 10);
          const events = mockFundingEvents.slice(
            startIndex,
            startIndex + FUNDING_PAGE_SIZE,
          );
          const nextIndex = startIndex + FUNDING_PAGE_SIZE;
          resolve(
            Ok({
              events,
              nextCursor:
                nextIndex < mockFundingEvents.length
                  ? String(nextIndex)
                  : undefined,
            }),
          );
        },
        cursor === undefined ? INITIAL_LOAD_LATENCY_MS : PAGINATION_LATENCY_MS,
      );
    }),
  getOrderEvents: (externalOrderId, _marketId, cursor) =>
    new Promise((resolve) => {
      setTimeout(() => {
        const events = mockEventsByOrderId.get(externalOrderId) ?? [];
        const startIndex =
          cursor === undefined ? 0 : Number.parseInt(cursor, 10);
        const page = events.slice(
          startIndex,
          startIndex + MOCK_ORDER_EVENTS_PAGE_SIZE,
        );
        const nextIndex = startIndex + MOCK_ORDER_EVENTS_PAGE_SIZE;
        resolve(
          Ok({
            events: page,
            externalOrderId,
            marketId: _marketId,
            nextCursor:
              nextIndex < events.length ? String(nextIndex) : undefined,
          }),
        );
      }, PAGINATION_LATENCY_MS);
    }),
  getOrderHistory: (
    optionsOrCursor?: GetOrderHistoryOptions | string | undefined,
  ) => {
    const requestedOptions =
      typeof optionsOrCursor === "string" ? undefined : optionsOrCursor;
    const validationReason =
      orderHistoryQueryValidationReason(requestedOptions);
    if (validationReason === undefined) {
      return resolveMockOrderHistoryQuery(optionsOrCursor).match({
        Err: (error) => Promise.resolve(Err(error)),
        Ok: ({ hasCursor, options, startIndex }) => {
          const orders = mockOrdersForHistoryQuery(options);
          return new Promise((resolve) => {
            setTimeout(
              () => {
                // The flat page carries no inline events; the widget fetches these
                // per-order via `getOrderEvents` when a row is expanded.
                const page = orders
                  .slice(startIndex, startIndex + ORDER_PAGE_SIZE)
                  .map((order) => ({ ...order, events: [] }));
                const nextIndex = startIndex + ORDER_PAGE_SIZE;
                resolve(
                  Ok({
                    nextCursor:
                      nextIndex < orders.length
                        ? formatMockOrderHistoryCursor(nextIndex, options)
                        : undefined,
                    orders: page,
                  }),
                );
              },
              hasCursor ? PAGINATION_LATENCY_MS : INITIAL_LOAD_LATENCY_MS,
            );
          });
        },
      });
    } else {
      return Promise.resolve(
        Err(GetOrderHistoryError.Rejected(validationReason)),
      );
    }
  },
  getVaultAccountPerf: (vaultAccount) =>
    new Promise((resolve) => {
      setTimeout(() => {
        const vault = MOCK_VAULTS.find(
          (candidate) => candidate.vaultAccountPubkey === vaultAccount,
        );
        // A single page carries the whole synthetic window (mirroring the live
        // client's max-page fetch), so there's never a next cursor.
        resolve(
          Ok({
            events: vault === undefined ? [] : generateMockVaultPerf(vault),
            nextCursor: undefined,
          }),
        );
      }, INITIAL_LOAD_LATENCY_MS);
    }),
  getVaultAccounts: (cursor) =>
    new Promise((resolve) => {
      setTimeout(
        () => {
          const startIndex =
            cursor === undefined ? 0 : Number.parseInt(cursor, 10);
          const page = MOCK_VAULTS.slice(
            startIndex,
            startIndex + VAULT_PAGE_SIZE,
          );
          const nextIndex = startIndex + VAULT_PAGE_SIZE;
          resolve(
            Ok({
              nextCursor:
                nextIndex < MOCK_VAULTS.length ? String(nextIndex) : undefined,
              vaults: page,
            }),
          );
        },
        cursor === undefined ? INITIAL_LOAD_LATENCY_MS : PAGINATION_LATENCY_MS,
      );
    }),
  registerUserDepositAddress: () => Promise.resolve(Ok(true)),
  submitBracketOrder: () => Promise.resolve(Ok(true)),
  // The mock client has no gateway, so dev/preview builds optimistically
  // accept every submission and the form's confirm flow exercises
  // end-to-end.  Trading-app tests that need a specific outcome inject
  // their own stub client.
  submitOrder: () => Promise.resolve(Ok(true)),
  // Same rationale as `submitOrder`: the mock optimistically accepts every
  // vault deposit / withdraw.  Trading-app tests inject their own stub client
  // when they need a specific outcome.
  submitVaultDeposit: () => Promise.resolve(Ok(true)),
  submitVaultWithdraw: () => Promise.resolve(Ok(true)),
  // Same rationale as `submitOrder`: the mock surface optimistically
  // accepts every withdraw with a placeholder request id.  Trading-app
  // tests of the WithdrawDialog inject their own stub client rather than
  // depending on this default.
  submitWithdraw: () => Promise.resolve(Ok({ requestId64: 0n })),
});
