import type { SymbologyUpdate } from "@aethon/client-protocol/symbology";
import { symbologyUpdateSchema } from "@aethon/client-protocol/symbology";
import { typeFieldOf } from "@aethon/client-protocol/typeFieldOf";
import type { FundingHistoryEvent } from "../funding/fundingHistoryWire";
import { fundingHistoryEventSchema } from "../funding/fundingHistoryWire";
import type { OrderEventsEvent } from "../orders/orderEventsWire";
import { orderEventsEventSchema } from "../orders/orderEventsWire";
import type { OrderHistoryEvent } from "../orders/orderHistoryWire";
import { orderHistoryEventSchema } from "../orders/orderHistoryWire";
import type { VaultAccountPerfEvent } from "../vaults/vaultAccountPerfWire";
import { vaultAccountPerfEventSchema } from "../vaults/vaultAccountPerfWire";
import type { VaultAccountsEvent } from "../vaults/vaultAccountsWire";
import { vaultAccountsEventSchema } from "../vaults/vaultAccountsWire";
import type { AccountStreamMessage } from "./wireSchema";
import { accountStreamMessageSchema } from "./wireSchema";

// A parsed frame off the authenticated account WS, classified into the
// dispositions the live client acts on. Pure parse/validation: the live client
// owns what each disposition *does* (resolve a pending request, apply to the
// state machines + fan out, log, or ignore).
export type AccountFrame =
  | { kind: "orderHistory"; data: OrderHistoryEvent }
  | { kind: "orderEvents"; data: OrderEventsEvent }
  | { kind: "fundingHistory"; data: FundingHistoryEvent }
  | { kind: "vaultAccounts"; data: VaultAccountsEvent }
  | { kind: "vaultAccountPerf"; data: VaultAccountPerfEvent }
  | { kind: "symbologyUpdate"; data: SymbologyUpdate }
  | { kind: "accountStream"; data: AccountStreamMessage }
  | { kind: "malformedKnown"; type: string; error: string }
  | { kind: "ignored" };

// The `type` discriminators the account stream handles. Used to distinguish
// "unknown discriminant, ignore" from "known type but its body failed
// validation, log it".
const HANDLED_TYPES = new Set([
  "AccountSnapshot",
  "AdlFailed",
  "Fill",
  "FillBusted",
  "FillSettled",
  "UserCollateralUpdate",
  "AccountFundingUpdate",
  "ConditionalApproved",
  "ConditionalTriggered",
  "ConditionalExpired",
  "ConditionalCancelled",
  "ConditionalInvalidated",
  "ConditionalCompleted",
  "InactivePositionSettlementStatus",
  "BackstopTransfer",
  "OrderAccepted",
  "OrderReject",
  "CancelAck",
  "CancelReject",
  "ModifyAck",
  "WithdrawStatus",
  "DepositVault",
  "DepositVaultStatus",
  "WithdrawVault",
  "WithdrawVaultStatus",
]);

// Classify a parsed account-WS frame. Order-history pages (correlated by
// `request_id`) are matched before the account-stream parse so a page isn't
// mis-classified as an unknown type. A frame that parses as neither but carries
// a known discriminant is a real bug worth surfacing (`malformedKnown`);
// anything else rides the same socket but is out of scope here (`ignored`).
// Classify a frame that isn't one of the request_id-correlated query responses
// (order history / vault accounts): a live account-stream message, a
// known-type-but-malformed body worth surfacing, or an ignorable frame.
// The gateway sends two distinct frames under `type: "OrderReject"`: the
// sequencer-sourced reject (carries `seq` + `subaccount_id` + the full order
// params, a real account-stream event) and the gateway-level fast-fail reject
// (a string `reason` only, no `seq`, e.g. "Permission Denied"). Only the former
// is an account-stream event; the latter is a submission response the order
// waiter handles and rides the same socket, so it must be ignored here rather
// than logged as a malformed account frame. Mirrors the reference codec's
// `"seq" in payload && "subaccount_id" in payload` disambiguation.
const isGatewayFastFailReject = (parsed: unknown): boolean =>
  typeFieldOf(parsed) === "OrderReject" &&
  typeof parsed === "object" &&
  parsed !== null &&
  !("seq" in parsed && "subaccount_id" in parsed);

const classifyNonCorrelatedFrame = (parsed: unknown): AccountFrame => {
  const symbologyUpdate = symbologyUpdateSchema.safeParse(parsed);
  if (symbologyUpdate.success) {
    return { data: symbologyUpdate.data, kind: "symbologyUpdate" };
  }
  const result = accountStreamMessageSchema.safeParse(parsed);
  if (result.success) {
    return { data: result.data, kind: "accountStream" };
  } else if (isGatewayFastFailReject(parsed)) {
    return { kind: "ignored" };
  } else {
    const type = typeFieldOf(parsed);
    if (type !== undefined && HANDLED_TYPES.has(type)) {
      return { error: result.error.message, kind: "malformedKnown", type };
    } else {
      return { kind: "ignored" };
    }
  }
};

export const classifyAccountFrame = (parsed: unknown): AccountFrame => {
  const historyEvent = orderHistoryEventSchema.safeParse(parsed);
  if (historyEvent.success) {
    return { data: historyEvent.data, kind: "orderHistory" };
  } else {
    const orderEvents = orderEventsEventSchema.safeParse(parsed);
    if (orderEvents.success) {
      return { data: orderEvents.data, kind: "orderEvents" };
    } else {
      const fundingEvent = fundingHistoryEventSchema.safeParse(parsed);
      if (fundingEvent.success) {
        return { data: fundingEvent.data, kind: "fundingHistory" };
      } else {
        const vaultEvent = vaultAccountsEventSchema.safeParse(parsed);
        if (vaultEvent.success) {
          return { data: vaultEvent.data, kind: "vaultAccounts" };
        } else {
          const vaultPerfEvent = vaultAccountPerfEventSchema.safeParse(parsed);
          if (vaultPerfEvent.success) {
            return { data: vaultPerfEvent.data, kind: "vaultAccountPerf" };
          } else {
            return classifyNonCorrelatedFrame(parsed);
          }
        }
      }
    }
  }
};
