import { z } from "zod";
import { wireBigint } from "../wire/wireBigint";

// Wire-format Zod schema for the gateway's `funding_history` event (response to
// `get_funding_history`).  Validating at the boundary (per
// `docs/typescript/data.md`) lets the live client work in branded TS types
// instead of `unknown`.
//
// `funding_delta` / `funding_accrued` and the two funding indices are signed
// (`int64` on the wire); the rest are unsigned counters.  Every numeric field
// arrives as a JSON number and is transformed to `bigint` by `wireBigint`
// (`market_id` stays a `number`, mirroring the order-history schema's `symbol`).
const fundingHistoryWireEventSchema = z.object({
  event_unix_ns: wireBigint,
  funding_accrued: wireBigint,
  funding_delta: wireBigint,
  last_funding_index_e8: wireBigint,
  market_id: z.number(),
  prev_funding_index_e8: wireBigint,
  stream_seq: wireBigint,
  subaccount_id: wireBigint,
});

export const fundingHistoryEventSchema = z.object({
  events: z.array(fundingHistoryWireEventSchema),
  next_cursor: z.string().optional(),
  request_id: z.string().optional(),
  type: z.literal("funding_history"),
});

export type FundingHistoryEvent = z.infer<typeof fundingHistoryEventSchema>;
export type FundingHistoryWireEvent = z.infer<
  typeof fundingHistoryWireEventSchema
>;
