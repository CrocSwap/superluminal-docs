import { z } from "zod";

// Ways the gateway ends (or signals the end of) an authenticated session,
// normalized for consumers:
//
// - `sessionPreempted` -- the wallet authenticated a new session elsewhere;
//   the gateway sends `session_preempted` and closes this socket.
// - `authExpired` -- the wallet's auth token expired or was revoked; the
//   gateway sends `auth_expired` with a reason string.
// - `rateLimited` -- the client exceeded the gateway's message rate limit;
//   the gateway closes the socket with reason `msg_rate_limit_exceeded`.
export type SessionEndEvent =
  | { type: "authExpired"; reason: string | undefined }
  | { type: "rateLimited" }
  | { type: "sessionPreempted" };

// Mirrors `dfba_gateway`'s `session_preempted` / `auth_expired` payloads.
export const sessionEndMessageSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("session_preempted") }),
  z.object({ reason: z.string().optional(), type: z.literal("auth_expired") }),
]);

// Close reason the gateway uses with its policy-violation close when the
// per-connection message rate limit is exceeded.
export const RATE_LIMIT_CLOSE_REASON = "msg_rate_limit_exceeded";
