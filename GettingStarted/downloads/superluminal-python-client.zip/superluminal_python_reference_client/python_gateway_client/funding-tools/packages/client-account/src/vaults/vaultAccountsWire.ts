import { z } from "zod";
import { wireBigint } from "../wire/wireBigint";

// Wire-format Zod schema for the gateway's `vault_accounts` event (response to
// `get_vault_accounts`).  Validating at the boundary (per
// `docs/typescript/data.md`) lets the live client work in branded TS types
// instead of `unknown`, mirroring `orderHistoryWire`.

// Latest persisted performance row for a vault.  `total_vault_shares` (uint64)
// and `total_equity` (int64) arrive as JSON numbers and are coerced to bigint;
// `leader_share_percentage` is forwarded as a decimal string (10 fractional
// digits) and `datetime` as an RFC3339 timestamp -- both stay strings here and
// are scaled/parsed in `vaultAccountsMapping`.
const vaultAccountPerfSchema = z.object({
  datetime: z.string(),
  leader_share_percentage: z.string(),
  total_equity: wireBigint,
  total_vault_shares: wireBigint,
});

const vaultAccountWireSchema = z.object({
  // The vault's creation time, as an RFC3339 timestamp.  Optional to tolerate a
  // gateway old enough not to send it (deploys aren't atomic); the gateway that
  // does send it may still emit an empty string when the value is unknown, which
  // the mapping treats the same as absent.
  creation_dt: z.string().optional(),
  latest_perf: vaultAccountPerfSchema.optional(),
  leader_pubkey: z.string(),
  operation_subaccount_pubkey: z.string(),
  vault_account_id: wireBigint,
  vault_account_pubkey: z.string(),
});

export const vaultAccountsEventSchema = z.object({
  next_cursor: z.string().optional(),
  request_id: z.string().optional(),
  type: z.literal("vault_accounts"),
  vault_accounts: z.array(vaultAccountWireSchema),
});

export type VaultAccountsEvent = z.infer<typeof vaultAccountsEventSchema>;
export type VaultAccountWire = z.infer<typeof vaultAccountWireSchema>;
