import type { Canceler } from "@aethon/client-protocol/canceler";
import type { ConnectionStatus } from "@aethon/client-protocol/connectionStatus";
import type { FundingHistoryPage } from "@aethon/client-protocol/fundingHistoryPage";
import type { OrderEventsPage } from "@aethon/client-protocol/orderEventsPage";
import type {
  HistoryEntry,
  OrderHistoryPage,
} from "@aethon/client-protocol/orderHistoryPage";
import type { VaultAccountPerfPage } from "@aethon/client-protocol/vaultAccountPerfPage";
import type { VaultAccountsPage } from "@aethon/client-protocol/vaultAccountsPage";
import type { Result } from "@cprussin/option-result";
import type { Dnum } from "dnum";
import type { RawAccountPositions } from "./accountState/rawAccountPositions";
import type { CancelConditionalOrderError } from "./cancelConditionalOrderError";
import type { CancelOrderError } from "./cancelOrderError";
import type { ConditionalOrderGroup } from "./conditionalOrder";
import type { ConnectError } from "./connectError";
import type { GetFundingHistoryError } from "./getFundingHistoryError";
import type { GetOrderEventsError } from "./getOrderEventsError";
import type { GetOrderHistoryError } from "./getOrderHistoryError";
import type { GetVaultAccountPerfError } from "./getVaultAccountPerfError";
import type { GetVaultAccountsError } from "./getVaultAccountsError";
import type { RegisterDepositAddressError } from "./registerDepositAddressError";
import type { SessionEndEvent } from "./session/sessionEnd";
import type { SubmitBracketOrderError } from "./submitBracketOrderError";
import type { SubmitOrderError } from "./submitOrderError";
import type { SubmitVaultDepositError } from "./submitVaultDepositError";
import type { SubmitVaultWithdrawError } from "./submitVaultWithdrawError";
import type { SubmitWithdrawError } from "./submitWithdrawError";
import type { VaultOperationStatus } from "./vaultOperationStatus";
import type { WithdrawStatus } from "./withdrawStatus";

export type GetOrderHistoryOptions = Readonly<{
  createdFromUnixS?: number;
  createdToUnixS?: number;
  cursor?: string;
}>;

export type ConditionalTriggerSources =
  | "oracle"
  | "auction"
  | "oracle-and-auction";

export type ConditionalOrderLeg = Readonly<{
  triggerPrice: Dnum;
  triggerSources: ConditionalTriggerSources;
}>;

type ConditionalOrderLegs =
  | Readonly<{
      stopLoss?: ConditionalOrderLeg | undefined;
      takeProfit: ConditionalOrderLeg;
    }>
  | Readonly<{
      stopLoss: ConditionalOrderLeg;
      takeProfit?: ConditionalOrderLeg | undefined;
    }>;

export type SubmitOrderParams = Readonly<{
  subaccountId: bigint;
  symbol: string;
  side: "long" | "short";
  reduceOnly: boolean;
  orderType: "market" | "limit" | "mark-to-mid";
  limitPrice?: Dnum | undefined;
  referencePrice?: Dnum | undefined;
  size: Dnum;
  deltaBps?: number | undefined;
  tif: "gtc" | "ioc";
}>;

type SubmitBracketOrderCommon = Readonly<{ expiresAtUnixS: bigint }> &
  ConditionalOrderLegs;

export type SubmitBracketOrderParams =
  | (SubmitBracketOrderCommon &
      Readonly<{
        activationMode: "parent-fill";
        exitSize?: Dnum;
        parent: SubmitOrderParams;
      }>)
  | (SubmitBracketOrderCommon &
      Readonly<{
        activationMode: "immediate";
        subaccountId: bigint;
        symbol: string;
        side: "long" | "short";
        size: Dnum;
      }>);

// `AccountClient` covers every method that needs the gateway-authenticated
// session: the WS the live implementation opens is authenticated once via
// `auth_wallet` / `auth_challenge` / `auth_response` and the same session is
// reused for every subscription on the client.  The trading app constructs
// one client per signer; logging in/out tears down the old client (via
// `close`, called from the React provider's effect cleanup) and
// re-establishes a new authenticated session for the new identity.
//
// Subscriptions emit raw protocol payloads -- `RawAccountPositions` mirrors
// the gateway's `account_snapshot.positions` literally (symbol ids, signed
// quantities and cost bases).  The `derived/` layer of this package
// (`subscribeAccountPositions` + `buildAccountPositions`) joins these with
// per-market mark prices and margin params from `PublicClient` to produce
// the consumer-facing enriched view.
export type AccountClient = {
  // Health of the authenticated gateway socket.  Emits the current status
  // immediately on subscribe and again whenever it changes.  With no session
  // desired (never authenticated, or after a deliberate `close`) the status
  // is `connected` -- the indicator reports problems with desired
  // connections, not idleness.  Synchronous because no I/O is needed to
  // observe status.
  createConnectionStatusSubscription: (
    onUpdate: (status: ConnectionStatus) => void,
  ) => Canceler;
  // Gateway-initiated session ends (preemption by a newer session, auth
  // expiry/revocation, rate-limit hangup).  Deliberate `disconnect()` /
  // `close()` do not emit.  The live client emits at most one event per
  // authenticated socket.
  createSessionEndSubscription: (
    onEvent: (event: SessionEndEvent) => void,
  ) => Canceler;
  // Re-establishes the authenticated session (fresh socket, fresh handshake,
  // `subscribe_account` re-sent) after a drop or a deliberate `disconnect`.
  // Resolves `Err(ConnectError)` when the session cannot be established (a
  // symbology fetch failure wraps its typed `SymbologyError`) -- never throws.
  connect: () => Promise<Result<true, ConnectError>>;
  // User-initiated disconnect: closes the socket and suppresses automatic
  // re-authentication until `connect()` is called.  Unlike `close`, the
  // client remains usable.
  disconnect: () => void;
  createRawAccountPositionsSubscription: (
    subaccountId: bigint,
    onUpdate: (positions: RawAccountPositions) => void,
  ) => Promise<Canceler>;
  // Emits the wallet's vault share holdings (`vaultAccountPubkey -> shares`, in
  // e6 wire units) parsed from the account snapshot's
  // `vault_participant_accounts`.  Emits the current map immediately once the
  // snapshot has arrived (replayed to late subscribers) and again on each fresh
  // snapshot.  The map omits vaults the wallet holds no position in; the UI
  // keys off it to show "your position" and gate the withdraw action.
  createVaultPositionsSubscription: (
    onUpdate: (shares: ReadonlyMap<string, bigint>) => void,
  ) => Canceler;
  // Paged order history for the authenticated wallet.  Sends
  // `get_order_history` over the session WS; the gateway proxies to the
  // notifier-backed query and replies with an `order_history` event
  // correlated by `request_id`. Accepts either a cursor-string shorthand or
  // an options object whose UTC Unix-second bounds filter by order creation
  // time; `nextCursor` on the result is `undefined` when the page is the last
  // one. Resolves
  // `Err(reason)` on a gateway-level reject (e.g. notifier unreachable),
  // timeout, or disconnect -- never throws.
  getOrderHistory: (
    optionsOrCursor?: GetOrderHistoryOptions | string | undefined,
  ) => Promise<Result<OrderHistoryPage, GetOrderHistoryError>>;
  // Paged lifecycle events for a single order, keyed by the gateway's
  // `external_order_id` + `market_id` (the wallet is the authenticated
  // session's bound wallet).  Sends `get_order_events` over the session WS;
  // the gateway proxies to the notifier-backed query and replies with an
  // `order_events` event correlated by `request_id`.  Backs the order
  // widget's "Show Activity" panel, which the flattened `get_order_history`
  // page no longer inlines.  Events are newest-first; `nextCursor` is
  // `undefined` on the last page.  Resolves `Err` with a typed
  // `GetOrderEventsError` on an invalid external order ID, gateway-level
  // reject (e.g. notifier unreachable), timeout, or disconnect -- never
  // throws.
  getOrderEvents: (
    externalOrderId: bigint,
    marketId: number,
    cursor?: string | undefined,
  ) => Promise<Result<OrderEventsPage, GetOrderEventsError>>;
  // Paged funding history for the authenticated wallet.  Sends
  // `get_funding_history` over the session WS; the gateway proxies to the
  // notifier-backed query and replies with a `funding_history` event
  // correlated by `request_id`.  Page size and cursor are passed through
  // unchanged (clamped server-side); `nextCursor` on the result is
  // `undefined` when the page is the last one.  Resolves `Err(reason)` on a
  // gateway-level reject (e.g. notifier unreachable), timeout, or disconnect
  // -- never throws.  Unlike the orders feed there is no live funding-history
  // subscription: funding events are fetched on demand and paginated.
  getFundingHistory: (
    cursor?: string | undefined,
  ) => Promise<Result<FundingHistoryPage, GetFundingHistoryError>>;
  // Paged vault catalog from the gateway's `get_vault_accounts` query.  Sends
  // the request over the session WS and resolves with the correlated
  // `vault_accounts` event mapped to the domain `VaultAccountsPage`; page size
  // is clamped server-side and `nextCursor` is `undefined` on the last page.
  // Requires an authenticated session (the query is private).  Resolves
  // `Err(GetVaultAccountsError)` on a gateway-level reject, timeout, or
  // disconnect -- never throws.
  getVaultAccounts: (
    cursor?: string | undefined,
  ) => Promise<Result<VaultAccountsPage, GetVaultAccountsError>>;
  // Paged historical performance series for a single vault from the gateway's
  // `get_vault_account_perf` query.  Sends the request (scoped to
  // `vaultAccount`, the vault's pubkey) over the session WS and resolves with
  // the correlated `vault_account_perf` event mapped to `VaultAccountPerfPage`;
  // events are newest-first and `nextCursor` is `undefined` on the last page.
  // The live client requests the max page size so one fetch covers the vault
  // UI's selectable window.  Requires an authenticated session.  Resolves
  // `Err(GetVaultAccountPerfError)` on a gateway-level reject, timeout, or
  // disconnect -- never throws.
  getVaultAccountPerf: (
    vaultAccount: string,
    cursor?: string | undefined,
  ) => Promise<Result<VaultAccountPerfPage, GetVaultAccountPerfError>>;
  // Live orders feed for the authenticated wallet.  Emits an `Order`
  // payload every time the live account stream touches an order the
  // client tracks: the bootstrap `AccountSnapshot.working_orders[]`
  // replay on (re)subscribe, plus each `OrderAccepted` / `OrderReject`
  // / `Fill` / `CancelAck` / `ModifyAck` event that follows.  The
  // consumer reconciles by `Order.id`: replace the entry if known,
  // prepend if new.  Subscribers receive the snapshot replay
  // asynchronously (after `subscribe_account` + the snapshot arrive);
  // late subscribers receive a fresh replay of the current set
  // immediately on subscribe.
  createOrderUpdateSubscription: (
    onUpdate: (entry: HistoryEntry) => void,
  ) => Canceler;
  createConditionalOrderSubscription: (
    onUpdate: (groups: readonly ConditionalOrderGroup[]) => void,
  ) => Canceler;
  // Sends `user_deposit_address` over the authenticated session so the
  // sequencer registers the (wallet, subaccountId) pair with the keeper.  The
  // keeper needs that mapping before the on-chain USDC transfer lands; the
  // first `deposit_collateral` on Solana lazily creates the subaccount PDA
  // from this registration.  Resolves `Ok` on the matching keeper
  // `UserDepositAddressStatus`, or `Err(reason)` on `rejected` / `busy` /
  // disconnect. It never throws (deposit-path APIs return `Result`; see
  // `./docs/AGENTS.md`).
  registerUserDepositAddress: (
    subaccountId: bigint,
  ) => Promise<Result<true, RegisterDepositAddressError>>;
  // Sends a `signed_order` over the authenticated session: builds the
  // `ContractOrderProof` envelope (codegen-emitted in
  // `@aethon/client-protocol/signedWire`),
  // has the `AuthSigner` produce the ORDER-domain-prefixed signature,
  // and posts the base64-wrapped proof to the gateway.  Resolves
  // `Ok(true)` when the gateway acks accepted (either via the legacy
  // `ack` channel or a sequencer-confirmed `OrderAccepted`); resolves
  // `Err(reason)` on a rejection, timeout, or disconnect.  Never
  // throws.
  //
  // Takes human-valued inputs: `symbol` is the market name (e.g. "BTC",
  // matched case-insensitively), `limitPrice` / `referencePrice` / `size` are
  // Dnums in human units, and `deltaBps` is basis points. The client resolves
  // the symbol against the symbology it fetched at init and applies exact
  // dnum wire scaling (limit-price snapping, price/size integer scaling,
  // bps→ppm) internally.  Resolves `Err("unknown symbol: X")` when the
  // name isn't in symbology and `Err("symbology not loaded")` when it
  // couldn't be fetched.  `tif` is honoured for limit orders and forced
  // to `"ioc"` for market / mark-to-mid.
  // Market orders omit both `referencePrice` and `deltaBps` for unrestricted
  // execution. Protected market orders require both fields, with slippage in
  // the range `(0, 10000]` bps.
  submitOrder: (
    params: SubmitOrderParams,
  ) => Promise<Result<true, SubmitOrderError>>;
  // Safely submits a parent order with recurring TP/SL protection. The parent
  // is signed and sent only after ConditionalApproved so its five-second proof
  // freshness window starts after the wait. A local signer failure cancels the
  // waiting group. Bop owns cleanup after a sequenced parent rejection, while
  // timeout/disconnect preserves the group because parent acceptance is
  // ambiguous.
  submitBracketOrder: (
    params: SubmitBracketOrderParams,
  ) => Promise<Result<true, SubmitBracketOrderError>>;
  // Cancels a Bop-owned group while it is still waiting. The group id is sent
  // as a taker-role `signed_conditional_cancel`; success resolves only when
  // the matching sequenced `ConditionalCancelled` arrives. Once the group has
  // triggered, its accepted child is cancelled through `cancelOrder` instead.
  cancelConditionalOrder: (params: {
    groupId: bigint;
    subaccountId: bigint;
    symbol: string;
  }) => Promise<Result<true, CancelConditionalOrderError>>;
  // Sends a `signed_cancel` over the authenticated session: builds the
  // `ContractCancelProofV2` envelope, has the `AuthSigner` produce the
  // CANCEL-domain-prefixed signature, and posts the base64-wrapped
  // proof to the gateway.  Resolves `Ok(true)` on the sequencer-
  // confirmed `CancelAck` for the requested `externalOrderId`;
  // resolves `Err(reason)` on a gateway-level `ack rejected` /
  // `ack busy`, timeout, or disconnect.  Never throws.
  //
  // `role` must match the matcher-assigned role of the live order
  // (carried on `Order.role` for orders tracked via the live snapshot,
  // `OrderAccepted`, or the persisted order history).  The matcher
  // rejects a cancel whose role doesn't match the live order's role.
  //
  // `symbol` is the market name (e.g. "BTC", matched case-insensitively);
  // the client resolves it to the numeric wire id from symbology.
  // Resolves `Err("unknown symbol: X")` / `Err("symbology not loaded")`
  // on a resolution failure, mirroring `submitOrder`.
  cancelOrder: (params: {
    subaccountId: bigint;
    symbol: string;
    externalOrderId: bigint;
    role: "maker" | "taker";
  }) => Promise<Result<true, CancelOrderError>>;
  // Sends `signed_withdraw` over the authenticated session: builds the
  // `ContractWithdrawProofV1` envelope, has the auth signer sign the inner
  // payload (ed25519 over the WITHDRAW_DOMAIN-prefixed bytes), and posts the
  // base64-wrapped proof.  Unlike `signed_order`, the gateway only acks
  // on rejection or busy (`dfba_gateway/signed_message_handlers.go:682-703`)
  // -- on success the actual collateral debit shows up later as a
  // `WithdrawStatus` on the same stream, and the bridged USDC lands
  // on EVM minutes after that (Wormhole guardian quorum + EVM keeper relay).
  // Resolves `Ok({ requestId64 })` on `accepted` (and on grace-period
  // silence), `Err(reason)` on `rejected` / `busy` / address-validation
  // failure / disconnect.  Never throws.
  //
  // Owner-only: the gateway rejects `signed_withdraw` from delegate-authed
  // sessions (api.md:994).  Today the Privy embedded SVM wallet always
  // auths as owner so this is enforced server-side; revisit when
  // delegate-key login lands.
  //
  // The `Ok` payload carries the `requestId64` the client generated and
  // embedded in the signed proof; consumers correlate to the eventual
  // `WithdrawStatus` event via this id (it lands in the JSON as
  // `client_instruction_id`).
  submitWithdraw: (params: {
    amount: bigint;
    destEvmAddress: string;
    subaccountId: bigint;
  }) => Promise<Result<{ requestId64: bigint }, SubmitWithdrawError>>;
  // Sends `signed_deposit_vault` over the authenticated session: builds the
  // `ContractDepositVaultProofV1` envelope, has the `AuthSigner` produce the
  // DEPOSIT_VAULT-domain-prefixed signature, and posts the base64-wrapped proof
  // targeting `vaultAccountPubkey` (from the `getVaultAccounts` listing).
  // Deposit is by USDC `amount` (e6 wire units) funded from `subaccountId`.
  // Like `submitWithdraw`, the gateway is silent on success (the credit lands
  // later as a `DepositVaultStatus`) and acks only on rejection, so this
  // resolves `Ok(true)` after a bounded grace period of silence;
  // `Err(SubmitVaultDepositError)` on bad pubkey / disconnect / signer refusal /
  // rejection.  Never throws.
  submitVaultDeposit: (params: {
    vaultAccountPubkey: string;
    amount: bigint;
    subaccountId: bigint;
  }) => Promise<Result<true, SubmitVaultDepositError>>;
  // Sends `signed_withdraw_vault` over the authenticated session, mirroring
  // `submitVaultDeposit`.  Withdraw is by `shares` (vault-share count, e6 wire
  // units) redeemed to `subaccountId`, matching the protocol's `vault_shares`
  // field.  Same silent-on-success ack contract.
  submitVaultWithdraw: (params: {
    vaultAccountPubkey: string;
    shares: bigint;
    subaccountId: bigint;
  }) => Promise<Result<true, SubmitVaultWithdrawError>>;
  // Subscribes to `WithdrawStatus` events for the given subaccount; the
  // gateway emits one per settled `signed_withdraw` request, carrying the
  // on-chain SVM tx signature in `onchain_signature`.  The consumer
  // typically filters by `client_instruction_id` to find the
  // `submitWithdraw` it just dispatched; the per-subaccount granularity
  // matches `createRawAccountPositionsSubscription`.
  createWithdrawStatusSubscription: (
    subaccountId: bigint,
    onStatus: (status: WithdrawStatus) => void,
  ) => Promise<Canceler>;
  // Subscribes to vault settlement outcomes (`DepositVaultStatus` /
  // `WithdrawVaultStatus`) for the given subaccount.  The gateway emits one per
  // settled `signed_deposit_vault` / `signed_withdraw_vault`: the proof is
  // processed off-chain, then the on-chain settlement lands (or fails) and this
  // event reports it.  The consumer surfaces failures (a `kind: "failed"`
  // status) in a dialog; `clientInstructionId` correlates back to the submit.
  createVaultOperationStatusSubscription: (
    subaccountId: bigint,
    onStatus: (status: VaultOperationStatus) => void,
  ) => Promise<Canceler>;
  // Releases the underlying transport (closes the live auth WS, rejects any
  // in-flight handshake) so a new client can be built cleanly when the signer
  // changes.  The mock client implements this as a no-op.
  close: () => void;
};
