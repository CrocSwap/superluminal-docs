import { z } from "zod";
import { wireBigint } from "../wire/wireBigint";

// Wire-format Zod schema for the gateway's `vault_account_perf` event (response
// to `get_vault_account_perf`).  Validating at the boundary (per
// `docs/typescript/data.md`) lets the live client work in branded TS types
// instead of `unknown`, mirroring `vaultAccountsWire`.
//
// Each event is one persisted `vault_account_perf` row, structurally identical
// to a vault's `latest_perf`: `total_vault_shares` (uint64) and `total_equity`
// (int64) arrive as JSON numbers and are coerced to bigint;
// `leader_share_percentage` is a decimal string (10 fractional digits) and
// `datetime` an RFC3339 timestamp -- both stay strings here and are scaled in
// `vaultAccountPerfMapping`.  Events are newest-first; `next_cursor` is the
// datetime to page from and is omitted on the last page.
const vaultAccountPerfPointSchema = z.object({
  datetime: z.string(),
  leader_share_percentage: z.string(),
  total_equity: wireBigint,
  total_vault_shares: wireBigint,
});

export const vaultAccountPerfEventSchema = z.object({
  events: z.array(vaultAccountPerfPointSchema),
  next_cursor: z.string().optional(),
  request_id: z.string().optional(),
  type: z.literal("vault_account_perf"),
  vault_account_pubkey: z.string(),
});

export type VaultAccountPerfEvent = z.infer<typeof vaultAccountPerfEventSchema>;
export type VaultAccountPerfWirePoint = z.infer<
  typeof vaultAccountPerfPointSchema
>;
