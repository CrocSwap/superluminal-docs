// Discriminant for `RegisterDepositAddressError`. Registration is only
// available on an authenticated account session. Funding actions surface
// `SignedOut` instead of moving assets before the keeper can watch the user's
// derived deposit address.
export enum RegisterDepositAddressErrorType {
  SignedOut,
  Disconnected,
  Rejected,
  Timeout,
}

// Typed failure channel for `AccountClient.registerUserDepositAddress`. Sends
// `user_deposit_address` and awaits the next command ack: the session can be
// gone (`Disconnected`), the gateway can reject (`Rejected`), or no ack arrives
// before the timeout (`Timeout`).
export const RegisterDepositAddressError = {
  Disconnected: () => ({
    type: RegisterDepositAddressErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: RegisterDepositAddressErrorType.Rejected as const,
  }),
  SignedOut: () => ({
    type: RegisterDepositAddressErrorType.SignedOut as const,
  }),
  Timeout: () => ({ type: RegisterDepositAddressErrorType.Timeout as const }),
};

export type RegisterDepositAddressError = ReturnType<
  (typeof RegisterDepositAddressError)[keyof typeof RegisterDepositAddressError]
>;

export const displayRegisterDepositAddressError = (
  error: RegisterDepositAddressError,
): string => {
  switch (error.type) {
    case RegisterDepositAddressErrorType.SignedOut:
      return "Sign in before registering a deposit address";
    case RegisterDepositAddressErrorType.Disconnected:
      return "deposit-address session disconnected";
    case RegisterDepositAddressErrorType.Rejected:
      return error.reason;
    case RegisterDepositAddressErrorType.Timeout:
      return "deposit address registration timed out";
  }
};
