import {
  encodeContractDepositVaultProofV1,
  encodeContractDepositVaultV1,
} from "@aethon/client-protocol/signedWire";
import { Err, Result } from "@cprussin/option-result";
import { awaitWithdrawAck } from "../session/awaitResolution";
import { SubmitVaultDepositError } from "../submitVaultDepositError";
import type { SignedCommandContext } from "./signedCommand";
import { SIGNED_TTL_SECONDS } from "./signedCommand";
import { base64Encode, buildDepositVaultSignMessage } from "./signMessage";
import { encodeVaultAccountPubkey } from "./vaultAccountPubkey";

export type SubmitVaultDepositParams = {
  // Base58 vault-account pubkey from the `vault_accounts` listing.
  vaultAccountPubkey: string;
  // USDC amount to deposit, in e6 wire units.
  amount: bigint;
  // Source subaccount funding the deposit.
  subaccountId: bigint;
};

// 64-byte ed25519 placeholder used to encode the proof envelope a first time
// (so we can extract the exact prefix bytes the gateway signs over); the real
// signature replaces it in the final encoding before send.
const ZERO_SIGNATURE = new Uint8Array(64);

// Builds the `ContractDepositVaultProofV1` envelope, signs the DEPOSIT_VAULT-
// domain-prefixed payload prefix, and posts the base64-wrapped proof.  Like
// `signed_withdraw`, the gateway only acks on rejection or busy
// (`handleOrderSubmitResult` in `dfba_gateway/signed_message_handlers.go`) --
// the happy path is silence and the credit lands later as a `DepositVaultStatus`
// -- so `awaitWithdrawAck` resolves `Ok` after a bounded grace period of
// silence.  The invalid-pubkey validation is surfaced as a typed
// `SubmitVaultDepositError` and this never throws.
export const submitVaultDeposit = (
  ctx: SignedCommandContext,
  params: SubmitVaultDepositParams,
  ackGraceMs: number,
): Promise<Result<true, SubmitVaultDepositError>> => {
  type DepositResult = Result<true, SubmitVaultDepositError>;
  return encodeVaultAccountPubkey(params.vaultAccountPubkey).match<
    Promise<DepositResult>
  >({
    Err: (message) =>
      Promise.resolve(Err(SubmitVaultDepositError.Validation(message))),
    Ok: async (vaultAccountPubkey) => {
      const iat = ctx.nowSeconds();
      const requestId64 = ctx.generateRequestId();
      const depositVaultBytes = encodeContractDepositVaultV1({
        depositAmount: params.amount,
        requestId64,
        vaultAccountPubkey,
      });
      // Shared envelope fields: spread into the two encodes below so the signed
      // bytes and the sent bytes can't drift.  Encoded once with a zero
      // placeholder signature to extract the bytes to sign, then again with the
      // real signature for the wire send -- mirroring `submitWithdraw`.
      const envelope = {
        depositVaultBytes,
        exp: iat + SIGNED_TTL_SECONDS,
        iat,
        partitionId: ctx.partitionId,
        senderPubkey: ctx.senderPubkey,
        signerPubkey: ctx.senderPubkey,
        sourceSubaccountId: params.subaccountId,
      };
      const unsignedProofBytes = encodeContractDepositVaultProofV1({
        ...envelope,
        signature: ZERO_SIGNATURE,
      });
      const signMessage = buildDepositVaultSignMessage(unsignedProofBytes);
      const sessionResult = await Result.wrapAsync(ctx.ensureAuthenticated());
      return sessionResult
        .mapErr(
          (): SubmitVaultDepositError => SubmitVaultDepositError.Disconnected(),
        )
        .andThenAsync(async (socket) => {
          const sigResult = await Result.wrapAsync(
            ctx.signer.signMessage(signMessage),
          );
          return sigResult
            .mapErr(
              (cause): SubmitVaultDepositError =>
                SubmitVaultDepositError.SignerRejected(
                  cause.match({ None: () => undefined, Some: (c) => c }),
                ),
            )
            .andThenAsync((signature) => {
              const signedProofBytes = encodeContractDepositVaultProofV1({
                ...envelope,
                signature,
              });
              // Listener attached before send so a fast-path rejection can't
              // race the promise resolution on a busy event loop.
              const ackPromise = awaitWithdrawAck<SubmitVaultDepositError>(
                socket,
                ackGraceMs,
                {
                  disconnected: SubmitVaultDepositError.Disconnected,
                  rejected: SubmitVaultDepositError.Rejected,
                },
              );
              socket.send(
                JSON.stringify({
                  msg_b64: base64Encode(signedProofBytes),
                  type: "signed_deposit_vault",
                }),
              );
              return ackPromise;
            });
        });
    },
  });
};
