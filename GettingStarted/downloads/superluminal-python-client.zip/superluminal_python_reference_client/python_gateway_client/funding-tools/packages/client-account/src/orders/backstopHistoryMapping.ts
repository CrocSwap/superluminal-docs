import type { BackstopHistory } from "@aethon/client-protocol/orderHistoryPage";
import type { BackstopHistoryWireRecord } from "./orderHistoryWire";
import type { OrderMarketInfo } from "./orderState";
import { dateFromUnixNs, dnumSize } from "./orderWireFields";

const positionBase = (
  position: BackstopHistoryWireRecord["backstop"]["positions"][number],
  getMarketInfo: (symbolId: number) => OrderMarketInfo | undefined,
) => {
  const market = getMarketInfo(position.market_id);
  if (market === undefined) {
    throw new Error(
      `unknown symbol ${position.market_id.toString()} in backstop history`,
    );
  } else {
    return {
      bucketIndex: position.bucket_index,
      positionIndex: position.position_index,
      quantity: dnumSize(position.quantity, market.sizeDecimals),
      symbol: market.symbol,
      symbolId: position.market_id,
    };
  }
};

// Confirmed collateral, basis, PnL and funding are all USDC atoms (10^-6).
export const toBackstopHistory = (
  wire: BackstopHistoryWireRecord,
  getMarketInfo: (symbolId: number) => OrderMarketInfo | undefined,
): BackstopHistory => {
  const detail = wire.backstop;
  const base = {
    bucketIndex: detail.bucket_index,
    collateral: dnumSize(detail.collateral, 6),
    complete: detail.complete,
    id: wire.last_event_seq,
    nonce: detail.nonce,
    signature: wire.onchain_signature,
    sourceSubaccountId: detail.source_subaccount_id,
    subaccountId: wire.subaccount_id,
    timestamp: dateFromUnixNs(wire.event_unix_ns),
  };
  if (detail.phase === "begin") {
    return {
      ...base,
      absorbedFees: dnumSize(detail.absorbed_fees, 6),
      buckets: detail.buckets.map((bucket) => ({
        collateral: dnumSize(bucket.collateral, 6),
        subaccountId: bucket.subaccount_id,
      })),
      events: [],
      orderType: "backstop-transfer",
      phase: "begin",
      positions: detail.positions.map((position) => ({
        ...positionBase(position, getMarketInfo),
        costBasis: dnumSize(position.cost_basis, 6),
        fundingIndex: position.funding_index,
      })),
      sourceCollateralRemoved: dnumSize(detail.source_collateral_removed, 6),
      sourceFeesRemoved: dnumSize(detail.source_fees_removed, 6),
      sourceNetFundingRemoved: dnumSize(detail.source_net_funding_removed, 6),
      status: "confirmed",
    };
  } else {
    return {
      ...base,
      events: [],
      orderType: "backstop-transfer",
      phase: "acquire",
      positions: detail.positions.map((position) => ({
        ...positionBase(position, getMarketInfo),
        costBasisDelta: dnumSize(position.cost_basis_delta, 6),
        fundingDelta: dnumSize(position.funding_delta, 6),
        realizedPnlDelta: dnumSize(position.realized_pnl_delta, 6),
      })),
      status: "confirmed",
    };
  }
};
