import type {
  AdlHistory,
  Order,
  OrderAcceptedEvent,
  OrderBustedEvent,
  OrderCancelledEvent,
  OrderFilledEvent,
  OrderModifiedEvent,
  OrderRejectedEvent,
  OrderStatus,
} from "@aethon/client-protocol/order";
import { add as dnAdd, subtract as dnSubtract, equal } from "dnum";
import type {
  AccountSnapshotWorkingOrder,
  AccountStreamMessage,
  AdlFailedMessage,
  CancelAckMessage,
  FillBustedMessage,
  FillMessage,
  FillSettledMessage,
  InactivePositionSettlementStatusMessage,
  ModifyAckMessage,
  OrderAcceptedMessage,
  OrderRejectMessage,
} from "../wire/wireSchema";
import {
  dateFromUnixNs,
  deltaPpmForOrderType,
  dnumPrice,
  dnumSize,
  orderTypeFromWire,
  roleFromWire,
  sideFromWireSide,
} from "./orderWireFields";

// Per-symbol metadata the order state machine needs to scale raw wire
// integers into the consumer-facing `Order` shape (Dnum prices/sizes
// scaled by symbology, plus a human symbol name).
export type OrderMarketInfo = {
  pxExponent: number;
  sizeDecimals: number;
  symbol: string;
};

export type OrderStateOptions = {
  // `undefined` for unknown symbol ids drops the event (matches
  // `createAccountState`'s no-decimals behavior for unknown markets).
  getMarketInfo: (symbolId: number) => OrderMarketInfo | undefined;
};

export type OrderState = {
  // Returns the order ids that were inserted or updated by this
  // message.  Returns `[]` for messages outside the order surface
  // (UserCollateralUpdate, AccountFundingUpdate, Fill[Settled|Busted]
  // when no matching order is tracked, unknown symbols, etc.) so the
  // live-client caller can dispatch every parsed message without
  // pre-filtering.
  apply: (message: AccountStreamMessage) => bigint[];
  get: (orderId: bigint) => Order | undefined;
  // Snapshot of every currently-tracked order.  Used by the live
  // client to replay state to a subscription that registered after
  // the bootstrap snapshot was already applied.  Iteration order is
  // unspecified; consumers reconcile by `Order.id`.
  all: () => Order[];
};

const MS_PER_SECOND = 1_000n;
const adlFillReason = 1;

const dateFromUnixSeconds = (unixS: bigint): Date =>
  new Date(Number(unixS * MS_PER_SECOND));

const tifFromWire = (tif: "GTC" | "IOC" | undefined): "gtc" | "ioc" =>
  tif === "IOC" ? "ioc" : "gtc";

const statusFromQty = (
  filledQty: bigint,
  remainingQty: bigint,
): OrderStatus => {
  if (remainingQty === 0n) {
    return "filled";
  } else if (filledQty === 0n) {
    return "unfilled";
  } else {
    return "partially_filled";
  }
};

// Reject events may arrive before the matcher stamps a timestamp;
// fall back to "now" so the resulting Order/Event sorts in roughly the
// right place in the displayed list.
const dateFromMatcherUnixNsOrNow = (matcherUnixNs: bigint | undefined): Date =>
  matcherUnixNs === undefined ? new Date() : dateFromUnixNs(matcherUnixNs);

const applyWorkingOrder = (
  orders: Map<bigint, Order>,
  wire: AccountSnapshotWorkingOrder,
  info: OrderMarketInfo,
): Order => {
  const orderType = orderTypeFromWire(wire.order_type);
  const order: Order = {
    clientInstructionId: wire.client_instruction_id,
    // Live orders carry no persisted close time; their "updated" time comes
    // from the event tail, so this stays undefined.
    closedTimestamp: undefined,
    deltaPpm: deltaPpmForOrderType(orderType, wire.delta_ppm),
    // The bootstrap snapshot doesn't carry per-event detail for working
    // orders; the persisted lifecycle for a pre-mount order comes in via
    // `get_order_history` and is merged at the hook layer.
    events: [],
    executionMode: wire.execution_mode,
    filledSize: dnumSize(wire.filled_qty, info.sizeDecimals),
    id: wire.external_order_id,
    orderType,
    price: dnumPrice(wire.price, info.pxExponent),
    role: roleFromWire(wire.role),
    side: sideFromWireSide(wire.side),
    size: dnumSize(wire.filled_qty + wire.remaining_qty, info.sizeDecimals),
    status: statusFromQty(wire.filled_qty, wire.remaining_qty),
    symbol: info.symbol,
    symbolId: wire.symbol,
    tif: tifFromWire(wire.tif),
    timestamp: dateFromUnixSeconds(wire.original_iat),
  };
  orders.set(order.id, order);
  return order;
};

const applyOrderAccepted = (
  orders: Map<bigint, Order>,
  wire: OrderAcceptedMessage,
  info: OrderMarketInfo,
  conditional: Order["conditional"],
): Order => {
  const acceptedEvent: OrderAcceptedEvent = {
    clientInstructionId: wire.client_instruction_id,
    id: wire.seq,
    kind: "accepted",
    price: dnumPrice(wire.price, info.pxExponent),
    size: dnumSize(wire.qty, info.sizeDecimals),
    timestamp: dateFromUnixNs(wire.matcher_unix_ns),
  };
  const orderType = orderTypeFromWire(wire.order_type);
  const order: Order = {
    clientInstructionId: wire.client_instruction_id,
    closedTimestamp: undefined,
    conditional,
    deltaPpm: deltaPpmForOrderType(orderType, wire.delta_ppm),
    events: [acceptedEvent],
    executionMode: wire.execution_mode,
    filledSize: dnumSize(0n, info.sizeDecimals),
    id: wire.external_order_id,
    orderType,
    price: dnumPrice(wire.price, info.pxExponent),
    role: roleFromWire(wire.role),
    side: sideFromWireSide(wire.side),
    size: dnumSize(wire.qty, info.sizeDecimals),
    status: "unfilled",
    symbol: info.symbol,
    symbolId: wire.symbol,
    tif: tifFromWire(wire.tif),
    timestamp: dateFromUnixNs(wire.matcher_unix_ns),
  };
  orders.set(order.id, order);
  return order;
};

const applyOrderReject = (
  orders: Map<bigint, Order>,
  wire: OrderRejectMessage,
  info: OrderMarketInfo,
  conditional: Order["conditional"],
): Order | undefined => {
  // `external_order_id` is optional on the wire because some rejections
  // happen before the matcher assigns one.  Without an id we have no
  // stable key for the entry in the list and skip it.
  if (wire.external_order_id === undefined) {
    return undefined;
  } else {
    const qty = wire.qty ?? 0n;
    const rejectedEvent: OrderRejectedEvent = {
      clientInstructionId: wire.client_instruction_id,
      id: wire.seq,
      kind: "rejected",
      reasonCode: wire.reason,
      timestamp: dateFromMatcherUnixNsOrNow(wire.matcher_unix_ns),
    };
    const orderType = orderTypeFromWire(wire.order_type);
    const order: Order = {
      clientInstructionId: wire.client_instruction_id,
      closedTimestamp: undefined,
      conditional,
      deltaPpm: deltaPpmForOrderType(orderType, wire.delta_ppm),
      events: [rejectedEvent],
      filledSize: dnumSize(0n, info.sizeDecimals),
      id: wire.external_order_id,
      orderType,
      price: dnumPrice(wire.price, info.pxExponent),
      role: "taker",
      side: sideFromWireSide(wire.side),
      size: dnumSize(qty, info.sizeDecimals),
      status: "rejected",
      symbol: info.symbol,
      symbolId: wire.symbol,
      timestamp: dateFromMatcherUnixNsOrNow(wire.matcher_unix_ns),
    };
    orders.set(order.id, order);
    return order;
  }
};

const applyFillToOrder = (
  orders: Map<bigint, Order>,
  wire: FillMessage,
  info: OrderMarketInfo,
): Order | undefined => {
  // Wire `external_order_id` is optional; fills without one can't be
  // routed back to a known order.
  if (wire.external_order_id === undefined) {
    return undefined;
  } else {
    const existing = orders.get(wire.external_order_id);
    if (existing === undefined) {
      return undefined;
    } else {
      const newFilledSize = dnAdd(
        existing.filledSize,
        dnumSize(wire.qty, info.sizeDecimals),
      );
      const status: OrderStatus = equal(newFilledSize, existing.size)
        ? "filled"
        : "partially_filled";
      // `id` is the gateway sequence so live and persisted events dedup by
      // the same key; `tradeId` is the matcher-assigned identifier and is
      // useful for cross-referencing fills with settlements.
      const filledEvent: OrderFilledEvent = {
        clientInstructionId: undefined,
        id: wire.seq,
        kind: "filled",
        price: dnumPrice(wire.price ?? 0n, info.pxExponent),
        size: dnumSize(wire.qty, info.sizeDecimals),
        timestamp: dateFromMatcherUnixNsOrNow(wire.matcher_unix_ns),
        tradeId: wire.trade_id,
      };
      const updated: Order = {
        ...existing,
        events: [...existing.events, filledEvent],
        filledSize: newFilledSize,
        status,
      };
      orders.set(updated.id, updated);
      return updated;
    }
  }
};

const applyAdlFillToOrder = (
  orders: Map<bigint, Order>,
  wire: FillMessage,
  info: OrderMarketInfo,
): Order => {
  if (
    wire.allocated_loss === undefined ||
    wire.batch_id === undefined ||
    wire.operation_nonce === undefined ||
    wire.price === undefined ||
    wire.request_seq === undefined ||
    wire.onchain_signature === undefined
  ) {
    throw new Error("settled ADL Fill is missing terminal workflow fields");
  } else if (wire.role !== "target" && wire.role !== "counterparty") {
    throw new Error("settled ADL Fill has an invalid ADL role");
  } else {
    const timestamp = dateFromMatcherUnixNsOrNow(wire.matcher_unix_ns);
    const adl: AdlHistory = {
      allocatedLoss: wire.allocated_loss,
      batchId: wire.batch_id,
      cleanupErrorCode: 0,
      errorCode: 0,
      failureStage: 0,
      operationNonce: wire.operation_nonce,
      requestSeq: wire.request_seq,
      role: wire.role,
      workflowErrorCode: 0,
    };
    const order: Order = {
      adl,
      closedTimestamp: timestamp,
      deltaPpm: undefined,
      events: [],
      executionMode: wire.execution_mode,
      filledSize: dnumSize(wire.qty, info.sizeDecimals),
      id: wire.operation_nonce,
      orderType: "adl",
      price: dnumPrice(wire.price, info.pxExponent),
      role: "taker",
      side: sideFromWireSide(wire.side),
      size: dnumSize(wire.qty, info.sizeDecimals),
      status: "filled",
      symbol: info.symbol,
      symbolId: wire.symbol,
      timestamp,
    };
    orders.set(order.id, order);
    return order;
  }
};

const applyFillBustedToOrder = (
  orders: Map<bigint, Order>,
  wire: FillBustedMessage,
  info: OrderMarketInfo,
): Order | undefined => {
  const existing = orders.get(wire.external_order_id);
  if (existing === undefined) {
    return undefined;
  } else {
    const bustedEvent: OrderBustedEvent = {
      clientInstructionId: undefined,
      errorCode: wire.error_code,
      errorMessage: wire.error_message,
      id: wire.seq,
      kind: "busted",
      size: dnumSize(wire.qty, info.sizeDecimals),
      timestamp: new Date(),
    };
    const updated: Order = {
      ...existing,
      events: [...existing.events, bustedEvent],
      filledSize: dnSubtract(
        existing.filledSize,
        dnumSize(wire.qty, info.sizeDecimals),
      ),
      status: "busted",
    };
    orders.set(updated.id, updated);
    return updated;
  }
};

const applyFillSettledToOrder = (
  orders: Map<bigint, Order>,
  wire: FillSettledMessage,
  info: OrderMarketInfo,
): Order | undefined => {
  if (wire.adjustment_reason !== "reduce_only") {
    return undefined;
  } else if (wire.settled_qty + wire.reduced_qty !== wire.qty) {
    throw new Error("reduce-only FillSettled has invalid quantity fields");
  } else if (wire.reduced_qty === 0n) {
    return undefined;
  } else {
    const existing = orders.get(wire.external_order_id);
    if (existing === undefined) {
      return undefined;
    } else {
      const filledSize = dnSubtract(
        existing.filledSize,
        dnumSize(wire.reduced_qty, info.sizeDecimals),
      );
      const restoresReducedQuantity =
        !wire.exhausted_leg &&
        existing.status !== "cancelled" &&
        existing.tif === "gtc" &&
        existing.orderType !== "market";
      const status = restoresReducedQuantity
        ? statusFromQty(filledSize[0], existing.size[0] - filledSize[0])
        : "cancelled";
      const updated: Order = { ...existing, filledSize, status };
      orders.set(updated.id, updated);
      return updated;
    }
  }
};

const applyAdlFailedToOrder = (
  orders: Map<bigint, Order>,
  wire: AdlFailedMessage,
  info: OrderMarketInfo,
): Order => {
  // The failure event has no matcher timestamp, so use arrival time for the
  // terminal row. The persisted ADL history later supplies event_unix_ns.
  const timestamp = new Date();
  const adl: AdlHistory = {
    allocatedLoss: wire.allocated_loss,
    batchId: wire.batch_id,
    cleanupErrorCode: wire.cleanup_error_code,
    errorCode: wire.error_code,
    failureStage: wire.failure_stage,
    operationNonce: wire.operation_nonce,
    requestSeq: wire.request_seq,
    role: wire.role,
    workflowErrorCode: wire.workflow_error_code,
  };
  const order: Order = {
    adl,
    closedTimestamp: timestamp,
    deltaPpm: undefined,
    events: [],
    filledSize: dnumSize(wire.qty, info.sizeDecimals),
    id: wire.operation_nonce,
    orderType: "adl",
    price: dnumPrice(wire.price, info.pxExponent),
    role: "taker",
    side: sideFromWireSide(wire.side),
    size: dnumSize(wire.qty, info.sizeDecimals),
    status: "rejected",
    symbol: info.symbol,
    symbolId: wire.market_id,
    timestamp,
  };
  orders.set(order.id, order);
  return order;
};

const applyCancelAck = (
  orders: Map<bigint, Order>,
  wire: CancelAckMessage,
): Order | undefined => {
  const existing = orders.get(wire.external_order_id);
  if (existing === undefined) {
    return undefined;
  } else {
    const cancelledEvent: OrderCancelledEvent = {
      clientInstructionId: undefined,
      id: wire.seq,
      kind: "cancelled",
      reasonCode: wire.reason,
      timestamp: dateFromMatcherUnixNsOrNow(wire.matcher_unix_ns),
    };
    const updated: Order = {
      ...existing,
      events: [...existing.events, cancelledEvent],
      status: "cancelled",
    };
    orders.set(updated.id, updated);
    return updated;
  }
};

const applyModifyAck = (
  orders: Map<bigint, Order>,
  wire: ModifyAckMessage,
  info: OrderMarketInfo,
): Order | undefined => {
  const existing = orders.get(wire.external_order_id);
  if (existing === undefined) {
    return undefined;
  } else if (
    existing.orderType === "adl" ||
    existing.orderType === "inactive-settlement"
  ) {
    throw new Error(
      `ModifyAck references ADL history id: ${wire.external_order_id.toString()}`,
    );
  } else {
    // ModifyAck.qty is the new remaining quantity. Preserve fills already
    // executed and reduce the order's total size by the canceled remainder.
    const newSize = dnAdd(
      existing.filledSize,
      dnumSize(wire.qty, info.sizeDecimals),
    );
    const newStatus: OrderStatus = equal(
      existing.filledSize,
      dnumSize(0n, info.sizeDecimals),
    )
      ? "unfilled"
      : "partially_filled";
    const deltaPpm = deltaPpmForOrderType(existing.orderType, wire.delta_ppm);
    const modifiedEvent: OrderModifiedEvent = {
      clientInstructionId: undefined,
      deltaPpm,
      id: wire.seq,
      kind: "modified",
      price: dnumPrice(wire.price, info.pxExponent),
      size: newSize,
      timestamp: dateFromMatcherUnixNsOrNow(wire.matcher_unix_ns),
    };
    const updated: Order = {
      ...existing,
      deltaPpm,
      events: [...existing.events, modifiedEvent],
      price: dnumPrice(wire.price, info.pxExponent),
      size: newSize,
      status: newStatus,
    };
    orders.set(updated.id, updated);
    return updated;
  }
};

const applyInactiveSettlement = (
  orders: Map<bigint, Order>,
  wire: InactivePositionSettlementStatusMessage,
  info: OrderMarketInfo,
): Order | undefined => {
  if (
    wire.settlement_price === undefined ||
    wire.settlement_price_exponent === undefined ||
    wire.settled_position_qty === undefined ||
    wire.settled_position_qty === 0n
  ) {
    return undefined;
  }
  const qty =
    wire.settled_position_qty < 0n
      ? -wire.settled_position_qty
      : wire.settled_position_qty;
  const order: Order = {
    closedTimestamp: dateFromMatcherUnixNsOrNow(wire.matcher_unix_ns),
    deltaPpm: undefined,
    events: [],
    filledSize: dnumSize(qty, info.sizeDecimals),
    id: wire.seq,
    inactiveSettlement: {
      errorCode: wire.error_code,
      executionSeq: wire.seq,
      workflowChangeCount: wire.workflow_change_count,
    },
    orderType: "inactive-settlement",
    price: dnumPrice(wire.settlement_price, wire.settlement_price_exponent),
    role: "taker",
    side: wire.settled_position_qty > 0n ? "short" : "long",
    size: dnumSize(qty, info.sizeDecimals),
    status: wire.status === 0 && wire.error_code === 0 ? "filled" : "rejected",
    symbol: info.symbol,
    symbolId: wire.market_id,
    timestamp: dateFromMatcherUnixNsOrNow(wire.matcher_unix_ns),
  };
  orders.set(order.id, order);
  return order;
};

export const createOrderState = (options: OrderStateOptions): OrderState => {
  const orders = new Map<bigint, Order>();
  const conditionalLegs = new Map<bigint, NonNullable<Order["conditional"]>>();
  const conditionalGroups = new Map<
    bigint,
    Readonly<{ stopLoss?: bigint | undefined; takeProfit?: bigint | undefined }>
  >();

  const addConditionalGroup = (
    groupId: bigint,
    takeProfit: bigint | undefined,
    stopLoss: bigint | undefined,
  ) => {
    conditionalGroups.set(groupId, { stopLoss, takeProfit });
    if (takeProfit !== undefined) {
      conditionalLegs.set(takeProfit, { groupId, leg: "take-profit" });
    }
    if (stopLoss !== undefined) {
      conditionalLegs.set(stopLoss, { groupId, leg: "stop-loss" });
    }
  };

  const removeConditionalGroup = (groupId: bigint) => {
    const group = conditionalGroups.get(groupId);
    if (group !== undefined) {
      if (group.takeProfit !== undefined) {
        conditionalLegs.delete(group.takeProfit);
      }
      if (group.stopLoss !== undefined) {
        conditionalLegs.delete(group.stopLoss);
      }
      conditionalGroups.delete(groupId);
    }
  };

  const apply = (message: AccountStreamMessage): bigint[] => {
    switch (message.type) {
      case "AccountSnapshot": {
        conditionalLegs.clear();
        conditionalGroups.clear();
        for (const subaccount of message.subaccounts) {
          for (const group of subaccount.conditional_groups ?? []) {
            addConditionalGroup(
              group.group_external_order_id,
              group.take_profit_external_order_id,
              group.stop_loss_external_order_id,
            );
          }
        }
        return message.subaccounts.flatMap((sub) =>
          (sub.working_orders ?? []).flatMap((wire) => {
            const info = options.getMarketInfo(wire.symbol);
            return info === undefined
              ? []
              : [applyWorkingOrder(orders, wire, info).id];
          }),
        );
      }
      case "ConditionalApproved": {
        addConditionalGroup(
          message.group_external_order_id,
          message.take_profit_external_order_id,
          message.stop_loss_external_order_id,
        );
        return [];
      }
      case "ConditionalTriggered": {
        const group = conditionalGroups.get(message.group_external_order_id);
        if (group !== undefined) {
          removeConditionalGroup(message.group_external_order_id);
          const conditional = {
            groupId: message.group_external_order_id,
            leg:
              message.selected_leg === 1
                ? ("take-profit" as const)
                : ("stop-loss" as const),
          };
          conditionalGroups.set(message.group_external_order_id, {
            stopLoss:
              message.selected_leg === 2
                ? message.selected_external_order_id
                : undefined,
            takeProfit:
              message.selected_leg === 1
                ? message.selected_external_order_id
                : undefined,
          });
          conditionalLegs.set(message.selected_external_order_id, conditional);
        }
        return [];
      }
      case "ConditionalExpired":
      case "ConditionalCancelled":
      case "ConditionalInvalidated":
      case "ConditionalCompleted":
        removeConditionalGroup(message.group_external_order_id);
        return [];
      case "OrderAccepted": {
        const info = options.getMarketInfo(message.symbol);
        if (info === undefined) {
          return [];
        } else {
          const conditional = conditionalLegs.get(message.external_order_id);
          const order = applyOrderAccepted(orders, message, info, conditional);
          if (conditional !== undefined) {
            removeConditionalGroup(conditional.groupId);
          }
          return [order.id];
        }
      }
      case "OrderReject": {
        const info = options.getMarketInfo(message.symbol);
        if (info === undefined) {
          return [];
        } else {
          const conditional =
            message.external_order_id === undefined
              ? undefined
              : conditionalLegs.get(message.external_order_id);
          const order = applyOrderReject(orders, message, info, conditional);
          if (conditional !== undefined) {
            removeConditionalGroup(conditional.groupId);
          }
          return order === undefined ? [] : [order.id];
        }
      }
      case "Fill": {
        if (message.reason === adlFillReason) {
          const info = options.getMarketInfo(message.symbol);
          if (info === undefined) {
            return [];
          } else {
            return [applyAdlFillToOrder(orders, message, info).id];
          }
        } else {
          const info = options.getMarketInfo(message.symbol);
          if (info === undefined) {
            return [];
          } else {
            const order = applyFillToOrder(orders, message, info);
            return order === undefined ? [] : [order.id];
          }
        }
      }
      case "AdlFailed": {
        const info = options.getMarketInfo(message.market_id);
        if (info === undefined) {
          return [];
        } else {
          return [applyAdlFailedToOrder(orders, message, info).id];
        }
      }
      case "CancelAck": {
        const order = applyCancelAck(orders, message);
        return order === undefined ? [] : [order.id];
      }
      case "ModifyAck": {
        const info = options.getMarketInfo(message.symbol);
        if (info === undefined) {
          return [];
        } else {
          const order = applyModifyAck(orders, message, info);
          return order === undefined ? [] : [order.id];
        }
      }
      case "FillBusted": {
        const info = options.getMarketInfo(message.symbol);
        if (info === undefined) {
          return [];
        } else {
          const order = applyFillBustedToOrder(orders, message, info);
          return order === undefined ? [] : [order.id];
        }
      }
      case "FillSettled": {
        const info = options.getMarketInfo(message.symbol);
        if (info === undefined) {
          return [];
        } else {
          const order = applyFillSettledToOrder(orders, message, info);
          return order === undefined ? [] : [order.id];
        }
      }
      case "CancelReject":
      case "UserCollateralUpdate":
      case "AccountFundingUpdate":
      case "BackstopTransfer":
        // These ride the same stream but don't touch the orders list.
        // `UserCollateralUpdate`/`AccountFundingUpdate`/`WithdrawStatus`
        // are balance/withdraw events; the account-state machine handles
        // them.
        return [];
      case "InactivePositionSettlementStatus": {
        const info = options.getMarketInfo(message.market_id);
        if (info === undefined) {
          return [];
        }
        const order = applyInactiveSettlement(orders, message, info);
        return order === undefined ? [] : [order.id];
      }
      case "WithdrawStatus":
      case "DepositVault":
      case "DepositVaultStatus":
      case "WithdrawVault":
      case "WithdrawVaultStatus":
        return [];
    }
  };

  return {
    all: () => Array.from(orders.values()),
    apply,
    get: (id) => orders.get(id),
  };
};
