import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

// Discriminant for `GetVaultAccountPerfError`. Owns its own enum. The perf
// mapping needs no symbology, but the shared `ensureInitialized` (which installs
// the socket handler that routes the `vault_account_perf` response) fetches it,
// so an init failure wraps the typed `SymbologyError` -- mirroring
// `GetVaultAccountsError`.
export enum GetVaultAccountPerfErrorType {
  Symbology,
  Disconnected,
  Rejected,
  Timeout,
  Unexpected,
}

// Typed failure channel for `AccountClient.getVaultAccountPerf`. Mirrors
// `GetVaultAccountsError`: shared-init failure (`Symbology`), unavailable/
// closed session (`Disconnected`), gateway `ack rejected` (`Rejected`), no
// answer before the deadline (`Timeout`), or a lifted promise rejection from
// the `useVaultAccountPerf` hook (`Unexpected`).
export const GetVaultAccountPerfError = {
  Disconnected: () => ({
    type: GetVaultAccountPerfErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: GetVaultAccountPerfErrorType.Rejected as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: GetVaultAccountPerfErrorType.Symbology as const,
  }),
  Timeout: () => ({ type: GetVaultAccountPerfErrorType.Timeout as const }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: GetVaultAccountPerfErrorType.Unexpected as const,
  }),
};

export type GetVaultAccountPerfError = ReturnType<
  (typeof GetVaultAccountPerfError)[keyof typeof GetVaultAccountPerfError]
>;

export const displayGetVaultAccountPerfError = (
  error: GetVaultAccountPerfError,
): string => {
  switch (error.type) {
    case GetVaultAccountPerfErrorType.Symbology:
      return displaySymbologyError(error.error);
    case GetVaultAccountPerfErrorType.Disconnected:
      return "vault performance session disconnected";
    case GetVaultAccountPerfErrorType.Rejected:
      return error.reason;
    case GetVaultAccountPerfErrorType.Timeout:
      return "vault performance request timed out";
    case GetVaultAccountPerfErrorType.Unexpected:
      return errorMessage(error.cause, "vault performance request failed");
  }
};
