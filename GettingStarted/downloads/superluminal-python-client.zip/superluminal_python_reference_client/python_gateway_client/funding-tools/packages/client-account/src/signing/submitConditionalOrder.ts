import {
  buildConditionalGroupSignMessageV1,
  CONDITIONAL_ACTIVATION_MODE_IMMEDIATE,
  CONDITIONAL_ACTIVATION_MODE_PARENT_FILL,
  encodeContractConditionalGroupProofV1,
  encodeContractConditionalGroupV1,
} from "@aethon/client-protocol/signedWire";
import { Result } from "@cprussin/option-result";
import { awaitConditionalOrderResolution } from "../session/awaitResolution";
import { SubmitConditionalOrderError } from "../submitConditionalOrderError";
import type { EncodedConditionalOrder } from "../wire/encodeConditionalOrderWire";
import type { SignedCommandContext } from "./signedCommand";
import { base64Encode } from "./signMessage";

export type SubmitConditionalOrderParams = EncodedConditionalOrder & {
  activationMode: "parent-fill" | "immediate";
  expiresAtUnixS: bigint;
  subaccountId: bigint;
};

export type PreparedConditionalOrder = Readonly<{
  proofBytes: Uint8Array;
  requestId64: bigint;
}>;

export type ConditionalOrderResolutionError =
  | ReturnType<typeof SubmitConditionalOrderError.Disconnected>
  | ReturnType<typeof SubmitConditionalOrderError.Rejected>
  | ReturnType<typeof SubmitConditionalOrderError.Timeout>;

const activationModeWireValue = (
  mode: SubmitConditionalOrderParams["activationMode"],
): number => {
  switch (mode) {
    case "parent-fill":
      return CONDITIONAL_ACTIVATION_MODE_PARENT_FILL;
    case "immediate":
      return CONDITIONAL_ACTIVATION_MODE_IMMEDIATE;
  }
};

export const prepareConditionalOrder = (
  ctx: SignedCommandContext,
  params: SubmitConditionalOrderParams,
  requestId64: bigint,
): Promise<Result<PreparedConditionalOrder, SubmitConditionalOrderError>> => {
  const iat = ctx.nowSeconds();
  const payload = {
    conditionalGroupBytes: encodeContractConditionalGroupV1({
      activationMode: activationModeWireValue(params.activationMode),
      exitSide: params.exitSide,
      legFlags: params.legFlags,
      qty: params.qty,
      requestId64,
      slTriggerPrice: params.slTriggerPrice,
      slTriggerSources: params.slTriggerSources,
      symbol: params.symbol,
      tpTriggerPrice: params.tpTriggerPrice,
      tpTriggerSources: params.tpTriggerSources,
      version: 1,
    }),
    exp: params.expiresAtUnixS,
    iat,
    partitionId: ctx.partitionId,
    senderPubkey: ctx.senderPubkey,
    subaccountId: params.subaccountId,
  };
  const signMessage = buildConditionalGroupSignMessageV1(payload);
  return Result.wrapAsync(ctx.signer.signMessage(signMessage)).then(
    (signatureResult) =>
      signatureResult
        .mapErr(
          (cause): SubmitConditionalOrderError =>
            SubmitConditionalOrderError.SignerRejected(
              cause.match({ None: () => undefined, Some: (value) => value }),
            ),
        )
        .map((signature) => ({
          proofBytes: encodeContractConditionalGroupProofV1({
            payload,
            signature,
            signerPubkey: ctx.senderPubkey,
          }),
          requestId64,
        })),
  );
};

export const sendPreparedConditionalOrder = (
  socket: WebSocket,
  prepared: PreparedConditionalOrder,
): Promise<Result<bigint, ConditionalOrderResolutionError>> => {
  const resolution =
    awaitConditionalOrderResolution<ConditionalOrderResolutionError>(
      socket,
      prepared.requestId64,
      {
        disconnected: SubmitConditionalOrderError.Disconnected,
        rejected: SubmitConditionalOrderError.Rejected,
        timeout: SubmitConditionalOrderError.Timeout,
      },
    );
  socket.send(
    JSON.stringify({
      msg_b64: base64Encode(prepared.proofBytes),
      type: "signed_conditional_group",
      version: 1,
    }),
  );
  return resolution;
};
