import type { Dnum } from "dnum";
import { setDecimals } from "dnum";

// Snap a user-entered limit price onto a value the gateway will accept,
// using exact dnum decimal math (never float).  A limit price must
// satisfy two combined server-side rules:
//   (1) after stripping trailing zeros, decimal places must be
//       <= MAX_PRICE_DECIMALS - market.sizeDecimals
//   (2) any remaining non-trailing-zero decimals must leave the integer
//       form within MAX_PRICE_SIG_FIGS significant figures
// The form snaps the user's input to a valid tick so what's shown equals
// what's submitted; the client validates against the same rule and
// rejects an off-tick price rather than silently coercing it.

// Matches the gateway's `signedcmd.DefaultMaxPriceDecimals`.
const MAX_PRICE_DECIMALS = 6;
const MAX_PRICE_SIG_FIGS = 5;

// floor(log10(|value|)) computed exactly from the Dnum's digits.  A Dnum
// [v, d] equals v / 10^d, so its base-10 magnitude is (digits of v) - 1 - d.
// Exact at powers of ten, where float `Math.log10` mis-rounds (e.g.
// `Math.log10(1000)` can return 2.9999…).
const magnitude = ([value, decimals]: Dnum): number => {
  const digits = (value < 0n ? -value : value).toString().length;
  return digits - 1 - decimals;
};

// Round a Dnum to `places` decimal places, half-up, exactly.  `places` may
// be negative (round to the nearest 10^-places).  dnum's `setDecimals`
// rounds half-up for the non-negative case; for negative `places` we shift
// the value down by `-places`, round to an integer, then shift back.
const roundToDecimalPlaces = (
  [value, decimals]: Dnum,
  places: number,
): Dnum => {
  if (places >= 0) {
    return setDecimals([value, decimals], places, { rounding: "ROUND_HALF" });
  } else {
    const shift = -places;
    const [rounded] = setDecimals([value, decimals + shift], 0, {
      rounding: "ROUND_HALF",
    });
    return [rounded * 10n ** BigInt(shift), 0];
  }
};

// Round a positive Dnum to `sigFigs` significant figures, half-up.
const roundToSigFigs = (value: Dnum, sigFigs: number): Dnum =>
  roundToDecimalPlaces(value, sigFigs - 1 - magnitude(value));

// Snap a user-entered limit price onto a value the gateway will accept:
// round to MAX_PRICE_SIG_FIGS first (e.g. $61234.56 → $61235), then drop any
// leftover decimals beyond the per-market allowance.
//
// Deliberate placement: this form helper is exported as the public subpath
// `@aethon/client-account/snapLimitPrice` even though it lives in the wire
// layer. It enforces exactly the gateway tick / significant-figure rules the
// wire codec encodes, so it belongs beside them rather than in a separate
// module — the shared export is an explicit decision, not a leak of internal
// wire structure. (Flagged periodically by audits; keeping this note here.)
export const snapLimitPrice = (price: Dnum, sizeDecimals: number): Dnum => {
  const sigFigsRounded = roundToSigFigs(price, MAX_PRICE_SIG_FIGS);
  const maxDecimals = Math.max(0, MAX_PRICE_DECIMALS - sizeDecimals);
  return roundToDecimalPlaces(sigFigsRounded, maxDecimals);
};
