import type {
  VaultAccount,
  VaultAccountPerf,
  VaultAccountsPage,
} from "@aethon/client-protocol/vaultAccountsPage";
import type { Dnum } from "dnum";
import { from } from "dnum";
import type { VaultAccountsEvent, VaultAccountWire } from "./vaultAccountsWire";

// Wire -> domain mapping for the gateway's `vault_accounts` event.  Kept
// separate from the socket lifecycle in `live.ts`: pure transport-to-domain
// translation, mirroring `orderHistoryMapping`.

// Shares are minted 1:1 with 6-decimal USDC collateral at vault creation
// (`contracts/svm/src/lib.rs`'s `create_vault`), so both the share count and
// the equity are 6-decimal quantities on the wire.
const USDC_DECIMALS = 6;
const SHARE_DECIMALS = 6;

const toDnumUsdc = (raw: bigint): Dnum => [raw, USDC_DECIMALS];
const toDnumShares = (raw: bigint): Dnum => [raw, SHARE_DECIMALS];

const toPerf = (
  wire: NonNullable<VaultAccountWire["latest_perf"]>,
): VaultAccountPerf => ({
  datetime: new Date(wire.datetime),
  // A decimal string with its own fractional precision; `from` reads the
  // scale off the string (e.g. "25.0000000000" -> 10 decimals).
  leaderSharePercentage: from(wire.leader_share_percentage),
  totalEquity: toDnumUsdc(wire.total_equity),
  totalVaultShares: toDnumShares(wire.total_vault_shares),
});

// The gateway sends the vault's creation time as an RFC3339 string, but emits an
// empty string when it's unknown (a null column); both absent and empty map to
// an unknown age.
const toInceptionDate = (raw: string | undefined): Date | undefined =>
  raw === undefined || raw === "" ? undefined : new Date(raw);

const toVaultAccount = (wire: VaultAccountWire): VaultAccount => ({
  inceptionDate: toInceptionDate(wire.creation_dt),
  latestPerf:
    wire.latest_perf === undefined ? undefined : toPerf(wire.latest_perf),
  leaderPubkey: wire.leader_pubkey,
  operationSubaccountPubkey: wire.operation_subaccount_pubkey,
  vaultAccountId: wire.vault_account_id,
  vaultAccountPubkey: wire.vault_account_pubkey,
});

export const toVaultAccountsPage = (
  wire: VaultAccountsEvent,
): VaultAccountsPage => ({
  nextCursor: wire.next_cursor,
  vaults: wire.vault_accounts.map(toVaultAccount),
});
