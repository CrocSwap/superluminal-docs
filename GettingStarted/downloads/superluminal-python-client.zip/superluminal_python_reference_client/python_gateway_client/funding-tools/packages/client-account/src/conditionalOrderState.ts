import type {
  ConditionalOrderGroup,
  ConditionalOrderGroupLeg,
  ConditionalOrderTriggerSources,
} from "./conditionalOrder";
import type { OrderMarketInfo } from "./orders/orderState";
import {
  dateFromUnixNs,
  dnumPrice,
  dnumSize,
  sideFromWireSide,
} from "./orders/orderWireFields";
import type {
  AccountSnapshotConditionalGroup,
  AccountStreamMessage,
  ConditionalApprovedMessage,
} from "./wire/wireSchema";

type ConditionalSource =
  | AccountSnapshotConditionalGroup
  | ConditionalApprovedMessage;

export type ConditionalOrderState = Readonly<{
  all: () => ConditionalOrderGroup[];
  apply: (message: AccountStreamMessage) => boolean;
}>;

const triggerSources = (wire: number): ConditionalOrderTriggerSources => {
  switch (wire) {
    case 1:
      return "oracle";
    case 2:
      return "auction";
    case 3:
      return "oracle-and-auction";
    default:
      throw new Error(`invalid conditional trigger sources: ${wire}`);
  }
};

const takeProfitFromWire = (
  wire: ConditionalSource,
  info: OrderMarketInfo,
): ConditionalOrderGroupLeg | undefined => {
  if (
    wire.take_profit_external_order_id === undefined ||
    wire.tp_trigger_price === undefined ||
    wire.tp_trigger_sources === undefined
  ) {
    return undefined;
  }
  return {
    externalOrderId: wire.take_profit_external_order_id,
    limitPrice: dnumPrice(wire.tp_trigger_price, info.pxExponent),
    triggerPrice: dnumPrice(wire.tp_trigger_price, info.pxExponent),
    triggerSources: triggerSources(wire.tp_trigger_sources),
  };
};

const stopLossFromWire = (
  wire: ConditionalSource,
  info: OrderMarketInfo,
): ConditionalOrderGroupLeg | undefined => {
  if (
    wire.stop_loss_external_order_id === undefined ||
    wire.sl_trigger_price === undefined ||
    wire.sl_trigger_sources === undefined
  ) {
    return undefined;
  }
  return {
    externalOrderId: wire.stop_loss_external_order_id,
    triggerPrice: dnumPrice(wire.sl_trigger_price, info.pxExponent),
    triggerSources: triggerSources(wire.sl_trigger_sources),
  };
};

const groupFromWire = (
  wire: ConditionalSource,
  subaccountId: bigint,
  info: OrderMarketInfo,
): ConditionalOrderGroup => {
  const takeProfit = takeProfitFromWire(wire, info);
  const stopLoss = stopLossFromWire(wire, info);
  const base = {
    activationMode: wire.activation_mode,
    clientInstructionId: wire.client_instruction_id,
    expiresAt: dateFromUnixNs(wire.expiry_unix_ns),
    groupId: wire.group_external_order_id,
    side: sideFromWireSide(wire.side),
    size: dnumSize(wire.qty, info.sizeDecimals),
    stopLoss,
    subaccountId,
    symbol: info.symbol,
    symbolId: wire.symbol,
    takeProfit,
  };
  switch (wire.state) {
    case "dormant":
      return { ...base, status: "armed" };
    case "waiting_fill":
    case "waiting_parent":
      return { ...base, status: wire.state };
    case "triggering":
      if (wire.pending_leg === 1) {
        if (takeProfit === undefined) {
          throw new Error(
            "triggering conditional group has no take-profit leg",
          );
        } else {
          return {
            ...base,
            selectedExternalOrderId: takeProfit.externalOrderId,
            selectedLeg: "take-profit",
            status: "triggering",
          };
        }
      } else if (stopLoss === undefined) {
        throw new Error("triggering conditional group has no stop-loss leg");
      } else {
        return {
          ...base,
          selectedExternalOrderId: stopLoss.externalOrderId,
          selectedLeg: "stop-loss",
          status: "triggering",
        };
      }
  }
};

export const createConditionalOrderState = (options: {
  getMarketInfo: (symbolId: number) => OrderMarketInfo | undefined;
}): ConditionalOrderState => {
  const groups = new Map<bigint, ConditionalOrderGroup>();

  const apply = (message: AccountStreamMessage): boolean => {
    switch (message.type) {
      case "AccountSnapshot":
        groups.clear();
        for (const subaccount of message.subaccounts) {
          for (const wire of subaccount.conditional_groups ?? []) {
            const info = options.getMarketInfo(wire.symbol);
            if (info !== undefined) {
              const group = groupFromWire(wire, subaccount.subaccount_id, info);
              groups.set(group.groupId, group);
            }
          }
        }
        return true;
      case "ConditionalApproved": {
        const info = options.getMarketInfo(message.symbol);
        if (info === undefined) {
          return false;
        }
        const group = groupFromWire(message, message.subaccount_id, info);
        groups.set(group.groupId, group);
        return true;
      }
      case "ConditionalTriggered": {
        const group = groups.get(message.group_external_order_id);
        if (group === undefined) {
          throw new Error(
            `conditional group is missing: ${message.group_external_order_id.toString()}`,
          );
        }
        if (message.selected_leg === 1) {
          if (group.takeProfit === undefined) {
            throw new Error("take-profit trigger references a missing leg");
          }
          groups.set(group.groupId, {
            ...group,
            selectedExternalOrderId: message.selected_external_order_id,
            selectedLeg: "take-profit",
            status: "triggering",
            takeProfit: {
              ...group.takeProfit,
              externalOrderId: message.selected_external_order_id,
            },
          });
        } else {
          if (group.stopLoss === undefined) {
            throw new Error("stop-loss trigger references a missing leg");
          }
          groups.set(group.groupId, {
            ...group,
            selectedExternalOrderId: message.selected_external_order_id,
            selectedLeg: "stop-loss",
            status: "triggering",
            stopLoss: {
              ...group.stopLoss,
              externalOrderId: message.selected_external_order_id,
            },
          });
        }
        return true;
      }
      case "ConditionalExpired":
      case "ConditionalCancelled":
      case "ConditionalInvalidated":
      case "ConditionalCompleted":
        return groups.delete(message.group_external_order_id);
      case "OrderAccepted":
      case "OrderReject":
      case "Fill":
      case "FillBusted":
      case "FillSettled":
      case "CancelAck":
      case "CancelReject":
      case "ModifyAck":
      case "AdlFailed":
      case "UserCollateralUpdate":
      case "AccountFundingUpdate":
      case "InactivePositionSettlementStatus":
      case "WithdrawStatus":
      case "DepositVault":
      case "DepositVaultStatus":
      case "WithdrawVault":
      case "WithdrawVaultStatus":
      case "BackstopTransfer":
        return false;
    }
  };

  return {
    all: () => Array.from(groups.values()),
    apply,
  };
};
