import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import type { Dnum } from "dnum";
import { equal, format, setDecimals } from "dnum";
import type { ConditionalTriggerSources } from "../accountClient";
import type { WireMarket } from "./encodeOrderWire";
import { snapLimitPrice } from "./snapLimitPrice";

export type EncodedConditionalOrder = {
  exitSide: number;
  legFlags: number;
  qty: bigint;
  slTriggerPrice: bigint;
  slTriggerSources: number;
  symbol: number;
  tpTriggerPrice: bigint;
  tpTriggerSources: number;
};

type ConditionalLeg = {
  triggerPrice: Dnum;
  triggerSources: ConditionalTriggerSources;
};

const triggerSourcesWireValue = (
  sources: ConditionalTriggerSources,
): number => {
  switch (sources) {
    case "oracle":
      return 1;
    case "auction":
      return 2;
    case "oracle-and-auction":
      return 3;
  }
};

const priceFor = (
  name: string,
  leg: ConditionalLeg | undefined,
  market: WireMarket,
): Result<bigint, string> => {
  if (leg === undefined) {
    return Ok(0n);
  } else {
    const snapped = snapLimitPrice(leg.triggerPrice, market.sizeDecimals);
    if (equal(snapped, leg.triggerPrice)) {
      const wirePrice = setDecimals(leg.triggerPrice, market.priceDecimals)[0];
      return wirePrice > 0n
        ? Ok(wirePrice)
        : Err(`${name} trigger price must scale to a positive wire price`);
    } else {
      return Err(
        `${name} trigger price ${format(leg.triggerPrice)} is not at a valid tick (nearest: ${format(snapped)})`,
      );
    }
  }
};

export const encodeConditionalOrderWire = (
  market: WireMarket,
  order: {
    positionSide: "long" | "short";
    size: Dnum;
    stopLoss?: ConditionalLeg | undefined;
    takeProfit?: ConditionalLeg | undefined;
  },
): Result<EncodedConditionalOrder, string> => {
  const qty = setDecimals(order.size, market.sizeDecimals)[0];
  if (qty <= 0n) {
    return Err("conditional order size must scale to a positive wire quantity");
  } else {
    return priceFor("take-profit", order.takeProfit, market).andThen(
      (tpTriggerPrice) =>
        priceFor("stop-loss", order.stopLoss, market).map((slTriggerPrice) => ({
          exitSide: order.positionSide === "long" ? 1 : 0,
          legFlags:
            (order.takeProfit === undefined ? 0 : 1) |
            (order.stopLoss === undefined ? 0 : 2),
          qty,
          slTriggerPrice,
          slTriggerSources:
            order.stopLoss === undefined
              ? 0
              : triggerSourcesWireValue(order.stopLoss.triggerSources),
          symbol: market.symbolId,
          tpTriggerPrice,
          tpTriggerSources:
            order.takeProfit === undefined
              ? 0
              : triggerSourcesWireValue(order.takeProfit.triggerSources),
        })),
    );
  }
};
