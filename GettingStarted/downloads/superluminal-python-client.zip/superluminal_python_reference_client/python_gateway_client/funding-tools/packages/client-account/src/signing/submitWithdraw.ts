import {
  encodeContractWithdrawProofV1,
  encodeContractWithdrawV1,
} from "@aethon/client-protocol/signedWire";
import { Err, Result } from "@cprussin/option-result";
import { awaitWithdrawAck } from "../session/awaitResolution";
import { SubmitWithdrawError } from "../submitWithdrawError";
import { encodeDestEvmAddress } from "./destEvmAddress";
import type { SignedCommandContext } from "./signedCommand";
import { SIGNED_TTL_SECONDS } from "./signedCommand";
import { base64Encode, buildWithdrawSignMessage } from "./signMessage";

export type SubmitWithdrawParams = {
  amount: bigint;
  destEvmAddress: string;
  subaccountId: bigint;
};

// 64-byte ed25519 placeholder used to encode the proof envelope a first
// time (so we can extract the exact bytes the gateway will hash); the
// real signature replaces it in the final encoding before send.
const ZERO_SIGNATURE = new Uint8Array(64);

// Builds the `ContractWithdrawProofV1` envelope, signs the inner payload, and
// posts the base64-wrapped proof.  The gateway only acks on rejection or busy,
// so `awaitWithdrawAck` resolves `Ok` after a bounded grace period of silence.
// The `Ok` payload carries the client-generated `requestId64` so the caller can
// correlate the eventual `WithdrawStatus` event.
export const submitWithdraw = (
  ctx: SignedCommandContext,
  params: SubmitWithdrawParams,
  ackGraceMs: number,
): Promise<Result<{ requestId64: bigint }, SubmitWithdrawError>> => {
  type WithdrawResult = Result<{ requestId64: bigint }, SubmitWithdrawError>;
  const destResult = encodeDestEvmAddress(params.destEvmAddress);
  return destResult.match<Promise<WithdrawResult>>({
    Err: (message) =>
      Promise.resolve(Err(SubmitWithdrawError.Validation(message))),
    Ok: async (destTokenAccount) => {
      const iat = ctx.nowSeconds();
      const requestId64 = ctx.generateRequestId();
      const withdrawBytes = encodeContractWithdrawV1({
        amount: params.amount,
        destTokenAccount,
        ownerWallet: ctx.senderPubkey,
        requestId64,
      });
      // Shared envelope fields: spread into the two encodes below so the
      // signed bytes and the sent bytes can't drift.  The codegen's
      // `buildWithdrawSignMessageV1` only hashes the inner withdraw,
      // not the envelope prefix the gateway actually verifies over, so
      // we reuse `encodeContractWithdrawProofV1` -- once with a zero
      // placeholder signature to extract the bytes to sign (per
      // `dfba_gateway/signedproof/signedproof.go:473-475`), and a
      // second time with the real signature for the wire send.
      const envelope = {
        exp: iat + SIGNED_TTL_SECONDS,
        iat,
        partitionId: ctx.partitionId,
        senderPubkey: ctx.senderPubkey,
        signerPubkey: ctx.senderPubkey,
        subaccountId: params.subaccountId,
        withdrawBytes,
      };
      const unsignedProofBytes = encodeContractWithdrawProofV1({
        ...envelope,
        signature: ZERO_SIGNATURE,
      });
      const signMessage = buildWithdrawSignMessage(unsignedProofBytes);
      const sessionResult = await Result.wrapAsync(ctx.ensureAuthenticated());
      return sessionResult
        .mapErr((): SubmitWithdrawError => SubmitWithdrawError.Disconnected())
        .andThenAsync(async (socket) => {
          const sigResult = await Result.wrapAsync(
            ctx.signer.signMessage(signMessage),
          );
          return sigResult
            .mapErr(
              (cause): SubmitWithdrawError =>
                SubmitWithdrawError.SignerRejected(
                  cause.match({ None: () => undefined, Some: (c) => c }),
                ),
            )
            .andThenAsync(async (signature) => {
              const signedProofBytes = encodeContractWithdrawProofV1({
                ...envelope,
                signature,
              });
              // Listener attached before send so a fast-path rejection
              // can't race the promise resolution on a busy event loop.
              // The gateway is silent on success, so this waits a
              // bounded grace period for any rejection ack and
              // otherwise resolves Ok.
              const ackPromise = awaitWithdrawAck<SubmitWithdrawError>(
                socket,
                ackGraceMs,
                {
                  disconnected: SubmitWithdrawError.Disconnected,
                  rejected: SubmitWithdrawError.Rejected,
                },
              );
              socket.send(
                JSON.stringify({
                  msg_b64: base64Encode(signedProofBytes),
                  type: "signed_withdraw",
                }),
              );
              const ackResult = await ackPromise;
              // Replace the `true` payload with the request id so the
              // caller can correlate the eventual `WithdrawStatus` event
              // (whose `client_instruction_id` equals this id).
              return ackResult.map(() => ({ requestId64 }));
            });
        });
    },
  });
};
