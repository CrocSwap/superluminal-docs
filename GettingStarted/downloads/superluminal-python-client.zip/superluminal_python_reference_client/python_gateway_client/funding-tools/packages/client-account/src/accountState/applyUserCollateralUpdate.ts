import type { UserCollateralUpdateMessage } from "../wire/wireSchema";
import type { Subaccount } from "./subaccount";
import {
  ensureSubaccount,
  positionAdjustedCollateralBalance,
} from "./subaccount";

export const applyUserCollateralUpdate = (
  subaccounts: Map<bigint, Subaccount>,
  message: UserCollateralUpdateMessage,
): bigint[] => {
  if (message.seq === 0n || message.collateral_balance < 0n) {
    return [];
  } else {
    const subaccount = ensureSubaccount(subaccounts, message.subaccount_id);
    subaccount.collateralBalance = positionAdjustedCollateralBalance(
      message.collateral_balance,
      [...subaccount.positions.values()],
    );
    return [message.subaccount_id];
  }
};
