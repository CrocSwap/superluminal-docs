import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

// Discriminant for `SubmitOrderError`. Owns its own enum; the symbology
// failure is composed by wrapping a typed `SymbologyError`, never by reusing
// its enum. `SignedOut` is produced by the `useSubmitOrder` hook (no
// authenticated session), the rest by the account client.
export enum SubmitOrderErrorType {
  Symbology,
  UnknownSymbol,
  Validation,
  Disconnected,
  SignerRejected,
  Rejected,
  Timeout,
  SignedOut,
}

// Typed failure channel for `AccountClient.submitOrder`. Symbology must load to
// resolve the symbol (`Symbology` wraps the fetch failure, `UnknownSymbol` when
// the loaded symbology has no such market); the human price must sit on a tick
// (`Validation`); then the signed command can fail because the session is gone
// (`Disconnected`), the signer refused (`SignerRejected`), the gateway/
// sequencer rejected the order (`Rejected`), or nothing answered in time
// (`Timeout`).
export const SubmitOrderError = {
  Disconnected: () => ({ type: SubmitOrderErrorType.Disconnected as const }),
  Rejected: (reason: string) => ({
    reason,
    type: SubmitOrderErrorType.Rejected as const,
  }),
  SignedOut: () => ({ type: SubmitOrderErrorType.SignedOut as const }),
  SignerRejected: (cause: unknown) => ({
    cause,
    type: SubmitOrderErrorType.SignerRejected as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: SubmitOrderErrorType.Symbology as const,
  }),
  Timeout: () => ({ type: SubmitOrderErrorType.Timeout as const }),
  UnknownSymbol: (symbol: string) => ({
    symbol,
    type: SubmitOrderErrorType.UnknownSymbol as const,
  }),
  Validation: (message: string) => ({
    message,
    type: SubmitOrderErrorType.Validation as const,
  }),
};

export type SubmitOrderError = ReturnType<
  (typeof SubmitOrderError)[keyof typeof SubmitOrderError]
>;

export const displaySubmitOrderError = (error: SubmitOrderError): string => {
  switch (error.type) {
    case SubmitOrderErrorType.Symbology:
      return displaySymbologyError(error.error);
    case SubmitOrderErrorType.UnknownSymbol:
      return `unknown symbol: ${error.symbol}`;
    case SubmitOrderErrorType.Validation:
      return error.message;
    case SubmitOrderErrorType.Disconnected:
      return "order session disconnected";
    case SubmitOrderErrorType.SignerRejected:
      return errorMessage(error.cause, "signer rejected order");
    case SubmitOrderErrorType.Rejected:
      return error.reason;
    case SubmitOrderErrorType.Timeout:
      return "order timed out";
    case SubmitOrderErrorType.SignedOut:
      return "Sign in to submit an order";
  }
};
