import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

// Discriminant for `GetOrderEventsError`. Owns its own enum; the symbology
// failure wraps a typed `SymbologyError` (symbology must load to scale the
// wire price/qty in the response); invalid order IDs fail before connecting.
export enum GetOrderEventsErrorType {
  Symbology,
  Disconnected,
  InvalidExternalOrderId,
  Rejected,
  Timeout,
  Unexpected,
}

// Typed failure channel for `AccountClient.getOrderEvents`. Mirrors
// `GetFundingHistoryError`: symbology fetch failure (`Symbology`), unavailable/
// closed session (`Disconnected`), unsafe order ID (`InvalidExternalOrderId`),
// gateway `ack rejected` (`Rejected`), no answer before the deadline
// (`Timeout`), or a lifted promise rejection from the `useOrderEvents` hook
// (`Unexpected`).
export const GetOrderEventsError = {
  Disconnected: () => ({
    type: GetOrderEventsErrorType.Disconnected as const,
  }),
  InvalidExternalOrderId: (externalOrderId: bigint) => ({
    externalOrderId,
    type: GetOrderEventsErrorType.InvalidExternalOrderId as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: GetOrderEventsErrorType.Rejected as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: GetOrderEventsErrorType.Symbology as const,
  }),
  Timeout: () => ({ type: GetOrderEventsErrorType.Timeout as const }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: GetOrderEventsErrorType.Unexpected as const,
  }),
};

export type GetOrderEventsError = ReturnType<
  (typeof GetOrderEventsError)[keyof typeof GetOrderEventsError]
>;

export const displayGetOrderEventsError = (
  error: GetOrderEventsError,
): string => {
  switch (error.type) {
    case GetOrderEventsErrorType.Symbology:
      return displaySymbologyError(error.error);
    case GetOrderEventsErrorType.Disconnected:
      return "order events session disconnected";
    case GetOrderEventsErrorType.InvalidExternalOrderId:
      return "external_order_id must be between 1 and 9007199254740991";
    case GetOrderEventsErrorType.Rejected:
      return error.reason;
    case GetOrderEventsErrorType.Timeout:
      return "order events request timed out";
    case GetOrderEventsErrorType.Unexpected:
      return errorMessage(error.cause, "order events request failed");
  }
};
