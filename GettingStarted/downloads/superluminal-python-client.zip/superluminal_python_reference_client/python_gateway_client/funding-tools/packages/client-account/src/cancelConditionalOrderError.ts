import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

export enum CancelConditionalOrderErrorType {
  Symbology,
  UnknownSymbol,
  Disconnected,
  SignerRejected,
  Rejected,
  Timeout,
  SignedOut,
}

export const CancelConditionalOrderError = {
  Disconnected: () => ({
    type: CancelConditionalOrderErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: CancelConditionalOrderErrorType.Rejected as const,
  }),
  SignedOut: () => ({
    type: CancelConditionalOrderErrorType.SignedOut as const,
  }),
  SignerRejected: (cause: unknown) => ({
    cause,
    type: CancelConditionalOrderErrorType.SignerRejected as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: CancelConditionalOrderErrorType.Symbology as const,
  }),
  Timeout: () => ({ type: CancelConditionalOrderErrorType.Timeout as const }),
  UnknownSymbol: (symbol: string) => ({
    symbol,
    type: CancelConditionalOrderErrorType.UnknownSymbol as const,
  }),
};

export type CancelConditionalOrderError = ReturnType<
  (typeof CancelConditionalOrderError)[keyof typeof CancelConditionalOrderError]
>;

export const displayCancelConditionalOrderError = (
  error: CancelConditionalOrderError,
): string => {
  switch (error.type) {
    case CancelConditionalOrderErrorType.Symbology:
      return displaySymbologyError(error.error);
    case CancelConditionalOrderErrorType.UnknownSymbol:
      return `unknown symbol: ${error.symbol}`;
    case CancelConditionalOrderErrorType.Disconnected:
      return "conditional cancel session disconnected";
    case CancelConditionalOrderErrorType.SignerRejected:
      return errorMessage(error.cause, "signer rejected conditional cancel");
    case CancelConditionalOrderErrorType.Rejected:
      return error.reason;
    case CancelConditionalOrderErrorType.Timeout:
      return "conditional cancel timed out";
    case CancelConditionalOrderErrorType.SignedOut:
      return "Sign in to cancel a TP/SL order";
  }
};
