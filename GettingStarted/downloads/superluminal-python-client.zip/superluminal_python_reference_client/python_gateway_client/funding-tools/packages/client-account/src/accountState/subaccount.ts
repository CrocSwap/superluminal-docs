import type { AccountSnapshotPosition } from "../wire/wireSchema";
import type { RawAccountPositions, RawPosition } from "./rawAccountPositions";

export type Subaccount = {
  collateralBalance: bigint;
  // Per-position state stored at the wire format's precision;
  // `lastFundingIndexE8` is internal-only -- the emitted
  // `RawAccountPositions` shape drops it but forwards `pendingFees` so the
  // derived layer can compute account equity (see `RawPosition`).
  positions: Map<number, InternalPosition>;
  // Realized PnL from reducing fills whose settlement hasn't arrived yet.
  // The notifier snapshot (the source of truth on refresh) folds a fill's
  // average-cost basis correction in at fill time but only commits its
  // realized PnL once the matching `FillSettled` lands (see
  // `dfba_notifier/snapshot_batch_source.go::recordPendingRealizedFill` /
  // `commitPendingRealizedFill`).  Mirroring that here keeps the live
  // realized/total PnL equal to the post-refresh snapshot at all times, not
  // just after settlement.  A snapshot replaces this wholesale (see
  // `applySnapshot`), which is the authoritative baseline.
  pendingRealized: PendingRealizedFill[];
};

export type InternalPosition = {
  symbolId: number;
  netQty: bigint;
  costBasis: bigint;
  pendingFees: bigint;
  fundingAccrued: bigint;
  lastFundingIndexE8: bigint;
  realizedPnl: bigint;
};

// Wire collateral is already net of the position fields. Normalize it to the
// baseline expected by the live state machine, which applies later position
// fee and funding deltas incrementally.
export const positionAdjustedCollateralBalance = (
  effectiveCollateralBalance: bigint,
  positions: readonly InternalPosition[],
): bigint =>
  positions.reduce(
    (balance, position) =>
      balance + position.pendingFees - position.fundingAccrued,
    effectiveCollateralBalance,
  );

// A reducing fill's realized PnL held until its `FillSettled` arrives, plus
// the identity fields used to match that settlement (or bust). `tradeId` is
// authoritative when present; the remaining fields support legacy events. `qty` is the
// fill leg's size; `costBasisCorrection` is the average-cost adjustment that
// was already applied to the position's basis and must be unwound on a bust.
export type PendingRealizedFill = {
  symbolId: number;
  externalOrderId: bigint;
  tradeId: bigint;
  side: "BID" | "ASK";
  qty: bigint;
  price: bigint;
  costBasisCorrection: bigint;
  realizedPnlDelta: bigint;
};

export const blankSubaccount = (): Subaccount => ({
  collateralBalance: 0n,
  pendingRealized: [],
  positions: new Map(),
});

export const ensureSubaccount = (
  subaccounts: Map<bigint, Subaccount>,
  subaccountId: bigint,
): Subaccount => {
  const existing = subaccounts.get(subaccountId);
  if (existing === undefined) {
    const created = blankSubaccount();
    subaccounts.set(subaccountId, created);
    return created;
  } else {
    return existing;
  }
};

// Find or create the position row for `symbolId`, mirroring the notifier's
// `ensurePosition`.  A freshly created row is all-zero, so applying a fill leg
// to it lands the same state as opening a brand-new position.
export const ensurePosition = (
  subaccount: Subaccount,
  symbolId: number,
): InternalPosition => {
  const existing = subaccount.positions.get(symbolId);
  if (existing === undefined) {
    const created: InternalPosition = {
      costBasis: 0n,
      fundingAccrued: 0n,
      lastFundingIndexE8: 0n,
      netQty: 0n,
      pendingFees: 0n,
      realizedPnl: 0n,
      symbolId,
    };
    subaccount.positions.set(symbolId, created);
    return created;
  } else {
    return existing;
  }
};

export const positionToInternal = (
  raw: AccountSnapshotPosition,
): InternalPosition => ({
  costBasis: raw.cost_basis,
  fundingAccrued: raw.funding_accrued,
  lastFundingIndexE8: raw.last_funding_index_e8,
  netQty: raw.net_qty,
  pendingFees: raw.pending_fees,
  realizedPnl: raw.realized_pnl,
  symbolId: raw.symbol,
});

const internalToRaw = (position: InternalPosition): RawPosition => ({
  costBasis: position.costBasis,
  fundingAccrued: position.fundingAccrued,
  netQty: position.netQty,
  pendingFees: position.pendingFees,
  realizedPnl: position.realizedPnl,
  symbolId: position.symbolId,
});

export const subaccountToRaw = (
  subaccount: Subaccount,
): RawAccountPositions => ({
  collateralBalance: subaccount.collateralBalance,
  positions: [...subaccount.positions.values()]
    // Stable ordering keeps consumer-side diffs minimal across emits.
    .sort((a, b) => a.symbolId - b.symbolId)
    .map(internalToRaw),
});
