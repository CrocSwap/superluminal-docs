import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

// Discriminant for `ConnectError`. Owns its own enum; the symbology failure is
// composed by wrapping a typed `SymbologyError`, never by reusing its enum.
export enum ConnectErrorType {
  Symbology,
  Unexpected,
}

// Typed failure channel for `AccountClient.connect`. Init runs the auth
// handshake and the symbology fetch in parallel: a symbology fetch failure
// threads its typed `SymbologyError` up as `Symbology`, and any other init
// failure (a rejected handshake, a signer error, a dropped socket) is an opaque
// thrown cause lifted to `Unexpected`.
export const ConnectError = {
  Symbology: (error: SymbologyError) => ({
    error,
    type: ConnectErrorType.Symbology as const,
  }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: ConnectErrorType.Unexpected as const,
  }),
};

export type ConnectError = ReturnType<
  (typeof ConnectError)[keyof typeof ConnectError]
>;

export const displayConnectError = (error: ConnectError): string => {
  switch (error.type) {
    case ConnectErrorType.Symbology:
      return displaySymbologyError(error.error);
    case ConnectErrorType.Unexpected:
      return errorMessage(error.cause, "connection failed");
  }
};
