import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

// Discriminant for `CancelOrderError`. Owns its own enum; the symbology failure
// wraps a typed `SymbologyError`. `SignedOut` is produced by the
// `useCancelOrder` hook, the rest by the account client. Mirrors
// `SubmitOrderError` minus the price `Validation` variant a cancel can't hit.
export enum CancelOrderErrorType {
  Symbology,
  UnknownSymbol,
  Disconnected,
  SignerRejected,
  Rejected,
  Timeout,
  SignedOut,
}

// Typed failure channel for `AccountClient.cancelOrder`.
export const CancelOrderError = {
  Disconnected: () => ({ type: CancelOrderErrorType.Disconnected as const }),
  Rejected: (reason: string) => ({
    reason,
    type: CancelOrderErrorType.Rejected as const,
  }),
  SignedOut: () => ({ type: CancelOrderErrorType.SignedOut as const }),
  SignerRejected: (cause: unknown) => ({
    cause,
    type: CancelOrderErrorType.SignerRejected as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: CancelOrderErrorType.Symbology as const,
  }),
  Timeout: () => ({ type: CancelOrderErrorType.Timeout as const }),
  UnknownSymbol: (symbol: string) => ({
    symbol,
    type: CancelOrderErrorType.UnknownSymbol as const,
  }),
};

export type CancelOrderError = ReturnType<
  (typeof CancelOrderError)[keyof typeof CancelOrderError]
>;

export const displayCancelOrderError = (error: CancelOrderError): string => {
  switch (error.type) {
    case CancelOrderErrorType.Symbology:
      return displaySymbologyError(error.error);
    case CancelOrderErrorType.UnknownSymbol:
      return `unknown symbol: ${error.symbol}`;
    case CancelOrderErrorType.Disconnected:
      return "cancel session disconnected";
    case CancelOrderErrorType.SignerRejected:
      return errorMessage(error.cause, "signer rejected cancel");
    case CancelOrderErrorType.Rejected:
      return error.reason;
    case CancelOrderErrorType.Timeout:
      return "cancel timed out";
    case CancelOrderErrorType.SignedOut:
      return "Sign in to cancel an order";
  }
};
