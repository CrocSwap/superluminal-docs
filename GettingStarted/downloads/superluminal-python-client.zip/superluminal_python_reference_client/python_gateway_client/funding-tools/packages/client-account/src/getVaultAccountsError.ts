import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

// Discriminant for `GetVaultAccountsError`. Owns its own enum. The vault
// mapping needs no symbology, but the shared `ensureInitialized` (which installs
// the socket handler that routes the `vault_accounts` response) fetches it, so
// an init failure wraps the typed `SymbologyError`.
export enum GetVaultAccountsErrorType {
  Symbology,
  Disconnected,
  Rejected,
  Timeout,
  Unexpected,
}

// Typed failure channel for `AccountClient.getVaultAccounts`. Mirrors
// `GetFundingHistoryError`: shared-init failure (`Symbology`), unavailable/
// closed session (`Disconnected`), gateway `ack rejected` (`Rejected`), no
// answer before the deadline (`Timeout`), or a lifted promise rejection from
// the `useVaults` hook (`Unexpected`).
export const GetVaultAccountsError = {
  Disconnected: () => ({
    type: GetVaultAccountsErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: GetVaultAccountsErrorType.Rejected as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: GetVaultAccountsErrorType.Symbology as const,
  }),
  Timeout: () => ({ type: GetVaultAccountsErrorType.Timeout as const }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: GetVaultAccountsErrorType.Unexpected as const,
  }),
};

export type GetVaultAccountsError = ReturnType<
  (typeof GetVaultAccountsError)[keyof typeof GetVaultAccountsError]
>;

export const displayGetVaultAccountsError = (
  error: GetVaultAccountsError,
): string => {
  switch (error.type) {
    case GetVaultAccountsErrorType.Symbology:
      return displaySymbologyError(error.error);
    case GetVaultAccountsErrorType.Disconnected:
      return "vault accounts session disconnected";
    case GetVaultAccountsErrorType.Rejected:
      return error.reason;
    case GetVaultAccountsErrorType.Timeout:
      return "vault accounts request timed out";
    case GetVaultAccountsErrorType.Unexpected:
      return errorMessage(error.cause, "vault accounts request failed");
  }
};
