import { errorMessage } from "@aethon/client-protocol/errorMessage";

// Discriminant for `SubmitVaultWithdrawError`. Owns its own enum. `SignedOut`
// is produced by the `useVaultWithdraw` hook, the rest by the account client.
// There is no `Timeout`: the gateway is silent on withdraw success, so
// grace-period silence resolves `Ok`, never a timeout error.
export enum SubmitVaultWithdrawErrorType {
  Validation,
  Disconnected,
  SignerRejected,
  Rejected,
  SignedOut,
}

// Typed failure channel for `AccountClient.submitVaultWithdraw`. The target
// vault pubkey is validated before any I/O (`Validation`); then the signed
// command can fail because the session is gone (`Disconnected`), the signer
// refused (`SignerRejected`), or the gateway rejected the withdraw
// (`Rejected`).
export const SubmitVaultWithdrawError = {
  Disconnected: () => ({
    type: SubmitVaultWithdrawErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: SubmitVaultWithdrawErrorType.Rejected as const,
  }),
  SignedOut: () => ({ type: SubmitVaultWithdrawErrorType.SignedOut as const }),
  SignerRejected: (cause: unknown) => ({
    cause,
    type: SubmitVaultWithdrawErrorType.SignerRejected as const,
  }),
  Validation: (message: string) => ({
    message,
    type: SubmitVaultWithdrawErrorType.Validation as const,
  }),
};

export type SubmitVaultWithdrawError = ReturnType<
  (typeof SubmitVaultWithdrawError)[keyof typeof SubmitVaultWithdrawError]
>;

export const displaySubmitVaultWithdrawError = (
  error: SubmitVaultWithdrawError,
): string => {
  switch (error.type) {
    case SubmitVaultWithdrawErrorType.Validation:
      return error.message;
    case SubmitVaultWithdrawErrorType.Disconnected:
      return "withdraw session disconnected";
    case SubmitVaultWithdrawErrorType.SignerRejected:
      return errorMessage(error.cause, "signer rejected vault withdraw");
    case SubmitVaultWithdrawErrorType.Rejected:
      return error.reason;
    case SubmitVaultWithdrawErrorType.SignedOut:
      return "Sign in to withdraw";
  }
};
