// `RawPosition` mirrors exactly what the gateway's `account_snapshot.positions`
// carries -- the numeric symbol id (resolved to a string by the `derived/`
// layer via symbology), the signed net quantity, the signed cost basis, the
// realized PnL, accrued funding, and the pending (un-swept) fees.  All
// numeric fields are raw int64 values straight off the wire; the `derived/`
// layer scales them into `Dnum`s using `Market.sizeDecimals` (for `netQty`)
// and the USDC e6 convention (for `costBasis` / `realizedPnl` /
// `fundingAccrued` / `pendingFees`).
//
// Side and size derive from `netQty`'s sign and absolute value; entry price
// is `costBasis / netQty`.  Fields that depend on mark price (mark price,
// unrealised PnL, leverage, liquidation) aren't available here -- the
// `derived/` layer joins this with per-market mark prices and per-market
// margin params to compute them. Account equity is
// `collateral + sum(realizedPnl + fundingAccrued - pendingFees) +
// sum(markPrice*netQty - costBasis)`, so the derived layer needs
// `realizedPnl` and `pendingFees` to compute it.
export type RawPosition = {
  symbolId: number;
  netQty: bigint;
  costBasis: bigint;
  realizedPnl: bigint;
  fundingAccrued: bigint;
  pendingFees: bigint;
};

// `RawAccountPositions` is the account-state shape derived from one gateway
// snapshot subaccount: the position-adjusted collateral baseline plus the raw
// position rows. Effective wire collateral is normalized before reaching it. The
// `derived/` layer enriches this with market data (mark price, margin
// params) to produce the consumer-facing `AccountPositions` shape.
//
// TODO: extend with `workingOrders` once the live decode lands the order
// path, so the `derived/` layer can compute reserved margin and surface a
// correct `availableBalance`.  Until then available balance is collateral
// minus open-position initial margin only.
export type RawAccountPositions = {
  collateralBalance: bigint;
  positions: RawPosition[];
};
