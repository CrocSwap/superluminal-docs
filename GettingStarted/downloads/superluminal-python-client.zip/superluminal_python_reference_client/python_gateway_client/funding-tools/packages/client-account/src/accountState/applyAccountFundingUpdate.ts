import type { AccountFundingUpdateMessage } from "../wire/wireSchema";
import type { Subaccount } from "./subaccount";
import { ensureSubaccount } from "./subaccount";

export const applyAccountFundingUpdate = (
  subaccounts: Map<bigint, Subaccount>,
  message: AccountFundingUpdateMessage,
): bigint[] => {
  if (message.seq === 0n || message.market_id === 0) {
    return [];
  } else {
    const subaccount = ensureSubaccount(subaccounts, message.subaccount_id);
    const symbolId = message.symbol ?? message.market_id;
    const existing = subaccount.positions.get(symbolId);
    if (existing === undefined) {
      subaccount.positions.set(symbolId, {
        costBasis: 0n,
        fundingAccrued: message.funding_accrued ?? 0n,
        lastFundingIndexE8: message.last_funding_index_e8 ?? 0n,
        netQty: 0n,
        pendingFees: 0n,
        realizedPnl: 0n,
        symbolId,
      });
    } else {
      existing.fundingAccrued =
        message.funding_accrued ?? existing.fundingAccrued;
      existing.lastFundingIndexE8 =
        message.last_funding_index_e8 ?? existing.lastFundingIndexE8;
    }
    return [message.subaccount_id];
  }
};
