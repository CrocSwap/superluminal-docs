import type { OrderEvent } from "@aethon/client-protocol/order";
import type { OrderEventsPage } from "@aethon/client-protocol/orderEventsPage";
import type { SymbologyMarket } from "@aethon/client-protocol/symbologyMarket";
import type { Dnum } from "dnum";
import type { MarketDecimals } from "../accountState/marketDecimals";
import type { OrderEventsEvent, OrderEventWire } from "./orderEventsWire";
import { dateFromUnixNs, dnumPrice, dnumSize } from "./orderWireFields";

// Wire -> domain mapping for the notifier's `get_order_events` response.  Raw
// bigints are scaled to Dnum using the per-symbol metadata the live client
// caches at init.  Kept separate from the socket lifecycle in `live.ts`: pure
// transport-to-domain translation, parameterised by the symbology lookups.

// USDC amounts (fees) are wire-encoded at e6; match the `USDC_DECIMALS`
// constant used elsewhere so the public surface stays uniform.
const USDC_DECIMALS = 6;

const toDnumUsdc = (raw: bigint): Dnum => [raw, USDC_DECIMALS];

// Map a persisted-history lifecycle event to the public `OrderEvent` shape.
// The wire schema is a discriminated union on `event_type`, so each arm below
// sees exactly the fields its variant guarantees -- no re-validation needed.
export const toOrderEvent = (
  wire: OrderEventWire,
  decimals: MarketDecimals,
): OrderEvent => {
  const base = {
    clientInstructionId: wire.client_instruction_id,
    id: wire.stream_seq,
    timestamp: dateFromUnixNs(wire.event_unix_ns),
  };
  switch (wire.event_type) {
    case "accepted": {
      return {
        ...base,
        kind: "accepted",
        price:
          wire.price === undefined
            ? undefined
            : dnumPrice(wire.price, decimals.pxExponent),
        size: dnumSize(wire.qty, decimals.sizeDecimals),
      };
    }
    case "modified": {
      return {
        ...base,
        deltaPpm: wire.delta_ppm,
        kind: "modified",
        price:
          wire.price === undefined
            ? undefined
            : dnumPrice(wire.price, decimals.pxExponent),
        size:
          wire.qty === undefined
            ? undefined
            : dnumSize(wire.qty, decimals.sizeDecimals),
      };
    }
    case "filled": {
      return {
        ...base,
        kind: "filled",
        price: dnumPrice(wire.price, decimals.pxExponent),
        size: dnumSize(wire.qty, decimals.sizeDecimals),
        tradeId: wire.trade_id,
      };
    }
    case "cancelled": {
      return { ...base, kind: "cancelled", reasonCode: wire.reason_code };
    }
    case "rejected": {
      return { ...base, kind: "rejected", reasonCode: wire.reason_code };
    }
    case "settled": {
      return {
        ...base,
        fee: wire.fee === undefined ? undefined : toDnumUsdc(wire.fee),
        kind: "settled",
        settlementSeq: wire.settlement_seq,
        size: dnumSize(wire.qty, decimals.sizeDecimals),
      };
    }
    case "busted": {
      return {
        ...base,
        errorCode: wire.error_code ?? wire.reason_code,
        errorMessage: wire.error_message,
        kind: "busted",
        size: dnumSize(wire.qty, decimals.sizeDecimals),
      };
    }
    case "reduced": {
      return {
        ...base,
        kind: "reduced",
        size: dnumSize(wire.qty, decimals.sizeDecimals),
      };
    }
    case "cancel_rejected": {
      return {
        ...base,
        kind: "cancel_rejected",
        reasonCode: wire.reason_code,
      };
    }
    case "modify_rejected": {
      return {
        ...base,
        kind: "modify_rejected",
        reasonCode: wire.reason_code,
      };
    }
  }
};

// Convert a wire `order_events` event to the public-facing `OrderEventsPage`,
// scaling raw bigints to Dnum using the market's decimals.  The page carries a
// single `market_id`, so all events resolve against the same decimals entry.
export const toOrderEventsPage = (
  wire: OrderEventsEvent,
  marketsBySymbolId: ReadonlyMap<number, SymbologyMarket>,
): OrderEventsPage => {
  const market = marketsBySymbolId.get(wire.market_id);
  if (market === undefined) {
    throw new Error(
      `unknown market ${wire.market_id.toString()} in order events; symbology cache missing entry`,
    );
  } else {
    return {
      events: wire.events.map((event) => toOrderEvent(event, market)),
      externalOrderId: wire.external_order_id,
      marketId: wire.market_id,
      nextCursor: wire.next_cursor,
    };
  }
};
