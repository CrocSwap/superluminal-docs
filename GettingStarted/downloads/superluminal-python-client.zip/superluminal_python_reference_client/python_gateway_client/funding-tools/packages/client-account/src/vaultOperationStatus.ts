import type { VaultStatusMessage } from "./wire/wireSchema";

// Consumer-facing settlement result for a `signed_deposit_vault` /
// `signed_withdraw_vault`.  The wire form (snake_case, numeric `status`) stays
// internal to the account stream; this is the normalized shape the trading-app
// sees.  `operation` distinguishes the two flows so the UI can title the
// failure ("deposit" vs "withdraw").  `clientInstructionId` matches the
// `request_id_64` the client embedded in the proof, so consumers correlate by
// equality.  The `settled`/`failed` split keeps the failure-only fields
// unrepresentable on a success.
export type VaultOperationStatus = {
  readonly operation: "deposit" | "withdraw";
  readonly clientInstructionId: bigint;
  readonly subaccountId: bigint;
  readonly vaultAccountPubkey: string | undefined;
} & (
  | { readonly kind: "settled" }
  | {
      readonly kind: "failed";
      readonly rawStatus: number;
      readonly errorCode: number | undefined;
      // Machine-ish failure enum (e.g. "TransactionFailed") — the key
      // `humanizeVaultFailure` maps to friendly copy.
      readonly error: string | undefined;
      // Failure origin (e.g. "settlement").
      readonly errorDomain: string | undefined;
      // Server-provided human sentence (e.g. "Settlement transaction failed").
      readonly errorMessage: string | undefined;
    }
);

// Map a wire vault settlement status to its domain form at the subscription
// fan-out.  A vault operation settled successfully only when it finalized
// (`status === 0`) AND carries no error (`error_code` 0/absent); a finalized
// status with a non-zero `status` or `error_code` means the on-chain settlement
// failed and nothing moved.  Mirrors `toWithdrawStatus`.
export const toVaultOperationStatus = (
  message: VaultStatusMessage,
): VaultOperationStatus => {
  const base = {
    clientInstructionId: message.client_instruction_id,
    operation:
      message.type === "WithdrawVaultStatus" || message.type === "WithdrawVault"
        ? ("withdraw" as const)
        : ("deposit" as const),
    subaccountId: message.subaccount_id,
    vaultAccountPubkey: message.vault_account_pubkey,
  };
  if (
    message.status === 0 &&
    (message.error_code === undefined || message.error_code === 0)
  ) {
    return { ...base, kind: "settled" };
  } else {
    return {
      ...base,
      error: message.error,
      errorCode: message.error_code,
      errorDomain: message.error_domain,
      errorMessage: message.error_message,
      kind: "failed",
      rawStatus: message.status,
    };
  }
};
