import {
  buildOrderSignMessage,
  EXECUTION_MODE_NORMAL,
  EXECUTION_MODE_REDUCE_ONLY,
  encodeContractOrderProof,
  encodeContractOrderV1,
} from "@aethon/client-protocol/signedWire";
import { Result } from "@cprussin/option-result";
import { awaitOrderResolution } from "../session/awaitResolution";
import { SubmitOrderError } from "../submitOrderError";
import type { SignedCommandContext } from "./signedCommand";
import {
  base64Encode,
  orderExpFor,
  orderTypeWireConfig,
  tifWireValue,
} from "./signMessage";

export type SubmitOrderParams = {
  subaccountId: bigint;
  symbol: number;
  side: "long" | "short";
  reduceOnly: boolean;
  orderType: "market" | "limit" | "mark-to-mid";
  price: bigint;
  size: bigint;
  deltaPpm: number;
  tif: "gtc" | "ioc";
};

export type PreparedOrder = Readonly<{
  proofBytes: Uint8Array;
  requestId64: bigint;
}>;

export type OrderResolutionError =
  | ReturnType<typeof SubmitOrderError.Disconnected>
  | ReturnType<typeof SubmitOrderError.Rejected>
  | ReturnType<typeof SubmitOrderError.Timeout>;

export const prepareOrder = (
  ctx: SignedCommandContext,
  params: SubmitOrderParams,
  requestId64: bigint,
): Promise<Result<PreparedOrder, SubmitOrderError>> => {
  const iat = ctx.nowSeconds();
  const wireConfig = orderTypeWireConfig(params.orderType);
  const orderBytes = encodeContractOrderV1({
    deltaPpm: params.deltaPpm,
    executionMode: params.reduceOnly
      ? EXECUTION_MODE_REDUCE_ONLY
      : EXECUTION_MODE_NORMAL,
    orderType: wireConfig.orderType,
    price: params.price,
    qty: params.size,
    requestId64,
    role: wireConfig.role,
    side: params.side === "long" ? 0 : 1,
    symbol: params.symbol,
    tif: tifWireValue(params.tif),
  });
  const payload = {
    exp: orderExpFor(iat, params.tif),
    iat,
    orderBytes,
    partitionId: ctx.partitionId,
    senderPubkey: ctx.senderPubkey,
    subaccountId: params.subaccountId,
  };
  const signMessage = buildOrderSignMessage(payload);
  return Result.wrapAsync(ctx.signer.signMessage(signMessage)).then(
    (signatureResult) =>
      signatureResult
        .mapErr(
          (cause): SubmitOrderError =>
            SubmitOrderError.SignerRejected(
              cause.match({ None: () => undefined, Some: (value) => value }),
            ),
        )
        .map((signature) => ({
          proofBytes: encodeContractOrderProof({
            payload,
            signature,
            signerPubkey: ctx.senderPubkey,
          }),
          requestId64,
        })),
  );
};

export const sendPreparedOrder = (
  socket: WebSocket,
  prepared: PreparedOrder,
): Promise<Result<true, OrderResolutionError>> => {
  const resolution = awaitOrderResolution<OrderResolutionError>(
    socket,
    prepared.requestId64,
    {
      disconnected: SubmitOrderError.Disconnected,
      rejected: SubmitOrderError.Rejected,
      timeout: SubmitOrderError.Timeout,
    },
  );
  socket.send(
    JSON.stringify({
      msg_b64: base64Encode(prepared.proofBytes),
      type: "signed_order",
    }),
  );
  return resolution;
};

export const sendPreparedConditionalParent = (
  socket: WebSocket,
  prepared: PreparedOrder,
  groupExternalOrderId: bigint,
): Promise<Result<true, OrderResolutionError>> => {
  const resolution = awaitOrderResolution<OrderResolutionError>(
    socket,
    prepared.requestId64,
    {
      disconnected: SubmitOrderError.Disconnected,
      rejected: SubmitOrderError.Rejected,
      timeout: SubmitOrderError.Timeout,
    },
  );
  socket.send(
    JSON.stringify({
      conditional_group_external_order_id: groupExternalOrderId.toString(),
      msg_b64: base64Encode(prepared.proofBytes),
      type: "signed_conditional_parent",
      version: 1,
    }),
  );
  return resolution;
};

// Builds and signs the order only after authentication, then posts it and
// waits for the sequencer-confirmed `OrderAccepted` / `OrderReject`.
export const submitOrder = (
  ctx: SignedCommandContext,
  params: SubmitOrderParams,
): Promise<Result<true, SubmitOrderError>> => {
  const requestId64 = ctx.generateRequestId();
  return Result.wrapAsync(ctx.ensureAuthenticated()).then((sessionResult) =>
    sessionResult
      .mapErr((): SubmitOrderError => SubmitOrderError.Disconnected())
      .andThenAsync((socket) =>
        prepareOrder(ctx, params, requestId64).then((preparedResult) =>
          preparedResult.andThenAsync((prepared) =>
            sendPreparedOrder(socket, prepared),
          ),
        ),
      ),
  );
};
