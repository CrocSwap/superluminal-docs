import type { AuthSigner } from "../session/authSigner";

// Collaborators every signed gateway command shares: the authenticated-socket
// source, the wallet signer, and the envelope fields the gateway verifies over
// (sender pubkey, partition id, the `iat` clock, and the request-id source).
// `nowSeconds` / `generateRequestId` are injected so tests can pin `iat` and
// `request_id_64` to fixed values and assert against a deterministic frame.
export type SignedCommandContext = {
  ensureAuthenticated: () => Promise<WebSocket>;
  signer: AuthSigner;
  senderPubkey: Uint8Array;
  partitionId: number;
  nowSeconds: () => bigint;
  generateRequestId: () => bigint;
};

// Freshness TTL for signed gateway envelopes. The on-chain program rejects a
// request whose issued-at or expiry timestamp is outside this five-minute window.
export const SIGNED_TTL_SECONDS = 300n;
