import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";

// Re-encodes a user-supplied 0x-prefixed 20-byte EVM address into the
// `dest_token_account` shape the signed_withdraw payload expects:
// 32 bytes with the leading 12 zero (the SVM handler at
// `contracts/svm/src/lib.rs:1217-1220` requires
// `dest_token_account[..12] == 0`) and the address bytes at offset 12.
// On the EVM side the Wormhole keeper decodes the inner 64-byte payload
// as `Withdrawal { address to; uint256 amount }`; the 12-byte zero
// prefix is the high half of the Solidity ABI encoding of `address to`.
const HEX_CHAR = /^[0-9a-fA-F]+$/;
const ADDRESS_PADDING = 12;
const ADDRESS_HEX_LEN = 40;
const DEST_ACCOUNT_LEN = 32;

export const encodeDestEvmAddress = (
  address: string,
): Result<Uint8Array, string> => {
  if (!address.startsWith("0x")) {
    return Err("EVM address must start with 0x");
  } else if (address.length === 2 + ADDRESS_HEX_LEN) {
    const hex = address.slice(2);
    if (HEX_CHAR.test(hex)) {
      const out = new Uint8Array(DEST_ACCOUNT_LEN);
      for (let i = 0; i < ADDRESS_HEX_LEN / 2; i++) {
        out[ADDRESS_PADDING + i] = Number.parseInt(
          hex.slice(i * 2, i * 2 + 2),
          16,
        );
      }
      return Ok(out);
    } else {
      return Err("EVM address contains non-hex characters");
    }
  } else {
    return Err("EVM address must be 0x + 40 hex characters");
  }
};
