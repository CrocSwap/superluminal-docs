import type { VaultAccountPerfPage } from "@aethon/client-protocol/vaultAccountPerfPage";
import type { VaultAccountPerf } from "@aethon/client-protocol/vaultAccountsPage";
import type { Dnum } from "dnum";
import { from } from "dnum";
import type {
  VaultAccountPerfEvent,
  VaultAccountPerfWirePoint,
} from "./vaultAccountPerfWire";

// Wire -> domain mapping for the gateway's `vault_account_perf` event.  Kept
// separate from the socket lifecycle in `live.ts`: pure transport-to-domain
// translation, mirroring `vaultAccountsMapping` (which maps the same perf-row
// shape for a vault's `latestPerf`).

// Shares are minted 1:1 with 6-decimal USDC collateral at vault creation, so
// both the share count and the equity are 6-decimal quantities on the wire --
// matching `vaultAccountsMapping`.
const USDC_DECIMALS = 6;
const SHARE_DECIMALS = 6;

const toDnumUsdc = (raw: bigint): Dnum => [raw, USDC_DECIMALS];
const toDnumShares = (raw: bigint): Dnum => [raw, SHARE_DECIMALS];

const toPerf = (wire: VaultAccountPerfWirePoint): VaultAccountPerf => ({
  datetime: new Date(wire.datetime),
  // A decimal string with its own fractional precision; `from` reads the
  // scale off the string (e.g. "25.0000000000" -> 10 decimals).
  leaderSharePercentage: from(wire.leader_share_percentage),
  totalEquity: toDnumUsdc(wire.total_equity),
  totalVaultShares: toDnumShares(wire.total_vault_shares),
});

export const toVaultAccountPerfPage = (
  wire: VaultAccountPerfEvent,
): VaultAccountPerfPage => ({
  events: wire.events.map(toPerf),
  nextCursor: wire.next_cursor,
});
