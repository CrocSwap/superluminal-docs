import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import type { Dnum } from "dnum";
import { equal, format, setDecimals } from "dnum";
import { snapLimitPrice } from "./snapLimitPrice";

// Pure human->gateway wire scaling for a single order, using exact dnum
// decimal math (never float).  Lives in the client so the per-symbol
// decimals fetched at init are the single source of truth for how orders
// are priced/sized on the wire; the app keeps only form concerns (string
// parsing, quote->base conversion against the live mid).

// Per-symbol scaling envelope.  `priceDecimals = -px_exponent` and
// `sizeDecimals = size_decimals` from symbology.
export type WireMarket = {
  symbolId: number;
  priceDecimals: number;
  sizeDecimals: number;
};

// Human-valued order, post-form-parsing, discriminated on `orderType` so
// each variant carries exactly the fields that are meaningful for it: only
// limit orders carry a limit price and honour the submitted `tif` (market /
// mark-to-mid always take liquidity, so their tif is forced to "ioc" on the
// wire). Protected market orders carry a reference price plus slippage;
// unrestricted market orders carry neither.
type WireOrderBase = {
  side: "long" | "short";
  size: Dnum;
};

export type WireOrder =
  | (WireOrderBase & {
      orderType: "limit";
      limitPrice: Dnum;
      tif: "gtc" | "ioc";
    })
  | (WireOrderBase &
      (
        | {
            orderType: "market";
            referencePrice: Dnum;
            deltaBps: number;
          }
        | {
            orderType: "market";
            referencePrice?: undefined;
            deltaBps?: undefined;
          }
      ))
  | (WireOrderBase & { orderType: "mark-to-mid"; deltaBps: number });

const MAX_MARKET_SLIPPAGE_BPS = 10_000;
const PPM_PER_BPS = 100;

// Narrow the flat order shape the public `submitOrder` params carry into the
// discriminated `WireOrder`.  The public surface keeps `limitPrice` /
// reference and delta fields independently optional, so their per-order-type
// invariants can only be enforced here at the boundary. Invalid combinations
// stay on the public submitOrder method's typed validation-error channel.
export const toWireOrder = (order: {
  side: "long" | "short";
  orderType: "market" | "limit" | "mark-to-mid";
  limitPrice?: Dnum | undefined;
  referencePrice?: Dnum | undefined;
  size: Dnum;
  deltaBps?: number | undefined;
  tif: "gtc" | "ioc";
}): Result<WireOrder, string> => {
  switch (order.orderType) {
    case "limit": {
      if (order.limitPrice === undefined) {
        return Err("limit order requires a limit price");
      } else {
        return Ok({
          limitPrice: order.limitPrice,
          orderType: "limit",
          side: order.side,
          size: order.size,
          tif: order.tif,
        });
      }
    }
    case "market": {
      if (order.referencePrice === undefined && order.deltaBps === undefined) {
        return Ok({
          orderType: "market",
          side: order.side,
          size: order.size,
        });
      } else if (
        order.referencePrice !== undefined &&
        order.deltaBps !== undefined
      ) {
        const deltaPpm = Math.round(order.deltaBps * PPM_PER_BPS);
        if (!Number.isFinite(order.deltaBps) || deltaPpm <= 0) {
          return Err(
            "market reference price requires non-zero positive slippage",
          );
        } else if (order.deltaBps > MAX_MARKET_SLIPPAGE_BPS) {
          return Err("market slippage must not exceed 100%");
        } else {
          return Ok({
            deltaBps: order.deltaBps,
            orderType: "market",
            referencePrice: order.referencePrice,
            side: order.side,
            size: order.size,
          });
        }
      } else {
        return Err(
          "market protection requires both reference price and slippage",
        );
      }
    }
    case "mark-to-mid": {
      if (order.deltaBps === undefined) {
        return Err("mark-to-mid order requires a delta");
      } else {
        return Ok({
          deltaBps: order.deltaBps,
          orderType: "mark-to-mid",
          side: order.side,
          size: order.size,
        });
      }
    }
  }
};

// Gateway-scaled wire shape, ready for the `signed_order` builder.
export type EncodedWireOrder = {
  symbol: number;
  side: "long" | "short";
  orderType: "market" | "limit" | "mark-to-mid";
  price: bigint;
  size: bigint;
  deltaPpm: number;
  tif: "gtc" | "ioc";
};

// Gateway-integer price, or `Err` when a limit price isn't at a valid tick.
// Limit orders validate the human price against `snapLimitPrice` and reject
// (rather than silently coerce) an off-tick value, so what the form showed is
// exactly what goes on the wire; the exact `order.limitPrice` is scaled by
// priceDecimals (it equals the snapped value when valid).  A protected market
// order scales its current-price reference without tick validation; an
// unrestricted market order and mark-to-mid send zero.
const priceFor = (
  order: WireOrder,
  market: WireMarket,
): Result<bigint, string> => {
  switch (order.orderType) {
    case "limit": {
      const snapped = snapLimitPrice(order.limitPrice, market.sizeDecimals);
      return equal(snapped, order.limitPrice)
        ? Ok(setDecimals(order.limitPrice, market.priceDecimals)[0])
        : Err(
            `limit price ${format(order.limitPrice)} is not at a valid tick (nearest: ${format(snapped)})`,
          );
    }
    case "market": {
      if (order.referencePrice === undefined) {
        return Ok(0n);
      } else {
        const referencePrice = setDecimals(
          order.referencePrice,
          market.priceDecimals,
        )[0];
        return referencePrice > 0n
          ? Ok(referencePrice)
          : Err("market reference price must scale to a positive wire price");
      }
    }
    case "mark-to-mid": {
      return Ok(0n);
    }
  }
};

// Gateway `delta_ppm`. Protected market slippage and mark-to-mid delta are
// form-facing basis points; bps→ppm is ×100.
const deltaPpmFor = (order: WireOrder): number => {
  switch (order.orderType) {
    case "market": {
      return order.deltaBps === undefined
        ? 0
        : Math.round(order.deltaBps * PPM_PER_BPS);
    }
    case "mark-to-mid": {
      return Math.round(order.deltaBps * PPM_PER_BPS);
    }
    case "limit": {
      return 0;
    }
  }
};

// Effective TIF.  Market and mark-to-mid always take liquidity immediately,
// so any unfilled remainder must cancel (IOC); limit orders honour the
// submitted choice.
const tifFor = (order: WireOrder): "gtc" | "ioc" => {
  switch (order.orderType) {
    case "limit": {
      return order.tif;
    }
    case "market":
    case "mark-to-mid": {
      return "ioc";
    }
  }
};

export const encodeOrderWire = (
  market: WireMarket,
  order: WireOrder,
): Result<EncodedWireOrder, string> =>
  priceFor(order, market).map((price) => ({
    deltaPpm: deltaPpmFor(order),
    orderType: order.orderType,
    price,
    side: order.side,
    size: setDecimals(order.size, market.sizeDecimals)[0],
    symbol: market.symbolId,
    tif: tifFor(order),
  }));
