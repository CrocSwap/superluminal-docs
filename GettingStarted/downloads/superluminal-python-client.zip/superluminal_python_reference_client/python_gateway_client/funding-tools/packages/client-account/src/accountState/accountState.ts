import type { AccountStreamMessage } from "../wire/wireSchema";
import { applyAccountFundingUpdate } from "./applyAccountFundingUpdate";
import { applyBackstopTransfer } from "./applyBackstopTransfer";
import { applyFill, applyFillBusted, applyFillSettled } from "./applyFill";
import { applyInactivePositionSettlementStatus } from "./applyInactivePositionSettlementStatus";
import { applySnapshot } from "./applySnapshot";
import { applyUserCollateralUpdate } from "./applyUserCollateralUpdate";
import { applyWithdrawStatus } from "./applyWithdrawStatus";
import type { MarketDecimals } from "./marketDecimals";
import type { RawAccountPositions } from "./rawAccountPositions";
import type { Subaccount } from "./subaccount";
import { subaccountToRaw } from "./subaccount";

export type AccountStateOptions = {
  // Lookup for the per-symbol decimals needed by the fill cost-basis math.
  // Returning `undefined` means we can't value the fill; the apply function
  // logs and applies only the qty leg in that case (the snapshot re-sets
  // cost basis and realized PnL on the next connect anyway).
  getMarketDecimals: (symbolId: number) => MarketDecimals | undefined;
};

export type AccountState = {
  // Apply one decoded gateway message.  Returns the list of subaccount ids
  // whose state was mutated, so the live client knows whom to notify.
  apply: (message: AccountStreamMessage) => bigint[];
  // Read the latest raw shape for one subaccount.  Returns `undefined` if
  // no snapshot or update has touched this subaccount yet.
  getRaw: (subaccountId: bigint) => RawAccountPositions | undefined;
};

type Internals = {
  subaccounts: Map<bigint, Subaccount>;
  lastSeq: bigint;
};

// Sequence numbers in incremental events are monotonic and the snapshot
// carries `last_seq`; events at or below `last_seq` are stale and ignored.
// This matches the C++ `AccountState::should_ignore_event` guard.
const shouldIgnoreEvent = (lastSeq: bigint, eventSeq: bigint): boolean =>
  eventSeq !== 0n && eventSeq <= lastSeq;

const advanceLastSeq = (lastSeq: bigint, seq: bigint): bigint =>
  seq > lastSeq ? seq : lastSeq;

// Common shape for every incremental event: drop if stale, run the
// applier, advance `lastSeq`.  Centralizes the bookkeeping so each
// case in `applyMessage` just describes how its specific message
// mutates state.
const dispatchSeqedEvent = <M extends { seq: bigint }>(
  internals: Internals,
  message: M,
  apply: () => bigint[],
): bigint[] => {
  if (shouldIgnoreEvent(internals.lastSeq, message.seq)) {
    return [];
  } else {
    const changed = apply();
    internals.lastSeq = advanceLastSeq(internals.lastSeq, message.seq);
    return changed;
  }
};

const applyMessage = (
  internals: Internals,
  options: AccountStateOptions,
  message: AccountStreamMessage,
): bigint[] => {
  switch (message.type) {
    case "AccountSnapshot": {
      if (internals.lastSeq !== 0n && message.last_seq <= internals.lastSeq) {
        // Snapshot is stale relative to events we've already applied.
        return [];
      } else {
        const changed = applySnapshot(internals.subaccounts, message);
        internals.lastSeq = message.last_seq;
        return changed;
      }
    }
    case "Fill":
      return dispatchSeqedEvent(internals, message, () =>
        applyFill(
          internals.subaccounts,
          message,
          options.getMarketDecimals(message.symbol),
        ),
      );
    case "FillBusted":
      return dispatchSeqedEvent(internals, message, () =>
        applyFillBusted(
          internals.subaccounts,
          message,
          options.getMarketDecimals(message.symbol),
        ),
      );
    case "FillSettled":
      // Settlement either commits the provisional fill or atomically replaces
      // it with the reduce-only settled quantity. An unmatched settlement is
      // a no-op; either way the seq is consumed.
      return dispatchSeqedEvent(internals, message, () =>
        applyFillSettled(
          internals.subaccounts,
          message,
          options.getMarketDecimals(message.symbol),
        ),
      );
    case "UserCollateralUpdate":
      return dispatchSeqedEvent(internals, message, () =>
        applyUserCollateralUpdate(internals.subaccounts, message),
      );
    case "AccountFundingUpdate":
      return dispatchSeqedEvent(internals, message, () =>
        applyAccountFundingUpdate(internals.subaccounts, message),
      );
    case "InactivePositionSettlementStatus":
      return dispatchSeqedEvent(internals, message, () =>
        applyInactivePositionSettlementStatus(internals.subaccounts, message),
      );
    case "BackstopTransfer":
      return dispatchSeqedEvent(internals, message, () =>
        applyBackstopTransfer(internals.subaccounts, message),
      );
    case "OrderAccepted":
    case "OrderReject":
    case "ConditionalApproved":
    case "ConditionalTriggered":
    case "ConditionalExpired":
    case "ConditionalCancelled":
    case "ConditionalInvalidated":
    case "ConditionalCompleted":
    case "CancelAck":
    case "CancelReject":
    case "ModifyAck":
    case "AdlFailed":
      // Order lifecycle events feed `orderState` (a separate state
      // machine focused on the orders list).  They don't move position
      // state, but they still carry a `seq` so we advance `lastSeq` to
      // keep the snapshot-vs-event ordering coherent.
      internals.lastSeq = advanceLastSeq(internals.lastSeq, message.seq);
      return [];
    case "WithdrawStatus":
      // Authoritative collateral debit for a user withdraw -- the
      // persistor mirrors it into `accounts.collateral_balance` when it
      // processes the event, so a replayed `WithdrawStatus` whose seq
      // sits at or below the snapshot's `last_seq` has already been
      // applied to the wire balance.  The standard seq guard drops
      // those; live events with `seq > lastSeq` debit incrementally so
      // the user sees the balance update ahead of the next snapshot.
      return dispatchSeqedEvent(internals, message, () =>
        applyWithdrawStatus(internals.subaccounts, message),
      );
    case "DepositVaultStatus":
    case "DepositVault":
    case "WithdrawVaultStatus":
    case "WithdrawVault":
      // Vault settlement outcomes: the collateral moved into/out of the
      // subaccount is reflected by the snapshot / `UserCollateralUpdate`
      // flow, so the position-state machine treats these as no-ops.  The
      // live client fans them out separately for the failure dialog.
      return [];
  }
};

export const createAccountState = (
  options: AccountStateOptions,
): AccountState => {
  const internals: Internals = {
    lastSeq: 0n,
    subaccounts: new Map(),
  };
  return {
    apply: (message) => applyMessage(internals, options, message),
    getRaw: (subaccountId) => {
      const subaccount = internals.subaccounts.get(subaccountId);
      return subaccount === undefined ? undefined : subaccountToRaw(subaccount);
    },
  };
};
