import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";
import type { CancelConditionalOrderError } from "./cancelConditionalOrderError";
import { displayCancelConditionalOrderError } from "./cancelConditionalOrderError";
import type { SubmitConditionalOrderError } from "./submitConditionalOrderError";
import { displaySubmitConditionalOrderError } from "./submitConditionalOrderError";
import type { SubmitOrderError } from "./submitOrderError";
import { displaySubmitOrderError } from "./submitOrderError";

export enum SubmitBracketOrderErrorType {
  Symbology,
  UnknownSymbol,
  Validation,
  Disconnected,
  Conditional,
  Parent,
  Cleanup,
  SignedOut,
}

export const SubmitBracketOrderError = {
  Cleanup: (
    parent: SubmitOrderError,
    cleanup: CancelConditionalOrderError,
  ) => ({
    cleanup,
    parent,
    type: SubmitBracketOrderErrorType.Cleanup as const,
  }),
  Conditional: (error: SubmitConditionalOrderError) => ({
    error,
    type: SubmitBracketOrderErrorType.Conditional as const,
  }),
  Disconnected: () => ({
    type: SubmitBracketOrderErrorType.Disconnected as const,
  }),
  Parent: (error: SubmitOrderError) => ({
    error,
    type: SubmitBracketOrderErrorType.Parent as const,
  }),
  SignedOut: () => ({
    type: SubmitBracketOrderErrorType.SignedOut as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: SubmitBracketOrderErrorType.Symbology as const,
  }),
  UnknownSymbol: (symbol: string) => ({
    symbol,
    type: SubmitBracketOrderErrorType.UnknownSymbol as const,
  }),
  Validation: (message: string) => ({
    message,
    type: SubmitBracketOrderErrorType.Validation as const,
  }),
};

export type SubmitBracketOrderError = ReturnType<
  (typeof SubmitBracketOrderError)[keyof typeof SubmitBracketOrderError]
>;

export const displaySubmitBracketOrderError = (
  error: SubmitBracketOrderError,
): string => {
  switch (error.type) {
    case SubmitBracketOrderErrorType.Symbology:
      return displaySymbologyError(error.error);
    case SubmitBracketOrderErrorType.UnknownSymbol:
      return `unknown symbol: ${error.symbol}`;
    case SubmitBracketOrderErrorType.Validation:
      return error.message;
    case SubmitBracketOrderErrorType.Disconnected:
      return "bracket order session disconnected";
    case SubmitBracketOrderErrorType.Conditional:
      return displaySubmitConditionalOrderError(error.error);
    case SubmitBracketOrderErrorType.Parent:
      return displaySubmitOrderError(error.error);
    case SubmitBracketOrderErrorType.Cleanup:
      return `${displaySubmitOrderError(error.parent)}; failed to cancel TP/SL group: ${displayCancelConditionalOrderError(error.cleanup)}`;
    case SubmitBracketOrderErrorType.SignedOut:
      return "Sign in to submit a bracket order";
  }
};
