import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { SymbologyError } from "@aethon/client-protocol/symbologyError";
import { displaySymbologyError } from "@aethon/client-protocol/symbologyError";

// Discriminant for `GetFundingHistoryError`. Owns its own enum; the symbology
// failure wraps a typed `SymbologyError` (symbology must load to resolve the
// wire market ids in the response back to human names).
export enum GetFundingHistoryErrorType {
  Symbology,
  Disconnected,
  Rejected,
  Timeout,
  Unexpected,
}

// Typed failure channel for `AccountClient.getFundingHistory`. Mirrors
// `GetOrderHistoryError`: symbology fetch failure (`Symbology`), unavailable/
// closed session (`Disconnected`), gateway `ack rejected` (`Rejected`), no
// answer before the deadline (`Timeout`), or a lifted promise rejection from
// the `useFundingHistory` hook (`Unexpected`).
export const GetFundingHistoryError = {
  Disconnected: () => ({
    type: GetFundingHistoryErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: GetFundingHistoryErrorType.Rejected as const,
  }),
  Symbology: (error: SymbologyError) => ({
    error,
    type: GetFundingHistoryErrorType.Symbology as const,
  }),
  Timeout: () => ({ type: GetFundingHistoryErrorType.Timeout as const }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: GetFundingHistoryErrorType.Unexpected as const,
  }),
};

export type GetFundingHistoryError = ReturnType<
  (typeof GetFundingHistoryError)[keyof typeof GetFundingHistoryError]
>;

export const displayGetFundingHistoryError = (
  error: GetFundingHistoryError,
): string => {
  switch (error.type) {
    case GetFundingHistoryErrorType.Symbology:
      return displaySymbologyError(error.error);
    case GetFundingHistoryErrorType.Disconnected:
      return "funding history session disconnected";
    case GetFundingHistoryErrorType.Rejected:
      return error.reason;
    case GetFundingHistoryErrorType.Timeout:
      return "funding history request timed out";
    case GetFundingHistoryErrorType.Unexpected:
      return errorMessage(error.cause, "funding history request failed");
  }
};
