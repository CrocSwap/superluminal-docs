import type { VaultStatusMessage } from "../wire/wireSchema";

// One participant account's per-vault holdings, as carried on the account
// snapshot's `vault_participant_accounts[]`.
type VaultParticipantAccount = {
  entries: readonly { shares: bigint; vault_account_pubkey: string }[];
};

const vaultShareDelta = (message: VaultStatusMessage): bigint => {
  switch (message.type) {
    case "DepositVault":
    case "WithdrawVault":
      return 0n;
    case "DepositVaultStatus":
      return message.minted_vault_shares ?? 0n;
    case "WithdrawVaultStatus":
      return -(message.requested_vault_shares ?? 0n);
  }
};

// Aggregates the wallet's vault holdings into `vaultAccountPubkey -> total
// shares` (e6 wire units).  Sums across every participant account and entry so
// a vault held via more than one entry reports its combined share count.  The
// UI keys off this to show "your position" and to gate the withdraw action.
export const vaultSharesFromSnapshot = (
  participantAccounts: readonly VaultParticipantAccount[] | undefined,
): Map<string, bigint> =>
  (participantAccounts ?? [])
    .flatMap((account) => account.entries)
    .reduce(
      (shares, entry) =>
        shares.set(
          entry.vault_account_pubkey,
          (shares.get(entry.vault_account_pubkey) ?? 0n) + entry.shares,
        ),
      new Map<string, bigint>(),
    );

// A settled vault deposit/withdraw only reaches `vault_participant_accounts`
// (and thus `vaultSharesFromSnapshot`) on the next account snapshot, which the
// gateway doesn't push eagerly.  So a successful `DepositVaultStatus` /
// `WithdrawVaultStatus` is treated as the authoritative delta to the wallet's
// holding for that vault -- mirroring how `WithdrawStatus` authoritatively
// debits collateral ahead of the next snapshot -- keeping the "your position"
// column and the withdraw gate live.  A deposit adds `minted_vault_shares`; a
// withdraw subtracts `requested_vault_shares` (the shares the settlement burns;
// the entry is dropped once it hits zero).  A failed settlement, an absent vault
// pubkey, or a missing/zero share delta returns the map unchanged (referentially,
// so callers can skip a redundant re-emit).
export const applyVaultStatusToShares = (
  current: ReadonlyMap<string, bigint>,
  message: VaultStatusMessage,
): ReadonlyMap<string, bigint> => {
  const settled =
    message.status === 0 &&
    (message.error_code === undefined || message.error_code === 0);
  if (!settled || message.vault_account_pubkey === undefined) {
    return current;
  } else {
    const delta = vaultShareDelta(message);
    if (delta === 0n) {
      return current;
    } else {
      const next = new Map(current);
      const updated = (next.get(message.vault_account_pubkey) ?? 0n) + delta;
      if (updated > 0n) {
        next.set(message.vault_account_pubkey, updated);
      } else {
        next.delete(message.vault_account_pubkey);
      }
      return next;
    }
  }
};
