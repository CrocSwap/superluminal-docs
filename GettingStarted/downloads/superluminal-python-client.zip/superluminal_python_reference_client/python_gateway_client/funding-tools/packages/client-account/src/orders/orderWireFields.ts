import type { NormalOrderType } from "@aethon/client-protocol/order";
import { priceDecimalsOf } from "@aethon/client-protocol/priceDecimals";
import type { Dnum } from "dnum";

// Shared wire-field -> domain converters for a single order, used by both the
// live order state machine (`orderState.ts`) and the persisted-history decoder
// (`orderHistoryMapping.ts`).  Both paths produce the same public `Order` /
// `OrderEvent` shape, so the per-field scaling rules live here once rather than
// drifting between the two decoders.

const NS_PER_MS = 1_000_000n;

// Wire timestamps are unix nanoseconds; scale to a JS `Date` (milliseconds).
export const dateFromUnixNs = (unixNs: bigint): Date =>
  new Date(Number(unixNs / NS_PER_MS));

// Raw `price` is interpreted as `human = price * 10^pxExponent`, so the
// matching Dnum exponent is the price-decimals count for that exponent.
export const dnumPrice = (raw: bigint, pxExponent: number): Dnum => [
  raw,
  priceDecimalsOf(pxExponent),
];

export const dnumSize = (raw: bigint, sizeDecimals: number): Dnum => [
  raw,
  sizeDecimals,
];

// Wire book side -> order-direction axis.  A `BID` is a book buy (long
// side); an `ASK` is a book sell (short side).  This is the only place the
// wire's BID/ASK encoding is translated into the public `long`/`short`
// vocabulary on the read path.
export const sideFromWireSide = (side: "BID" | "ASK"): "long" | "short" =>
  side === "BID" ? "long" : "short";

// Wire role is optional (the snapshot omits it for orders the matcher hasn't
// classified; OrderAccepted omits it when the gateway forwards the raw client
// submission).  The trading-app only submits as taker, so absent-role events
// fall back to "taker" -- the public surface stays non-optional and the cancel
// path can always send a role the matcher recognises.
export const roleFromWire = (
  role: "MAKER" | "TAKER" | undefined,
): "maker" | "taker" => (role === "MAKER" ? "maker" : "taker");

// `delta_ppm` is meaningful for mark-to-mid orders and carries slippage for
// market orders. Limit orders do not use it.
export const deltaPpmForOrderType = (
  orderType: NormalOrderType,
  deltaPpm: number | undefined,
): number | undefined => {
  switch (orderType) {
    case "limit":
      return undefined;
    case "market":
      return deltaPpm ?? 0;
    case "mark-to-mid":
      return deltaPpm;
  }
};

// Decodes the gateway's numeric `order_type` enum (pinned in
// `protocol/idl/signed_wire.json` and mirrored in `orderTypeWireConfig` in
// `live.ts`) into the public-facing string union.  Unknown values throw -- the
// gateway only emits the three documented variants, and silently folding a
// future variant into an existing label would mislabel orders in the UI.
export const orderTypeFromWire = (wire: number): NormalOrderType => {
  switch (wire) {
    case 0: {
      return "limit";
    }
    case 1: {
      return "mark-to-mid";
    }
    case 2: {
      return "market";
    }
    default: {
      throw new Error(`unknown order_type wire value: ${wire.toString()}`);
    }
  }
};
