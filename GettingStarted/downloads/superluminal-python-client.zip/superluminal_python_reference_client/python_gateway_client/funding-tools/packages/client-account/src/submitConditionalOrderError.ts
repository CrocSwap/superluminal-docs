import { errorMessage } from "@aethon/client-protocol/errorMessage";

export enum SubmitConditionalOrderErrorType {
  Disconnected,
  SignerRejected,
  Rejected,
  Timeout,
}

export const SubmitConditionalOrderError = {
  Disconnected: () => ({
    type: SubmitConditionalOrderErrorType.Disconnected as const,
  }),
  Rejected: (reason: string) => ({
    reason,
    type: SubmitConditionalOrderErrorType.Rejected as const,
  }),
  SignerRejected: (cause: unknown) => ({
    cause,
    type: SubmitConditionalOrderErrorType.SignerRejected as const,
  }),
  Timeout: () => ({
    type: SubmitConditionalOrderErrorType.Timeout as const,
  }),
};

export type SubmitConditionalOrderError = ReturnType<
  (typeof SubmitConditionalOrderError)[keyof typeof SubmitConditionalOrderError]
>;

export const displaySubmitConditionalOrderError = (
  error: SubmitConditionalOrderError,
): string => {
  switch (error.type) {
    case SubmitConditionalOrderErrorType.Disconnected:
      return "conditional order session disconnected";
    case SubmitConditionalOrderErrorType.SignerRejected:
      return errorMessage(error.cause, "signer rejected conditional order");
    case SubmitConditionalOrderErrorType.Rejected:
      return error.reason;
    case SubmitConditionalOrderErrorType.Timeout:
      return "conditional order timed out";
  }
};
