import type { GetOrderHistoryOptions } from "./accountClient";

export const INVALID_ORDER_HISTORY_CREATED_FROM =
  "invalid_order_history_created_from";
export const INVALID_ORDER_HISTORY_CREATED_TO =
  "invalid_order_history_created_to";
export const INVALID_ORDER_HISTORY_CREATED_RANGE =
  "invalid_order_history_created_range";

const isInvalidUnixSeconds = (value: number | undefined): boolean =>
  value !== undefined && (!Number.isSafeInteger(value) || value < 0);

export const orderHistoryQueryValidationReason = (
  options: GetOrderHistoryOptions | undefined,
): string | undefined => {
  if (isInvalidUnixSeconds(options?.createdFromUnixS)) {
    return INVALID_ORDER_HISTORY_CREATED_FROM;
  } else if (isInvalidUnixSeconds(options?.createdToUnixS)) {
    return INVALID_ORDER_HISTORY_CREATED_TO;
  } else if (
    options?.createdFromUnixS !== undefined &&
    options.createdToUnixS !== undefined &&
    options.createdFromUnixS >= options.createdToUnixS
  ) {
    return INVALID_ORDER_HISTORY_CREATED_RANGE;
  } else {
    return undefined;
  }
};
