import { z } from "zod";
import { backstopDetailsSchema } from "../wire/backstopWire";
import {
  wireBigint,
  wireDecimalUint64,
  wireExternalOrderId,
} from "../wire/wireBigint";

// Wire-format Zod schema for the gateway's `order_history` event (response
// to `get_order_history`).  Validating at the boundary (per
// `docs/typescript/data.md`) lets the live client work in branded TS types
// instead of `unknown`.

// `side` and `status` are forwarded verbatim from the gateway-side
// notifier query (which mirrors the persisted enum strings). `role` is parsed because the cancel
// path needs it to match the matcher-assigned role on cancel.  The page is
// flat: `filled_qty` / `settled_qty` / `busted_qty` / `reduced_qty` are
// gateway-aggregated totals and per-order lifecycle events are fetched separately with
// `get_order_events` (see `orderEventsWire.ts`).
//
// `filled_qty` is optional because the released gateway does not yet emit it
// (it lands with PR #880); the mapping falls back to
// `original_qty - remaining_qty` when it is absent.  The released gateway also
// still emits a legacy `events` field (as `null`); the schema ignores it (the
// default `z.object` strips unknown keys), so a `null` or array value passes
// through harmlessly.
const orderHistoryOrderSchema = z
  .object({
    busted_qty: wireBigint,
    client_instruction_id: wireDecimalUint64.optional(),
    closed_unix_ns: wireBigint.optional(),
    conditional_group_external_order_id: wireExternalOrderId.optional(),
    conditional_leg: z.union([z.literal(1), z.literal(2)]).optional(),
    created_unix_ns: wireBigint,
    delta_ppm: z.number().optional(),
    execution_mode: z.number().int().min(0).max(4).optional(),
    external_order_id: wireExternalOrderId,
    filled_qty: wireBigint.optional(),
    last_event_seq: wireBigint,
    order_type: z.number(),
    original_qty: wireBigint,
    price: wireBigint,
    reduced_qty: wireBigint.optional(),
    remaining_qty: wireBigint,
    role: z.enum(["MAKER", "TAKER"]).optional(),
    settled_qty: wireBigint,
    side: z.enum(["BID", "ASK"]),
    status: z.enum(["open", "filled", "canceled", "rejected"]),
    symbol: z.number(),
    tif: z.enum(["GTC", "IOC"]).optional(),
  })
  .superRefine((order, ctx) => {
    if (
      (order.conditional_group_external_order_id === undefined) !==
      (order.conditional_leg === undefined)
    ) {
      ctx.addIssue({
        code: "custom",
        message: "TP/SL group id and leg must be provided together",
        path: ["conditional_group_external_order_id"],
      });
    }
  });

const adlHistoryRecordSchema = z.object({
  allocated_loss: wireBigint,
  batch_id: wireBigint,
  cleanup_error_code: z.number(),
  error_code: z.number(),
  event_unix_ns: wireBigint,
  failure_stage: z.number(),
  fill_price: wireBigint,
  fill_qty: wireBigint,
  last_event_seq: wireBigint,
  market_id: z.number(),
  operation_nonce: wireBigint,
  request_seq: wireBigint,
  role: z.enum(["target", "counterparty"]),
  side: z.enum(["BID", "ASK"]),
  status: z.enum(["settled", "failed"]),
  subaccount_id: wireBigint,
  workflow_error_code: z.number(),
});

const inactiveSettlementHistoryRecordSchema = z.object({
  error_code: z.number(),
  event_unix_ns: wireBigint,
  last_event_seq: wireBigint,
  market_id: z.number(),
  position_qty: wireBigint,
  settlement_execution_seq: wireBigint,
  settlement_price: wireBigint,
  settlement_price_exponent: z.number(),
  status: z.enum(["settled", "failed"]),
  subaccount_id: wireBigint,
  workflow_change_count: wireBigint,
});

const backstopHistoryRecordSchema = z.object({
  backstop: backstopDetailsSchema,
  event_unix_ns: wireBigint,
  last_event_seq: wireBigint,
  onchain_signature: z.string(),
  subaccount_id: wireBigint,
});

export type BackstopHistoryWireRecord = z.infer<
  typeof backstopHistoryRecordSchema
>;

export const orderHistoryEventSchema = z.object({
  adl: z.array(adlHistoryRecordSchema).default([]),
  backstop_transfers: z.array(backstopHistoryRecordSchema).default([]),
  inactive_settlements: z
    .array(inactiveSettlementHistoryRecordSchema)
    .default([]),
  next_cursor: z.string().optional(),
  orders: z.array(orderHistoryOrderSchema),
  request_id: z.string().optional(),
  type: z.literal("order_history"),
});

export type OrderHistoryEvent = z.infer<typeof orderHistoryEventSchema>;
export type OrderHistoryWireOrder = z.infer<typeof orderHistoryOrderSchema>;
export type AdlHistoryWireRecord = z.infer<typeof adlHistoryRecordSchema>;
export type InactiveSettlementHistoryWireRecord = z.infer<
  typeof inactiveSettlementHistoryRecordSchema
>;
