import type { BackstopTransferMessage } from "../wire/backstopWire";
import type { Subaccount } from "./subaccount";
import { ensurePosition, ensureSubaccount } from "./subaccount";

export const applyBackstopTransfer = (
  subaccounts: Map<bigint, Subaccount>,
  message: BackstopTransferMessage,
): bigint[] => {
  const transfer = message.backstop;
  switch (transfer.phase) {
    case "begin": {
      const account = subaccounts.get(message.subaccount_id);
      if (
        account === undefined ||
        account.positions.size !== transfer.positions.length ||
        transfer.positions.some(
          (position) =>
            account.positions.get(position.market_id)?.netQty !==
            position.quantity,
        )
      ) {
        throw new Error(
          "backstop source positions disagree with confirmed seizure",
        );
      } else {
        // The client's baseline includes header funding minus header fees.
        // Debit the seized header values, not net bucket collateral (which also
        // crystallizes position PnL). Later deposits remain on the source.
        account.collateralBalance -=
          transfer.source_collateral_removed -
          transfer.source_fees_removed +
          transfer.source_net_funding_removed;
        account.positions.clear();
        account.pendingRealized = [];
        return [message.subaccount_id];
      }
    }
    case "acquire": {
      const account = ensureSubaccount(subaccounts, message.subaccount_id);
      account.collateralBalance += transfer.collateral;
      for (const incoming of transfer.positions) {
        const position = ensurePosition(account, incoming.market_id);
        position.netQty += incoming.quantity;
        position.costBasis += incoming.cost_basis_delta;
        position.realizedPnl += incoming.realized_pnl_delta;
        position.fundingAccrued += incoming.funding_delta;
      }
      return [message.subaccount_id];
    }
  }
};
