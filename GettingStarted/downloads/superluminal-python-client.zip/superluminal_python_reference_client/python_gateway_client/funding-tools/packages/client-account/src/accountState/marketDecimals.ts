// Per-symbol scaling info the state machine needs to compute the cost-basis
// delta for an incremental fill.  `pxExponent` is the market's `px_exponent`
// from symbology (typically negative -- e.g. `-2` means a unit price is e2);
// `sizeDecimals` is the market's `size_decimals`.  The conversion mirrors
// `api_client/account_state.cpp::cost_basis_delta_usd`.
export type MarketDecimals = {
  pxExponent: number;
  sizeDecimals: number;
};
