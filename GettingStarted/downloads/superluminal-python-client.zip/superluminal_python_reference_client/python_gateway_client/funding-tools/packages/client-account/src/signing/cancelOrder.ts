import {
  encodeContractCancelProofV2,
  encodeContractCancelV2,
} from "@aethon/client-protocol/signedWire";
import { Result } from "@cprussin/option-result";
import { CancelOrderError } from "../cancelOrderError";
import { awaitCancelResolution } from "../session/awaitResolution";
import type { SignedCommandContext } from "./signedCommand";
import { SIGNED_TTL_SECONDS } from "./signedCommand";
import { base64Encode, buildCancelSignedMessage } from "./signMessage";

export type CancelOrderParams = {
  subaccountId: bigint;
  symbol: number;
  externalOrderId: bigint;
  role: "maker" | "taker";
};

// Builds the `ContractCancelProofV2` envelope, has the signer produce the
// CANCEL-domain-prefixed signature, posts the base64-wrapped proof, and waits
// for the sequencer-confirmed `CancelAck` for the requested `externalOrderId`.
export const cancelOrder = (
  ctx: SignedCommandContext,
  params: CancelOrderParams,
): Promise<Result<true, CancelOrderError>> => {
  const iat = ctx.nowSeconds();
  const exp = iat + SIGNED_TTL_SECONDS;
  const cancelBytes = encodeContractCancelV2({
    externalOrderId: params.externalOrderId,
    requestId64: ctx.generateRequestId(),
    // Wire role enum: maker=0, taker=1 (see `protocol/idl/signed_wire.json`
    // `enums.role`).  Must match the live order role or the matcher
    // rejects the cancel.
    role: params.role === "maker" ? 0 : 1,
    symbol: params.symbol,
  });
  const signMessage = buildCancelSignedMessage({
    cancelBytes,
    exp,
    iat,
    partitionId: ctx.partitionId,
    senderPubkey: ctx.senderPubkey,
    subaccountId: params.subaccountId,
  });
  return Result.wrapAsync(ctx.ensureAuthenticated()).then((sessionResult) =>
    sessionResult
      .mapErr((): CancelOrderError => CancelOrderError.Disconnected())
      .andThenAsync((socket) =>
        Result.wrapAsync(ctx.signer.signMessage(signMessage)).then(
          (sigResult) =>
            sigResult
              .mapErr(
                (cause): CancelOrderError =>
                  CancelOrderError.SignerRejected(
                    cause.match({ None: () => undefined, Some: (c) => c }),
                  ),
              )
              .andThenAsync((signature) => {
                const proofBytes = encodeContractCancelProofV2({
                  cancelBytes,
                  exp,
                  iat,
                  partitionId: ctx.partitionId,
                  senderPubkey: ctx.senderPubkey,
                  signature,
                  signerPubkey: ctx.senderPubkey,
                  subaccountId: params.subaccountId,
                });
                // Attach the listener before send for the same race
                // reason `submitOrder` does.  `signed_cancel`'s
                // success is signaled by a `CancelAck` with our
                // `externalOrderId` on the live account stream;
                // gateway-level `ack rejected` / `ack busy` cover
                // the fast-fail path.
                const ackPromise = awaitCancelResolution<CancelOrderError>(
                  socket,
                  params.externalOrderId,
                  {
                    disconnected: CancelOrderError.Disconnected,
                    rejected: CancelOrderError.Rejected,
                    timeout: CancelOrderError.Timeout,
                  },
                );
                socket.send(
                  JSON.stringify({
                    msg_b64: base64Encode(proofBytes),
                    type: "signed_cancel",
                  }),
                );
                return ackPromise;
              }),
        ),
      ),
  );
};
