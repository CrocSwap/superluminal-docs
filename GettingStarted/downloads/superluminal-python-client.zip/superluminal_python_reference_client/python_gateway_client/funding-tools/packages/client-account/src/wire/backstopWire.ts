import { z } from "zod";
import { wireBigint, wireDecimalUint64 } from "./wireBigint";

const signedDecimal = (bits: bigint) =>
  z
    .string()
    .regex(/^-?\d+$/)
    .transform((value) => BigInt(value))
    .refine(
      (value) => value >= -(1n << (bits - 1n)) && value < 1n << (bits - 1n),
    );

const amount = signedDecimal(128n);
const quantity = signedDecimal(64n);
const position = {
  bucket_index: z.number().int().min(0).max(19),
  change_count: z.number().int().min(0).max(65_535),
  market_id: z.number().int().min(0).max(0xff_ff_ff_ff),
  position_index: z.number().int().min(0).max(49),
  quantity,
};
const transfer = {
  bucket_index: z.number().int().min(0).max(19),
  collateral: amount,
  complete: z.boolean(),
  nonce: wireDecimalUint64,
  source_subaccount_id: wireBigint,
};

export const backstopDetailsSchema = z.discriminatedUnion("phase", [
  z.object({
    ...transfer,
    absorbed_fees: amount,
    buckets: z
      .array(z.object({ collateral: amount, subaccount_id: wireBigint }))
      .min(1)
      .max(20),
    phase: z.literal("begin"),
    positions: z
      .array(
        z.object({ ...position, cost_basis: amount, funding_index: quantity }),
      )
      .min(1)
      .max(50),
    source_collateral_removed: amount,
    source_fees_removed: amount,
    source_net_funding_removed: amount,
  }),
  z.object({
    ...transfer,
    phase: z.literal("acquire"),
    positions: z
      .array(
        z.object({
          ...position,
          cost_basis_delta: amount,
          funding_delta: amount,
          realized_pnl_delta: amount,
        }),
      )
      .min(1)
      .max(50),
  }),
]);

export const backstopTransferSchema = z.object({
  backstop: backstopDetailsSchema,
  matcher_unix_ns: wireBigint,
  onchain_signature: z.string(),
  seq: wireBigint,
  subaccount_id: wireBigint,
  type: z.literal("BackstopTransfer"),
});

export type BackstopTransferMessage = z.infer<typeof backstopTransferSchema>;
