// The minimal EIP-1193 request surface the app drives against a connected EVM
// wallet (MetaMask, Rabby, ...). `@aethon/privy` maps its vendor wallet down to
// this, and `@aethon/client-deposit` consumes it to broadcast the deposit
// transfer, so the two ends of the same wire share one contract instead of
// each declaring their own structurally-identical copy.
export type Eip1193Provider = {
  request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
};
