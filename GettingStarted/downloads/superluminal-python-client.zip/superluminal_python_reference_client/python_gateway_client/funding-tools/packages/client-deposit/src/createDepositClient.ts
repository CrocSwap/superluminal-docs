import type { DepositClient } from "./depositClient";
import type { LiveDepositClientOptions } from "./live";
import { createLiveDepositClient } from "./live";
import { createMockDepositClient } from "./mock";

// This module is the package entrypoint (`@aethon/client-deposit`): it holds
// the client factory and re-exports its two companion types so the "construct
// and type the client" surface lives in one place. Domain types
// (`DepositReceipt`, `Eip1193Provider`, `NetworkKind`) and the per-method error
// types are their own subpaths, not re-exported here.
export type { DepositClient } from "./depositClient";
export type { LiveDepositClientOptions } from "./live";

// `createDepositClient` takes EITHER an empty options bag (mock) OR every field
// of `LiveDepositClientOptions` (live).  A discriminated union (instead of
// `Partial<LiveDepositClientOptions>`) makes "half-configured" states
// unrepresentable -- TS rejects them at the call site rather than the factory
// crashing at runtime.  `createLiveClient` / `createMockClient` are DI hooks
// defaulted to the real factories so tests can verify dispatch without standing
// up the real implementations.
type CreateDepositClientArgs = (
  | { evmRpcUrl?: undefined; evmGatewayAddress?: undefined }
  | LiveDepositClientOptions
) & {
  createLiveClient?: typeof createLiveDepositClient;
  createMockClient?: typeof createMockDepositClient;
};

export const createDepositClient = ({
  createLiveClient = createLiveDepositClient,
  createMockClient = createMockDepositClient,
  ...options
}: CreateDepositClientArgs = {}): DepositClient =>
  options.evmRpcUrl === undefined
    ? createMockClient()
    : createLiveClient(options);
