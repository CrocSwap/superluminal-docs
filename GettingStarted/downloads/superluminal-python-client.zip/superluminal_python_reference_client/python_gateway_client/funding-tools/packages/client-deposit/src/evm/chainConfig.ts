import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import { rpcCall } from "./evmRpc";
import type { NetworkKind } from "./networkKind";

// Per-chain configuration for the deposit flow.  Sourcing everything by chain
// id lets a single EVM_RPC_URL config switch the chain, the USDC contract, and
// the explorer link together.  Mainnet USDC is 6 decimals on every chain we
// support, but rather than hardcode that we read `decimals()` off the deployed
// contract so testnet / mock USDC contracts with non-standard precision are
// handled correctly.  `networkKind` (see `./networkKind`) flags mainnet vs
// testnet.

type ChainConfig = {
  usdc: string;
  explorerTxBase: string;
  networkKind: NetworkKind;
};

const CHAIN_CONFIG = new Map<number, ChainConfig>([
  [
    1,
    {
      explorerTxBase: "https://etherscan.io/tx/",
      networkKind: "mainnet",
      usdc: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", // Ethereum
    },
  ],
  [
    10,
    {
      explorerTxBase: "https://optimistic.etherscan.io/tx/",
      networkKind: "mainnet",
      usdc: "0x0b2c639c533813f4aa9d7837caf62653d097ff85", // Optimism
    },
  ],
  [
    137,
    {
      explorerTxBase: "https://polygonscan.com/tx/",
      networkKind: "mainnet",
      usdc: "0x3c499c542cef5e3811e1192ce70d8cc03d5c3359", // Polygon
    },
  ],
  [
    8453,
    {
      explorerTxBase: "https://basescan.org/tx/",
      networkKind: "mainnet",
      usdc: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", // Base
    },
  ],
  [
    42_161,
    {
      explorerTxBase: "https://arbiscan.io/tx/",
      networkKind: "mainnet",
      usdc: "0xaf88d065e77c8cc2239327c5edb3a432268e5831", // Arbitrum
    },
  ],
  [
    43_114,
    {
      explorerTxBase: "https://snowtrace.io/tx/",
      networkKind: "mainnet",
      usdc: "0xb97ef9ef8734c71904d8002f8b6bc66dd9c48a6e", // Avalanche
    },
  ],
  [
    421_614,
    {
      explorerTxBase: "https://sepolia.arbiscan.io/tx/",
      networkKind: "testnet",
      usdc: "0x83260073a88de28f293f04a712438e906eda4fbf", // Arbitrum Sepolia
    },
  ],
]);

const chainIdHexToNumber = (hex: string): number => Number.parseInt(hex, 16);

export type ResolvedChain = {
  chainIdHex: string;
  usdcContract: string;
  explorerTxBase: string;
  networkKind: NetworkKind;
};

// Constructors for the caller's own typed error, injected so `resolveChain`
// builds the method error directly rather than owning a shared enum: `rpc` for
// an upstream chain-id RPC failure, `unconfiguredChain` for a chain id with no
// USDC config. Both the balance read and the deposit path resolve the chain, so
// each passes its own error's constructors.
export type ResolveChainErrorConstructors<E extends NonNullable<unknown>> = {
  rpc: (message: string) => E;
  unconfiguredChain: (chainId: number) => E;
};

const lookupChainConfig = <E extends NonNullable<unknown>>(
  chainIdHex: string,
  unconfiguredChain: (chainId: number) => E,
): Result<ResolvedChain, E> => {
  const chainId = chainIdHexToNumber(chainIdHex);
  const config = CHAIN_CONFIG.get(chainId);
  if (config === undefined) {
    return Err(unconfiguredChain(chainId));
  } else {
    return Ok({
      chainIdHex,
      explorerTxBase: config.explorerTxBase,
      networkKind: config.networkKind,
      usdcContract: config.usdc,
    });
  }
};

// Discovers the deployment's chain by asking the RPC endpoint for its chain id
// and resolves the matching USDC contract / explorer / network kind -- so the
// EVM_RPC_URL config alone is enough to switch between supported chains.
export const resolveChain = async <E extends NonNullable<unknown>>(
  rpcUrl: string,
  errors: ResolveChainErrorConstructors<E>,
  fetchFn: typeof fetch = fetch,
): Promise<Result<ResolvedChain, E>> => {
  const chainIdResult = await rpcCall(
    rpcUrl,
    "eth_chainId",
    [],
    errors.rpc,
    fetchFn,
  );
  return chainIdResult.andThen((chainIdHex) =>
    lookupChainConfig(chainIdHex, errors.unconfiguredChain),
  );
};
