import type { Result } from "@cprussin/option-result";
import type { Dnum } from "dnum";
import type { ResolveChainErrorConstructors } from "./chainConfig";
import { resolveChain } from "./chainConfig";
import { ethCall } from "./evmRpc";

// ERC-20 `balanceOf(address)` and `decimals()` selectors.
const BALANCE_OF_SELECTOR = "0x70a08231";
const DECIMALS_SELECTOR = "0x313ce567";

const encodeBalanceOf = (owner: string): string =>
  BALANCE_OF_SELECTOR +
  owner.replace(/^0x/, "").toLowerCase().padStart(64, "0");

const combineBalanceAndDecimals = <E extends NonNullable<unknown>>(
  balance: Result<string, E>,
  decimals: Result<string, E>,
): Result<Dnum, E> =>
  balance.andThen((balanceHex) =>
    decimals.map(
      (decimalsHex): Dnum => [
        BigInt(balanceHex),
        Number.parseInt(decimalsHex, 16),
      ],
    ),
  );

const fetchBalanceAndDecimals = async <E extends NonNullable<unknown>>(
  rpcUrl: string,
  usdcContract: string,
  owner: string,
  rpc: (message: string) => E,
  fetchFn: typeof fetch = fetch,
): Promise<Result<Dnum, E>> => {
  const [balance, decimals] = await Promise.all([
    ethCall(rpcUrl, usdcContract, encodeBalanceOf(owner), rpc, fetchFn),
    ethCall(rpcUrl, usdcContract, DECIMALS_SELECTOR, rpc, fetchFn),
  ]);
  return combineBalanceAndDecimals(balance, decimals);
};

// Reads the USDC balance of an EVM address.  Discovers the chain by asking
// the RPC endpoint, then looks up the matching USDC contract -- so the
// EVM_RPC_URL config alone is enough to switch between supported chains with
// no separate contract-address config.  The token's `decimals()` is read off
// the contract rather than assumed, so the returned Dnum reflects the on-chain
// precision (which can vary for testnet / mock contracts).  The caller injects
// its own typed error's constructors so the failure channel stays typed.
export const fetchUsdcBalance = async <E extends NonNullable<unknown>>(
  rpcUrl: string,
  owner: string,
  errors: ResolveChainErrorConstructors<E>,
  fetchFn: typeof fetch = fetch,
): Promise<Result<Dnum, E>> => {
  const chainResult = await resolveChain(rpcUrl, errors, fetchFn);
  return chainResult.andThenAsync(({ usdcContract }) =>
    fetchBalanceAndDecimals(rpcUrl, usdcContract, owner, errors.rpc, fetchFn),
  );
};
