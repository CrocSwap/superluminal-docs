import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import { z } from "zod";

const rpcResponseSchema = z.object({
  error: z.object({ message: z.string() }).optional(),
  // A `0x`-prefixed hex quantity/data string. Validating the shape here keeps
  // the downstream `BigInt(result)` / `parseInt(result, 16)` reads total: a
  // schema-valid-but-non-hex `result` would otherwise throw past the `Result`
  // and break the never-throw contract of the deposit methods.
  result: z
    .string()
    .regex(/^0x[0-9a-fA-F]+$/)
    .optional(),
});

// Issues a single JSON-RPC POST against the given EVM RPC and returns the
// `result` field as a hex string, wrapped in a `Result` so error handling is
// explicit at every call site (no throws on this path).  Shared between the
// USDC balance / chain lookup helpers and the deposit-vault
// `userDepositInitCodeHash` read so the transport, request shape, and
// validation stay in lockstep.
//
// The caller injects the `rpc` constructor for its own typed error's `Rpc`
// variant, so this transport helper builds the method's error directly instead
// of owning a shared error enum (mirrors the `awaitResolution` constructor-
// injection pattern in `@aethon/client-account`). Both failure paths -- an
// upstream JSON-RPC error / absent result, and a thrown `fetchFn` (network) /
// `Response.json` / `Zod.parse` (malformed response) -- map to `rpc(message)`,
// keeping the never-throw contract while preserving the exact upstream string.
export const rpcCall = async <E extends NonNullable<unknown>>(
  rpcUrl: string,
  method: string,
  params: unknown[],
  rpc: (message: string) => E,
  fetchFn: typeof fetch = fetch,
): Promise<Result<string, E>> => {
  try {
    const response = await fetchFn(rpcUrl, {
      body: JSON.stringify({ id: 1, jsonrpc: "2.0", method, params }),
      headers: { "content-type": "application/json" },
      method: "POST",
    });
    const { error, result } = rpcResponseSchema.parse(await response.json());
    return result === undefined
      ? Err(rpc(error?.message ?? `RPC ${method} failed`))
      : Ok(result);
  } catch (cause) {
    return Err(rpc(errorMessage(cause, `RPC ${method} failed`)));
  }
};

// Convenience wrapper over `rpcCall` for the common `eth_call` shape.
export const ethCall = <E extends NonNullable<unknown>>(
  rpcUrl: string,
  to: string,
  data: string,
  rpc: (message: string) => E,
  fetchFn: typeof fetch = fetch,
): Promise<Result<string, E>> =>
  rpcCall(rpcUrl, "eth_call", [{ data, to }, "latest"], rpc, fetchFn);
