import { errorMessage } from "@aethon/client-protocol/errorMessage";

// Discriminant for `DepositError`. Each error type owns its own enum,
// co-located with the error, so a variant means exactly one thing and adding a
// variant only touches this error's own switch.
export enum DepositErrorType {
  Rpc,
  UnconfiguredChain,
  Validation,
  WalletRejected,
  Unexpected,
}

// Typed failure channel for `DepositClient.deposit`, the full end-to-end
// deposit. It resolves the chain and reads the gateway init-code hash (`Rpc`
// carries an upstream provider message, `UnconfiguredChain` an unsupported
// chain id), derives the CREATE2 deposit address (`Validation` for a malformed
// gateway address / init-code hash), then broadcasts the ERC-20 transfer
// through the injected wallet (`WalletRejected` when the wallet fails the
// chain switch, rejects the transaction, or returns no hash). `Unexpected`
// lifts an opaque thrown cause -- the deposit hook maps a rejected
// provider-acquisition promise here.
export const DepositError = {
  Rpc: (message: string) => ({
    message,
    type: DepositErrorType.Rpc as const,
  }),
  UnconfiguredChain: (chainId: number) => ({
    chainId,
    type: DepositErrorType.UnconfiguredChain as const,
  }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: DepositErrorType.Unexpected as const,
  }),
  Validation: (message: string) => ({
    message,
    type: DepositErrorType.Validation as const,
  }),
  WalletRejected: (message: string) => ({
    message,
    type: DepositErrorType.WalletRejected as const,
  }),
};

export type DepositError = ReturnType<
  (typeof DepositError)[keyof typeof DepositError]
>;

// Rust `Display`-trait analog: fold a `DepositError` back into the exact human
// string the old `Result<DepositReceipt, string>` channel produced.
export const displayDepositError = (error: DepositError): string => {
  switch (error.type) {
    case DepositErrorType.Rpc:
      return error.message;
    case DepositErrorType.UnconfiguredChain:
      return `USDC contract not configured for chain id ${error.chainId}`;
    case DepositErrorType.Validation:
      return error.message;
    case DepositErrorType.WalletRejected:
      return error.message;
    case DepositErrorType.Unexpected:
      return errorMessage(error.cause, "Failed to obtain wallet provider");
  }
};
