import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";
import { keccak_256 } from "@noble/hashes/sha3.js";
import type { Address } from "@solana/kit";
import { getAddressEncoder } from "@solana/kit";
import { ethCall } from "./evmRpc";

const HEX_RE = /^0x[0-9a-fA-F]+$/;

const hexToBytes = (hex: string): Result<Uint8Array, string> => {
  if (!HEX_RE.test(hex) || hex.length % 2 !== 0) {
    return Err(`Invalid hex string: ${hex}`);
  } else {
    const out = new Uint8Array((hex.length - 2) / 2);
    for (let i = 0; i < out.length; i++) {
      out[i] = Number.parseInt(hex.slice(2 + i * 2, 4 + i * 2), 16);
    }
    return Ok(out);
  }
};

const bytesToHex = (bytes: Uint8Array): string =>
  `0x${Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("")}`;

const u64BigEndian = (value: bigint): Uint8Array => {
  const out = new Uint8Array(8);
  let v = value;
  for (let i = 7; i >= 0; i--) {
    out[i] = Number(v & 0xffn);
    v >>= 8n;
  }
  return out;
};

const checksumAddress = (address20: Uint8Array): string => {
  const lower = bytesToHex(address20).slice(2);
  const hash = keccak_256(new TextEncoder().encode(lower));
  let out = "0x";
  for (let i = 0; i < lower.length; i++) {
    // `i >> 1` ranges over 0..(lower.length/2 - 1), always within the 32-byte
    // keccak digest, so a missing byte is an invariant violation.
    const hashByte = hash[i >> 1];
    if (hashByte === undefined) {
      throw new Error(`checksumAddress: hash byte missing at index ${i >> 1}`);
    } else {
      const nibble = hashByte >> (i % 2 === 0 ? 4 : 0);
      const ch = lower.charAt(i);
      out += /[0-9]/.test(ch) || (nibble & 0xf) < 8 ? ch : ch.toUpperCase();
    }
  }
  return out;
};

const finalizeAddress = (
  deployer: Uint8Array,
  initHash: Uint8Array,
  ownerKey: Address,
  subaccountId: bigint,
): string => {
  const ownerKeyBytes = getAddressEncoder().encode(ownerKey);
  const saltInput = new Uint8Array(40);
  saltInput.set(ownerKeyBytes, 0);
  saltInput.set(u64BigEndian(subaccountId), 32);
  const salt = keccak_256(saltInput);

  const create2Input = new Uint8Array(1 + 20 + 32 + 32);
  create2Input[0] = 0xff;
  create2Input.set(deployer, 1);
  create2Input.set(salt, 21);
  create2Input.set(initHash, 53);
  const digest = keccak_256(create2Input);
  return checksumAddress(digest.slice(12));
};

const validateLength = (
  bytes: Uint8Array,
  expected: number,
  errorMessage: string,
): Result<Uint8Array, string> =>
  bytes.length === expected ? Ok(bytes) : Err(errorMessage);

const parseFixedLengthHex = (
  hex: string,
  expected: number,
  errorMessage: string,
): Result<Uint8Array, string> =>
  hexToBytes(hex.toLowerCase()).andThen((bytes) =>
    validateLength(bytes, expected, errorMessage),
  );

// Mirrors EVMVault.sol's `computeUserDepositAddressFor`: deterministic CREATE2
// address of the per-user `UserDeposit` vault.  The deployer is the gateway,
// the salt is `keccak256(ownerKey || subaccountId)`, and the initcode hash is
// `keccak256(type(UserDeposit).creationCode)` (read off-chain from
// `userDepositInitCodeHash()` on the gateway).
// The private hex helpers above produce the malformed-input message strings;
// `validation` (the caller's own typed error's `Validation` variant) wraps them
// at this boundary, so both callers (`getUserDepositAddress`, `deposit`) keep a
// typed channel while sharing the parse logic.
export const computeUserDepositAddress = <E extends NonNullable<unknown>>(
  {
    gatewayAddress,
    initCodeHash,
    ownerKey,
    subaccountId,
  }: {
    gatewayAddress: string;
    initCodeHash: string;
    ownerKey: Address;
    subaccountId: bigint;
  },
  validation: (message: string) => E,
): Result<string, E> => {
  const deployerResult = parseFixedLengthHex(
    gatewayAddress,
    20,
    `Gateway address must be 20 bytes: ${gatewayAddress}`,
  );
  const initHashResult = parseFixedLengthHex(
    initCodeHash,
    32,
    `Init code hash must be 32 bytes: ${initCodeHash}`,
  );
  return deployerResult
    .andThen((deployer) =>
      initHashResult.map((initHash) =>
        finalizeAddress(deployer, initHash, ownerKey, subaccountId),
      ),
    )
    .mapErr(validation);
};

// `userDepositInitCodeHash()` selector — `keccak256("userDepositInitCodeHash()")[:4]`.
const USER_DEPOSIT_INIT_CODE_HASH_SELECTOR = "0x058df612";

const rejectEmptyResponse = <E extends NonNullable<unknown>>(
  value: string,
  rpc: (message: string) => E,
): Result<string, E> =>
  value === "0x"
    ? Err(rpc("Failed to read userDepositInitCodeHash"))
    : Ok(value);

// Reads the immutable `userDepositInitCodeHash` off the on-chain EVMVault.
// The hash is fixed at construction (UserDeposit has no constructor args), so
// callers cache the result for the lifetime of the gateway address.  A `0x`
// response means the contract at `gatewayAddress` doesn't implement the
// selector -- treated as an upstream `Rpc` failure via the injected constructor.
export const fetchUserDepositInitCodeHash = async <
  E extends NonNullable<unknown>,
>(
  rpcUrl: string,
  gatewayAddress: string,
  rpc: (message: string) => E,
  fetchFn: typeof fetch = fetch,
): Promise<Result<string, E>> => {
  const rpcResult = await ethCall(
    rpcUrl,
    gatewayAddress,
    USER_DEPOSIT_INIT_CODE_HASH_SELECTOR,
    rpc,
    fetchFn,
  );
  return rpcResult.andThen((value) => rejectEmptyResponse(value, rpc));
};
