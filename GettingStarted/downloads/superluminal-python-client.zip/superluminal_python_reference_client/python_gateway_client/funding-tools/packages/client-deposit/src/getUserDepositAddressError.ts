import { errorMessage } from "@aethon/client-protocol/errorMessage";

// Discriminant for `GetUserDepositAddressError`. Each error type owns its own
// enum, co-located with the error, so a variant means exactly one thing and
// adding a variant only touches this error's own switch.
export enum GetUserDepositAddressErrorType {
  Rpc,
  Validation,
  Unexpected,
}

// Typed failure channel for `DepositClient.getUserDepositAddress`. Deriving the
// deterministic CREATE2 deposit address reads `userDepositInitCodeHash` off the
// gateway (`Rpc` carries the upstream provider message when that call fails or
// returns empty data) and then parses the gateway address / init-code hash into
// fixed-length byte strings (`Validation` when either is malformed). This method
// does not resolve the chain, so it has no `UnconfiguredChain` variant.
// `Unexpected` lifts a rejected producer promise -- a bug, since the client is
// contractually non-throwing -- carrying the opaque cause.
export const GetUserDepositAddressError = {
  Rpc: (message: string) => ({
    message,
    type: GetUserDepositAddressErrorType.Rpc as const,
  }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: GetUserDepositAddressErrorType.Unexpected as const,
  }),
  Validation: (message: string) => ({
    message,
    type: GetUserDepositAddressErrorType.Validation as const,
  }),
};

export type GetUserDepositAddressError = ReturnType<
  (typeof GetUserDepositAddressError)[keyof typeof GetUserDepositAddressError]
>;

// Rust `Display`-trait analog: fold a `GetUserDepositAddressError` back into the
// exact human string the old `Result<string, string>` channel produced.
export const displayGetUserDepositAddressError = (
  error: GetUserDepositAddressError,
): string => {
  switch (error.type) {
    case GetUserDepositAddressErrorType.Rpc:
      return error.message;
    case GetUserDepositAddressErrorType.Validation:
      return error.message;
    case GetUserDepositAddressErrorType.Unexpected:
      return errorMessage(error.cause, "failed to derive deposit address");
  }
};
