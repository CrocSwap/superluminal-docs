// Flags whether the EVM deposit deployment lives on a mainnet or testnet chain.
// UI surfaces that link to chain-aware downstream services (the Fogo block
// explorer in `WithdrawDialog` / `OrderRow`) use this to pick the matching
// network without needing a separate env var -- the EVM chain id is the single
// source of truth.
export type NetworkKind = "mainnet" | "testnet";
