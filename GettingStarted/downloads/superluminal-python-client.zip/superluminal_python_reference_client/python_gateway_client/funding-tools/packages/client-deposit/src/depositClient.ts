import type { Eip1193Provider } from "@aethon/eip1193";
import type { Result } from "@cprussin/option-result";
import type { Address } from "@solana/kit";
import type { Dnum } from "dnum";
import type { DepositError } from "./depositError";
import type { DepositReceipt } from "./depositReceipt";
import type { NetworkKind } from "./evm/networkKind";
import type { GetEvmWalletUsdcBalanceError } from "./getEvmWalletUsdcBalanceError";
import type { GetNetworkKindError } from "./getNetworkKindError";
import type { GetUserDepositAddressError } from "./getUserDepositAddressError";

// `DepositClient` covers the EVM-side deposit/settlement surface: USDC balance
// reads, deposit-address derivation, and deposit broadcast.  These methods do
// not touch the gateway -- they operate against the EVM RPC the client was
// configured with and the user-provided EIP-1193 wallet directly -- so they
// live on their own client rather than on the gateway-facing `PublicClient`.
// Every method returns `Result<T, MethodError>` with a per-method typed error
// (own enum, exhaustive `display*`) so failure handling is explicit at each
// call site and the deposit path never throws.
export type DepositClient = {
  // Reads the connected wallet's USDC balance off the configured EVM RPC.
  getEvmWalletUsdcBalance: (
    walletAddress: string,
  ) => Promise<Result<Dnum, GetEvmWalletUsdcBalanceError>>;
  // Derives the per-user deterministic deposit address for the configured
  // EVMVault gateway.
  getUserDepositAddress: (
    ownerKey: Address,
    subaccountId: bigint,
  ) => Promise<Result<string, GetUserDepositAddressError>>;
  // Runs the full end-to-end deposit -- derive the address, then broadcast the
  // ERC-20 transfer through the wallet's EIP-1193 provider -- and on success
  // returns the transaction hash plus a per-chain explorer URL the UI can link
  // to.
  deposit: (params: {
    provider: Eip1193Provider;
    from: string;
    ownerKey: Address;
    amount: bigint;
    subaccountId: bigint;
  }) => Promise<Result<DepositReceipt, DepositError>>;
  // Resolves the EVM chain configured on the deployment's RPC and returns
  // whether it's a mainnet or testnet chain.  UI surfaces that link to
  // dependent services (e.g. the Fogo block explorer) use this to pick the
  // matching network without a separate env var -- the EVM chain id is the
  // single source of truth.
  getNetworkKind: () => Promise<Result<NetworkKind, GetNetworkKindError>>;
};
