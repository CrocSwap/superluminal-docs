import { errorMessage } from "@aethon/client-protocol/errorMessage";

// Discriminant for `GetEvmWalletUsdcBalanceError`. Each error type owns its own
// enum, co-located with the error, so a variant means exactly one thing and
// adding a variant only touches this error's own switch.
export enum GetEvmWalletUsdcBalanceErrorType {
  Rpc,
  UnconfiguredChain,
  Unexpected,
}

// Typed failure channel for `DepositClient.getEvmWalletUsdcBalance`. The read
// resolves the chain (`UnconfiguredChain` when the RPC's chain id has no USDC
// config) and then issues `balanceOf` / `decimals` calls (`Rpc` carries the
// upstream provider message when any of those RPC calls fails). `Unexpected`
// lifts a rejected producer promise -- a bug, since the client is contractually
// non-throwing -- carrying the opaque cause.
export const GetEvmWalletUsdcBalanceError = {
  Rpc: (message: string) => ({
    message,
    type: GetEvmWalletUsdcBalanceErrorType.Rpc as const,
  }),
  UnconfiguredChain: (chainId: number) => ({
    chainId,
    type: GetEvmWalletUsdcBalanceErrorType.UnconfiguredChain as const,
  }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: GetEvmWalletUsdcBalanceErrorType.Unexpected as const,
  }),
};

export type GetEvmWalletUsdcBalanceError = ReturnType<
  (typeof GetEvmWalletUsdcBalanceError)[keyof typeof GetEvmWalletUsdcBalanceError]
>;

// Rust `Display`-trait analog: fold a `GetEvmWalletUsdcBalanceError` back into
// the exact human string the old `Result<Dnum, string>` channel produced.
export const displayGetEvmWalletUsdcBalanceError = (
  error: GetEvmWalletUsdcBalanceError,
): string => {
  switch (error.type) {
    case GetEvmWalletUsdcBalanceErrorType.Rpc:
      return error.message;
    case GetEvmWalletUsdcBalanceErrorType.UnconfiguredChain:
      return `USDC contract not configured for chain id ${error.chainId}`;
    case GetEvmWalletUsdcBalanceErrorType.Unexpected:
      return errorMessage(error.cause, "failed to read wallet USDC balance");
  }
};
