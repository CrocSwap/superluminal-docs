export type DepositReceipt = {
  txHash: string;
  explorerUrl: string;
};
