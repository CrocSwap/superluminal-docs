import type { DepositClient } from "./depositClient";
import { DepositError } from "./depositError";
import type { DepositReceipt } from "./depositReceipt";
import { resolveChain } from "./evm/chainConfig";
import { fetchUsdcBalance } from "./evm/evmUsdcBalance";
import { sendUsdcTransfer } from "./evm/usdcTransfer";
import {
  computeUserDepositAddress,
  fetchUserDepositInitCodeHash,
} from "./evm/userDepositVault";
import { GetEvmWalletUsdcBalanceError } from "./getEvmWalletUsdcBalanceError";
import { GetNetworkKindError } from "./getNetworkKindError";
import { GetUserDepositAddressError } from "./getUserDepositAddressError";

export type LiveDepositClientOptions = {
  evmRpcUrl: string;
  evmGatewayAddress: string;
  fetch?: typeof fetch | undefined;
};

// Live EVM deposit client.  Every method returns `Result<T, MethodError>` (a
// per-method typed error, own enum) so failure handling is explicit at each
// call site; the shared EVM helpers take that error's variant constructors so
// the failure channel stays typed from the RPC boundary up.  Built
// independently of the gateway-facing `PublicClient`: it needs only an EVM RPC
// URL and the gateway contract address, not the market-data WebSocket.
export const createLiveDepositClient = (
  options: LiveDepositClientOptions,
): DepositClient => {
  const fetchFn = options.fetch ?? fetch;
  const { evmRpcUrl, evmGatewayAddress } = options;

  return {
    deposit: async ({ provider, from, ownerKey, amount, subaccountId }) => {
      const [chainResult, initCodeHashResult] = await Promise.all([
        resolveChain<DepositError>(
          evmRpcUrl,
          {
            rpc: DepositError.Rpc,
            unconfiguredChain: DepositError.UnconfiguredChain,
          },
          fetchFn,
        ),
        fetchUserDepositInitCodeHash<DepositError>(
          evmRpcUrl,
          evmGatewayAddress,
          DepositError.Rpc,
          fetchFn,
        ),
      ]);
      return chainResult.andThenAsync(async (chain) => {
        const sendResult = await initCodeHashResult.andThenAsync(
          (initCodeHash) =>
            computeUserDepositAddress<DepositError>(
              {
                gatewayAddress: evmGatewayAddress,
                initCodeHash,
                ownerKey,
                subaccountId,
              },
              DepositError.Validation,
            ).andThenAsync((depositAddress) =>
              sendUsdcTransfer<DepositError>(
                provider,
                from,
                depositAddress,
                amount,
                chain.chainIdHex,
                chain.usdcContract,
                DepositError.WalletRejected,
              ),
            ),
        );
        return sendResult.map(
          (txHash): DepositReceipt => ({
            explorerUrl: `${chain.explorerTxBase}${txHash}`,
            txHash,
          }),
        );
      });
    },

    getEvmWalletUsdcBalance: (walletAddress) =>
      fetchUsdcBalance<GetEvmWalletUsdcBalanceError>(
        evmRpcUrl,
        walletAddress,
        {
          rpc: GetEvmWalletUsdcBalanceError.Rpc,
          unconfiguredChain: GetEvmWalletUsdcBalanceError.UnconfiguredChain,
        },
        fetchFn,
      ),

    getNetworkKind: async () => {
      const chainResult = await resolveChain<GetNetworkKindError>(
        evmRpcUrl,
        {
          rpc: GetNetworkKindError.Rpc,
          unconfiguredChain: GetNetworkKindError.UnconfiguredChain,
        },
        fetchFn,
      );
      return chainResult.map((chain) => chain.networkKind);
    },

    getUserDepositAddress: async (ownerKey, subaccountId) => {
      const initCodeHashResult =
        await fetchUserDepositInitCodeHash<GetUserDepositAddressError>(
          evmRpcUrl,
          evmGatewayAddress,
          GetUserDepositAddressError.Rpc,
          fetchFn,
        );
      return initCodeHashResult.andThen((initCodeHash) =>
        computeUserDepositAddress<GetUserDepositAddressError>(
          {
            gatewayAddress: evmGatewayAddress,
            initCodeHash,
            ownerKey,
            subaccountId,
          },
          GetUserDepositAddressError.Validation,
        ),
      );
    },
  };
};
