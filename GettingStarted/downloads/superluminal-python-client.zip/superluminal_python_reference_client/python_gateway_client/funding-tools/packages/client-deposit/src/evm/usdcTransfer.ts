import { errorMessage } from "@aethon/client-protocol/errorMessage";
import type { Eip1193Provider } from "@aethon/eip1193";
import type { Result } from "@cprussin/option-result";
import { Err, Ok } from "@cprussin/option-result";

// The ERC-20 `transfer(address,uint256)` function selector.
const TRANSFER_SELECTOR = "0xa9059cbb";

const padHex = (value: string, length: number): string =>
  value.replace(/^0x/, "").toLowerCase().padStart(length, "0");

const encodeTransfer = (to: string, amount: bigint): string =>
  TRANSFER_SELECTOR + padHex(to, 64) + padHex(amount.toString(16), 64);

// Sentinel value used as the `Ok` payload for provider calls whose successful
// return value doesn't carry useful information (`wallet_switchEthereumChain`
// resolves to `null`, which `Result` can't store because `T extends
// NonNullable<unknown>`).
const ok = true as const;

// Lifts a provider call's rejection into a `Result` whose `Ok` payload is
// `true`.  Used when we only care that the call didn't fail.
const callIgnoringValue = (
  provider: Eip1193Provider,
  args: { method: string; params: unknown[] },
  fallback: string,
): Promise<Result<typeof ok, string>> =>
  provider.request(args).then(
    () => Ok<typeof ok, string>(ok),
    (cause: unknown) => Err<typeof ok, string>(errorMessage(cause, fallback)),
  );

const sendTransaction = (
  provider: Eip1193Provider,
  from: string,
  amount: bigint,
  to: string,
  usdcContract: string,
): Promise<Result<string, string>> =>
  provider
    .request({
      method: "eth_sendTransaction",
      params: [{ data: encodeTransfer(to, amount), from, to: usdcContract }],
    })
    .then(
      (value) =>
        typeof value === "string"
          ? Ok<string, string>(value)
          : Err<string, string>("EVM wallet did not return a transaction hash"),
      (cause: unknown) =>
        Err<string, string>(
          errorMessage(cause, "Failed to send USDC transfer"),
        ),
    );

// Broadcasts an ERC-20 USDC transfer from the connected EVM wallet to `to`,
// returning the transaction hash via `Result`.
//
// The caller passes the chain id and USDC contract (both resolved up-front
// via `resolveChain`) so we don't re-resolve them mid-flow.  Before
// broadcasting we ask the wallet to switch to that chain -- without this, a
// wallet pointed at a different chain would call our contract address on the
// wrong network and the wallet's simulation backend can fail in confusing
// ways (Rabby surfaces this as a generic "Request failed with status code
// 500").
// The private helpers above produce the wallet-side message strings (chain
// switch rejected, transaction rejected, no hash returned); `walletRejected`
// (the caller's own typed error's `WalletRejected` variant) wraps whichever
// fired at this boundary, so the deposit path keeps a typed failure channel.
export const sendUsdcTransfer = async <E extends NonNullable<unknown>>(
  provider: Eip1193Provider,
  from: string,
  to: string,
  amount: bigint,
  chainIdHex: string,
  usdcContract: string,
  walletRejected: (message: string) => E,
): Promise<Result<string, E>> => {
  const switchResult = await callIgnoringValue(
    provider,
    {
      method: "wallet_switchEthereumChain",
      params: [{ chainId: chainIdHex }],
    },
    "Failed to switch wallet chain",
  );
  return (
    await switchResult.andThenAsync(() =>
      sendTransaction(provider, from, amount, to, usdcContract),
    )
  ).mapErr(walletRejected);
};
