import { Ok } from "@cprussin/option-result";
import type { Dnum } from "dnum";

import type { DepositClient } from "./depositClient";

// Static placeholders for the mock EVM-deposit surface.  Deliberately not
// derived from on-chain state so dev/preview builds render the deposit dialog
// without an EVM RPC or a deployed gateway.
const MOCK_EVM_USDC_BALANCE: Dnum = [100_000_000n, 6];
const MOCK_DEPOSIT_ADDRESS = "0xDeadBeefDeadBeefDeadBeefDeadBeefDeadBeef";
const MOCK_TX_HASH = `0x${"00".repeat(32)}`;
const MOCK_EXPLORER_URL = `https://example.test/tx/${MOCK_TX_HASH}`;

export const createMockDepositClient = (): DepositClient => ({
  deposit: () =>
    Promise.resolve(
      Ok({
        explorerUrl: MOCK_EXPLORER_URL,
        txHash: MOCK_TX_HASH,
      }),
    ),
  getEvmWalletUsdcBalance: () => Promise.resolve(Ok(MOCK_EVM_USDC_BALANCE)),
  getNetworkKind: () => Promise.resolve(Ok("testnet")),
  getUserDepositAddress: () => Promise.resolve(Ok(MOCK_DEPOSIT_ADDRESS)),
});
