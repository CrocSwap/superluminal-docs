import { errorMessage } from "@aethon/client-protocol/errorMessage";

// Discriminant for `GetNetworkKindError`. Each error type owns its own enum,
// co-located with the error, so a variant means exactly one thing and adding a
// variant only touches this error's own switch.
export enum GetNetworkKindErrorType {
  Rpc,
  UnconfiguredChain,
  Unexpected,
}

// Typed failure channel for `DepositClient.getNetworkKind`. Resolving the
// network kind asks the configured EVM RPC for its chain id (`Rpc` carries the
// upstream provider message when that call fails) and maps it to a supported
// chain (`UnconfiguredChain` when the returned chain id has no USDC config).
// `Unexpected` lifts a rejected producer promise -- a bug, since the client is
// contractually non-throwing -- carrying the opaque cause.
export const GetNetworkKindError = {
  Rpc: (message: string) => ({
    message,
    type: GetNetworkKindErrorType.Rpc as const,
  }),
  UnconfiguredChain: (chainId: number) => ({
    chainId,
    type: GetNetworkKindErrorType.UnconfiguredChain as const,
  }),
  Unexpected: (cause: unknown) => ({
    cause,
    type: GetNetworkKindErrorType.Unexpected as const,
  }),
};

export type GetNetworkKindError = ReturnType<
  (typeof GetNetworkKindError)[keyof typeof GetNetworkKindError]
>;

// Rust `Display`-trait analog: fold a `GetNetworkKindError` back into the exact
// human string the old `Result<NetworkKind, string>` channel produced.
export const displayGetNetworkKindError = (
  error: GetNetworkKindError,
): string => {
  switch (error.type) {
    case GetNetworkKindErrorType.Rpc:
      return error.message;
    case GetNetworkKindErrorType.UnconfiguredChain:
      return `USDC contract not configured for chain id ${error.chainId}`;
    case GetNetworkKindErrorType.Unexpected:
      return errorMessage(error.cause, "failed to resolve network kind");
  }
};
