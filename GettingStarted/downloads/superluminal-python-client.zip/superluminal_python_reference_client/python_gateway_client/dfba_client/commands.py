from __future__ import annotations

import json
from typing import Any


def encode_signed_order(msg_b64: str) -> str:
    return _compact({"type": "signed_order", "msg_b64": msg_b64})


def encode_signed_conditional_group(msg_b64: str) -> str:
    return _compact({"type": "signed_conditional_group", "version": 1, "msg_b64": msg_b64})


def encode_signed_conditional_parent(group_external_order_id: int, msg_b64: str) -> str:
    if not 0 < group_external_order_id <= 2**64 - 1:
        raise ValueError("invalid conditional group ID")
    return _compact({
        "type": "signed_conditional_parent", "version": 1,
        "conditional_group_external_order_id": str(group_external_order_id),
        "msg_b64": msg_b64,
    })


def encode_signed_conditional_cancel(msg_b64: str) -> str:
    return _compact({"type": "signed_conditional_cancel", "version": 1, "msg_b64": msg_b64})


def encode_signed_cancel(msg_b64: str) -> str:
    return _compact({"type": "signed_cancel", "msg_b64": msg_b64})


def encode_signed_modify(msg_b64: str) -> str:
    return _compact({"type": "signed_modify", "msg_b64": msg_b64})


def encode_signed_withdraw(msg_b64: str) -> str:
    return _compact({"type": "signed_withdraw", "msg_b64": msg_b64})


def encode_signed_create_vault(msg_b64: str) -> str:
    return _compact({"type": "signed_create_vault", "msg_b64": msg_b64})


def encode_signed_deposit_vault(msg_b64: str) -> str:
    return _compact({"type": "signed_deposit_vault", "msg_b64": msg_b64})


def encode_signed_withdraw_vault(msg_b64: str) -> str:
    return _compact({"type": "signed_withdraw_vault", "msg_b64": msg_b64})


def encode_signed_transfer_subaccount(msg_b64: str) -> str:
    return _compact({"type": "signed_transfer_subaccount", "msg_b64": msg_b64})


def encode_ping(client_unix_ns: int) -> str:
    return _compact({"type": "ping", "client_unix_ns": client_unix_ns})


def encode_subscribe_market(symbol: int) -> str:
    return _compact({"type": "subscribe_market", "symbol": symbol})


def encode_subscribe_account() -> str:
    return _compact({"type": "subscribe_account"})


def encode_user_deposit_address(subaccount_id: int) -> str:
    return _compact({"type": "user_deposit_address", "subaccount_id": subaccount_id})


def encode_auth_wallet(wallet_pubkey: str, expiry_seconds: int = 0) -> str:
    return _compact(
        {
            "type": "auth_wallet",
            "wallet_pubkey": wallet_pubkey,
            "expiry_seconds": expiry_seconds,
        }
    )


def encode_auth_response(nonce: str, signature_b64: str, wallet_pubkey: str = "") -> str:
    payload: dict[str, Any] = {
        "type": "auth_response",
        "nonce": nonce,
        "signature_b64": signature_b64,
    }
    if wallet_pubkey != "":
        payload["wallet_pubkey"] = wallet_pubkey
    return _compact(payload)


def _compact(payload: dict[str, Any]) -> str:
    return json.dumps(payload, separators=(",", ":"), ensure_ascii=True)
