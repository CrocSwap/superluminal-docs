from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, TypeAlias

from dfba_client.types import BookType, MarketInfo


@dataclass(frozen=True, slots=True)
class AckMessage:
    status: str
    reason: str = ""
    client_instruction_id: int | None = None
    external_order_id: int | None = None


@dataclass(frozen=True, slots=True)
class AuthChallengeMessage:
    wallet_pubkey: str
    nonce: str
    message: str
    expires_unix_ms: int


@dataclass(frozen=True, slots=True)
class AuthExpiredMessage:
    reason: str


@dataclass(frozen=True, slots=True)
class SessionPreemptedMessage:
    reason: str


@dataclass(frozen=True, slots=True)
class PongMessage:
    client_unix_ns: int


@dataclass(frozen=True, slots=True)
class CreateVaultStatusMessage:
    message_type: Literal["CreateVaultStatus", "CreateVault"]
    client_instruction_id: int
    source_subaccount_id: int
    operation_subaccount_id: int
    vault_id: int
    status: int
    error_code: int
    total_vault_shares: int | None = None
    error_domain: str | None = None
    error: str | None = None
    error_message: str | None = None
    onchain_signature: str | None = None


@dataclass(frozen=True, slots=True)
class DepositVaultStatusMessage:
    message_type: Literal["DepositVaultStatus", "DepositVault"]
    client_instruction_id: int
    source_subaccount_id: int
    operation_subaccount_id: int
    operation_subaccount_pubkey: str
    vault_account_pubkey: str
    participant_account_pubkey: str
    deposit_amount: int
    insurance_payback: int
    actual_deposit: int
    minted_vault_shares: int
    previous_total_vault_shares: int
    total_vault_shares: int
    status: int
    error_code: int
    batch_id: int | None = None
    error_domain: str | None = None
    error: str | None = None
    error_message: str | None = None
    onchain_signature: str | None = None


@dataclass(frozen=True, slots=True)
class VaultOperationStatusMessage:
    message_type: Literal["VaultOperationSubaccountCollateralChange", "WithdrawVaultStatus", "WithdrawVault"]
    client_instruction_id: int
    subaccount_id: int
    source_subaccount_id: int
    destination_subaccount_id: int
    operation_subaccount_id: int
    operation_subaccount_pubkey: str
    vault_account_pubkey: str
    participant_account_pubkey: str
    deposit_amount: int
    minted_vault_shares: int
    requested_vault_shares: int
    actual_withdraw_amount: int
    leader_fee_amount: int
    previous_total_vault_shares: int
    total_vault_shares: int
    status: int
    error_code: int
    batch_id: int | None = None
    term: int | None = None
    error_domain: str | None = None
    error: str | None = None
    error_message: str | None = None
    onchain_signature: str | None = None


@dataclass(frozen=True, slots=True)
class TransferSubaccountStatusMessage:
    client_instruction_id: int
    source_subaccount_id: int
    target_subaccount_id: int
    transfer_amount: int
    insurance_payback: int
    status: int
    error_code: int
    batch_id: int | None = None
    error_domain: str | None = None
    error: str | None = None
    error_message: str | None = None
    onchain_signature: str | None = None


@dataclass(frozen=True, slots=True)
class BookLevelMessage:
    price: int
    qty: int
    order_count: int = 0


@dataclass(frozen=True, slots=True)
class BookSnapshotMessage:
    seq: int
    book_type: BookType
    feed_id: int
    symbol: str
    book_cursor: int
    batch_id: int
    term: int
    matcher_unix_ns: int
    depth_cap: int
    mark_price: int
    bids: tuple[BookLevelMessage, ...]
    asks: tuple[BookLevelMessage, ...]
    gateway_send_unix_ns: int


@dataclass(frozen=True, slots=True)
class BookDeltaMessage:
    seq: int
    book_type: BookType
    feed_id: int
    symbol: str
    prev_book_cursor: int
    book_cursor: int
    batch_id: int
    term: int
    matcher_unix_ns: int
    depth_cap: int
    mark_price: int
    bids: tuple[BookLevelMessage, ...]
    asks: tuple[BookLevelMessage, ...]
    gateway_send_unix_ns: int


@dataclass(frozen=True, slots=True)
class StreamResetMessage:
    book_type: BookType
    feed_id: int


@dataclass(frozen=True, slots=True)
class TradeMessage:
    seq: int
    trade_id: int
    price: int
    qty: int
    symbol_id: int
    symbol: str
    side: str


@dataclass(frozen=True, slots=True)
class AccountPositionMessage:
    symbol: int
    net_qty: int
    cost_basis: int
    realized_pnl: int = 0


@dataclass(frozen=True, slots=True)
class AccountWorkingOrderMessage:
    external_order_id: int
    client_instruction_id: int
    original_iat: int
    symbol: int
    side: str
    role: str
    tif: str
    order_type: int
    price: int
    original_qty: int
    remaining_qty: int
    delta_ppm: int
    execution_mode: int = 0


@dataclass(frozen=True, slots=True)
class AccountConditionalGroupMessage:
    group_external_order_id: int
    client_instruction_id: int
    symbol: int
    qty: int
    side: str
    state: str
    activation_mode: str
    leg_flags: int
    tp_trigger_price: int
    sl_trigger_price: int
    take_profit_external_order_id: int = 0
    stop_loss_external_order_id: int = 0
    pending_leg: int = 0


@dataclass(frozen=True, slots=True)
class AccountFilledOrderMessage:
    external_order_id: int
    client_instruction_id: int
    symbol: int
    side: str
    last_price: int
    filled_qty: int
    pending_settlement_qty: int
    settled_qty: int
    busted_qty: int


@dataclass(frozen=True, slots=True)
class AccountSubaccountMessage:
    subaccount_id: int
    collateral_balance: int
    accrued_fee: int
    accrued_funding: int
    status: str
    owe_to_insurance: int
    positions: tuple[AccountPositionMessage, ...]
    working_orders: tuple[AccountWorkingOrderMessage, ...]
    filled_orders: tuple[AccountFilledOrderMessage, ...]
    conditional_groups: tuple[AccountConditionalGroupMessage, ...] = ()


@dataclass(frozen=True, slots=True)
class AccountVaultAccountMessage:
    vault_account_pubkey: str
    vault_id: int
    operation_subaccount_id: int
    leader_source_subaccount_id: int
    collateral_amount: int
    total_vault_shares: int
    last_seq: int


@dataclass(frozen=True, slots=True)
class AccountSnapshotMessage:
    last_seq: int
    subaccounts: tuple[AccountSubaccountMessage, ...]
    vault_accounts: tuple[AccountVaultAccountMessage, ...] = ()


@dataclass(frozen=True, slots=True)
class ConditionalGroupMessage:
    message_type: Literal[
        "ConditionalApproved", "ConditionalTriggered", "ConditionalExpired",
        "ConditionalCancelled", "ConditionalInvalidated", "ConditionalCompleted",
    ]
    seq: int
    subaccount_id: int
    group_external_order_id: int
    client_instruction_id: int = 0
    symbol: int = 0
    qty: int = 0
    side: str = ""
    state: str = ""
    activation_mode: str = ""
    leg_flags: int = 0
    tp_trigger_price: int = 0
    sl_trigger_price: int = 0
    take_profit_external_order_id: int = 0
    stop_loss_external_order_id: int = 0
    selected_external_order_id: int = 0
    selected_leg: int = 0


@dataclass(frozen=True, slots=True)
class AccountSnapshotErrorMessage:
    wallet_pubkey: str
    message: str


@dataclass(frozen=True, slots=True)
class OrderAcceptedMessage:
    seq: int
    subaccount_id: int
    external_order_id: int
    client_instruction_id: int
    symbol: int
    side: str
    role: str
    tif: str
    order_type: int
    price: int
    qty: int
    delta_ppm: int
    execution_mode: int = 0
    matcher_unix_ns: int | None = None
    sequencer_recv_unix_ns: int | None = None
    original_iat: int = 0


@dataclass(frozen=True, slots=True)
class OrderRejectMessage:
    seq: int
    subaccount_id: int
    external_order_id: int
    client_instruction_id: int
    reason: int
    symbol: int
    side: str
    role: str
    tif: str
    order_type: int
    price: int
    qty: int
    delta_ppm: int
    matcher_unix_ns: int | None = None
    sequencer_recv_unix_ns: int | None = None


@dataclass(frozen=True, slots=True)
class LocalOrderRejectMessage:
    reason: str
    client_instruction_id: int | None = None
    external_order_id: int | None = None
    gateway_send_unix_ns: int | None = None


@dataclass(frozen=True, slots=True)
class FillMessage:
    seq: int
    subaccount_id: int
    external_order_id: int
    client_instruction_id: int
    trade_id: int
    symbol: int
    side: str
    role: str
    price: int
    qty: int
    remaining_qty: int | None = None
    fee: int | None = None
    execution_mode: int | None = None
    matcher_unix_ns: int | None = None
    sequencer_recv_unix_ns: int | None = None
    gateway_send_unix_ns: int | None = None
    reason: int = 0
    request_seq: int = 0
    operation_nonce: int = 0
    batch_id: int = 0
    allocated_loss: int = 0
    onchain_signature: str | None = None
    counterparty_wallet: tuple[int, int, int, int] | None = None


@dataclass(frozen=True, slots=True)
class FillSettlementMessage:
    message_type: Literal["FillSettled", "FillBusted"]
    seq: int
    subaccount_id: int
    external_order_id: int
    symbol: int
    side: str
    price: int
    qty: int
    fee: int | None = None
    status: int = 0
    error_code: int = 0
    error_domain: str | None = None
    error: str | None = None
    error_message: str | None = None
    onchain_signature: str | None = None
    gateway_send_unix_ns: int | None = None
    trade_id: int = 0
    settled_qty: int | None = None
    reduced_qty: int | None = None
    applied_fee: int | None = None
    adjustment_reason: str | None = None
    reduce_only_leg: bool | None = None
    limiting_leg: bool | None = None
    exhausted_leg: bool | None = None


@dataclass(frozen=True, slots=True)
class AccountFundingUpdateMessage:
    seq: int
    subaccount_id: int
    symbol: int
    market_id: int
    prev_funding_index_e8: int
    last_funding_index_e8: int
    funding_delta: int
    funding_accrued: int


@dataclass(frozen=True, slots=True)
class UserCollateralUpdateMessage:
    seq: int
    subaccount_id: int
    collateral_delta: int
    collateral_balance: int
    actual_deposit: int
    total_deposit: int
    insurance_payback: int
    fee: int


@dataclass(frozen=True, slots=True)
class InactivePositionSettlementStatusMessage:
    seq: int
    subaccount_id: int
    symbol: int
    market_id: int
    position_index: int
    position_qty: int
    workflow_change_count: int
    status: int
    error_code: int
    audit_event_present: bool
    collateral_balance: int | None = None
    fees_accrued_after: int | None = None
    net_funding_after: int | None = None
    position_count_after: int | None = None
    account_status: str | None = None
    onchain_signature: str | None = None


@dataclass(frozen=True, slots=True)
class UserDepositAddressStatusMessage:
    seq: int
    subaccount_id: int
    gateway_recv_unix_ns: int
    client_unix_ns: int | None = None
    sequencer_recv_unix_ns: int | None = None


@dataclass(frozen=True, slots=True)
class WithdrawStatusMessage:
    seq: int
    client_instruction_id: int
    subaccount_id: int
    requested_withdraw_amount: int
    actual_withdraw_amount: int
    status: int
    error_code: int
    batch_id: int | None = None
    term: int | None = None
    onchain_signature: str | None = None
    error_domain: str | None = None
    error: str | None = None
    error_message: str | None = None
    gateway_send_unix_ns: int | None = None


@dataclass(frozen=True, slots=True)
class FundingIndexEntryMessage:
    market_id: int
    perp_price: int
    premium_e8: int
    cum_funding_index_e8: int


@dataclass(frozen=True, slots=True)
class FundingIndexMessage:
    seq: int
    entries: tuple[FundingIndexEntryMessage, ...]
    oracle_price_batch_id: int | None = None


@dataclass(frozen=True, slots=True)
class CancelAckMessage:
    seq: int
    subaccount_id: int
    external_order_id: int
    client_instruction_id: int
    reason: int = 0
    matcher_unix_ns: int | None = None
    sequencer_recv_unix_ns: int | None = None


@dataclass(frozen=True, slots=True)
class CancelRejectMessage:
    seq: int
    subaccount_id: int
    external_order_id: int
    client_instruction_id: int
    reason: int
    matcher_unix_ns: int | None = None
    sequencer_recv_unix_ns: int | None = None


@dataclass(frozen=True, slots=True)
class ModifyAckMessage:
    seq: int
    subaccount_id: int
    external_order_id: int
    client_instruction_id: int
    symbol: int
    price: int
    qty: int
    delta_ppm: int
    original_client_instruction_id: int = 0
    matcher_unix_ns: int | None = None
    sequencer_recv_unix_ns: int | None = None


@dataclass(frozen=True, slots=True)
class ModifyRejectMessage:
    seq: int
    subaccount_id: int
    external_order_id: int
    client_instruction_id: int
    reason: int
    original_client_instruction_id: int = 0
    matcher_unix_ns: int | None = None
    sequencer_recv_unix_ns: int | None = None


@dataclass(frozen=True, slots=True)
class LiquidationStatusMessage:
    message_type: Literal["LiquidationTriggered", "LiquidationCleared"]
    seq: int
    subaccount_id: int
    account_status: str
    owe_to_insurance: int = 0
    batch_id: int | None = None
    error_domain: str | None = None
    error: str | None = None
    error_message: str | None = None
    onchain_signature: str | None = None


@dataclass(frozen=True, slots=True)
class AdlStatusMessage:
    message_type: Literal["AdlSettled", "AdlFailed"]
    seq: int
    subaccount_id: int
    role: str
    client_instruction_id: int
    external_order_id: int
    request_seq: int
    operation_nonce: int
    batch_id: int
    market_id: int
    price: int
    qty: int
    allocated_loss: int
    counterparty_subaccount_id: int
    status: int
    error_code: int
    workflow_error_code: int
    cleanup_error_code: int
    failure_stage: int
    error_domain: str | None = None
    error: str | None = None
    error_message: str | None = None
    onchain_signature: str | None = None


ExchangeEnvironment: TypeAlias = Literal["unknown", "dev", "testnet", "prod"]


@dataclass(frozen=True, slots=True)
class ExchangeConfigMessage:
    message_type: Literal["ExchangeConfigSnapshot", "ExchangeConfigUpdate"]
    taker_fee_ppm: int
    maker_fee_ppm: int
    environment: ExchangeEnvironment
    min_deposit_amount_usd: int
    deposit_withdraw_fee_usd: int
    min_vault_deposit_amount_usd: int
    vault_creation_fee_usd: int
    leader_share_bps: int
    leader_fee_bps: int


@dataclass(frozen=True, slots=True)
class UnknownMessage:
    message_type: str
    payload: str


@dataclass(frozen=True, slots=True)
class SymbologySnapshotMessage:
    version: int
    markets: dict[int, MarketInfo]


@dataclass(frozen=True, slots=True)
class SymbologyMarketUpdateMessage:
    market: MarketInfo


@dataclass(frozen=True, slots=True)
class MarketUnsubscribedMessage:
    market_id: int
    reason: str


GatewayMessage: TypeAlias = (
    AckMessage
    | AuthChallengeMessage
    | AuthExpiredMessage
    | SessionPreemptedMessage
    | PongMessage
    | CreateVaultStatusMessage
    | DepositVaultStatusMessage
    | VaultOperationStatusMessage
    | TransferSubaccountStatusMessage
    | BookSnapshotMessage
    | BookDeltaMessage
    | StreamResetMessage
    | TradeMessage
    | AccountSnapshotMessage
    | ConditionalGroupMessage
    | AccountSnapshotErrorMessage
    | OrderAcceptedMessage
    | OrderRejectMessage
    | LocalOrderRejectMessage
    | FillMessage
    | FillSettlementMessage
    | AccountFundingUpdateMessage
    | UserCollateralUpdateMessage
    | InactivePositionSettlementStatusMessage
    | UserDepositAddressStatusMessage
    | WithdrawStatusMessage
    | FundingIndexMessage
    | CancelAckMessage
    | CancelRejectMessage
    | ModifyAckMessage
    | ModifyRejectMessage
    | LiquidationStatusMessage
    | AdlStatusMessage
    | ExchangeConfigMessage
    | SymbologySnapshotMessage
    | SymbologyMarketUpdateMessage
    | MarketUnsubscribedMessage
    | UnknownMessage
)
