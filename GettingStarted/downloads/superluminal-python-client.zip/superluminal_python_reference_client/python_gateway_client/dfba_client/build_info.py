from __future__ import annotations

import subprocess
from pathlib import Path

_AETHON_VERSION = "1.0.0"
_AETHON_GIT_COMMIT = "7b208c4c5d59"


def version_text(program: str) -> str:
    version, git_commit = _build_info()
    return f"{program} version {version} commit {git_commit}"


def _build_info() -> tuple[str, str]:
    if not _AETHON_VERSION.startswith("@") and not _AETHON_GIT_COMMIT.startswith("@"):
        return _AETHON_VERSION, _AETHON_GIT_COMMIT

    source_root = _find_source_root()
    if source_root is None:
        return "unknown", "unknown"

    version = (source_root / "VERSION").read_text(encoding="utf-8").strip()
    git_commit = subprocess.run(
        ["git", "rev-parse", "--short=12", "HEAD"],
        cwd=source_root,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    return version, git_commit


def _find_source_root() -> Path | None:
    candidates = (Path.cwd(), Path(__file__).resolve())
    for start in candidates:
        for candidate in (start, *start.parents):
            client_build_info = candidate / "python_gateway_client/dfba_client/build_info.py"
            if (
                (candidate / "VERSION").is_file()
                and (candidate / ".git").exists()
                and client_build_info.is_file()
            ):
                return candidate
    return None
